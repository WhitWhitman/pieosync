# MindMake startup (X3.0)

Startup now lives in one place. Read [GUARD.md](GUARD.md), then follow **Startup** in [AGENTS.md](AGENTS.md).

This file stays so older prompts like "load MindMake" still find the way in.
