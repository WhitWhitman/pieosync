# Memory pointer

The memory rules are in [Brain/MEMORY.md](Brain/MEMORY.md). Shared seeds are in [Seeds/](Seeds/README.md); each project keeps its own in its Jobs folder. This file is a pointer, not another memory store.
