# Downloads inbox

Browser downloads and other incoming files wait here until complete and classified. The watcher applies configured routes; ambiguous files stay queued for assistant review. No overwrites. See [filing rules](../Brain/FILING.md).

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

<!-- MINDMAKE FOLDER MAP END -->
