# MindMake setup (X3.0)

Setup is a short conversation, never a form. **It never blocks real work.** The X2.0 version is preserved in [Brain/governance/history/INTAKE_X2.0.md](Brain/governance/history/INTAKE_X2.0.md).

**Made for Apple computers.** Tested on a Mac; results may vary elsewhere. Windows users report it works, but X3.0's new scripts aren't tested on Windows yet. Apple Reminders needs a Mac.

## How to run it

- Ask one short question at a time. Every question can be skipped or put off.
- If the user arrives with a task, do the task first. Offer the next setup question once, at a natural pause.
- Offer setup at most once per session while it's unfinished. Don't repeat an outstanding question.
- Record only explicit answers. Silence is not an answer, and existing tools or host memory never supply one.
- Check where setup stands with `python3 -B Brain/tools/mindmake.py intake_status`.

## The questions, in order

1. **What should I call you?**
2. **Do you already have another second brain you'd like to bring into MindMake?** (Obsidian, Notion, a notes app or folders.) Yes, no or later (field `switch_from`). A yes loads [Brain/MIGRATION.md](Brain/MIGRATION.md), which runs the switch over a few days. It still never blocks the user's work.

**After question 2: the tool check** (once, skippable). Ask: **"Want me to check your computer has the tools that make MindMake work best? It takes a minute."** Then:
1. **Check, don't ask.** Run `python3 --version` (on Windows, also try `python --version`). Tell the user in one line what you found. Some AI apps run commands in their own built-in workspace that already has Python (Claude's Cowork does). If so, say so: nothing to install.
2. **Two separate needs:** MindMake itself needs **Python 3.9 or newer**. The optional personal MCP needs **3.10 or newer**. **If Python 3.9 or newer is missing,** say in one line what it unlocks: the folder checks, filing, the task list, the brain clean and cloning. Installing software needs a clear yes (GUARD section 9). On yes, give **one step at a time** and wait for "done" before the next:
   - **Mac:** go to python.org/downloads, click the yellow Download button, open the downloaded file, and click Continue, Agree and Install until it finishes. (If a box pops up offering "command line developer tools", clicking Install also works.)
   - **Windows:** the same page. On the first installer screen, tick **"Add python.exe to PATH"** before clicking Install. Say plainly that Windows users report MindMake works, but X3.0's new scripts aren't tested on Windows yet.
   - **Linux:** Python is usually there already. If not, use the system's package manager.
   Install it yourself only if the user said yes and the app lets you. Otherwise guide them. Afterwards, run the check again and run `python3 -B Brain/tools/mindmake.py boot`. Python counts as working only once boot runs.
3. **Then offer the personal MCP** (the `personal_mcp` question, [Brain/PERSONAL_MCP.md](Brain/PERSONAL_MCP.md)). First run `python3 Brain/tools/personal_mcp.py check`. Offer the install only if it says `compatible: true`. If not, say the reason in one line (for example "Your Python runs MindMake, but the MCP needs 3.10 or newer"), and offer the newer Python with the same one-step-at-a-time install, or skip the MCP. MindMake works fine without it. In plain words: it's a small local helper that lets the AI app re-read GUARD, keep a count for each chat and spot changed files, so MindMake can check itself. It helps, but it doesn't guarantee the AI follows the rules, and it does nothing while the app is closed.
4. **Without Python, MindMake still works, just more simply:** the assistant reads and writes the files, but boot, maps, the task tool, the brain clean and cloning don't run. Say that once. Never block work, never nag, and offer the check again only if the user brings it up or a task needs it.

Note what you found in the session seed (Python version and where it runs, MCP yes, no or later). It isn't a profile answer.

3. **How should I nudge you?** Offer Apple Reminders, with time zone and quiet hours. Explain plainly that nothing runs between chats without it.
4. **How should I work with you?** Level of detail, and how much to do without asking.
5. **How blunt should I be when I push back?** Gentle, direct or no-holds-barred (field `bluntness`, saved in the user profile). The strongest objection still comes first either way. This only sets the tone. Turning the critique off goes through GUARD's three-yes override, not setup.
6. **Which accounts would help?** Email, calendar, documents. Explain the benefit and read versus write access, and check what's already connected first. Follow [Brain/PERSONAL_ASSISTANT.md](Brain/PERSONAL_ASSISTANT.md). Then ask what it should handle routinely in them, such as reviewing messages or drafting replies (field `routine_actions`). Start small.
7. **What do you want help with first?** (field `current_work`) Ask this once things are set up. If the user arrives with a task, do the task first anyway; setup never blocks work. If it's a project, create its folder with `python3 Brain/tools/mindmake.py new_job --name "<Project Name>"`. Offer the two-minute [First Win](Brain/FIRST_WIN.md) walkthrough.
8. **Optional extras, only if the user is interested:** SMS or a companion style. (The personal MCP is offered in the tool check above.) No persona is adopted unless the user picks one.

## Saving answers

- Record an answer: `python3 Brain/tools/mindmake.py record_intake --field <field> --answer '<answer>'`. Boot's `intake.next_question` names the field.
- Record a skip: the same command with `--skip`.
- Put setup on hold: `python3 Brain/tools/mindmake.py defer_intake --reason "<what the user said>"`. Resume with `resume_intake`, or when the user answers a question.
- Update the matching profile (via `Brain/Profiles/profiles.json`) and the maps after each answer.

## Checking it works

Follow [Brain/FIRST_WIN.md](Brain/FIRST_WIN.md) and [the acceptance checklist](Brain/governance/FIRST_RUN_ACCEPTANCE.md). Report each check separately: files written, a seed saved and found again, and the next session resuming the right step. A same-session readback is not a fresh-session test.

## New or changed helpers

When a helper source is imported or changed, record its review with `python3 Brain/tools/mindmake.py record_review --job 'Jobs/<Job>' --evidence '<review file>' --fingerprint '<from boot>'`, then update the maps. Use `--job '_shared'` for the shared rules and tools. Reviews start pending on purpose: a review records that an assistant actually read that helper, so it can't be filled in ahead of time. Pending reviews never block work. A review record is an assistant's documented reading, not proof of behavior.
