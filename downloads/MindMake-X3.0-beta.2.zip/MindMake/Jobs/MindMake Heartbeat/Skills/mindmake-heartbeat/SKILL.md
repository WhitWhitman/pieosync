---
name: mindmake-heartbeat
description: "Checks that an AI assistant's setup actually loaded (governing instructions, profiles, memory, task list, other helpers) and restores it after the conversation is compressed or reset. Reports only what it can confirm, in one short status. Use at session start, after a long conversation is summarized, or when someone says Heartbeat status, run verification, reload or run recovery."
---

# MindMake Heartbeat

Use this wrapper during MindMake startup (this is a core helper), when the user names MindMake Heartbeat, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/HEARTBEAT_v0.1.1.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
