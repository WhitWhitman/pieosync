# MindMake Guide

Purpose: The quick start and user manual in one: what MindMake is, the two ways to use it, the helpers, the folder, memory, safety and troubleshooting.
Type: reference, version 0.4.

## Source and routing

- [PPI source](<Products/MINDMAKE_X2_GUIDE_v0.4.md>): the selected source, with the full instructions, hard lines, safety floor and knowledge.
- [PDF](<Products/MINDMAKE_X2_GUIDE_v0.4.pdf>): the same content, for people to read.
- [Skill wrapper](<Skills/mindmake-guide/SKILL.md>)
- [Source contract](<LGI_ENGINE_CONTRACT.md>)
- [Seed policy](<Seeds/README.md>)

## Use

Read the PPI source before precision work, and apply only what the user has authorized. A file being present doesn't activate the helper. [GUARD.md](<../../GUARD.md>) comes first. The PPI's own hard lines and safety floor apply whenever it is in use.

Follow the workspace [AGENTS.md](<../../AGENTS.md>), the [intake checkpoint](<../../INTAKE.md>) during unfinished setup, the map completion rule after changes, and `Brain/tools/SEED_MEMORY_PROTOCOL.md` for memory. Save this job's continuity in its own `Seeds/`.

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

- [Workspace folder map](<../../FOLDER_MAP.md>)

- [LGI_ENGINE_CONTRACT.md](<LGI_ENGINE_CONTRACT.md>)
- [Products](<Products>)
- [Products/MINDMAKE_X2_GUIDE_v0.4.md](<Products/MINDMAKE_X2_GUIDE_v0.4.md>)
- [Products/MINDMAKE_X2_GUIDE_v0.4.pdf](<Products/MINDMAKE_X2_GUIDE_v0.4.pdf>)
- [Research](<Research>)
- [Seeds](<Seeds>)
- [Seeds/Long-term](<Seeds/Long-term>)
- [Seeds/README.md](<Seeds/README.md>)
- [Seeds/Short-term](<Seeds/Short-term>)
- [Skills](<Skills>)
- [Skills/mindmake-guide](<Skills/mindmake-guide>)
- [Skills/mindmake-guide/SKILL.md](<Skills/mindmake-guide/SKILL.md>)

<!-- MINDMAKE FOLDER MAP END -->
