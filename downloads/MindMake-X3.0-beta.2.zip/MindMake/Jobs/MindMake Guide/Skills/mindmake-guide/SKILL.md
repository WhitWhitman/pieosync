---
name: mindmake-guide
description: "The quick start and user manual in one: what MindMake is, the two ways to use it, the helpers, the folder, memory, safety and troubleshooting."
---

# MindMake Guide

Use this wrapper during MindMake startup, when the user names MindMake Guide, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/MINDMAKE_X2_GUIDE_v0.4.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
