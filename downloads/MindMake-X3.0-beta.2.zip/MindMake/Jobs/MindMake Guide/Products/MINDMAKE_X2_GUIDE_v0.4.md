---
title: "MindMake X2.0 Guide"
subtitle: "Quick-start guide"
---

# What is MindMake?

MindMake is a second brain that helps keep everything organized. It gives your AI one place to find your projects, files, and past decisions.

# Get started

Give your AI access to the MindMake Brain folder. In each connected thread or project, say “Load GUARD.md” to pick up the relevant context.

# Find your stuff

Ask your AI to find something by name, topic, or project. The folder map shows where things live.

- **Jobs:** Projects and their files.
- **Seeds:** Past decisions and notes for later.
- **Wiki:** References and saved knowledge.
- **Downloads:** Incoming files to sort.
- **Brain:** Profiles, settings, and workspace tools.

# Downloads

Set your browser to save files to MindMake Brain/Downloads if you want everything arriving in one place. With your AI connected, say “Check downloads” to sort what’s there. Automatic filing needs the optional watcher running.

# Optional: MCP

A personal MCP connection can help a compatible AI check the workspace and keep track of its sessions. Ask your AI if you want setup help or more detail about how MindMake works.

# If MindMake doesn’t load

Check that your AI has access to MindMake Brain, then say “Load GUARD.md” again.
