---
name: mindmake-seed-capsule
description: "Adds a short capsule (assertion, proof, uncertainty, plus optional meaning and next move) to the top of important memory seeds, so a future assistant can orient fast and then check the real proof. Also audits whether an existing header still matches its seed. Use when writing handoff, decision or blocker seeds, or when someone says apply Seed Capsule or is this capsule valid."
---

# MindMake Seed Capsule

Use this wrapper during MindMake startup, when the user names MindMake Seed Capsule, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/SEED_CAPSULE_v0.2.1.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
