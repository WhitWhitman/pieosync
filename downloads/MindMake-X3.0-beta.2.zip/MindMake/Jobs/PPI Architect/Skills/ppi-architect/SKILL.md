---
name: ppi-architect
description: "Turns a person's own knowledge into a PPI (Portable Plug-in): a helper another AI can run without guessing. Interviews the user one question at a time, then drafts instructions, source list and tests. Use when someone wants to build an AI helper from their expertise, notes or documents."
---

# PPI Architect

Use this wrapper during MindMake startup, when the user names PPI Architect, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/PPI_ARCHITECT_v0.2.3.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
