---
name: ppi-test
description: "Checks whether a PPI helper is complete and behaves as its own tests say, before anyone relies on it. Reports failures with quoted evidence and proposes fixes only when asked. Use after building or revising a PPI, or when someone asks to test, check or break an AI helper."
---

# PPI Test

Use this wrapper during MindMake startup, when the user names PPI Test, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/PPI_TEST_v0.2.1.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
