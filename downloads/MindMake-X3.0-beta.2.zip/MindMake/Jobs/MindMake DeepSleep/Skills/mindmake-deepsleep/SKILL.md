---
name: mindmake-deepsleep
description: "Keeps an AI workspace tidy and findable at the start of a session. Counts memory seed folders and moves the oldest to the archive past a cap, checks that profiles, the to-do list and folders exist, keeps a folder map up to date, flags unmapped files, and reports exactly what it checked. Never deletes without permission. Use at session start or when someone says run DeepSleep, check the folder map or rebuild the folder map."
---

# MindMake DeepSleep

Use this wrapper during MindMake startup (this is a core helper), when the user names MindMake DeepSleep, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/DEEPSLEEP_v0.1.3.md>), before applying it. This wrapper doesn't contain the instructions.

In MindMake X3.0, boot runs the daily brain clean itself, once a day. JOB.md explains the script and the shared "last run" log.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
