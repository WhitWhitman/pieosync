# MindMake DeepSleep

Purpose: Keeps an AI workspace tidy and findable at the start of a session.
Type: helper (PPI), version 0.1.3.

## Source and routing

- [PPI source](<Products/DEEPSLEEP_v0.1.3.md>): the selected source, with the full instructions, hard lines, safety floor and knowledge.
- [PDF](<Products/DEEPSLEEP_v0.1.3.pdf>): the same content, for people to read.
- [Tests](<Products/TESTS_DEEPSLEEP_v0.1.3.md>): what it was tested against. Results: [review record](<../../Brain/governance/setup-reviews/mindmake-deepsleep.md>).
- [Skill wrapper](<Skills/mindmake-deepsleep/SKILL.md>)
- [Source contract](<LGI_ENGINE_CONTRACT.md>)
- [Seed policy](<Seeds/README.md>)

## In MindMake X3.0

DeepSleep's daily job now runs as a script, so no chat has to remember it:
- **Daily brain clean.** At the first chat of each day, boot runs [mindmake_clean.py](<../../Brain/tools/mindmake_clean.py>). It's read-only and reports missing files, duplicates, broken links, broken Markdown, empty files and orphaned seeds. Later chats that day skip it.
- **One shared "last run" log** for all regular routines: [mindmake_routines.py](<../../Brain/tools/mindmake_routines.py>), kept in `Brain/.mindmake/work-records/last-run.json`.
- **Seed rollover** still runs in boot at 500 seeds. **Folder maps** use `update_map` and `check_map` (AGENTS.md, Quiet housekeeping).

Read the full PPI source below for a deep folder-health check ("run DeepSleep"), or when using DeepSleep on its own outside MindMake. The standalone PDF and source are unchanged.

## Use

It loads on demand in X3.0, no longer at every "load up" (see [AGENTS.md](<../../AGENTS.md>), Helpers).

Read the PPI source before precision work, and apply only what the user has authorized. A file being present doesn't activate the helper. [GUARD.md](<../../GUARD.md>) comes first. The PPI's own hard lines and safety floor apply whenever it is in use.

Follow the workspace [AGENTS.md](<../../AGENTS.md>), the [intake checkpoint](<../../INTAKE.md>) during unfinished setup, the map completion rule after changes, and `Brain/tools/SEED_MEMORY_PROTOCOL.md` for memory. Save this job's continuity in its own `Seeds/`.

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

- [Workspace folder map](<../../FOLDER_MAP.md>)

- [LGI_ENGINE_CONTRACT.md](<LGI_ENGINE_CONTRACT.md>)
- [Products](<Products>)
- [Products/DEEPSLEEP_v0.1.3.md](<Products/DEEPSLEEP_v0.1.3.md>)
- [Products/DEEPSLEEP_v0.1.3.pdf](<Products/DEEPSLEEP_v0.1.3.pdf>)
- [Products/TESTS_DEEPSLEEP_v0.1.3.md](<Products/TESTS_DEEPSLEEP_v0.1.3.md>)
- [Research](<Research>)
- [Seeds](<Seeds>)
- [Seeds/Long-term](<Seeds/Long-term>)
- [Seeds/README.md](<Seeds/README.md>)
- [Seeds/Short-term](<Seeds/Short-term>)
- [Skills](<Skills>)
- [Skills/mindmake-deepsleep](<Skills/mindmake-deepsleep>)
- [Skills/mindmake-deepsleep/SKILL.md](<Skills/mindmake-deepsleep/SKILL.md>)

<!-- MINDMAKE FOLDER MAP END -->
