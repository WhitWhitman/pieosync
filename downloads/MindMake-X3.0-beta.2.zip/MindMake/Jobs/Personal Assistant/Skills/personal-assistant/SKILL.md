---
name: personal-assistant
description: "A goal-focused personal assistant that keeps you moving on what matters: it remembers the current direction, turns unfinished work into one next action, follows up on commitments from sources you approve, and sets reminders you control, while being honest about what is actually connected, scheduled or sent. Use when someone says load Personal Assistant, help me finish this, what's next, or remind me."
---

# Personal Assistant

Use this wrapper during MindMake startup, when the user names Personal Assistant, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/PERSONAL_ASSISTANT_v0.1.1.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
