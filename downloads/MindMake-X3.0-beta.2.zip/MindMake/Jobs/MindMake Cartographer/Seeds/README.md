# MindMake Cartographer seeds

Job-specific continuity for MindMake Cartographer. Save new records in [Short-term](Short-term/); [Long-term](Long-term/) holds archives and rollover summaries. Use the X2.0 capsule: front matter with `assertion`, `proof` and `uncertainty` (required), and `meaning` and `next` (optional). Never create filler seeds. Shared continuity belongs in the workspace [Seeds](<../../../Seeds/README.md>).
