---
name: mindmake-cartographer
description: "A reasoning lens that makes an AI assistant's answers tighter, grounded and honest. It checks each answer for focus, evidence, real work and clear order, keeps track of how it knows each claim, surfaces contradictions instead of hiding them, and holds an ethics floor against dependence. Also writes and reads continuity seeds. Use for analysis, research, decisions and long working sessions, or when someone says load Cartographer, stress test this or seed this thread."
---

# MindMake Cartographer

Use this wrapper during MindMake startup (this is a core helper), when the user names MindMake Cartographer, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/CARTOGRAPHER_v0.1.2.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
