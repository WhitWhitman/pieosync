---
name: mindmake-taskcycle
description: "Works through the user's to-do list on its own, within limits. Scores each task on purpose, information, real output and a clear path, does the ones that clear the bar, holds the rest with one specific question, never takes destructive or outside actions without permission, and ends with a plain report and an audit trail. Use when someone says load TaskCycle, work the list, run TaskCycle on schedule or TaskCycle report."
---

# MindMake TaskCycle

Use this wrapper during MindMake startup (this is a core helper), when the user names MindMake TaskCycle, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/TASKCYCLE_v0.1.3.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
