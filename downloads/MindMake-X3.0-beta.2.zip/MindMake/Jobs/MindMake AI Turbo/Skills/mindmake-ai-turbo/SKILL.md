---
name: mindmake-ai-turbo
description: "Keeps every answer as short and direct as the task allows, stated with exactly the confidence the evidence supports, and still aimed at the question the user actually asked. Removes padding, needless hedging and agreeable drift. Use alongside any other work, or when someone says tighten up, too verbose, stop hedging or check yourself."
---

# MindMake AI Turbo

Use this wrapper during MindMake startup (this is a core helper), when the user names MindMake AI Turbo, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/AI_TURBO_v0.1.2.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
