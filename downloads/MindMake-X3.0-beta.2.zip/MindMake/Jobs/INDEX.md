# MindMake jobs

This folder holds the installed MindMake helpers, the PPI Toolbox, the Guide, and any project sandboxes you create.

## Creating a project
```sh
python3 Brain/tools/mindmake.py new_job --name "Project Name"
```
Or ask your assistant: *"Create a new project for [topic]"*.

## Installed

- [MindMake DeepSleep](<MindMake DeepSleep/JOB.md>): Keeps an AI workspace tidy and findable at the start of a session.
- [MindMake Cartographer](<MindMake Cartographer/JOB.md>): A reasoning lens that makes an AI assistant's answers tighter, grounded and honest.
- [MindMake SignalGuard](<MindMake SignalGuard/JOB.md>): Keeps an AI assistant honest about how it knows what it says.
- [MindMake ThoughtVault](<MindMake ThoughtVault/JOB.md>): Gives an AI assistant a memory and a to-do list that last between conversations.
- [MindMake DreamWeaver](<MindMake DreamWeaver/JOB.md>): Reads a handful of random memory seeds and "dreams" over them, finding patterns, contradictions and conspicuous gaps nobody asked about, then compresses the result into one short, clearly labeled dream seed.
- [MindMake Seed Protocol](<MindMake Seed Protocol/JOB.md>): Keeps an AI assistant's long-term memory small, honest and findable.
- [MindMake AI Turbo](<MindMake AI Turbo/JOB.md>): Keeps every answer as short and direct as the task allows, stated with exactly the confidence the evidence supports, and still aimed at the question the user actually asked.
- [MindMake Heartbeat](<MindMake Heartbeat/JOB.md>): Checks that an AI assistant's setup actually loaded (governing instructions, profiles, memory, task list, other helpers) and restores it after the conversation is compressed or reset.
- [MindMake SkillMaster](<MindMake SkillMaster/JOB.md>): Helps an AI assistant pick the right skill, tool or connection for the task, and be honest about what actually works.
- [MindMake TaskCycle](<MindMake TaskCycle/JOB.md>): Works through the user's to-do list on its own, within limits.
- [MindMake Seed Capsule](<MindMake Seed Capsule/JOB.md>): Adds a short capsule (assertion, proof, uncertainty, plus optional meaning and next move) to the top of important memory seeds, so a future assistant can orient fast and then check the real proof.
- [Personal Assistant](<Personal Assistant/JOB.md>): A goal-focused personal assistant that keeps you moving on what matters: it remembers the current direction, turns unfinished work into one next action, follows up on commitments from sources you approve, and sets reminders you control, while being honest about what is actually connected, scheduled or sent.
- [Personal MCP Builder](<Personal MCP Builder/JOB.md>): Explains why an AI assistant sometimes needs a small local tool server (MCP), and helps a person design, build, connect and verify one safely, with the smallest possible set of tools.
- [Your AI Companion](<Your AI Companion/JOB.md>): Gives an AI assistant a steady, honest working personality, Pete or Jess, the user's choice.
- [PPI Architect](<PPI Architect/JOB.md>): Turns a person's own knowledge into a PPI (Portable Plug-in): a helper another AI can run without guessing.
- [PPI Export](<PPI Export/JOB.md>): Packages a tested PPI helper as a readable document and an optional Agent Plugins folder, checks the files are well formed, and states plainly where they will and won't work.
- [PPI Revise](<PPI Revise/JOB.md>): Applies only the changes a PPI owner approved, keeps everything else word for word, and records every change so versions can be trusted or rolled back.
- [PPI Test](<PPI Test/JOB.md>): Checks whether a PPI helper is complete and behaves as its own tests say, before anyone relies on it.
- [MindMake Guide](<MindMake Guide/JOB.md>): The quick start and user manual in one: what MindMake is, the two ways to use it, the helpers, the folder, memory, safety and troubleshooting.

---

[Workspace folder map](../FOLDER_MAP.md)

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

- [MindMake AI Turbo](<MindMake AI Turbo/JOB.md>)
- [MindMake Cartographer](<MindMake Cartographer/JOB.md>)
- [MindMake DeepSleep](<MindMake DeepSleep/JOB.md>)
- [MindMake DreamWeaver](<MindMake DreamWeaver/JOB.md>)
- [MindMake Guide](<MindMake Guide/JOB.md>)
- [MindMake Heartbeat](<MindMake Heartbeat/JOB.md>)
- [MindMake Seed Capsule](<MindMake Seed Capsule/JOB.md>)
- [MindMake Seed Protocol](<MindMake Seed Protocol/JOB.md>)
- [MindMake SignalGuard](<MindMake SignalGuard/JOB.md>)
- [MindMake SkillMaster](<MindMake SkillMaster/JOB.md>)
- [MindMake TaskCycle](<MindMake TaskCycle/JOB.md>)
- [MindMake ThoughtVault](<MindMake ThoughtVault/JOB.md>)
- [PPI Architect](<PPI Architect/JOB.md>)
- [PPI Export](<PPI Export/JOB.md>)
- [PPI Revise](<PPI Revise/JOB.md>)
- [PPI Test](<PPI Test/JOB.md>)
- [Personal Assistant](<Personal Assistant/JOB.md>)
- [Personal MCP Builder](<Personal MCP Builder/JOB.md>)
- [Your AI Companion](<Your AI Companion/JOB.md>)

<!-- MINDMAKE FOLDER MAP END -->
