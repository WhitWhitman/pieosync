---
name: mindmake-seed-protocol
description: "Keeps an AI assistant's long-term memory small, honest and findable. Turns each reference into a five-line retrieval seed, loads only the few sources a task needs, and saves a short seed whenever a decision or correction changes what happens next. Use for knowledge libraries, project memory and handoffs, or when someone says seed this, what do we know about, or save that decision."
---

# MindMake Seed Protocol

Use this wrapper during MindMake startup (this is a core helper), when the user names MindMake Seed Protocol, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/SEED_PROTOCOL_v0.1.3.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
