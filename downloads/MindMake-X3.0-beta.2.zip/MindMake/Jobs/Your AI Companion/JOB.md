# Your AI Companion

Purpose: Gives an AI assistant a steady, honest working personality, Pete or Jess, the user's choice.
Type: helper (PPI), version 0.1.2.

## Source and routing

- [PPI source](<Products/YOUR_AI_COMPANION_v0.1.2.md>): the selected source, with the full instructions, hard lines, safety floor and knowledge.
- [PDF](<Products/YOUR_AI_COMPANION_v0.1.2.pdf>): the same content, for people to read.
- [Tests](<Products/TESTS_YOUR_AI_COMPANION_v0.1.2.md>): what it was tested against. Results: [review record](<../../Brain/governance/setup-reviews/your-ai-companion.md>).
- [Skill wrapper](<Skills/your-ai-companion/SKILL.md>)
- [Source contract](<LGI_ENGINE_CONTRACT.md>)
- [Seed policy](<Seeds/README.md>)

## Use

Read the PPI source before precision work, and apply only what the user has authorized. A file being present doesn't activate the helper. [GUARD.md](<../../GUARD.md>) comes first. The PPI's own hard lines and safety floor apply whenever it is in use.

Follow the workspace [AGENTS.md](<../../AGENTS.md>), the [intake checkpoint](<../../INTAKE.md>) during unfinished setup, the map completion rule after changes, and `Brain/tools/SEED_MEMORY_PROTOCOL.md` for memory. Save this job's continuity in its own `Seeds/`.

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

- [Workspace folder map](<../../FOLDER_MAP.md>)

- [LGI_ENGINE_CONTRACT.md](<LGI_ENGINE_CONTRACT.md>)
- [Products](<Products>)
- [Products/TESTS_YOUR_AI_COMPANION_v0.1.2.md](<Products/TESTS_YOUR_AI_COMPANION_v0.1.2.md>)
- [Products/YOUR_AI_COMPANION_v0.1.2.md](<Products/YOUR_AI_COMPANION_v0.1.2.md>)
- [Products/YOUR_AI_COMPANION_v0.1.2.pdf](<Products/YOUR_AI_COMPANION_v0.1.2.pdf>)
- [Research](<Research>)
- [Seeds](<Seeds>)
- [Seeds/Long-term](<Seeds/Long-term>)
- [Seeds/README.md](<Seeds/README.md>)
- [Seeds/Short-term](<Seeds/Short-term>)
- [Skills](<Skills>)
- [Skills/your-ai-companion](<Skills/your-ai-companion>)
- [Skills/your-ai-companion/SKILL.md](<Skills/your-ai-companion/SKILL.md>)

<!-- MINDMAKE FOLDER MAP END -->
