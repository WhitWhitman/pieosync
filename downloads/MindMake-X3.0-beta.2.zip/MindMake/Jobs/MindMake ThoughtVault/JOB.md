# MindMake ThoughtVault

Purpose: Gives an AI assistant a memory and a to-do list that last between conversations.
Type: helper (PPI), version 0.1.3.

## Source and routing

- [PPI source](<Products/THOUGHTVAULT_v0.1.3.md>): the selected source, with the full instructions, hard lines, safety floor and knowledge.
- [PDF](<Products/THOUGHTVAULT_v0.1.3.pdf>): the same content, for people to read.
- [Tests](<Products/TESTS_THOUGHTVAULT_v0.1.3.md>): what it was tested against. Results: [review record](<../../Brain/governance/setup-reviews/mindmake-thoughtvault.md>).
- [Skill wrapper](<Skills/mindmake-thoughtvault/SKILL.md>)
- [Source contract](<LGI_ENGINE_CONTRACT.md>)
- [Seed policy](<Seeds/README.md>)

## Use

It is one of the ten core helpers loaded on "load up" (see [MINDMAKE.md](<../../MINDMAKE.md>)).

Read the PPI source before precision work, and apply only what the user has authorized. A file being present doesn't activate the helper. [GUARD.md](<../../GUARD.md>) comes first. The PPI's own hard lines and safety floor apply whenever it is in use.

Follow the workspace [AGENTS.md](<../../AGENTS.md>), the [intake checkpoint](<../../INTAKE.md>) during unfinished setup, the map completion rule after changes, and `Brain/tools/SEED_MEMORY_PROTOCOL.md` for memory. Save this job's continuity in its own `Seeds/`.

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

- [Workspace folder map](<../../FOLDER_MAP.md>)

- [LGI_ENGINE_CONTRACT.md](<LGI_ENGINE_CONTRACT.md>)
- [Products](<Products>)
- [Products/TESTS_THOUGHTVAULT_v0.1.3.md](<Products/TESTS_THOUGHTVAULT_v0.1.3.md>)
- [Products/THOUGHTVAULT_v0.1.3.md](<Products/THOUGHTVAULT_v0.1.3.md>)
- [Products/THOUGHTVAULT_v0.1.3.pdf](<Products/THOUGHTVAULT_v0.1.3.pdf>)
- [Research](<Research>)
- [Seeds](<Seeds>)
- [Seeds/Long-term](<Seeds/Long-term>)
- [Seeds/README.md](<Seeds/README.md>)
- [Seeds/Short-term](<Seeds/Short-term>)
- [Skills](<Skills>)
- [Skills/mindmake-thoughtvault](<Skills/mindmake-thoughtvault>)
- [Skills/mindmake-thoughtvault/SKILL.md](<Skills/mindmake-thoughtvault/SKILL.md>)

<!-- MINDMAKE FOLDER MAP END -->
