---
name: mindmake-thoughtvault
description: "Gives an AI assistant a memory and a to-do list that last between conversations. Saves short dated memory seeds when something changes, finds them again without inventing anything, keeps a NOW / NEXT / LATER list the user controls, and can build the memory folders when file access exists. Use for long projects, personal knowledge and task tracking, or when someone says remember this, what's on my list, finish up the list or load my memory."
---

# MindMake ThoughtVault

Use this wrapper during MindMake startup (this is a core helper), when the user names MindMake ThoughtVault, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/THOUGHTVAULT_v0.1.3.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
