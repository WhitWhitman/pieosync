# PPI Export

Purpose: Packages a tested PPI helper as a readable document and an optional Agent Plugins folder, checks the files are well formed, and states plainly where they will and won't work.
Type: tool (PPI Toolbox), version 0.2.2.

## Source and routing

- [PPI source](<Products/PPI_EXPORT_v0.2.2.md>): the selected source, with the full instructions, hard lines, safety floor and knowledge.
- [PDF](<Products/PPI_EXPORT_v0.2.2.pdf>): the same content, for people to read.
- [Tests](<Products/TESTS_PPI_EXPORT_v0.2.2.md>): what it was tested against. Results: [review record](<../../Brain/governance/setup-reviews/ppi-export.md>).
- [Skill wrapper](<Skills/ppi-export/SKILL.md>)
- [Source contract](<LGI_ENGINE_CONTRACT.md>)
- [Seed policy](<Seeds/README.md>)

## Use

Read the PPI source before precision work, and apply only what the user has authorized. A file being present doesn't activate the helper. [GUARD.md](<../../GUARD.md>) comes first. The PPI's own hard lines and safety floor apply whenever it is in use.

Follow the workspace [AGENTS.md](<../../AGENTS.md>), the [intake checkpoint](<../../INTAKE.md>) during unfinished setup, the map completion rule after changes, and `Brain/tools/SEED_MEMORY_PROTOCOL.md` for memory. Save this job's continuity in its own `Seeds/`.

## Export script

`tools/ppi_export.py` builds the readable file, tests, plugin folder and ZIP from a folder of PPIs: `python3 tools/ppi_export.py SOURCE_DIR OUT_DIR --bundle NAME [--pdf]`. It needs Python 3; `--pdf` also needs pandoc with xelatex. It refuses to overwrite an existing output folder.

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

- [Workspace folder map](<../../FOLDER_MAP.md>)

- [LGI_ENGINE_CONTRACT.md](<LGI_ENGINE_CONTRACT.md>)
- [Products](<Products>)
- [Products/PPI_EXPORT_v0.2.2.md](<Products/PPI_EXPORT_v0.2.2.md>)
- [Products/PPI_EXPORT_v0.2.2.pdf](<Products/PPI_EXPORT_v0.2.2.pdf>)
- [Products/TESTS_PPI_EXPORT_v0.2.2.md](<Products/TESTS_PPI_EXPORT_v0.2.2.md>)
- [Research](<Research>)
- [Seeds](<Seeds>)
- [Seeds/Long-term](<Seeds/Long-term>)
- [Seeds/README.md](<Seeds/README.md>)
- [Seeds/Short-term](<Seeds/Short-term>)
- [Skills](<Skills>)
- [Skills/ppi-export](<Skills/ppi-export>)
- [Skills/ppi-export/SKILL.md](<Skills/ppi-export/SKILL.md>)
- [tools](<tools>)
- [tools/ppi_export.py](<tools/ppi_export.py>)
- [tools/std_tail.md](<tools/std_tail.md>)

<!-- MINDMAKE FOLDER MAP END -->
