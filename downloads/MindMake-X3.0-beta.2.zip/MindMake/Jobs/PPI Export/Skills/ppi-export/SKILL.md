---
name: ppi-export
description: "Packages a tested PPI helper as a readable document and an optional Agent Plugins folder, checks the files are well formed, and states plainly where they will and won't work. Use when a PPI has passed PPI Test and the owner wants to take it to an AI assistant."
---

# PPI Export

Use this wrapper during MindMake startup, when the user names PPI Export, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/PPI_EXPORT_v0.2.2.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
