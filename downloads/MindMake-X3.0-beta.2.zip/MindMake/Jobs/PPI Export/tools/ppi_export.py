"""PPI Export: deterministic build for one or more PPIs (spec v0.2).

Usage: python3 ppi_export.py SOURCE_DIR OUT_DIR [--bundle NAME] [--pdf] [--plugin-version X.Y.Z]
--plugin-version sets the bundle plugin's version (default: the highest PPI version in the bundle).
SOURCE_DIR holds one folder per PPI, each with ppi.md and tests/tests.md (knowledge/ optional).
No model is involved: instructions are copied, never rewritten. Refuses to overwrite OUT_DIR.
"""
import json, re, sys, shutil, pathlib, subprocess, zipfile

SCHEMA = "https://agent-plugins.org/schemas/1.0.0/plugin.schema.json"
NAME_RE = re.compile(r"^(?=.{1,64}$)[a-z0-9](?:[a-z0-9]|-(?!-))*[a-z0-9]$|^[a-z0-9]$")
HEADINGS = ["Goal", "Who it's for", "Out of scope", "Hard lines", "How to work", "Knowledge and sources",
            "Tools and permissions", "Inputs and outputs", "When something is missing",
            "Keeping this helper", "Safety floor"]
PLUGIN_KEYS = {"$schema", "name", "version", "description", "author", "homepage", "repository",
               "license", "keywords", "extensions"}

def parse(path):
    text = path.read_text()
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.S)
    if not m:
        raise SystemExit(f"{path}: no frontmatter")
    meta = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip()
    return meta, m.group(2).strip() + "\n"

def check(meta, body, where):
    errs = []
    if not NAME_RE.match(meta.get("name", "")):
        errs.append("name breaks the Agent Skills / Agent Plugins name rule")
    if not re.match(r"^\d+\.\d+\.\d+$", meta.get("version", "")):
        errs.append("version is not major.minor.patch")
    if not 1 <= len(meta.get("description", "")) <= 1024:
        errs.append("description must be 1 to 1024 characters")
    found = re.findall(r"^# (.+)$", body, re.M)
    missing = [h for h in HEADINGS if h not in found]
    if missing:
        errs.append("missing headings: " + ", ".join(missing))
    hard = re.search(r"^# Hard lines\n(.*?)^# ", body, re.S | re.M)
    if hard:
        for line in re.findall(r"^\d+\. .*$", hard.group(1), re.M):
            if not line.rstrip().endswith(")"):
                errs.append("hard line without a bracketed reason: " + line[:60])
    return [f"{where}: {e}" for e in errs]

def main():
    args = sys.argv[1:]
    if len(args) < 2:
        raise SystemExit(__doc__)
    src, out = pathlib.Path(args[0]), pathlib.Path(args[1])
    bundle = args[args.index("--bundle") + 1] if "--bundle" in args else None
    want_pdf = "--pdf" in args
    plugin_ver = args[args.index("--plugin-version") + 1] if "--plugin-version" in args else None  # 2026-10-15: product release version for bundles
    if plugin_ver and not re.match(r"^\d+\.\d+\.\d+$", plugin_ver):
        sys.exit("--plugin-version must be major.minor.patch")
    if out.exists():
        raise SystemExit(f"{out} exists; refusing to overwrite")
    ppis = sorted(p for p in src.iterdir() if (p / "ppi.md").exists())
    loaded, errs = [], []
    for p in ppis:
        meta, body = parse(p / "ppi.md")
        errs += check(meta, body, p.name)
        if meta.get("name") != p.name:
            errs.append(f"{p.name}: folder name differs from name '{meta.get('name')}'")
        if not (p / "tests" / "tests.md").exists():
            errs.append(f"{p.name}: tests/tests.md missing")
        loaded.append((p, meta, body))
    if errs:
        raise SystemExit("EXPORT BLOCKED\n- " + "\n- ".join(errs))

    (out / "readable").mkdir(parents=True)
    (out / "tests").mkdir()
    record = {"ppis": [], "checks": {}}
    for p, meta, body in loaded:
        name, ver, title = meta["name"], meta["version"], meta.get("title", meta["name"])
        stem = f"{name.upper().replace('-', '_')}_v{ver}"
        test_file = f"TESTS_{stem}.md"
        knowledge = sorted((p / "knowledge").glob("*.md")) if (p / "knowledge").exists() else []
        parts = [f"# {title} v{ver}\n",
                 f"{meta.get('description','')}\n",
                 f"Owner: {meta.get('owner','')}. License: {meta.get('license','')}. Updated: {meta.get('updated','')}.\n",
                 "## How to load it\n"
                 f"Start a new chat, upload this file (or paste its text), then say: \"Use {title}.\" "
                 "One tool per chat works best. Loading this file gives that chat instructions. It does not install software. "
                 f"After loading, run the tests in {test_file} to check it took hold.\n",
                 "## Instructions\n" + re.sub(r"^# ", "### ", body, flags=re.M)]
        if knowledge:
            parts.append("## Reference knowledge\n")
            for k in knowledge:
                parts.append(f"### {k.name}\n" + re.sub(r"^#", "####", k.read_text(), flags=re.M))
        md = out / "readable" / f"{stem}.md"
        md.write_text("\n".join(parts))
        shutil.copy(p / "tests" / "tests.md", out / "tests" / test_file)
        if want_pdf:
            pdf = md.with_suffix(".pdf")
            r = subprocess.run(["pandoc", str(md), "-o", str(pdf), "--pdf-engine=xelatex",
                                "-V", "geometry:margin=1in", "-V", "mainfont=DejaVu Sans", "-V", "fontsize=10pt"],
                               capture_output=True, text=True)
            record["checks"][f"{name} pdf rendered"] = r.returncode == 0 and pdf.exists()
            if r.returncode:
                print(r.stderr[-800:], file=sys.stderr)
        record["ppis"].append({"name": name, "version": ver, "readable": md.name, "tests": test_file})

    if bundle:
        plug = out / "agent-plugin" / bundle
        for p, meta, body in loaded:
            skill = plug / "skills" / meta["name"]
            skill.mkdir(parents=True)
            fm = (f"---\nname: {meta['name']}\ndescription: {json.dumps(meta['description'])}\n"
                  f"license: {meta.get('license','')}\nmetadata:\n  version: \"{meta['version']}\"\n---\n")
            (skill / "SKILL.md").write_text(fm + f"# {meta.get('title', meta['name'])}\n\n" + re.sub(r"^# ", "## ", body, flags=re.M))
            if (p / "knowledge").exists():
                shutil.copytree(p / "knowledge", skill / "knowledge")  # 2026-10-13: was "references"; SKILL.md text says knowledge/, and instructions are never rewritten
        vers = sorted({m["version"] for _, m, _ in loaded}, key=lambda v: tuple(int(x) for x in v.split(".")))
        pver = plugin_ver or vers[-1]
        manifest = {"$schema": SCHEMA, "name": bundle, "version": pver,
                    "description": (loaded[0][1]["description"] if len(loaded) == 1 else
                                    "Bundle of PPI helpers. Skills: " + ", ".join(m["name"] for _, m, _ in loaded) + "."),
                    "author": {"name": loaded[0][1].get("owner", "")}, "license": loaded[0][1].get("license", "")}
        (plug / "plugin.json").write_text(json.dumps(manifest, indent=2) + "\n")
        c = record["checks"]
        m2 = json.loads((plug / "plugin.json").read_text())
        c["plugin.json $schema exact"] = m2["$schema"] == SCHEMA
        c["plugin name valid"] = bool(NAME_RE.match(m2["name"]))
        c["plugin.json has only spec fields"] = set(m2) <= PLUGIN_KEYS
        for s in sorted((plug / "skills").iterdir()):
            fmname = re.search(r"^name: (.+)$", (s / "SKILL.md").read_text(), re.M).group(1)
            c[f"skill {s.name}: folder matches name"] = fmname == s.name
            c[f"skill {s.name}: under 500 lines"] = (s / "SKILL.md").read_text().count("\n") < 500
        c["no tests inside plugin"] = not any(q.name.lower().startswith("tests") for q in plug.rglob("*"))
        z = out / f"{bundle}_agent-plugin_v{pver}.zip"
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for q in sorted(plug.rglob("*")):
                if q.is_file():
                    zf.write(q, q.relative_to(plug.parent))
        record["plugin_zip"] = z.name
    (out / "EXPORT_RECORD.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))
    if not all(record["checks"].values()):
        raise SystemExit("VALIDATION FAILED")

if __name__ == "__main__":
    main()
