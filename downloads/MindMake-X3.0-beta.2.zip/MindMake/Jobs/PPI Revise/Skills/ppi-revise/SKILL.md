---
name: ppi-revise
description: "Applies only the changes a PPI owner approved, keeps everything else word for word, and records every change so versions can be trusted or rolled back. Use after a PPI Test report, when the owner edits a helper, or when new knowledge files are added."
---

# PPI Revise

Use this wrapper during MindMake startup, when the user names PPI Revise, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/PPI_REVISE_v0.2.2.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
