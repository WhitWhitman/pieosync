---
name: mindmake-signalguard
description: "Keeps an AI assistant honest about how it knows what it says. Gives each claim the right confidence, catches contradictions with earlier facts, and shows the evidence against a premise when a costly decision rides on it. Use for research, decisions and long working sessions, or when someone says audit this, what do you actually know, or epistemic check."
---

# MindMake SignalGuard

Use this wrapper during MindMake startup (this is a core helper), when the user names MindMake SignalGuard, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/SIGNALGUARD_v0.1.3.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
