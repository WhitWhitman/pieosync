---
name: mindmake-dreamweaver
description: "Reads a handful of random memory seeds and \"dreams\" over them, finding patterns, contradictions and conspicuous gaps nobody asked about, then compresses the result into one short, clearly labeled dream seed. Watches gently for unhealthy reliance. Use with a seed archive when someone says dream, run a dream cycle, or what patterns am I missing."
---

# MindMake DreamWeaver

Use this wrapper during MindMake startup (this is a core helper), when the user names MindMake DreamWeaver, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/DREAMWEAVER_v0.1.1.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
