---
name: personal-mcp-builder
description: "Explains why an AI assistant sometimes needs a small local tool server (MCP), and helps a person design, build, connect and verify one safely, with the smallest possible set of tools. Covers the design pattern (the model reports, the server remembers and counts), the common traps, and the MindMake starter server. Use when someone asks what an MCP is, why they'd want one, build me a local MCP, or why isn't my counter working."
---

# Personal MCP Builder

Use this wrapper during MindMake startup, when the user names Personal MCP Builder, or for its work. Read [JOB.md](<../../JOB.md>), then the full [PPI source](<../../Products/PERSONAL_MCP_BUILDER_v0.1.1.md>), before applying it. This wrapper doesn't contain the instructions.

"Load up" and "load MindMake" run through [MINDMAKE.md](<../../../../MINDMAKE.md>) and [INTAKE.md](<../../../../INTAKE.md>). [GUARD.md](<../../../../GUARD.md>) comes first. A recorded package review is not current-session loading.
