# Capability guide

Use this as a routing list. Read the chosen skill and source before applying it. Inspect the host's available skills, tools and accounts; packaged instructions do not install host connectors. Rebuild this guide when adding, moving or revising a helper, then update maps. [Skill wrappers](SKILLS.md) provide trigger details. [Personal assistance](PERSONAL_ASSISTANT.md) defines setup and evidence.

| Helper | What it helps with |
| --- | --- |
| [MindMake DeepSleep](<../Jobs/MindMake DeepSleep/JOB.md>) | Keeps an AI workspace tidy and findable at the start of a session. |
| [MindMake Cartographer](<../Jobs/MindMake Cartographer/JOB.md>) | A reasoning lens that makes an AI assistant's answers tighter, grounded and honest. |
| [MindMake SignalGuard](<../Jobs/MindMake SignalGuard/JOB.md>) | Keeps an AI assistant honest about how it knows what it says. |
| [MindMake ThoughtVault](<../Jobs/MindMake ThoughtVault/JOB.md>) | Gives an AI assistant a memory and a to-do list that last between conversations. |
| [MindMake DreamWeaver](<../Jobs/MindMake DreamWeaver/JOB.md>) | Reads a handful of random memory seeds and "dreams" over them, finding patterns, contradictions and conspicuous gaps nobody asked about, then compresses the result into one short, clearly labeled dream seed. |
| [MindMake Seed Protocol](<../Jobs/MindMake Seed Protocol/JOB.md>) | Keeps an AI assistant's long-term memory small, honest and findable. |
| [MindMake AI Turbo](<../Jobs/MindMake AI Turbo/JOB.md>) | Keeps every answer as short and direct as the task allows, stated with exactly the confidence the evidence supports, and still aimed at the question the user actually asked. |
| [MindMake Heartbeat](<../Jobs/MindMake Heartbeat/JOB.md>) | Checks that an AI assistant's setup actually loaded (governing instructions, profiles, memory, task list, other helpers) and restores it after the conversation is compressed or reset. |
| [MindMake SkillMaster](<../Jobs/MindMake SkillMaster/JOB.md>) | Helps an AI assistant pick the right skill, tool or connection for the task, and be honest about what actually works. |
| [MindMake TaskCycle](<../Jobs/MindMake TaskCycle/JOB.md>) | Works through the user's to-do list on its own, within limits. |
| [MindMake Seed Capsule](<../Jobs/MindMake Seed Capsule/JOB.md>) | Adds a short capsule (assertion, proof, uncertainty, plus optional meaning and next move) to the top of important memory seeds, so a future assistant can orient fast and then check the real proof. |
| [Personal Assistant](<../Jobs/Personal Assistant/JOB.md>) | A goal-focused personal assistant that keeps you moving on what matters: it remembers the current direction, turns unfinished work into one next action, follows up on commitments from sources you approve, and sets reminders you control, while being honest about what is actually connected, scheduled or sent. |
| [Personal MCP Builder](<../Jobs/Personal MCP Builder/JOB.md>) | Explains why an AI assistant sometimes needs a small local tool server (MCP), and helps a person design, build, connect and verify one safely, with the smallest possible set of tools. |
| [Your AI Companion](<../Jobs/Your AI Companion/JOB.md>) | Gives an AI assistant a steady, honest working personality, Pete or Jess, the user's choice. |
| [PPI Architect](<../Jobs/PPI Architect/JOB.md>) | Turns a person's own knowledge into a PPI (Portable Plug-in): a helper another AI can run without guessing. |
| [PPI Export](<../Jobs/PPI Export/JOB.md>) | Packages a tested PPI helper as a readable document and an optional Agent Plugins folder, checks the files are well formed, and states plainly where they will and won't work. |
| [PPI Revise](<../Jobs/PPI Revise/JOB.md>) | Applies only the changes a PPI owner approved, keeps everything else word for word, and records every change so versions can be trusted or rolled back. |
| [PPI Test](<../Jobs/PPI Test/JOB.md>) | Checks whether a PPI helper is complete and behaves as its own tests say, before anyone relies on it. |
| [MindMake Guide](<../Jobs/MindMake Guide/JOB.md>) | The quick start and user manual in one: what MindMake is, the two ways to use it, the helpers, the folder, memory, safety and troubleshooting. |

## Useful connections

| Connection | Benefit | Verify before relying on it |
| --- | --- | --- |
| Gmail | Follow-ups, commitments and reply drafts | Intended account and one authorized message read; separate draft/send permissions |
| Google Drive / Docs | Find project context and prepare or revise documents | Intended account and one chosen document read; separate folder/edit scope |
| Google Calendar | Upcoming deadlines and preparation | Intended calendar and a bounded event read; separate event-write scope |
| Local files / Downloads | Sort incoming work and find current artifacts | Approved folders, actual browser destination and watcher status |
| Personal MCP | Easier MindMake/GUARD retrieval and session records | Actual host tool calls; optional, independent of cloud account connectors |
| SMS | Timely nudges away from the AI app | Opted-in destination, provider and delivery test |

For each dependency distinguish availability, requested setup, observed verification, stale evidence and failure. Explain the relevant benefit when offering a connection. Do not repeatedly offer a declined option. A deferred personal MCP follows the existing 30-day rule. Other deferred connections wait until the agreed time or a relevant task. Never claim access or install an unrelated service merely because it appears in this table.

During setup, follow [the intake checkpoint](../INTAKE.md). A goal or request for assistance can guide useful work while the next unanswered setup question stays active. Only an explicit user deferral pauses it.
