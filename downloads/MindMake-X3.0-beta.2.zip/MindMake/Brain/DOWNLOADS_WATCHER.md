# Downloads ingestion & watcher

The workspace monitors files dropped into its `Downloads/` intake tray. Files can be processed **on-demand during user chat sessions** (recommended) or via an **optional background process**.

## 1. In-Session, On-Demand Ingestion (Recommended)

Users and assistants can check and ingest downloads directly during conversation without running a terminal daemon:

```sh
python3 Brain/tools/mindmake.py check_downloads [--force]
python3 Brain/tools/mindmake.py file_download --file <filename> --destination <Brain/|Jobs/|Wiki/>
```

Or conversationally:
- *"Check downloads"* / *"Process new files in Downloads"*
- *"File [filename] into Wiki/References"*

When run on-demand:
- Any files matching established routing rules in [download-routes.json](.mindmake/download-routes.json) are automatically filed to their destination, with journaled, recoverable folder map updates.
- Files without a pre-configured rule appear in `needs_review`. The assistant can inspect their metadata and confirm the user's intended destination, then file them directly with `file_download`.
- Filing uses exclusive destination creation, then flushes and verifies copied bytes and source identity before removing the source. It does not require hardlinks. Unix locks and a simulated Windows lock branch are tested; native Windows operation is not certified.

## 2. Optional Background Watcher Daemon

For continuous automatic ingestion while the computer is awake, a cooperative polling daemon is available:

```sh
python3 Brain/tools/downloads_watch.py start
python3 Brain/tools/downloads_watch.py status
python3 Brain/tools/downloads_watch.py stop
```

Start is idempotent. Stop writes a cooperative stop request. Daemon operation is strictly optional; in-session processing via `check_downloads` is the primary, zero-friction interface.

## Routing configuration

Configure rules in [download-routes.json](.mindmake/download-routes.json). Each rule has a case-sensitive filename glob `pattern` and an existing workspace-relative `destination` under Brain, Jobs or Wiki. Use one unambiguous rule per file. No extension-only PDF rule ships: a PDF may be a helper, project research or general reference. Never add broad rules without a basis in the user's filing intent.

The watcher and on-demand scanner ignore partial extensions (`.part`, `.crdownload`, `.tmp`), preserve filenames, refuse symlinks and overwrites, verify file hashes, and update affected maps after filing. Both filing entry points share a lock. A durable transfer journal records planned work before copying. Interrupted complete copies can resume; partial files or conflicting edits are preserved for review. `filed_map_pending` remains pending until map verification passes. These controls cover helper operations, not unrelated writers or a guarantee against physical disk failure.

## X.1 knowledge processing

Follow [Wiki intake and retrieval](<WIKI_WORKFLOW.md>) for source registration, separate retrieval seeds and Wiki pages, evidence checks, retry, and optional Journal/Contacts jobs. A filed download is not a processed source. Use `python3 Brain/tools/knowledge.py status` from the workspace root to check the queue.

## macOS metadata sidecars

If the source has an AppleDouble `._` sidecar, filing records it in the transfer journal and preserves its exact bytes in a separate `<filename>.appledouble` artifact beside the filed document. Both copies must verify before source removal. The artifact preserves raw metadata for recovery; it does not claim that metadata has been reapplied to the destination. An existing or changed backup is a conflict for review. Native resource forks without an accessible sidecar are refused instead of silently discarded. Tests exercise these paths on a macOS-mounted ExFAT volume; a native Windows run remains unverified.
