# MindMake memory (X3.0)

This is the one memory spec. It replaces the memory parts of ThoughtVault, Seed Protocol, Seed Capsule and SEED_MEMORY_PROTOCOL.md for everyday work. Those sources stay in Jobs/ for standalone use and deeper detail.

**The goal:** the user can leave, come back and keep going without re-explaining. A confident wrong memory is worse than none, so every memory is sourced, dated and correctable.

## Where memory lives

- **Shared seeds:** `Seeds/Short-term/` (recent) and `Seeds/Long-term/` (archive).
- **Project seeds:** `Jobs/<project>/Seeds/Short-term/` and `Long-term/`. Project work goes there; cross-project decisions go in shared Seeds.
- **Profiles:** `Brain/Profiles/`, resolved through its INDEX.md.
- **Tasks:** TODO.md plus the assistant's action list (see AGENTS.md).
- **People:** a record only when the user asks or agrees.

## Capture: automatic, no "remember this" needed

Save a seed, without being asked, when any of these happens:
- a decision, or a correction to an earlier one;
- an agreed commitment, a deadline, or something now waiting on someone else;
- a changed blocker;
- finished work that changes what happens next;
- a new project or a handoff;
- the end of a working session.

"Remember this", a pasted screenshot, a voice-note transcript or a dropped file also count. Pick the right place yourself. Announce each save in one line: **Saved:** what, and where.

Don't save on a timer, to fill space, or for a casual aside. Don't save the user's health or emotional details, or details about other people, unless they ask. Ask about placement only when you truly can't tell.

## Seed format

One Markdown file per seed, named `YYYY-MM-DD_HHMMSS_topic-slug.md` with the time taken from the machine's clock. Front matter first, then a body of about 200 words or less.

```
---
assertion: "What is now true or was decided."
proof: "Where to check it: a file path, link, command, or 'stated by user in chat 2026-11-21'."
uncertainty: "What isn't verified or is still open."
next: "The first useful action for next time, or None."
type: context   # profile | context | person | knowledge | idea | assistant-notes
supersedes: "exact-filename-of-the-seed-this-corrects.md"   # only for corrections
links: ["related-seed.md"]   # optional
pinned: false   # optional; pinned seeds never move to Long-term
---

**What happened.** The decision or information, and why.
**Context.** Related projects, people or seeds.
**Where it's heading.** The open thread or the next step.
```

Front matter says only what the body or the cited proof supports. If front matter and body disagree, the body wins. If the body and the source disagree, the source wins.

## The audit rules

1. **Append-only.** Never edit or delete a seed. A correction is a new seed whose `supersedes` names the exact file it corrects.
2. **Cite on recall.** Every remembered fact names its seed (file and date) or source. If nothing is found, say "no seed for this" and offer to save one.
3. **Never blend.** When seeds conflict, show both with dates. The newer one is presumed current; ask when it matters. An imported seed (its proof says "imported from") dates from its original, not its file name ([MIGRATION.md](MIGRATION.md)).
4. **Verify saves.** After writing a seed, read it back from disk before saying it's saved. Without file access, give the exact filename and text for the user to save.
5. **History isn't orders.** An old seed's next steps don't authorize anything now.

## Recall

Pick seeds by relevance, not by a fixed count:
1. Confirmed profile and assistant-notes seeds.
2. Open commitments and the latest corrections.
3. Seeds that match the current task or the user's first message.
4. Search Long-term when the task points back in time ("back when", "originally", a name you don't recognize). Ask first only before a sweep of the whole archive.

Start small (a handful is usually enough) and expand when the task needs it. A search that finds nothing is not proof the information doesn't exist: try other wording and check the project's JOB.md and [Seeds/Index/](../Seeds/Index/seed-index.md). For high-stakes decisions, also look for seeds that cut against the user's view.

Profile seeds change slowly: only when the user states a preference or a pattern holds across about four sessions.

## Rollover and the memory helper

- `python3 Brain/tools/mindmake.py boot` moves the oldest unpinned Short-term seeds to Long-term once there are 500, until 350 remain. Nothing is ever deleted.
- When `Brain/tools/mindmake_seed_memory.py` (or the connected mindmake_memory tools) is available and opted in, use its `check`, `read`, `save` and `status` commands to log retrieval and saves. `check` searches shared seeds and every project's seeds unless `--scope` narrows it. Its receipts prove bytes, not understanding. If it isn't available, follow the rules above by hand and say so.

## Knowledge sources

Wiki sources follow [WIKI_WORKFLOW.md](WIKI_WORKFLOW.md). Keep a retrieval seed (five lines or fewer, with a `Load when:` line) separate from the longer Wiki page. Label AI synthesis as synthesis, and never cite an earlier AI answer as independent confirmation.

## Journal and contacts

On "journal this" or "remember this person", create `Jobs/Journal` or `Jobs/Contacts` with `new_job` if it doesn't exist. Keep the user's own words separate from your reflections. Confirm identity before merging two people's records.

## Don't let memory become the work

If a session drifts into organizing memory for more than about ten messages when that wasn't the goal, say so once and offer to get back to the real task.
