# MindMake First Win

This short walkthrough creates a project, records a decision and checks that its files are discoverable. A separate fresh-conversation check tests whether an assistant actually retrieves and uses that decision. Filesystem checks alone cannot establish conversational continuity.

## 1 Create a project

Ask the assistant to start a named project, or run:

```sh
python3 Brain/tools/mindmake.py new_job --name "Launch Strategy" --purpose "Plan the launch"
```

The helper creates `Jobs/Launch Strategy/` with `JOB.md`, `Research/`, `Notes/`, and `Seeds/Short-term/` and `Seeds/Long-term/` pools. It registers the project in the folder maps. These folders organize work; they are not an operating-system security sandbox. An existing project is preserved rather than overwritten.

## 2 Record a real decision

Tell the assistant a decision and an unresolved next action. Ask it to save a short continuity seed in that project's `Seeds/Short-term/` folder. A useful seed states what was done, key decisions, open questions and next steps. Its date comes from the current local clock.

Seeds are selective continuity notes. They do not capture every action or restore complete model state. An empty file does not count as a recorded decision, and a nonempty file alone does not prove its contents are accurate or complete.

## 3 Check file readiness

After writing the seed, update and verify its maps:

```sh
python3 Brain/tools/mindmake.py update_map --paths "Jobs/Launch Strategy"
python3 Brain/tools/mindmake.py check_map
python3 Brain/tools/mindmake.py tutorial
```

`FILESYSTEM_READY` means the helper found a registered user project, a nonempty seed and valid maps. The returned seed path is the exact record to use in the next step. This is a file-readiness result; it is not a test of memory in another conversation. The tutorial status check does not run automatic seed maintenance.

Maps retain navigation and generation checks within their declared scope. They cannot guarantee complete filesystem integrity or prevent arbitrary writes by other applications.

## 4 Check a fresh conversation

Open a fresh conversation connected to this same extracted workspace. Name the project and ask the assistant to resume it. Check that it reads the saved seed and accurately identifies both the recorded decision and the unresolved next action without those answers being supplied again.

Record the observed conversation result and source path in a new dated seed. If either item is missed, leave acceptance pending, repair the source/retrieval route and repeat the check. A personalized host may supply context from elsewhere; record that limitation. One successful check applies to that case and does not establish reliable recall across all future sessions.

The `tutorial` command leaves this conversational acceptance step `PENDING`; it does not infer success from running `boot` or from the presence of an evidence file. Human review of the actual conversation remains necessary.

## Assistant procedure

After the preferred name is explicitly recorded during [intake](../INTAKE.md), offer this walkthrough or let the user continue their chosen project. Give one useful step at a time and preserve the intake checkpoint. Do not fabricate answers, decisions or successful tests. Read the original seed before claiming its contents; report file readiness separately from observed conversational acceptance.
