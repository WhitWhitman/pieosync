---
name: mindmake-workspace
description: Load or repair this local MindMake workspace, route shared versus job seeds, and update navigation after authorized filesystem changes.
---

On load, recovery or any workspace change, read [GUARD.md](<../../../GUARD.md>) and follow [AGENTS.md](<../../../AGENTS.md>). Memory rules are in [Brain/MEMORY.md](<../../MEMORY.md>). Setup follows [INTAKE.md](<../../../INTAKE.md>), and folder rules are in [the deployment policy](../../governance/WORKSPACE_POLICY.md).

Each rule lives once in those files; this wrapper only routes to them. The X2.0 text is preserved in `Brain/governance/history/mindmake-workspace_SKILL_X2.0.md`.
