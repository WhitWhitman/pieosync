#!/usr/bin/env python3
"""Local MindMake navigation and startup checks. Standard library only."""
import argparse
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import uuid
from urllib.parse import unquote

BEGIN = '<!-- MINDMAKE FOLDER MAP BEGIN -->'
END = '<!-- MINDMAKE FOLDER MAP END -->'
REGISTRY = 'Brain/.mindmake/folder-map.json'
INVENTORY = 'Brain/.mindmake/folder-inventory.json'
PENDING = 'Brain/.mindmake/folder-map.pending.json'
EXCLUSIONS = ['root archive/revision directories beginning with _',
              'macOS sidecars, lock files, temporary files, Python caches',
              'Brain/.mindmake/map-history and repair-history',
              'generated inventory, transaction journal, updater lock',
              'all symbolic links (reported separately)', 'personal MCP runtime and session state (documented in Brain/PERSONAL_MCP.md)', 'assistant runtime state (documented in Brain/PERSONAL_ASSISTANT.md)', 'seed rollover manifests (Brain/.mindmake/seed-rollovers)', 'private correction/work records (Brain/.mindmake/corrections and work-records)']

def now():
    return dt.datetime.now().astimezone().isoformat(timespec='seconds')

def digest(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None

def read(path):
    return path.read_bytes() if path.exists() else None

def atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.mindmake-write-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)

def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def within(root, rel):
    p = root / rel
    if Path(rel).is_absolute() or '..' in Path(rel).parts:
        raise ValueError('Path must be relative to the chosen workspace: ' + str(rel))
    for parent in [p, *p.parents]:
        if parent == root:
            break
        if parent.is_symlink():
            raise ValueError('Symbolic link is outside helper scope: ' + str(rel))
    if not p.resolve().is_relative_to(root.resolve()):
        raise ValueError('Path escapes chosen workspace: ' + str(rel))
    return p

def excluded(rel):
    parts = Path(rel).parts
    name = parts[-1]
    return (any(rel == 'Brain/.mindmake/'+name or rel.startswith('Brain/.mindmake/'+name+'/') for name in ('work-records','corrections','seed-memory')) or rel == 'Brain/.mindmake/assistant-state' or rel.startswith('Brain/.mindmake/assistant-state/') or rel in ('Brain/.mindmake/personal-mcp-state', 'Brain/.mindmake/personal-mcp-runtime') or rel.startswith(('Brain/.mindmake/personal-mcp-state/', 'Brain/.mindmake/personal-mcp-runtime/')) or rel == 'Brain/.mindmake/downloads-watch' or rel.startswith('Brain/.mindmake/downloads-watch/') or rel == 'Brain/.mindmake/seed-rollovers' or rel.startswith('Brain/.mindmake/seed-rollovers/') or parts[0].startswith('_') or
            any(p.startswith('._') or p == '__pycache__' for p in parts) or
            name.startswith(('.~lock.', '.mindmake-write-')) or
            name.endswith(('.tmp', '.pyc')) or name == '.DS_Store' or
            rel in (INVENTORY, PENDING, 'Brain/.mindmake/map.lock') or
            rel.startswith(('Brain/.mindmake/map-history/', 'Brain/.mindmake/repair-history/')) or
            rel in ('Brain/.mindmake/map-history', 'Brain/.mindmake/repair-history'))

def scan(root, start=''):
    entries, links = {}, []
    def visit(path):
        rel = path.relative_to(root).as_posix()
        if excluded(rel):
            return
        if path.is_symlink():
            links.append(rel)
            return
        stat = path.stat()
        parts = Path(rel).parts
        owner = '/'.join(parts[:2]) if len(parts) > 1 and parts[0] == 'Jobs' and (root.joinpath(*parts[:2])/'JOB.md').is_file() else None
        entries[rel] = dict(path=rel, kind='directory' if path.is_dir() else 'file',
                            parent=path.parent.relative_to(root).as_posix(), owning_project=owner,
                            modified_ns=stat.st_mtime_ns, size=None if path.is_dir() else stat.st_size,
                            observed_at=now(), verification='verified')
        if path.is_dir():
            for child in sorted(path.iterdir()):
                visit(child)
    if start:
        path = within(root, start)
        if path.exists() or path.is_symlink():
            visit(path)
    else:
        for child in sorted(root.iterdir()):
            visit(child)
    return entries, links

def replace_block(text, body):
    if text.count(BEGIN) != text.count(END) or text.count(BEGIN) > 1:
        raise ValueError('Malformed or duplicate generated-map markers')
    block = BEGIN + '\n\n' + body.rstrip() + '\n\n' + END
    if BEGIN not in text:
        return text.rstrip() + '\n\n' + block + '\n'
    if text.index(BEGIN) > text.index(END):
        raise ValueError('Reversed generated-map markers')
    return text[:text.index(BEGIN)] + block + text[text.index(END) + len(END):]

def link(root, owner_file, target, label=None):
    rel = os.path.relpath(root / target, (root / owner_file).parent)
    return '[' + (label or Path(target).name) + '](<' + rel + '>)'

def link_errors(root, rel, text, prospective=()):
    errors = []
    for m in re.finditer(r'\[[^\]\n]+\]\((?:<([^>]+)>|([^\s)]+))\)', text):
        target = unquote((m.group(1) or m.group(2)).split('#')[0])
        if not target or re.match(r'[a-zA-Z]+:', target):
            continue
        p = (root / rel).parent / target
        contained = p.resolve().is_relative_to(root.resolve())
        planned = contained and p.resolve().relative_to(root.resolve()).as_posix() in prospective
        if not contained or (not p.exists() and not planned):
            errors.append(rel + ': unresolved or external link ' + target)
    return errors

def state(root):
    return json.loads((root / REGISTRY).read_text())

def verify(root, allow_pending=False, rollover_paths=()):
    errors = []
    if (root / PENDING).exists() and not allow_pending:
        errors.append('Interrupted map transaction: run recover_map before updating')
    try:
        reg = state(root)
        files = [reg['root_map'], *reg['project_maps'].values(), *reg.get('specialist_maps', [])]
        for rel in files:
            p = within(root, rel)
            if not p.is_file():
                errors.append('Missing map: ' + rel)
                continue
            text = p.read_text()
            replace_block(text, '')
            if BEGIN not in text or reg['generation_id'] not in text.split(BEGIN)[1].split(END)[0]:
                errors.append('Generation mismatch: ' + rel)
            errors += link_errors(root, rel, text, prospective=rollover_paths)
        inv_path = reg.get('inventory_path')
        if inv_path:
            inv = json.loads(within(root, inv_path).read_text())
            if inv['generation_id'] != reg['generation_id']:
                errors.append('Inventory generation mismatch')
            known = {e['path'] for e in inv['entries']}
            top = {p.relative_to(root).as_posix() for p in root.iterdir()
                   if not excluded(p.relative_to(root).as_posix()) and not p.is_symlink()}
            unknown = top - known
            for project in [*reg['project_maps'], *reg.get('area_roots', [])]:
                found, _ = scan(root, project)
                unknown |= set(found) - known
            found, _ = scan(root, 'Seeds')
            unknown |= set(found) - known
            unknown -= set(rollover_paths)
            if unknown:
                errors.append('Unmapped paths need a verified update: '+', '.join(sorted(unknown)))
        observed = {p.relative_to(root).as_posix() for p in (root/'Jobs').iterdir() if p.is_dir() and not p.name.startswith(('.', '_'))}
        if observed != set(reg['project_maps']):
            errors.append('Jobs registration differs from actual job directories')
        for rel, expected in reg.get('map_hashes', {}).items():
            if digest(read(within(root, rel))) != expected:
                errors.append('Map changed since commit: ' + rel)
        checked = files
    except (OSError, ValueError, KeyError, TypeError) as e:
        errors.append(str(e))
        checked = []
    return dict(status='PASS' if not errors else 'FAIL', coverage='scoped',
                checked_at=now(), checked_scope=checked, exclusions=EXCLUSIONS, errors=errors)

def acquire(root, lock_rel='Brain/.mindmake/map.lock'):
    lock = within(root, lock_rel).open('a+b')
    try:
        import fcntl
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            lock.close()
            raise ValueError('Another map writer holds the lock')
    except ImportError:
        try:
            import msvcrt
            try:
                lock.seek(0, os.SEEK_END)
                if not lock.tell():
                    lock.write(b'0'); lock.flush()
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                lock.close()
                raise ValueError('Another map writer holds the lock')
        except ImportError:
            lock.close()
            raise OSError('No supported file-locking primitive available (fcntl or msvcrt required)')
    return lock

def rebuild(root, changes=None):
    with acquire(root):
        if (root/PENDING).exists():
            raise ValueError('Pending transaction; use recover_map first')
        previous = state(root)
        before_registry = read(root/REGISTRY)
        generation = 'folder-map-' + dt.datetime.now().strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:8]
        if changes is not None:
            if not changes:
                raise ValueError('update_map requires confirmed --paths (old and new paths for a move)')
            inv = json.loads((root/INVENTORY).read_text())
            entries = {e['path']: e for e in inv['entries']}
            links = list(inv.get('excluded_symlinks', []))
            for rel in changes:
                within(root, rel)
                entries = {p:e for p,e in entries.items() if p != rel and not p.startswith(rel.rstrip('/')+'/')}
                links = [p for p in links if p != rel and not p.startswith(rel.rstrip('/')+'/')]
                found, syms = scan(root, rel)
                entries.update(found)
                links += syms
                for parent in Path(rel).parents:
                    if parent == Path('.'):
                        continue
                    key = parent.as_posix()
                    p = within(root, key)
                    if key not in entries and p.is_dir() and not excluded(key):
                        stat = p.stat()
                        entries[key] = dict(path=key, kind='directory', parent=parent.parent.as_posix(),
                                            owning_project=None, modified_ns=stat.st_mtime_ns, size=None,
                                            observed_at=now(), verification='verified')
            scope, coverage = changes, 'scoped'
        else:
            entries, links = scan(root)
            scope, coverage = ['authorized active workspace tree'], 'complete'
        projects = {}
        for p in sorted((root/'Jobs').iterdir()):
            if p.is_dir() and not p.name.startswith(('.', '_')):
                if p.is_symlink() or not (p/'JOB.md').is_file():
                    raise ValueError('Job needs a real JOB.md before registration: '+p.name)
                projects[p.relative_to(root).as_posix()] = (p/'JOB.md').relative_to(root).as_posix()
        missing = set(previous['project_maps']) - set(projects)
        if missing and changes is None:
            raise ValueError('Previously registered jobs missing; verify removal and use update_map --paths: '+str(sorted(missing)))
        if missing and not all(any(p == c or p.startswith(c.rstrip('/')+'/') for c in changes) for p in missing):
            raise ValueError('A missing job is not covered by the confirmed paths')
        root_map = previous['root_map']
        header = f'Generation: `{generation}`. Checked: {now()}. Coverage: {coverage}.\n'
        bodies = {}
        top = sorted(p for p,e in entries.items() if e['parent'] == '.' and not p.startswith('.'))
        body = header + '\n## Shared workspace routes\n\n' + '\n'.join('- '+link(root,root_map,p) for p in top)
        body += '\n\n## Jobs\n\n' + '\n'.join('- '+link(root,root_map,m,Path(p).name) for p,m in projects.items())
        body += '\n\nDetailed file metadata: ' + link(root,root_map,INVENTORY) + '.\n\nExclusions: '+ '; '.join(EXCLUSIONS)+'.'
        if links:
            body += '\n\nExcluded symbolic links: '+', '.join('`'+p+'`' for p in sorted(set(links)))+'.'
        bodies[root_map] = body
        for p,m in projects.items():
            paths = sorted(x for x in entries if x.startswith(p+'/') and x != m)
            bodies[m] = header + '\n- ' + link(root,m,root_map,'Workspace folder map') + '\n\n' + '\n'.join('- '+link(root,m,x,os.path.relpath(x,p)) for x in paths)
        bodies['Jobs/INDEX.md'] = header + '\n' + '\n'.join('- '+link(root,'Jobs/INDEX.md',m,Path(p).name) for p,m in projects.items())
        pools = ['Seeds'] + [p+'/Seeds' for p in projects]
        bodies['Seeds/SEEDS_MAP.md'] = header + '\n| Pool | Short-term | Long-term |\n|---|---:|---:|\n'
        seeds = []
        for pool in pools:
            counts = []
            for tier in ('Short-term','Long-term'):
                found = sorted(x for x,e in entries.items() if e['parent'] == pool+'/'+tier and e['kind']=='file' and Path(x).suffix.lower() in ('.md','.txt'))
                counts.append(len(found)); seeds += found
            bodies['Seeds/SEEDS_MAP.md'] += '| '+link(root,'Seeds/SEEDS_MAP.md',pool)+' | '+str(counts[0])+' | '+str(counts[1])+' |\n'
        bodies['Seeds/Index/seed-index.md'] = header + '\n' + '\n'.join('- '+link(root,'Seeds/Index/seed-index.md',s,s) for s in seeds)
        specialist = ['Jobs/INDEX.md','Seeds/SEEDS_MAP.md','Seeds/Index/seed-index.md']
        areas = [area for area in ['Brain','Wiki','Downloads'] if (root/area/'INDEX.md').is_file()]
        for area in areas:
            rel = area+'/INDEX.md'
            paths = sorted(x for x,e in entries.items() if x.startswith(area+'/') and x != rel and e['kind']=='file')
            bodies[rel] = header + '\n' + '\n'.join('- '+link(root,rel,x,os.path.relpath(x,area)) for x in paths)
            specialist.append(rel)
        if (root/'Jobs/FILES.md').is_file():
            rel='Jobs/FILES.md'
            bodies[rel]=header+'\n'+'\n'.join('- '+link(root,rel,x,x.removeprefix('Jobs/')) for x,e in sorted(entries.items()) if x.startswith('Jobs/') and x != rel and e['kind']=='file')
            specialist.append(rel)
        candidates, original = {}, {}
        for rel, body in bodies.items():
            path = within(root,rel)
            original[rel] = read(path)
            authored = original[rel]
            if authored is None:
                expected = previous.get('map_hashes', {}).get(rel)
                for history in sorted((root/'Brain/.mindmake/map-history').glob('*'), reverse=True):
                    for saved_path in (history/'committed'/rel, history/rel):
                        saved = read(saved_path)
                        if expected and digest(saved) == expected:
                            authored = saved
                            break
                    if authored is not None:
                        break
                if authored is None:
                    raise ValueError('Authored map missing and no matching backup; restore it before rebuilding: '+rel)
            text = replace_block(authored.decode(),body)
            errors = link_errors(root,rel,text,prospective=set(bodies) | {INVENTORY})
            if errors:
                raise ValueError('\n'.join(errors))
            candidates[rel] = text.encode()
            entry = entries.setdefault(rel, dict(path=rel, kind='file', parent=Path(rel).parent.as_posix(),
                                                owning_project=next((p for p in projects if rel.startswith(p+'/')), None)))
            entry.update(size=len(candidates[rel]), modified_ns=None, observed_at=now(),
                         verification='generated; committed bytes recorded in registry map_hashes')
        original[INVENTORY] = read(root/INVENTORY)
        original[REGISTRY] = before_registry
        inventory = dict(schema_version=1,generation_id=generation,scope=scope,coverage=coverage,
                         exclusions=EXCLUSIONS,excluded_symlinks=sorted(set(links)),entries=list(entries.values()))
        candidates[INVENTORY] = encoded(inventory)
        registry = dict(schema_version=1,area_roots=areas,root_map=root_map,project_maps=projects,specialist_maps=specialist,
                        inventory_path=INVENTORY,generation_id=generation,checked_at=now(),checked_scope=scope,
                        coverage=coverage,exclusions=EXCLUSIONS,errors=[],
                        map_hashes={p:digest(b) for p,b in candidates.items() if p != INVENTORY})
        candidates[REGISTRY] = encoded(registry)
        known = set(entries)
        top = {p.relative_to(root).as_posix() for p in root.iterdir()
               if not excluded(p.relative_to(root).as_posix()) and not p.is_symlink()}
        unmapped = top - known
        for project in [*projects, *areas]:
            found, _ = scan(root, project)
            unmapped |= set(found) - known
        found, _ = scan(root, 'Seeds')
        unmapped |= set(found) - known
        if unmapped:
            raise ValueError('Unmapped paths need a verified update: ' + ', '.join(sorted(unmapped)))
        backup = root/'Brain/.mindmake/map-history'/generation
        backup.mkdir(parents=True)
        journal = dict(generation_id=generation,files={})
        for rel,data in candidates.items():
            old = original[rel]
            journal['files'][rel] = dict(before=None if old is None else base64.b64encode(old).decode(),after_sha256=digest(data))
            if old is not None:
                atomic(backup/rel,old)
            # Keep the candidate too: its hash must match the committed registry before reuse.
            atomic(backup/'committed'/rel,data)
        # All originals are guarded, including the registry; registry is always written last.
        for rel,old in original.items():
            if read(root/rel) != old:
                raise ValueError('Concurrent edit before commit: '+rel)
        atomic(root/PENDING,encoded(journal))
        for rel,data in candidates.items():
            if read(root/rel) != original[rel]:
                raise ValueError('Concurrent edit during commit; pending journal retained: '+rel)
            atomic(root/rel,data)
        try:
            result = verify(root,allow_pending=True)
            if result['errors']:
                recover(root)
                raise ValueError('Post-commit verification failed; transaction rolled back: '+str(result['errors']))
            (root/PENDING).unlink()
        except Exception:
            if (root/PENDING).exists():
                try:
                    recover(root)
                except Exception:
                    pass
            raise
        return dict(status='PASS',generation_id=generation,coverage=coverage,checked_scope=scope,
                    changed_entries=list(candidates),inventory_entries=len(entries),exclusions=EXCLUSIONS,
                    excluded_symlinks=sorted(set(links)),errors=[])

def recover(root):
    with acquire(root):
        if not (root/PENDING).exists():
            return dict(status='PASS',action='No pending transaction',errors=[])
        journal = json.loads((root/PENDING).read_text())
        changes = []
        for rel,item in journal['files'].items():
            path = within(root,rel)
            old = None if item['before'] is None else base64.b64decode(item['before'])
            current = read(path)
            if current != old and digest(current) != item['after_sha256']:
                raise ValueError('Recovery preserves a concurrent edit; manual reconciliation needed: '+rel)
            changes.append((path,old))
        for path,old in changes:
            if old is None:
                if path.exists(): path.unlink()
            else:
                atomic(path,old)
        (root/PENDING).unlink()
        return dict(status='PASS',action='Rolled back interrupted map generation',errors=[])

REVIEW = 'Brain/.mindmake/setup-review.json'

def review_fingerprint(root, item):
    """Bind review to sources and authored deployment rules, not generated maps."""
    paths = set(item['sha256']) | {
        'AGENTS.md', 'MINDMAKE.md', 'INTAKE.md', 'GUARD.md',
        'Brain/governance/WORKSPACE_POLICY.md', 'Brain/tools/mindmake.py',
        'Brain/tools/downloads_watch.py', 'Brain/DOWNLOADS_WATCHER.md',
        'Brain/FIRST_WIN.md', 'Brain/governance/FIRST_RUN_ACCEPTANCE.md',
        'Brain/WIKI_WORKFLOW.md', 'Brain/tools/knowledge.py',
        'Brain/PERSONAL_ASSISTANT.md', 'Brain/CAPABILITIES.md', 'Brain/tools/assistant.py',
        'Brain/PERSONAL_MCP.md', 'Brain/tools/personal_mcp.py', 'Brain/MCP/personal_mcp_server.py',
        item['job'] + '/JOB.md', item['job'] + '/LGI_ENGINE_CONTRACT.md'}
    paths.update(rel for rel in ('Brain/tools/apple_reminders.py', 'Brain/tools/apple_reminders.jxa',
                                 'Brain/tools/apple_reminders.applescript')
                 if within(root, rel).is_file())
    paths.update(rel for rel in ['Brain/tools/mindmake_seed_memory.py', 'Brain/tools/mindmake_seeds.py', 'Brain/tools/SEED_MEMORY_PROTOCOL.md', 'Brain/tools/mindmake_local.py', 'Brain/tools/mindmake_review.py', 'Brain/tools/mindmake_corrections.py', 'Brain/tools/mindmake_work.py', 'Brain/tools/mindmake_task_eval.py', 'Brain/tools/mindmake_skill_routes.py', 'Brain/tools/mindmake_release.py', 'Brain/tools/task-eval-cases.json', 'Brain/tools/skill-routing-cases.json', 'Brain/tools/WORKFLOW_IMPROVEMENT.md', 'Brain/tools/WORK_RECORDS.md', 'Brain/tools/TASK_EVAL.md', 'Brain/tools/FOLLOW_THROUGH.md', 'Brain/tools/RELEASE_TOOL.md'] if within(root,rel).is_file())
    if within(root,'Brain/tools/mindmake_review.py').is_file():
        paths.update(['Brain/governance/RUNTIME.md', 'Brain/SKILLS.md', 'Brain/skills/mindmake-workspace/SKILL.md'])
    paths.update(p.relative_to(root).as_posix()
                 for p in within(root, item['job'] + '/Skills').glob('*/SKILL.md'))
    hashes = {}
    for rel in sorted(paths):
        data = read(within(root, rel))
        if data is None:
            raise ValueError('Review input missing: ' + rel)
        if rel.endswith('/JOB.md'):
            text = data.decode()
            replace_block(text, '')  # Validate marker pairs before removing them.
            if BEGIN in text:
                text = text[:text.index(BEGIN)] + text[text.index(END)+len(END):]
            data = text.strip().encode()
        hashes[rel] = digest(data)
    return digest(encoded(hashes))

def setup_review(root):
    catalog = json.loads((root/'Brain/.mindmake/source-catalog.json').read_text())
    ledger = json.loads(within(root, REVIEW).read_text())
    if ledger.get('schema_version') != 1 or not isinstance(ledger.get('records'), dict):
        raise ValueError('Invalid setup review ledger')
    queue = []
    for item in catalog['sources']:
        fingerprint = review_fingerprint(root, item)
        record = ledger['records'].get(item['job'], {})
        valid = False
        if record.get('fingerprint') == fingerprint and record.get('reviewed_at'):
            evidence = record.get('evidence')
            if evidence:
                data = read(within(root, evidence))
                valid = data is not None and digest(data) == record.get('evidence_sha256')
        queue.append(dict(job=item['job'], source=item['selected_pdf'],
                          fingerprint=fingerprint, status='reviewed' if valid else 'pending'))
    pending = [item for item in queue if item['status'] == 'pending']
    return dict(status='PENDING' if pending else 'RECORDED', total=len(queue),
                reviewed=len(queue)-len(pending), pending=pending,
                evidence_type='Assistant source-review attestation; not independent behavioral acceptance')

def record_setup_review(root, job, evidence, fingerprint):
    if not all([job, evidence, fingerprint]):
        raise ValueError('record_review requires --job, --evidence and --fingerprint')
    with acquire(root):
        catalog = json.loads((root/'Brain/.mindmake/source-catalog.json').read_text())
        item = next((x for x in catalog['sources'] if x['job'] == job), None)
        if item is None:
            raise ValueError('Unknown catalog job: ' + job)
        if review_fingerprint(root, item) != fingerprint:
            raise ValueError('Review inputs changed; inspect changes and obtain a fresh fingerprint')
        if not evidence.startswith('Brain/governance/setup-reviews/') or not evidence.endswith('.md'):
            raise ValueError('Evidence must be a Markdown file under governance/setup-reviews/')
        data = within(root, evidence).read_bytes()
        text = data.decode()
        for section in ['Source read', 'Requirements', 'Conflicts', 'Verification', 'Open issues']:
            match = re.search(r'^## ' + re.escape(section) + r'\s*\n(.*?)(?=^## |\Z)', text, re.M | re.S)
            if not match or not match.group(1).strip():
                raise ValueError('Evidence needs a nonempty section: ' + section)
        if not re.search(r'^## Open issues\s*\n\s*None\.?\s*$', text, re.M):
            raise ValueError('Unresolved issues must remain pending; record only after resolution')
        before = read(within(root, REVIEW))
        ledger = json.loads(before)
        ledger['records'][job] = dict(fingerprint=fingerprint, evidence=evidence,
                                      evidence_sha256=digest(data), reviewed_at=now())
        # Guard external edits before the atomic ledger replacement.
        if read(within(root, REVIEW)) != before or within(root, evidence).read_bytes() != data or review_fingerprint(root, item) != fingerprint:
            raise ValueError('Concurrent review edit; record not committed')
        atomic(within(root, REVIEW), encoded(ledger))
    return dict(status='RECORDED', job=job, errors=[],
                next_action='Update maps for the evidence and '+REVIEW+'; then run boot')


INTAKE = 'Brain/.mindmake/intake.json'
INTAKE_QUESTIONS = [
    ('preferred_name', 'What name would you like me to call you?'),
    ('current_work', 'What would you like MindMake to help you with first?'),
    ('personal_mcp', 'Would you like a personal MCP connection? It can save repeated setup explanations by helping this AI app find current MindMake navigation and GUARD, keep separate session counters and flag changed files. I will check and reuse an existing compatible connection first. A new connection needs a compatible local app and a small local Python setup; it does not guarantee AI compliance or work while the app is closed. Yes, no, or later?'),
    ('connections', 'Which sources would help with your goal? Gmail can surface follow-ups, Google Drive/Docs can find and improve your work, and Calendar can surface deadlines. I will check existing access first and help connect what you choose; you can defer this.'),
    ('working_preferences', 'How would you like me to work with you, including detail and initiative?'),
    ('routine_actions', 'What should I handle routinely within those sources, such as reviewing messages, drafting replies or organizing an agreed folder? We can start small and adjust.'),
    ('reminders', 'How should I help you follow through: in-chat next steps, scheduled check-ins or optional SMS? Tell me a useful rhythm and quiet hours, or defer reminders.'),
    ('companion', 'Would you like to choose a companion style now, or skip it?')]

def intake_status(root):
    data = json.loads(within(root, INTAKE).read_text())
    if data.get('schema_version') != 1 or not isinstance(data.get('answers'), dict):
        raise ValueError('Invalid intake state')
    pending = []
    for field, question in INTAKE_QUESTIONS:
        value = data['answers'].get(field, {})
        due = False
        if field == 'personal_mcp' and value.get('answer') == 'later':
            try:
                revisit = dt.datetime.fromisoformat(value['revisit_after'])
                due = revisit.tzinfo is None or dt.datetime.now(dt.timezone.utc) >= revisit
            except (KeyError, ValueError, TypeError):
                due = True  # Unknown deferral date cannot silently suppress the offer forever.
        if due or value.get('status') not in ('confirmed', 'skipped') or (value.get('status') == 'confirmed' and not value.get('answer', '').strip()):
            pending.append(dict(field=field, question=question))
    conversation = data.get('conversation', {})
    deferred = bool(pending and conversation.get('status') == 'deferred')
    return dict(status='PENDING' if pending else 'COMPLETE', pending=pending,
                next_question=pending[0] if pending else None,
                interaction='DEFERRED' if deferred else 'ACTIVE' if pending else 'COMPLETE',
                deferral=conversation if deferred else None,
                next_action=('Continue authorized work; resume intake when the user asks' if deferred else
                             'ask the next unanswered question; a work request does not silently defer intake' if pending else
                             'Intake answers recorded; verify optional services separately'))

def set_intake_conversation(root, deferred, reason=None):
    if deferred and not (reason and reason.strip()):
        raise ValueError('Deferral requires the user supplied request in --reason; silence is not deferral')
    with acquire(root):
        old = read(within(root, INTAKE))
        data = json.loads(old)
        checkpoint = intake_status(root)['next_question']
        data['conversation'] = dict(status='deferred' if deferred else 'active',
                                    reason=reason.strip() if deferred else None,
                                    checkpoint=checkpoint, recorded_at=now())
        if read(within(root, INTAKE)) != old:
            raise ValueError('Concurrent intake edit; no change recorded')
        atomic(within(root, INTAKE), encoded(data))
    return dict(status='RECORDED', errors=[], intake=intake_status(root),
                next_action='Update maps for ' + INTAKE)


def record_intake(root, field, answer, skip=False):
    if field not in dict(INTAKE_QUESTIONS):
        raise ValueError('Unknown intake field')
    if bool(answer and answer.strip()) == bool(skip):
        raise ValueError('Provide either an explicit --answer or --skip')
    if field == 'personal_mcp' and not skip:
        answer = answer.strip().lower()
        if answer not in ('yes', 'no', 'later'):
            raise ValueError('Personal MCP choice must be yes, no or later; clarify ambiguous answers')
    with acquire(root):
        old = read(within(root, INTAKE))
        data = json.loads(old)
        data['answers'][field] = dict(status='skipped' if skip else 'confirmed',
                                     answer=None if skip else answer.strip(), recorded_at=now())
        if field == 'personal_mcp' and not skip and answer == 'later':
            data['answers'][field]['revisit_after'] = (dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=30)).isoformat(timespec='seconds')
        data.pop('conversation', None)  # An explicit intake answer resumes the conversation.
        # Only structured, explicit answers are persisted. Caller updates profile prose.
        if read(within(root, INTAKE)) != old:
            raise ValueError('Concurrent intake edit; no answer recorded')
        atomic(within(root, INTAKE), encoded(data))
    return dict(status='RECORDED', field=field, errors=[], intake=intake_status(root),
                optional_setup=('INSPECT_EXISTING_MCP' if field == 'personal_mcp' and answer == 'yes' and not skip else 'NONE'),
                next_action='Copy the explicit answer/status to its Profiles record; update maps for changed files; ask the next question')


def seed_load_target(records, config):
    """Use explicit session IDs or bounded timestamp clusters, never extraction mtimes."""
    metadata = []
    for p in records:
        text = p.read_text()
        front = text.split('---', 2)[1] if text.startswith('---\n') and text.count('---') >= 2 else ''
        session = re.search(r'^session_id:\s*[\"\']?([^\n\"\']+)', front, re.M)
        stamp = re.search(r'^created_at:\s*[\"\']?([^\n\"\']+)', front, re.M)
        parsed = None
        if stamp:
            try:
                candidate = stamp.group(1).strip()
                if 'T' in candidate:
                    parsed = dt.datetime.fromisoformat(candidate.replace('Z', '+00:00'))
                    if parsed.tzinfo is None: parsed = None
            except ValueError:
                pass
        metadata.append((p, session.group(1).strip() if session else None, parsed))
    latest = max((x for x in metadata if x[2]), key=lambda x:x[2], default=None)
    if latest and latest[1]:
        count = sum(x[1] == latest[1] for x in metadata)
        method = 'explicit session_id of newest timestamped seed'
    elif latest:
        ordered = sorted((x[2] for x in metadata if x[2]), reverse=True)
        gap = float(config.get('seed_cluster_gap_minutes', 120))
        if not 0 < gap <= 1440: raise ValueError('Seed cluster gap must be between 0 and 1440 minutes')
        count = 1
        for previous, current in zip(ordered, ordered[1:]):
            if (previous-current).total_seconds() > gap*60: break
            count += 1
        method = 'timestamp cluster estimate; not proven thread identity'
    else:
        count = 0
        method = 'no precise seed timestamps; minimum target fallback'
    return dict(target=min(25, max(10, count)), previous_session_count=count,
                method=method, relevance='assistant selects up to three additional indexed references')


PINNED_SEED = re.compile(r"(?mi)^(?:pin|pinned|retention):\s*(?:true|yes|pinned|keep)\s*$")
ROLLOVER_MANIFEST_DIR = 'Brain/.mindmake/seed-rollovers'


def is_pinned_seed(path):
    # An unreadable seed is an error, never an implicitly unpinned record.
    return bool(PINNED_SEED.search(path.read_bytes()[:4096].decode('utf-8', errors='ignore')))


def _rollover_pool(root, pool_rel):
    if pool_rel != 'Seeds' and pool_rel not in {p + '/Seeds' for p in state(root)['project_maps']}:
        raise ValueError('Rollover requires a registered seed pool: ' + str(pool_rel))
    pool = within(root, pool_rel)
    for tier in ('Short-term', 'Long-term'):
        if not within(root, pool_rel + '/' + tier).is_dir():
            raise ValueError('Pool missing Short-term or Long-term: ' + pool_rel)
    return pool


def _rollover_records(root, pool_rel):
    pool = _rollover_pool(root, pool_rel)
    records = []
    for p in (pool/'Short-term').iterdir():
        if p.name.startswith('.') or p.suffix.lower() not in ('.md', '.txt'):
            continue
        within(root, p.relative_to(root).as_posix())
        if p.is_file(): records.append(p)
    # ISO-dated seed names preserve chronology when copies reset filesystem mtimes.
    # Undated names use the same deterministic lexical order; no date is invented.
    return sorted(records, key=lambda p: p.name)


def archive_seed_destination(long_term, source):
    # Also reserve the corresponding AppleDouble name, even when absent at source.
    destination = long_term / source.name
    content_id = digest(source.read_bytes())[:10]
    sequence = 0
    while (os.path.lexists(destination) or os.path.lexists(destination.parent/('._' + destination.name))
           or os.path.lexists(destination.parent/(destination.name + '.appledouble'))):
        suffix = '' if sequence == 0 else '_' + str(sequence + 1)
        destination = long_term / f'{source.stem}__rollover_{content_id}{suffix}{source.suffix}'
        sequence += 1
    return destination


def _rollover_limits(target, cap):
    if type(target) is not int or type(cap) is not int or not 0 <= target < cap:
        raise ValueError('Rollover requires integer limits: 0 <= target < cap')


def _validate_rollover_plan(root, plan, manifest):
    if plan.get('schema_version') != 2 or plan.get('status') not in ('pending', 'complete'):
        raise ValueError('Unsupported rollover plan; preserve it for explicit recovery: ' + str(manifest))
    pool_rel = plan['scope']
    _rollover_pool(root, pool_rel)
    _rollover_limits(plan['target'], plan['cap'])
    if manifest.name != plan['batch_id'] + '.json' or not re.fullmatch(r'rollover-[A-Za-z0-9-]+', plan['batch_id']):
        raise ValueError('Invalid rollover manifest identity')
    destinations, sources = set(), set()
    for entry in plan['files']:
        for key, tier, seen in [('source', 'Short-term', sources), ('destination', 'Long-term', destinations)]:
            path = within(root, entry[key])
            if path.parent != root/pool_rel/tier or entry[key] in seen:
                raise ValueError('Invalid or duplicate rollover path: ' + entry[key])
            seen.add(entry[key])
        if entry.get('state') not in ('planned', 'creating', 'copied', 'moved') or not re.fullmatch(r'[a-f0-9]{64}', entry['sha256']):
            raise ValueError('Invalid rollover hash or state')
        if type(entry['size']) is not int or entry['size'] < 0:
            raise ValueError('Invalid rollover size')
    summary = within(root, plan['summary'])
    if summary.parent != root/pool_rel/'Long-term' or plan['summary'] in destinations or plan['batch_id'] not in summary.name:
        raise ValueError('Invalid rollover summary path')
    if digest(plan['summary_text'].encode()) != plan['summary_sha256']:
        raise ValueError('Invalid rollover summary hash')
    originals = [e for e in plan['files'] if not Path(e['source']).name.startswith('._')]
    if (not originals or plan['moved'] != len(originals) or plan['count_after'] != plan['target']
            or plan['count_before'] - plan['moved'] != plan['count_after']):
        raise ValueError('Invalid rollover counts')
    for entry in originals:
        if Path(entry['source']).name.startswith('.') or Path(entry['source']).suffix.lower() not in ('.md', '.txt'):
            raise ValueError('Invalid rollover seed path')
    sidecars = {(str(Path(e['source']).with_name('._' + Path(e['source']).name)), destination)
                for e in originals for destination in (
                    str(Path(e['destination']).with_name(Path(e['destination']).name + '.appledouble')),
                    str(Path(e['destination']).with_name('._' + Path(e['destination']).name)))}
    for entry in plan['files']:
        if Path(entry['source']).name.startswith('._') and (entry['source'], entry['destination']) not in sidecars:
            raise ValueError('Invalid rollover sidecar pairing')
    return plan


def pending_rollover_plans(root, pool_rel=None):
    folder = within(root, ROLLOVER_MANIFEST_DIR)
    if not folder.exists(): return []
    pending = []
    for manifest in sorted(folder.glob('rollover-*.json')):
        within(root, manifest.relative_to(root).as_posix())
        plan = json.loads(manifest.read_text())
        if plan.get('status') == 'complete': continue  # Historical v1 manifests remain history.
        _validate_rollover_plan(root, plan, manifest)
        if pool_rel is None or plan['scope'] == pool_rel: pending.append((manifest, plan))
    scopes = [p['scope'] for _, p in pending]
    if len(scopes) != len(set(scopes)):
        raise ValueError('Multiple pending rollover plans for one pool; explicit recovery required')
    return pending


def _rollover_bytes(root, rel, expected_hash, expected_size):
    path = within(root, rel)
    import stat
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode): raise ValueError('Rollover path is not a regular file: ' + rel)
        data = stream.read()
        after = os.fstat(stream.fileno())
    current = path.stat()
    signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if signature(before) != signature(after) or signature(after) != signature(current) or len(data) != expected_size or digest(data) != expected_hash:
        raise ValueError('Rollover bytes changed; source preserved: ' + rel)
    return data


def _sync_rollover_directory(path):
    # Directory fsync is available on Unix filesystems; Windows/ExFAT may reject it.
    if os.name == 'nt': return
    import errno
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
        try: os.fsync(fd)
        finally: os.close(fd)
    except OSError as error:
        if error.errno not in (errno.EINVAL, errno.ENOTSUP): raise


def _exclusive_rollover_write(root, rel, data):
    path = within(root, rel)
    # O_EXCL works on ExFAT; no hard link or replacing rename is required.
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    _sync_rollover_directory(path.parent)


def _check_rollover_metadata(root, entry, plan):
    source = within(root, entry['source'])
    if source.name.startswith('._') or not os.path.lexists(source):
        return
    companion = source.with_name('._' + source.name)
    paired = next((item for item in plan['files'] if root/item['source'] == companion), None)
    if os.path.lexists(companion):
        if paired is None:
            raise ValueError('Source sidecar metadata appeared after planning; preserve originals')
        _rollover_bytes(root, paired['source'], paired['sha256'], paired['size'])
    elif paired is None and sys.platform == 'darwin':
        import errno
        try:
            if (source/'..namedfork/rsrc').stat().st_size:
                raise ValueError('Native resource fork requires a metadata-aware transfer')
        except OSError as exc:
            if exc.errno not in (errno.ENOENT, errno.ENOTDIR): raise
    elif paired is not None:
        raise ValueError('Planned source sidecar is missing while primary remains; preserve originals')


def _resume_rollover(root, manifest, plan):
    _validate_rollover_plan(root, plan, manifest)
    if (root/PENDING).exists(): raise ValueError('Interrupted map transaction: run recover_map, then resume rollover')
    def save():
        atomic(manifest, encoded(plan))
        _sync_rollover_directory(manifest.parent)
    for entry in plan['files']:
        _check_rollover_metadata(root, entry, plan)
    # Preserve raw AppleDouble bytes independently of macOS-managed ._ paths.
    # Creating/unlinking a primary on ExFAT can mutate/delete its matching ._ file.
    for entry in sorted(plan['files'], key=lambda e: not Path(e['source']).name.startswith('._')):
        source, destination = within(root, entry['source']), within(root, entry['destination'])
        expected_hash, size = entry['sha256'], entry['size']
        if entry['state'] == 'moved':
            _rollover_bytes(root, entry['destination'], expected_hash, size)
            if os.path.lexists(source): raise ValueError('Rollover source reappeared; preserve it for explicit recovery')
            continue
        if entry['state'] == 'planned':
            data = _rollover_bytes(root, entry['source'], expected_hash, size)
            if os.path.lexists(destination): raise ValueError('Rollover destination appeared; source preserved: ' + entry['destination'])
            entry['state'] = 'creating'
            save()
            _exclusive_rollover_write(root, entry['destination'], data)
        elif not os.path.lexists(destination):
            if entry['state'] != 'creating': raise ValueError('Rollover destination missing; explicit recovery required')
            data = _rollover_bytes(root, entry['source'], expected_hash, size)
            _exclusive_rollover_write(root, entry['destination'], data)
        _rollover_bytes(root, entry['destination'], expected_hash, size)
        entry['state'] = 'copied'
        save()
    # All archived bytes, including sidecars, must survive primary creation before
    # the first source path is removed. A crash below resumes from copied states.
    for entry in plan['files']:
        _rollover_bytes(root, entry['destination'], entry['sha256'], entry['size'])
        if os.path.lexists(root/entry['source']):
            _rollover_bytes(root, entry['source'], entry['sha256'], entry['size'])
    for entry in plan['files']:
        if entry['state'] == 'moved': continue
        source = within(root, entry['source'])
        if os.path.lexists(source):
            _check_rollover_metadata(root, entry, plan)
            _rollover_bytes(root, entry['source'], entry['sha256'], entry['size'])
            # Verify paired sidecar backups immediately before primary removal.
            paired_source = str(source.with_name('._' + source.name).relative_to(root))
            for archived in plan['files']:
                if archived is entry or archived['source'] == paired_source:
                    _rollover_bytes(root, archived['destination'], archived['sha256'], archived['size'])
            source.unlink()
            _sync_rollover_directory(source.parent)
        entry['state'] = 'moved'
        save()
    summary = within(root, plan['summary'])
    if not os.path.lexists(summary):
        _exclusive_rollover_write(root, plan['summary'], plan['summary_text'].encode())
    _rollover_bytes(root, plan['summary'], plan['summary_sha256'], len(plan['summary_text'].encode()))
    changed = [e[key] for e in plan['files'] for key in ('source', 'destination')] + [plan['summary']]
    result = rebuild(root, changes=sorted(set(changed)))
    checked = verify(root)
    if result['status'] != 'PASS' or checked['status'] != 'PASS':
        raise ValueError('Rollover map verification failed; plan remains pending')
    for entry in plan['files']:
        _rollover_bytes(root, entry['destination'], entry['sha256'], entry['size'])
        if os.path.lexists(root/entry['source']): raise ValueError('Rollover source reappeared; plan remains pending')
    _rollover_bytes(root, plan['summary'], plan['summary_sha256'], len(plan['summary_text'].encode()))
    plan['status'] = 'complete'
    plan['completed_at'] = now()
    save()
    return dict(status='PASS', applied=True, scope=plan['scope'], count_before=plan['count_before'],
                count_after=len(_rollover_records(root, plan['scope'])), moved=plan['moved'],
                summary=plan['summary'], manifest=manifest.relative_to(root).as_posix())


def rollover_seed_pool(root, pool_rel, target=350, cap=500, force=False):
    _rollover_limits(target, cap)
    visible = _rollover_records(root, pool_rel)
    pending = pending_rollover_plans(root, pool_rel)
    if not pending and (len(visible) <= target or (len(visible) < cap and not force)):
        return dict(status='PASS', applied=False, scope=pool_rel, count=len(visible), cap=cap, due=False)
    folder = within(root, ROLLOVER_MANIFEST_DIR)
    folder.mkdir(parents=True, exist_ok=True)
    lock_rel = ROLLOVER_MANIFEST_DIR + '/pool-' + digest(pool_rel.encode())[:24] + '.lock'
    with acquire(root, lock_rel):
        pending = pending_rollover_plans(root, pool_rel)
        if pending: return _resume_rollover(root, *pending[0])
        if (root/PENDING).exists(): raise ValueError('Pending map transaction; run recover_map before rollover')
        visible = _rollover_records(root, pool_rel)
        if len(visible) <= target or (len(visible) < cap and not force):
            return dict(status='PASS', applied=False, scope=pool_rel, count=len(visible), cap=cap, due=False)
        movable = [p for p in visible if not is_pinned_seed(p)]
        move_count = len(visible) - target
        if len(movable) < move_count:
            return dict(status='FAIL', applied=False, scope=pool_rel,
                        errors=['Pinned records prevent reaching rollover target; no seeds moved'])
        batch_id = 'rollover-' + dt.datetime.now().strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex
        entries = []
        for source in movable[:move_count]:
            destination = archive_seed_destination(root/pool_rel/'Long-term', source)
            pairs = [(source, destination)]
            sidecar = source.parent/('._' + source.name)
            if os.path.lexists(sidecar): pairs.append((sidecar, destination.parent/(destination.name + '.appledouble')))
            for src, dest in pairs:
                within(root, src.relative_to(root).as_posix())
                data = src.read_bytes()
                entries.append(dict(source=src.relative_to(root).as_posix(), destination=dest.relative_to(root).as_posix(),
                                    sha256=digest(data), size=len(data), state='planned'))
        summary_rel = f'{pool_rel}/Long-term/{dt.date.today().isoformat()}_{batch_id}_memory.md'
        summary_text = (f'---\ntype: rollover-memory\nscope: {pool_rel}\nbatch_id: {batch_id}\n---\n\n'
                        f'# Seed rollover\n\nArchived {move_count} oldest unpinned records from Short-term to Long-term. '
                        f'Active records: {len(visible)} to {target}. Original bytes are preserved. '
                        f'Raw AppleDouble companions use .appledouble archive files; OS-generated ._ metadata remains separate.\n\n'
                        f'Manifest: `{ROLLOVER_MANIFEST_DIR}/{batch_id}.json`\n\n' +
                        '\n'.join(f"- `{e['source']}` → `{e['destination']}`" for e in entries) + '\n')
        plan = dict(schema_version=2, status='pending', batch_id=batch_id, scope=pool_rel, created_at=now(),
                    count_before=len(visible), count_after=target, moved=move_count, target=target, cap=cap,
                    files=entries, summary=summary_rel, summary_text=summary_text, summary_sha256=digest(summary_text.encode()))
        manifest = within(root, f'{ROLLOVER_MANIFEST_DIR}/{batch_id}.json')
        _validate_rollover_plan(root, plan, manifest)
        # Validate every source and destination before persisting the entire plan, before any move.
        for entry in entries:
            _rollover_bytes(root, entry['source'], entry['sha256'], entry['size'])
            if os.path.lexists(root/entry['destination']): raise ValueError('Rollover destination appeared before plan commit')
        if os.path.lexists(root/summary_rel): raise ValueError('Rollover summary destination appeared')
        _exclusive_rollover_write(root, manifest.relative_to(root).as_posix(), encoded(plan))
        return _resume_rollover(root, manifest, plan)

CORE_SESSION_COMPONENTS = (
    'DeepSleep', 'Cartographer', 'SignalGuard', 'ThoughtVault', 'DreamWeaver',
    'Seed Protocol', 'AI Turbo', 'Heartbeat', 'SkillMaster', 'TaskCycle',
)

def session_loading(root, config, catalog):
    """Validate and route instructions; never attest that a model has read them."""
    routes = config.get('session_components')
    expected = ['Jobs/MindMake ' + name for name in CORE_SESSION_COMPONENTS]
    errors = []
    components = []
    if not isinstance(routes, list) or any(not isinstance(row, dict) for row in routes):
        errors.append('Session component routes must be an ordered list of objects')
    elif [row.get('job') for row in routes] != expected:
        errors.append('Session component routes must contain all ten core jobs once, in startup order')
    else:
        for row in routes:
            job = row['job']
            try:
                matches = [item for item in catalog['sources'] if item.get('job') == job]
                if len(matches) != 1:
                    raise ValueError('job must have exactly one catalog entry')
                item = matches[0]
                source = row.get('source')
                if source != item['selected_pdf'] or source not in item['sha256']:
                    raise ValueError('source must match the catalog-selected PDF')
                wrapper = row.get('wrapper')
                slug = job.split('/')[-1].lower().replace(' ', '-')
                if wrapper != job + '/Skills/' + slug + '/SKILL.md':
                    raise ValueError('wrapper must match the component installation')
                order = [job + '/JOB.md', job + '/LGI_ENGINE_CONTRACT.md', wrapper, source]
                for rel in order:
                    path = within(root, rel)
                    if not path.is_file():
                        raise ValueError('missing read source: ' + rel)
                if digest(read(within(root, source))) != item['sha256'][source]:
                    raise ValueError('selected source hash differs from catalog')
                components.append(dict(job=job, source=source, wrapper=wrapper, read_order=order))
            except (ValueError, KeyError, OSError, TypeError) as exc:
                errors.append('Session component ' + job + ': ' + str(exc))
    return dict(status='BLOCKED' if errors else 'READ_REQUIRED',
                model_activation_verified=False, components=components, errors=errors,
                instruction='After GUARD and the local deployment policy, read each component read_order in order, including Cartographer; apply applicable session instructions before intake or readiness. Read only missing instructions if already present in this conversation. Recorded package reviews do not establish current-session reading. Report unreadable sources; do not claim activation from this check.')

def boot(root, allow_maintenance=True):
    config = json.loads((root/'Brain/.mindmake/runtime.json').read_text())
    for field in ('startup_order', 'required_paths'):
        if not isinstance(config.get(field), list) or any(not isinstance(rel, str) for rel in config[field]):
            raise ValueError('Runtime ' + field + ' must be a list of workspace paths')
    for rel in config['startup_order']:
        within(root, rel).read_text()
    errors = []
    locator = Path((root/'.mindmake-home').read_text().strip())
    if not locator.is_absolute():
        locator = root / locator
    if locator.resolve() != root.resolve():
        errors.append('Local home locator conflicts with explicit workspace')
    for rel in config['required_paths']:
        p = within(root,rel)
        if not p.exists(): errors.append('Missing required path: '+rel)
        elif p.is_file(): p.read_bytes()
    pending_plans = pending_rollover_plans(root)
    recovery_paths = set()
    for _, plan in pending_plans:
        for entry in plan['files']:
            if entry['state'] != 'planned' and os.path.lexists(root/entry['destination']):
                _rollover_bytes(root, entry['destination'], entry['sha256'], entry['size'])
                recovery_paths.add(entry['destination'])
                if not os.path.lexists(root/entry['source']): recovery_paths.add(entry['source'])
        if os.path.lexists(root/plan['summary']):
            _rollover_bytes(root, plan['summary'], plan['summary_sha256'], len(plan['summary_text'].encode()))
            recovery_paths.add(plan['summary'])
    map_result = verify(root, rollover_paths=recovery_paths if allow_maintenance else ())
    errors += map_result['errors']
    source_manifest = json.loads((root/'Brain/.mindmake/source-catalog.json').read_text())
    has_core_catalog = any(item.get('job') == 'Jobs/MindMake ' + name for item in source_manifest['sources'] for name in CORE_SESSION_COMPONENTS)
    loading = session_loading(root, config, source_manifest) if has_core_catalog or config.get('require_setup_review') or 'session_components' in config else None
    if loading: errors.extend(loading['errors'])
    registered_jobs = set(state(root)['project_maps'])
    declared_jobs = {item['job'] for item in source_manifest['sources'] if 'job' in item}
    if not declared_jobs.issubset(registered_jobs):
        errors.append('Source catalog has unregistered jobs; finish product registration')
    for item in source_manifest['sources']:
        for rel, expected in item['sha256'].items():
            if digest(read(within(root,rel))) != expected: errors.append('Source changed or missing: '+rel)
    profiles = json.loads((root/'Brain/Profiles/profiles.json').read_text())
    for role, profile in profiles.items():
        path = within(root, profile['path'])
        if not path.is_file():
            errors.append('Missing profile for '+role+': '+profile['path'])
        else:
            path.read_text()
        if profile['status'] not in ('pending','confirmed','declined'):
            errors.append('Unknown profile status for '+role)
    pending = [k for k,v in profiles.items() if v['status']=='pending']
    warnings = []
    rollover_results = []
    census = {}
    dreams = sum(1 for p in (root/'Seeds/Dreams').iterdir() if p.is_file() and not p.name.startswith('.'))
    if dreams > 30: warnings.append('Dreams exceed advisory 30-record threshold; no records changed')
    todo = (root/'TODO.md').read_text()
    open_tasks = len(re.findall(r'^\s*- \[ \]', todo, re.M))
    completed_tasks = len(re.findall(r'^\s*- \[[xX]\]', todo, re.M))
    if completed_tasks: warnings.append('TODO includes completed items; review without automatic removal')
    age_days = (dt.datetime.now().timestamp()-(root/'TODO.md').stat().st_mtime)/86400
    if open_tasks and age_days > 30: warnings.append('TODO has open items and has not changed for over 30 days; review suggested')
    lists = {}
    for name in ['wonder','hobby']:
        data = json.loads((root/f'Brain/Profiles/{name}-list.json').read_text())
        lists[name] = {'items':len(data['items']),'status':data['status']}
        for item in data['items']:
            if not all(k in item for k in ['text','created_at','last_reviewed_at']):
                warnings.append(name+' item lacks persistence metadata')
            if name == 'wonder' and ('score' not in item or not isinstance(item['score'],(float,int))):
                warnings.append('Wonder item lacks a numeric review score')
    incoming = []
    known = {path for s in source_manifest['sources'] for path in s['sha256']}
    for folder in [root,root/'pdfs']:
        if not folder.is_dir():
            continue
        for p in folder.iterdir():
            if p.is_file() and p.suffix.lower() in ('.pdf','.docx') and not p.name.startswith('.') and p.relative_to(root).as_posix() not in known:
                incoming.append(p.relative_to(root).as_posix())
    if incoming: warnings.append('Unregistered source candidates: '+', '.join(incoming))
    knowledge = None
    if (root/'Brain/tools/knowledge.py').is_file() and not errors:
        import importlib.util
        spec = importlib.util.spec_from_file_location('mm_knowledge',root/'Brain/tools/knowledge.py')
        module = importlib.util.module_from_spec(spec)
        previous_bytecode = sys.dont_write_bytecode
        try:
            sys.dont_write_bytecode = True
            spec.loader.exec_module(module)
            knowledge = module.status(root)
        finally:
            sys.dont_write_bytecode = previous_bytecode
        if knowledge['pending']: warnings.append(str(len(knowledge['pending']))+' Wiki sources need processing or repair')
    intake = intake_status(root) if config.get('require_intake_state') and not errors else None
    personal_mcp = {'choice':'pending','connection':'UNVERIFIED'}
    if intake:
        choice = json.loads(within(root, INTAKE).read_text())['answers'].get('personal_mcp', {})
        personal_mcp['choice'] = choice.get('answer') or choice.get('status', 'pending')
        personal_mcp['revisit_after'] = choice.get('revisit_after')
        if personal_mcp['choice'] == 'yes':
            personal_mcp['launch_bundle_exists'] = within(root, 'Brain/MCP/generated/connection.json').is_file()
            warnings.append('Personal MCP opted in: finish build/host connection and verify live tools; folder checks cannot establish activation')
    assistant = None
    if not errors and within(root, 'Brain/.mindmake/assistant.json').is_file():
        c = json.loads(within(root, 'Brain/.mindmake/assistant.json').read_text())
        assistant = dict(enabled=c.get('enabled', False), connections=c.get('connections', {}),
                         scheduler=c.get('scheduler', {}), sms_opted_in=c.get('sms', {}).get('consented', False),
                         evidence='Saved configuration only; run helper status and verify actual host and provider operations')
    review = setup_review(root) if config.get('require_setup_review') and not errors else None
    auto_rollover = config.get('auto_seed_rollover', True)
    rollover_cap = config.get('seed_rollover_cap', 500)
    rollover_target = config.get('seed_rollover_target', 350)
    _rollover_limits(rollover_target, rollover_cap)
    pending_scopes = {plan['scope'] for _, plan in pending_plans}
    all_pools = ['Seeds'] + [j + '/Seeds' for j in state(root)['project_maps']]
    # Validate every pool before allowing the first pool to change.
    preflight_pools = {pool: _rollover_records(root, pool) for pool in all_pools}
    for path in preflight_pools['Seeds']:
        path.read_text()  # Do not archive before detecting an unreadable startup seed.
    if config.get('adaptive_seed_loading'): seed_load_target(preflight_pools['Seeds'], config)
    else: min(25, max(10, config.get('last_thread_seed_count', 10)))
    for rel_pool in all_pools:
        records_in_pool = preflight_pools[rel_pool]
        due = len(records_in_pool) >= rollover_cap
        resume = rel_pool in pending_scopes
        if (resume or (auto_rollover and due)) and allow_maintenance and not errors:
            result = rollover_seed_pool(root, rel_pool, target=rollover_target, cap=rollover_cap)
            rollover_results.append(result)
            errors.extend(result.get('errors', []))
        elif resume or due:
            warnings.append(rel_pool + ': rollover pending or due; maintenance was not performed')
        for tier, limit in [('Short-term', 450), ('Long-term', 1000)]:
            folder = within(root, rel_pool + '/' + tier)
            n = sum(1 for f in folder.iterdir() if f.is_file() and not f.is_symlink() and not f.name.startswith('.') and f.suffix.lower() in ('.md', '.txt'))
            census[rel_pool + '/' + tier] = n
            if n >= limit: warnings.append(f'{rel_pool}/{tier}: {n} records; retention review due')
    # Revalidate navigation after all maintenance, then select surviving seed paths.
    final_map = verify(root)
    errors.extend(e for e in final_map['errors'] if e not in errors)
    records = sorted(_rollover_records(root, 'Seeds'), reverse=True)
    seed_target = seed_load_target(records, config) if config.get('adaptive_seed_loading') else {'target': min(25,max(10,config.get('last_thread_seed_count',10))), 'method':'legacy configured target'}
    selected = records[:seed_target['target']]
    for p in selected: p.read_text()
    if knowledge is not None:
        knowledge = module.status(root)  # Refresh navigation-dependent status after maintenance.
    next_step = (('Follow INTAKE.md: ' + intake['next_action'] + ('; finish pending source reviews' if review and review['pending'] else '')) if intake else ('Follow INTAKE.md: finish pending source reviews' if review and review['pending'] else 'Follow INTAKE.md')) if (pending or (intake and intake['pending']) or (review and review['pending'])) else 'Continue authorized work; verify current-session behavior'
    if loading: next_step = 'Read and apply session_loading.components in order before intake or readiness; then ' + next_step
    if errors: next_step = 'Repair structural errors before dependent work'
    return dict(status='FAIL' if errors else 'SETUP_REVIEW_PENDING' if review and review['pending'] else 'READY_INTAKE_PENDING' if pending or (intake and intake['pending']) else 'READY',
                intake=intake, knowledge=knowledge, personal_mcp=personal_mcp, personal_assistant=assistant,
                setup_review=review, seed_rollover=rollover_results if rollover_results else {'status':'not performed', 'maintenance_allowed':allow_maintenance, 'pending_pools':sorted(pending_scopes), 'cap':rollover_cap}, session_components=config.get('session_components', []),
                next_action=next_step, session_loading=loading,
                checked_at=now(),root=str(root),jobs=len(state(root)['project_maps']),
                startup_files_verified=config['startup_order'],pending_profiles=pending,
                shared_seed_count=len(records),seed_read_order=[p.relative_to(root).as_posix() for p in selected],
                seed_target=seed_target,
                seed_census=census,dream_records=dreams,profile_lists=lists,
                task_hygiene={'open':open_tasks,'completed':completed_tasks,'execution':'none'},
                seed_loading='Available recent shared records; assistant applies relevance and identity ordering after reading',
                incoming_sources=incoming,warnings=warnings,errors=errors,
                coverage='Local structure, registered source hashes, navigation, readable startup files and available shared seeds',
                limitations=['Downloads can be processed on-demand via check_downloads or with the optional background daemon','No scheduled TaskCycle, idle DreamWeaver, timed Heartbeat or guaranteed prompt injection','File checks do not prove model activation or behavioral acceptance'])

def create_new_job(root, name, purpose=None):
    if not name or not name.strip():
        raise ValueError('Job name cannot be empty')
    name = name.strip()
    if any(c in name for c in ('/', '\\', '..')) or name.startswith(('.', '_')):
        raise ValueError('Invalid job name: ' + name)
    job_dir = root / 'Jobs' / name
    if job_dir.exists():
        raise ValueError('Job already exists: Jobs/' + name)
    seeds_short = job_dir / 'Seeds' / 'Short-term'
    seeds_long = job_dir / 'Seeds' / 'Long-term'
    research_dir = job_dir / 'Research'
    notes_dir = job_dir / 'Notes'
    for d in (seeds_short, seeds_long, research_dir, notes_dir):
        d.mkdir(parents=True, exist_ok=True)
    p_desc = purpose.strip() if purpose and purpose.strip() else 'User project workspace.'
    job_md_content = (
        f'# {name}\n\n'
        f'Purpose: {p_desc}\n\n'
        '- [Seed policy](Seeds/README.md)\n'
        '- [Workspace folder map](../../FOLDER_MAP.md)\n\n'
        'Type: User Project.\n\n'
        '## Sync Rule\n'
        '- Root `TODO.md` tracks global cross-job priorities and blockers.\n'
        f'- This file tracks active tasks and decisions for {name}.\n\n'
        '## Active Work (NOW)\n'
        f'- [ ] Define initial scope and milestones for {name}\n\n'
        '## Upcoming (NEXT)\n'
        '- [ ] Plan first deliverable\n\n'
        '## Seeds & Continuity\n'
        f'- Active session seeds: `Jobs/{name}/Seeds/Short-term/`\n'
        f'- Archived records: `Jobs/{name}/Seeds/Long-term/`\n\n'
        '<!-- MINDMAKE FOLDER MAP BEGIN -->\n'
        '<!-- MINDMAKE FOLDER MAP END -->\n'
    )
    atomic(job_dir / 'JOB.md', job_md_content.encode())
    seeds_readme_content = (
        f'# {name} Seeds\n\n'
        f'Continuity and session memory for the {name} project.\n\n'
        '- `Short-term/`: Active session records and recent decisions.\n'
        '- `Long-term/`: Archived project records.\n'
    )
    atomic(job_dir / 'Seeds' / 'README.md', seeds_readme_content.encode())
    map_result = rebuild(root, changes=['Jobs/' + name])
    return dict(status='CREATED', job='Jobs/' + name,
                paths=['Jobs/' + name + '/JOB.md', 'Jobs/' + name + '/Seeds/README.md'],
                map_status=map_result.get('status'),
                next_action='Job Jobs/' + name + ' created and registered in folder map.')

def check_downloads(root, force=False):
    import importlib.util
    spec = importlib.util.spec_from_file_location('downloads_watch', root / 'Brain/tools/downloads_watch.py')
    dw = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(dw)
    raw = dw.scan_once(root, force=force)
    files = raw.get('files', {})
    filed, needs_review, downloading = [], [], []
    for path, info in files.items():
        st = info.get('status')
        if st == 'filed':
            filed.append({'file': path, 'destination': info.get('destination')})
        elif st == 'needs_review':
            needs_review.append({'file': path, 'reason': info.get('reason')})
        elif st == 'downloading':
            downloading.append({'file': path})
    inbox = [p.name for p in (root / 'Downloads').iterdir() if p.is_file() and p.name != 'INDEX.md' and not p.name.startswith('.')]
    return dict(
        status='PASS',
        inbox_count=len(inbox),
        inbox_files=inbox,
        filed=filed,
        needs_review=needs_review,
        downloading=downloading,
        last_scan=raw.get('last_scan'),
        daemon_running=dw.status(root).get('running', False),
        next_action='All stable files processed' if not needs_review else f'{len(needs_review)} file(s) in Downloads need review; classify destination by purpose'
    )

def file_download(root, filename, destination):
    import importlib.util
    spec = importlib.util.spec_from_file_location('downloads_watch', root / 'Brain/tools/downloads_watch.py')
    dw = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(dw)
    return dw.file_download(root, filename, destination)

def tutorial_status(root):
    """Read-only file readiness; conversational acceptance is never inferred."""
    catalog = json.loads(within(root, 'Brain/.mindmake/source-catalog.json').read_text())
    shipped_jobs = {item['job'] for item in catalog['sources']}
    user_jobs = sorted(set(state(root)['project_maps']) - shipped_jobs)
    target_job = user_jobs[0] if user_jobs else None
    first_seed = None
    if target_job:
        st_dir = within(root, target_job + '/Seeds/Short-term')
        if st_dir.is_dir():
            for path in sorted(st_dir.iterdir()):
                if path.is_symlink() or not path.is_file() or path.name.startswith('.') or path.suffix.lower() not in ('.md', '.txt'):
                    continue
                # Check actual bytes, without treating nonempty text as semantic proof.
                if path.read_bytes().strip():
                    first_seed = path.relative_to(root).as_posix()
                    break
    map_result = verify(root) if first_seed else None
    ready = bool(map_result and map_result.get('status') == 'PASS')
    steps = [
        dict(step=1, name='Create a project folder',
             command='python3 Brain/tools/mindmake.py new_job --name "My First Project" --purpose "Learning MindMake"',
             status='PASS' if target_job else 'PENDING',
             detail='Registered project: ' + target_job if target_job else 'Choose a project name and purpose.'),
        dict(step=2, name='Record a decision and next action',
             command='Write a dated seed in the selected project Seeds/Short-term folder.',
             status='PASS' if first_seed else 'PENDING',
             detail='Nonempty seed found: ' + first_seed if first_seed else 'No nonempty seed found. Record a real decision; do not create filler.'),
        dict(step=3, name='Check file readiness',
             command='python3 Brain/tools/mindmake.py check_map',
             status='PASS' if ready else 'PENDING',
             detail='Folder maps verify. This does not establish correct or complete seed content.' if ready else 'Update and verify the affected maps.'),
        dict(step=4, name='Verify in a fresh conversation',
             command='Open a fresh conversation in this workspace and ask it to resume the selected project.',
             status='PENDING',
             detail='Observe retrieval of the recorded decision and unresolved next action without supplying the answers again. Record the result and host-context limitations; a boot check is not this test.'),
    ]
    current = 4 if ready else 3 if first_seed else 2 if target_job else 1
    return dict(status='FILESYSTEM_READY' if ready else 'IN_PROGRESS',
                current_step=current, completed_count=sum(s['status'] == 'PASS' for s in steps),
                total_steps=4, steps=steps, project=target_job, seed=first_seed,
                conversational_acceptance='PENDING',
                map_errors=map_result.get('errors', []) if map_result else [],
                message='Project files are ready. Check the saved decision in a fresh conversation.' if ready else steps[current-1]['detail'])



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['boot', 'check_map', 'update_map', 'rebuild_map', 'recover_map', 'record_review', 'record_intake', 'intake_status', 'defer_intake', 'resume_intake', 'new_job', 'check_downloads', 'file_download', 'rollover_seeds', 'tutorial'])
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--paths', nargs='+')
    parser.add_argument('--field')
    parser.add_argument('--answer')
    parser.add_argument('--skip', action='store_true')
    parser.add_argument('--job')
    parser.add_argument('--name')
    parser.add_argument('--purpose')
    parser.add_argument('--evidence')
    parser.add_argument('--fingerprint')
    parser.add_argument('--reason')
    parser.add_argument('--force', action='store_true')
    parser.add_argument('--file')
    parser.add_argument('--destination')
    parser.add_argument('--pool')
    parser.add_argument('--target', type=int, default=350)
    parser.add_argument('--mode', choices=['full','review'], default='full', help='Review boot routes registered commitments only')
    parser.add_argument('--no-maintenance', action='store_true', help='Read-only boot: do not start or resume seed rollover')
    args = parser.parse_args()
    root = args.root.resolve()
    try:
        if args.mode == 'review':
            if args.operation != 'boot' or args.job:
                raise ValueError('Review mode requires boot and cannot be combined with --job')
            from mindmake_review import boot as review_boot
            result = review_boot(root)
        elif args.operation == 'record_intake': result = record_intake(root, args.field, args.answer, args.skip)
        elif args.operation == 'intake_status': result = intake_status(root)
        elif args.operation in ('defer_intake', 'resume_intake'): result = set_intake_conversation(root, args.operation == 'defer_intake', args.reason)
        elif args.operation == 'record_review': result = record_setup_review(root, args.job, args.evidence, args.fingerprint)
        elif args.operation == 'new_job': result = create_new_job(root, args.name or args.job, args.purpose)
        elif args.operation == 'check_downloads': result = check_downloads(root, args.force)
        elif args.operation == 'file_download': result = file_download(root, args.file, args.destination)
        elif args.operation == 'tutorial': result = tutorial_status(root)
        elif args.operation == 'rollover_seeds':
            if args.pool:
                result = rollover_seed_pool(root, args.pool, target=args.target, cap=500, force=args.force)
            else:
                all_pools = ['Seeds'] + [p+'/Seeds' for p in state(root)['project_maps']]
                results = [rollover_seed_pool(root, p, target=args.target, cap=500, force=args.force) for p in all_pools]
                result = dict(status='FAIL' if any(r.get('errors') for r in results) else 'PASS', pools=results, errors=[e for r in results for e in r.get('errors', [])])
        elif args.operation == 'boot': result = boot(root, allow_maintenance=not args.no_maintenance)
        elif args.operation == 'check_map': result = verify(root)
        elif args.operation == 'recover_map': result = recover(root)
        else: result = rebuild(root, args.paths if args.operation == 'update_map' else None)
    except (OSError, ValueError, KeyError, TypeError) as e:
        result = dict(status='FAIL', errors=[str(e)], coverage='incomplete')
    print(json.dumps(result, indent=2))
    return 1 if result.get('errors') else 0

if __name__ == '__main__':
    sys.exit(main())
