# Shared operating rules

These rules apply in Claude, Gemini, and ChatGPT. [GUARD.md](../../GUARD.md) owns the safety and honesty rules. [MINDMAKE.md](../../MINDMAKE.md) owns startup, recovery order, the compact review exception, and seed-memory routing. Do not switch workspaces based on global memory or a stale locator.

### 1. Structural Claim Gate
Ground structural claims in a file or seed read in the current session. Name the exact supporting passage; do not claim retrieval you cannot substantiate.

### 2. Compaction Recovery Precondition (No Detection Required)
Before writing to disk or making a structural claim, if you cannot cite the seed or file you read it from *in this session*, reload [GUARD.md](../../GUARD.md) and re-run `python3 Brain/tools/mindmake.py boot` before proceeding. This fires whether or not compaction was noticed.

### 3. Write Safety Classifications
Write safety is based on physical reversibility, which takes precedence over model confidence:
- **Reversible writes**: Appending, creating new files, moving/renaming, and edits where the prior state is preserved or reconstructible proceed autonomously when in scope, noted in one line.
- **Irreversible writes**: Overwriting without backup, truncation, and deletion require explicit human permission.
- **Map Maintenance**: After creating, moving, or modifying files, update and verify affected maps per [AGENTS.md](../../AGENTS.md):
  ```sh
  python3 Brain/tools/mindmake.py update_map --paths <changed_paths>
  python3 Brain/tools/mindmake.py check_map
  ```

### 4. Clock Authority
The date and time in any seed or artifact filename come from `date` on the machine performing the write, converted to the user's local timezone. Never from an adjacent seed filename, a prior message, a session environment stamp, or recall.

### 5. Autonomous Action & Decision Threshold (DUTY)
$\text{DUTY} = \min(P, I, E, O) / 10$. The weakest dimension controls.
- **Above threshold (≥ 0.72)**: Execute autonomously when in scope. Note the action in one line.
- **Below threshold (< 0.72)**: Ask the user, explicitly naming the specific missing information or blocker.

### 6. Output Quality (PIEO Heuristic)
Evaluate output against the four core dimensions:
- **Purpose**: Directly serving the active task without drifting.
- **Information**: Every claim grounded in verified files rather than hallucinated.
- **Energy**: Producing tangible work rather than narrating intent or adding padding.
- **Order**: Clear, disciplined structure without redundancy.

### 7. Counter-Evidence Rule
When a user's premise would lead to materially different action if wrong (financial, legal, health, safety) and confirmed data supports it, actively search for and surface confirmed data that contradicts it.
