# MINDMAKE workspace instructions

## Helper installation rule

Every MindMake helper (PPI), tool and reference has its own job folder.

- Install every helper, tool and reference in its own `Jobs/<Name>/` folder.
- Each installation includes `JOB.md`, `LGI_ENGINE_CONTRACT.md`, `Products/`, `Skills/<slug>/SKILL.md`, `Research/`, `Seeds/Short-term/`, `Seeds/Long-term/`, and `Seeds/README.md`.
- Keep the PPI source (readable `.md`), its PDF and its tests in `Products/`. The `.md` is the selected source; skill wrappers route work and do not replace it. (`LGI_ENGINE_CONTRACT.md` keeps its X1.6 filename; it holds the PPI source contract.)
- Read and activate the product in the working conversation before precision work. A file's presence is not proof of activation or behavioral acceptance.
- Register each skill in the existing [skills.md](Brain/SKILLS.md). Update only that product's entry and preserve unrelated entries. Do not duplicate existing entries, installation seeds, or folders.
- Verify existing installations before reporting them complete. Preserve user work and report missing parts accurately.
- Use the actual filesystem and source files to verify installation. Distinguish file checks from live model tests.

No product type is exempt from having its own folder. Apply it to installations and revisions within the user's authorized scope; it does not authorize an unrelated bulk rewrite of the product catalog.

## User project sandboxes

The `Jobs/` directory houses both installed MindMake helpers and customer project sandboxes.
- For customer projects (such as consulting clients, books, research, or personal trackers), scaffold an isolated sandbox using:
  `python3 Brain/tools/mindmake.py new_job --name "<Project Name>" [--purpose "<Description>"]`
- This creates `Jobs/<Project Name>/` with its own `JOB.md`, `Research/`, `Notes/`, and local `Seeds/Short-term/` and `Seeds/Long-term/` pools, and registers it across all workspace maps.
- User projects follow the same local map and sync conventions as helper packages, but are user-directed rather than internal engine components.

## Workspace boundary

This workspace is the extracted folder containing this file. Its .mindmake-home locator is relative to this root. Use the included Jobs product copies and never redirect customer work to the authoring machine or an old Cartographer path.

## Folder map maintenance

Use [FOLDER_MAP.md](FOLDER_MAP.md) as the single workspace folder map, registered by `Brain/.mindmake/folder-map.json`. The registry is navigation metadata, not workspace-location authority. Every helper, tool and reference keeps its own Jobs folder.

**Completion rule:** After creating, importing, moving, renaming, archiving, or deleting anything in MINDMAKE, update and verify the affected maps before reporting completion. If map updating fails, report the work as incomplete.

Apply this rule to all files and folders, not only helper installations. Verify the resulting paths, update the affected root or job map and its registry metadata, and update Jobs/INDEX.md or Brain/SKILLS.md when their entries are affected. Verify that new links resolve and that moved or deleted paths are no longer presented as current.

Keep generated navigation within `<!-- MINDMAKE FOLDER MAP BEGIN -->` and `<!-- MINDMAKE FOLDER MAP END -->`, preserve surrounding authored text, and commit the folder-map registry after verifying changed maps. Reuse each job's JOB.md as its project map. Report checked scope and exclusions; do not claim a full inventory or continuous watcher from a scoped map update.

## Startup and recovery

On load, a new working session or recovery, follow [MINDMAKE.md](MINDMAKE.md). Read GUARD.md and the local deployment policy first, run the installed boot check, then read and apply the ordered `session_loading.components`, including their selected product sources and Cartographer, before intake or readiness. Recorded package review is not current-session loading. Then read the available shared seeds and current task context. Do not mistake a startup-file check for model activation. Brain/Profiles are resolved through Brain/Profiles/INDEX.md; pending intake is explicit. Follow [INTAKE.md](INTAKE.md): first load must begin the first unanswered intake question and reconcile installed setup against every selected PPI source. A pending status is a next action, not a stopping point.

The installed shared host stores its own seeds in Seeds/Short-term and Seeds/Long-term. Each helper retains its job-specific pools. [Brain/governance/WORKSPACE_POLICY.md](Brain/governance/WORKSPACE_POLICY.md) is the common local setup amendment linked from all source contracts and wrappers. Seed pools automatically roll over from Short-term to Long-term upon reaching 500 records (target: 350).

After confirmed changes, run `python3 Brain/tools/mindmake.py update_map --paths <changed paths>` (include old/new paths for moves), then `python3 Brain/tools/mindmake.py check_map`. Use `rebuild_map` for explicit full reconstruction. If a source is newly dropped into this folder, verify its identity and create or complete its own Jobs package under the existing installation rule, register its skill and source, then update maps. Do this during authorized load/install/repair work; there is no filesystem watcher.

## X.1 areas

Follow [Brain/FILING.md](Brain/FILING.md). Maintain Brain/INDEX.md, Jobs/INDEX.md, Jobs/FILES.md, Wiki/INDEX.md and Downloads/INDEX.md through the map helper. Keep Wiki lazy; operational helpers remain Jobs packages.

## X.1 knowledge processing

Follow [Wiki intake and retrieval](<Brain/WIKI_WORKFLOW.md>) for source registration, separate retrieval seeds and Wiki pages, evidence checks, retry, and optional Journal/Contacts jobs. A filed download is not a processed source. Use `python3 Brain/tools/knowledge.py status` from the workspace root to check the queue.

Optional intake: follow [Personal MCP](Brain/PERSONAL_MCP.md). An explicit yes starts the builder job; no/later/skip preserve ordinary use. Report optional setup and live tool availability separately from folder readiness.

## Personal assistance and connections

At intake or resumed assistance, apply [Personal Assistant](Brain/PERSONAL_ASSISTANT.md) and read [the capability guide](Brain/CAPABILITIES.md). Offer relevant account connections with their benefits, reuse existing permissions and verify needed operations. Keep one useful next action. Configuration is not evidence of background operation or SMS delivery.

## Intake checkpoint

Follow [the intake checkpoint](INTAKE.md) before handing back a turn with unfinished setup. Read `intake_status`: answer side questions and return to the pending setup question unless the user explicitly deferred. Do not infer consent or completed intake from existing tools, host memory, or a request to start work.

## Explicit compact review exception

For an authorized scheduled commitment review, `boot --mode review` and [the review procedure](Brain/tools/FOLLOW_THROUGH.md) replace the ordinary full startup, compaction recovery and intake checkpoint above. Read the required governance and registered due-source routes; do not expand into unrelated queues, seeds or intake questions. Ordinary customer load and project work retain the full setup procedure. This exception performs no maintenance and grants no task or native-service permission.

## Seed Memory Protocol 1

Read `Brain/tools/SEED_MEMORY_PROTOCOL.md` from the verified workspace root before substantive work and after recovery. It is the shared deployment implementation of the Seed Protocol helper. At task entry/change/recovery, check relevant Short-term and Long-term seeds using the exact conversation ID, stable event ID, explicit job scope and topic query. Read the returned content before dependent decisions. At each substantive response, check whether the current task evidence or unsaved consequential work changed. Report meaningful work before writing its seed, then reopen/hash it and record only the pending change IDs actually covered. Required continuity saves override older distant checkpoints and caps; do not create filler seeds.

Use the existing connected `mindmake_memory_check`, `mindmake_memory_read`, `mindmake_memory_saved` and `mindmake_memory_status` tools when exposed and opted in, or `python3 -B Brain/tools/mindmake_seed_memory.py --root <verified-workspace>` with check/read/save/status. Do not enable a connection or create a schedule for this protocol. An uncalled thread is UNCOUNTED; returned bytes do not prove comprehension. If handlers remain old, use the CLI until that connection is reconnected. Preserve source authority, ownership and exact supersession history; unresolved retrieval remains visible. Direct file access and bypassed turns are unobserved.
