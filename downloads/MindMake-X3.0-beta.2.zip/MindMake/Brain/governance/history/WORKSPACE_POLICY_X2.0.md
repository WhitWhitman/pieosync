# Local MindMake deployment policy

**X2.0 note:** every package is now a PPI. Its selected source is the readable `.md` in `Products/`, with a PDF of the same content beside it. Wording below about a selected PDF, DOCX copies or LGIs refers to that PPI source. X1.x amendment headings are kept as history.


Effective September 5, 2026 for the extracted MindMake X workspace, as the packaged shared deployment policy. This is the shared installation amendment for all 19 local packages. Read it before source instructions about setup, storage, startup or testing. It resolves local deployment conflicts; it does not claim to revise the preserved PDF/DOCX publications.

| Conflict in source documents | Active local resolution |
|---|---|
| Tools/enhancers/references exempt from folders; Seed Capsule points to Cartographer's Jobs/LGI/Finished/MindMake | Every helper, tool and reference has its own Jobs/<name> folder. Preserve sources in that folder's Products. (X2.0: Component M, the separate manuals and the acceptance battery are retired; the Guide and each helper's own tests replace them.) Never route this installation into Cartographer. |
| Source-specific instructions omit installation seeds or skills | Each package keeps its existing wrapper and any installation seed it has; verify before creating anything, avoid duplicates. X2.0 ships without author installation seeds by design; don't create filler seeds to satisfy this row. Source workflow type remains intact. |
| Missing host seed store | Shared conversation, host governance and collaborator continuity go in root Seeds/Short-term; archives go in root Seeds/Long-term. Job-only work goes in that job's Seeds. Index cross-cutting material instead of copying seeds. |
| Seven seeds, 10–15 seeds, or adaptive 10–25 | Use ThoughtVault's later adaptive rule: clamp the previous thread's saved-seed count to 10–25, then up to three relevant indexed references. Load only records that actually exist. Explicit all-source audits can exceed the retrieval budget. |
| Hardcoded author profile names from X1.x, Pete/Jess, or lowercase profiles | Resolve profiles through Brain/Profiles/profiles.json and INDEX.md. Intake starts pending. User name, work, relationships, goals and persona are never inferred from app metadata. Do not create duplicate case variants. |
| ThoughtVault says four seed sections but lists three | Use four: What was done, Key decisions, Open questions, Next steps; include name, description, type and date metadata, about 200 words where useful. |
| Short-term rollover varies across older PDF and installed plugin | Local policy: warn at 450; automatic rollover runs at boot or on demand at 500, moving the oldest unpinned records down to 350 into Long-term. A content-hashed plan in Brain/.mindmake/seed-rollovers/ precedes movement; pending plans resume below the trigger. Preserve verified archive bytes before removing a source, retain a rollover memory, and verify maps before completion. Refuse conflicting changes; do not claim a disk-wide guarantee. |
| Long-term 1,000 and Dreams 30 retention thresholds | Advisory checks. Preserve records; no automatic deletion or day-based pruning. |
| Automatic dreams, background tasks, timed Heartbeat, universal re-injection | On-demand/session workflow only. The Downloads watcher is a separate installed capability; no component timer, scheduler or guaranteed model activation is supplied. DreamWeaver requires actual source seeds (at least ten, or fewer only when the user explicitly chooses a thin dream, which is labeled thin); no fabricated dreams or hobby/wonder records. |
| ThoughtVault task quality floor 0.5 versus TaskCycle 0.72 | TaskCycle owns its task-cycle review: use DUTY = min(P, I, E, O) / 10; 0.72 is its task review threshold, not an execution permission. Maximum 20 tasks and depth three per authorized cycle. Read TODO at boot, then follow the user's active request. |
| Seed Capsule acceptance probes forbid all installation writes | During explicitly authorized installation/repair, own-folder, wrapper, registry and seed writes are expected once. During ordinary capsule evaluation, no unsolicited installation writes. Source body governs capsule content; stale Cartographer paths fail local routing. This amendment is not a claim that the original model battery passed. |
| Multiple map names and manual updates omitted | FOLDER_MAP.md is the single root map. JOB.md is each job map. Map every completed local mutation; verify links and commit registry last. AGENTS.md owns this completion requirement. |

Sources remain byte-preserved and versioned in [the source catalog](../.mindmake/source-catalog.json). In X2.0 the package's PPI `.md` is its selected source; the PDF beside it holds the same content for reading. For precise published wording inspect the source; apply this local amendment for installation and host behavior.

Existing job setup notes describe the original installation event. They are history; the shared host's current startup instructions are [MINDMAKE.md](<../../MINDMAKE.md>). Unknowns and unrun behavior tests remain unknown.

## X.1 first-run correction

[INTAKE.md](<../../INTAKE.md>) supplies the onboarding procedure and conversational handoff. All 19 shipped packages have review entries under Brain/governance/setup-reviews/ and Brain/.mindmake/setup-review.json; boot reports any that are still pending. Initiate the first unanswered intake question after structural checks pass, without waiting for the user to request intake again. File checks, source-review attestations, profile completion and live behavior are separate states.

A MindMake load request invokes the core startup/session sequence and intake through MINDMAKE.md; it need not explicitly name every component. This supersedes explicit-name-only wrapper triggers for that workflow. Apply applicable session checks after reading the source; technical maintenance, persona selection and unrelated tasks retain their stated authorization boundaries.

Companion Component S correction: the existence of Brain/Profiles/companion.md does not establish onboarding. Check explicit intake state and confirmed/declined profile status; blank or pending placeholders always remain pending.

*(X1.x history: the LGI Architect battery is retired in X2.0; PPI Architect has its own tests.)* Architect battery Probe 9 correction: the preserved current Architect implementation requires one continuous paragraph. For X.1 local acceptance, evaluate that format instead of the stale probe expectation of labeled output sections. The battery original is preserved; a pass under this amendment is not a pass of the unmodified battery.

TaskCycle uses DUTY, not normalized PSI. With P=I=E=O=8, DUTY is 0.8. With P=I=E=10 and O=4, DUTY is 0.4. Do not substitute multiplication when applying the 0.72 gate.

X.1 adaptive loading: count the latest explicit session_id among seeds with timezone-qualified created_at timestamps; otherwise estimate a cluster using a configurable 120-minute gap. ThoughtVault does not specify a cluster gap, so this is a local heuristic, not proof of thread identity. With no precise timestamps use the minimum target of ten and load only available seeds. Never use file modification times, which change during copying. New session seeds should include session_id and timezone-qualified created_at metadata. Semantic relevance and up to three additional indexed references remain the assistant’s responsibility.

Downloads can be processed on demand in session via `python3 Brain/tools/mindmake.py check_downloads`, or continuously via the optional [Downloads watcher](../DOWNLOADS_WATCHER.md).

## X.1 knowledge processing

Follow [Wiki intake and retrieval](<../WIKI_WORKFLOW.md>) for source registration, separate retrieval seeds and Wiki pages, evidence checks, retry, and optional Journal/Contacts jobs. A filed download is not a processed source. Use `python3 Brain/tools/knowledge.py status` from the workspace root to check the queue.

## Personal MCP intake

The [Personal MCP procedure](../PERSONAL_MCP.md) defines optional consent, benefits at every offer, 30-day Later follow-up and bounded construction. The starter MCP reports context and recorded events; GUARD remains guidance and Cartographer performs retrieval and reasoning. It does not independently prove compliance. Runtime/session state exclusions are explicit; mapped source and setup files remain subject to normal maintenance.

## Proactive assistance amendment

[Personal Assistant](../PERSONAL_ASSISTANT.md) owns the shared connection and follow-through procedure. Cartographer routes direction and context; SkillMaster inventories capabilities and dependencies; TaskCycle executes within scope; ThoughtVault records continuity; DeepSleep maintains health and maps. GUARD governs evidence and authorization. This amendment binds packaged deployment where older source wording implies blanket access, automatic activation or guaranteed compliance. It does not create a background process.

## X1.5 onboarding amendment

The [intake procedure](../../INTAKE.md) governs setup order, explicit deferral and resumption across all packaged LGIs. It supersedes source or wrapper wording that would let useful work silently terminate intake, put companion selection ahead of MCP/connections, or build a duplicate MCP solely because the user opted in. Keep all confirmed answers. Read-only status is distinct from consent and live setup. [Personal MCP](../PERSONAL_MCP.md) owns discovery and reuse; [Personal Assistant](../PERSONAL_ASSISTANT.md) returns to pending intake after side work. Shipped source reviews are pre-recorded for release; new sources continue reviews alongside questions, with complete page coverage before attestation. These are deployment amendments; preserved product versions remain unchanged.

### Rollover chronology clarification — 2026-09-14

Oldest means filename timestamp order for the prescribed ISO-dated seed names, with lexical filename ordering for ties. Undated names use deterministic lexical ordering without inventing a timestamp. Filesystem modification time is not the chronology authority because copying can reset it. Pinned records remain excluded from archival.

### AppleDouble preservation — 2026-09-14

Filing and rollover preserve an existing macOS AppleDouble sidecar as a distinct `.appledouble` artifact named in the operation journal. Copy and verify all planned bytes before removing originals, because the operating system can remove a source sidecar with its primary file. Do not overwrite operating-system-generated destination `._` files. Raw sidecar preservation is separate from restoration of native metadata. Conflicts remain pending for explicit recovery.

A native resource fork without an accessible AppleDouble sidecar requires a metadata-aware transfer; these byte-copy helpers refuse removal. New or changed source metadata after planning is a conflict. Existing destination metadata must be preserved.

## X1.5 scoped review and evidence amendment

The explicit scheduled-review mode in [MINDMAKE.md](../../MINDMAKE.md) substitutes governance plus registered due commitments for full startup intake, profiles, global queues and seed loading. All ordinary customer loads retain their existing setup and source activation requirements. Missing configured ledger, missing sources and stale deployment reviews block review; paused assistance performs no dispatch or native sync. This exception applies to scheduled commitment review only, not generic job work.

Use [workflow improvements](../tools/WORKFLOW_IMPROVEMENT.md) and [work records](../tools/WORK_RECORDS.md) for original request, owner/scope/constraints and separate check/artifact/deployment/user-observation criteria. Failed results may propose a repair but cannot authorize it. Attention measurements require attributed observed intervals and evidence; missing observations remain NOT_MEASURED. [Task checks](../tools/TASK_EVAL.md) and skill-selection probes bind current source/corpus/metadata/model provenance; stale observations cannot establish a new pass.

The new helpers augment these local deployment procedures. Preserved product PDF/DOCX engines keep their versions. Source-review attestations must substantively reconcile these deltas; adding hashes alone is not review. Work/correction runtime history is excluded from maps and distribution packages, while source procedures, tests, required review evidence and selected publications remain included.

## X1.6 current-session loading

Packaging review and session loading are separate. After GUARD, ordinary startup reads and applies the ten ordered components returned in `session_loading.components`, including Cartographer, through each wrapper and selected product source. A release review never proves that a new conversation has those instructions. Reuse unchanged instructions only when read and still available in this conversation. Missing or unreadable instructions block full startup; report the exact source. Loading grants no maintenance, task, service or scheduling authority beyond the active request. Explicit scheduled compact review retains its existing exception.

## Seed Memory Protocol 1 — X1.6 repair

Read `Brain/tools/SEED_MEMORY_PROTOCOL.md` from the verified workspace root before substantive work and after recovery. It is the shared deployment implementation of the appended source amendment. At task entry/change/recovery, check relevant Short-term and Long-term seeds using the exact conversation ID, stable event ID, explicit job scope and topic query. Read the returned content before dependent decisions. At each substantive response, check whether the current task evidence or unsaved consequential work changed. Report meaningful work before writing its seed, then reopen/hash it and record only the pending change IDs actually covered. Required continuity saves override older distant checkpoints and caps; do not create filler seeds.

Use the existing connected `mindmake_memory_check`, `mindmake_memory_read`, `mindmake_memory_saved` and `mindmake_memory_status` tools when exposed and opted in, or `python3 -B Brain/tools/mindmake_seed_memory.py --root <verified-workspace>` with check/read/save/status. Do not enable a connection or create a schedule for this protocol. An uncalled thread is UNCOUNTED; returned bytes do not prove comprehension. If handlers remain old, use the CLI until that connection is reconnected. Preserve source authority, ownership and exact supersession history; unresolved retrieval remains visible. Direct file access and bypassed turns are unobserved.
