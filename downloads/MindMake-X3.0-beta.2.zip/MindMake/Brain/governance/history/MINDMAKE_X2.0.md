# MindMake startup (X2.0)

This folder is the shared workspace. Read [GUARD.md](GUARD.md) first, then [FOLDER_MAP.md](FOLDER_MAP.md), [AGENTS.md](AGENTS.md), [the deployment policy](Brain/governance/WORKSPACE_POLICY.md), and [the shared operating rules](Brain/governance/RUNTIME.md). The workspace's shared seeds live in [Seeds/](Seeds/README.md). Each job keeps its own seeds inside its Jobs folder.

Every helper in X2.0 is a **PPI** (Portable Plug-in). Its selected source is a readable `.md` file in its job's `Products/` folder. That file holds the full instructions, the hard lines, the safety floor and its knowledge. The PDF beside it holds the same content for people to read.

## On "Load GUARD.md", "load up", "load MindMake" or recovery

1. **Check the folder.** Run `python3 Brain/tools/mindmake.py boot` from this root. Report missing or conflicting files before dependent work. This is a file check, not proof that any helper is active.
2. **Check Downloads.** Run `python3 Brain/tools/mindmake.py check_downloads`, or use the optional watcher in [Brain/DOWNLOADS_WATCHER.md](Brain/DOWNLOADS_WATCHER.md). Report filed items and anything that needs review.
3. **Load the ten core helpers.** Follow `session_loading.components` from boot, in order. For each component, read its JOB.md, its source contract, its skill wrapper and its PPI source, then apply its session instructions.
   - The order is DeepSleep → Cartographer → SignalGuard → ThoughtVault → DreamWeaver → Seed Protocol → AI Turbo → Heartbeat → SkillMaster → TaskCycle.
   - Review status `RECORDED` means the installed files match a documented review. It does **not** mean you have read them.
   - Reuse instructions only if they were already read in this conversation and are still available. A new session or lost context means reading them again.
   - If a source can't be read, name it and don't claim full startup.
4. **Use saved intake status.** For active, unfinished setup, follow [INTAKE.md](INTAKE.md), ask only the next unanswered question, and offer the [First Win tutorial](Brain/FIRST_WIN.md). If intake is complete or deferred, skip it and continue loading context.
5. **Read the person's context:**
   - [Brain/Profiles/INDEX.md](Brain/Profiles/INDEX.md) and the confirmed profiles it names;
   - [TODO.md](TODO.md);
   - the [skill registry](Brain/SKILLS.md).

   Pending intake disables only profile-dependent work. A name alone does not complete intake.
6. **Read the shared seeds boot names.** Confirmed identity and preferences come first, then recent and relevant continuity. Aim for 10–25 seeds and never pad to reach it. Check [the reference index](Seeds/Index/reference-index.md) before opening up to three relevant sources.
7. **Report readiness briefly and factually.** Then continue the user's authorized work. Loading does not authorize:
   - running every TODO;
   - adopting a persona;
   - sending messages;
   - pruning seeds;
   - scheduling anything.

When a job is named, read its JOB.md, its local seeds, its source contract and its PPI source before precision work. For a user's own project, create a sandbox with `python3 Brain/tools/mindmake.py new_job --name "<Project Name>"`.

Seed rollover runs during boot or on demand: at 500 Short-term records, the oldest unpinned records move to Long-term until 350 remain. Other maintenance is advisory unless authorized. TaskCycle stays within the active request. Scripts check files. They never inject prompts into a model or install a scheduler.

After changes, follow the map completion rule in AGENTS.md and [the helper commands](Brain/tools/README.md). Save shared continuity under Seeds/Short-term, and job-specific continuity inside that job.

## Optional: personal MCP

Follow [Personal MCP](Brain/PERSONAL_MCP.md). An explicit yes starts the Personal MCP Builder job. No, later or skip keep ordinary use. Report optional setup and live tool availability separately from folder readiness. The included server requires `mcp>=1.2,<2` (see `Brain/MCP/requirements.txt`).

## Personal assistance and connections

At intake or resumed assistance, apply [Personal Assistant](Brain/PERSONAL_ASSISTANT.md) and read [the capability guide](Brain/CAPABILITIES.md). Offer relevant connections with their benefits, reuse existing permissions and verify the operations you need. Keep one useful next action. A setting being configured is not evidence that anything ran in the background or that a message was delivered.

## Intake checkpoint

Before handing back a turn while setup is unfinished, read `intake_status`. Answer side questions, then return to the pending setup question unless the user explicitly deferred it. Never infer consent or completed intake from existing tools, host memory or a request to start work.

For structural checks without seed moves, use `python3 Brain/tools/mindmake.py boot --no-maintenance`. A pending rollover stays visible and must be reconciled.

## Follow-through, scoped review and work records

When assistance is configured, read `python3 Brain/tools/assistant.py status`. Follow Brain/PERSONAL_ASSISTANT.md to capture explicit commitments and keep the next action current. Never claim a scheduler ran or a reminder reached a phone without evidence.

For an authorized scheduled commitment review, use `python3 -B Brain/tools/mindmake.py boot --mode review` and [the review procedure](Brain/tools/FOLLOW_THROUGH.md). That mode replaces the ordinary startup and intake sequence for that review only.

For workflow changes, see [the improvement guide](Brain/tools/WORKFLOW_IMPROVEMENT.md), [work records](Brain/tools/WORK_RECORDS.md) and [task checks](Brain/tools/TASK_EVAL.md). Load these only when the work needs them.

## Seed Memory Protocol 1

Read `Brain/tools/SEED_MEMORY_PROTOCOL.md` before substantive work and after recovery.
- At task entry, task change or recovery, check the relevant Short-term and Long-term seeds. Use the exact conversation ID, a stable event ID, an explicit job scope and a topic query.
- Read what comes back before making decisions that depend on it.
- Report meaningful work before writing its seed, then reopen and hash the seed to confirm it saved. Record only the pending change IDs it actually covers. Required continuity saves override old checkpoints and retention caps; never create filler seeds.

Use the connected `mindmake_memory_*` tools when they are exposed and the user has opted in. Otherwise use `python3 -B Brain/tools/mindmake_seed_memory.py --root <workspace>` with check, read, save or status. Don't enable a connection or create a schedule for this protocol. A thread that was never checked is UNCOUNTED. Bytes returned from a read don't prove they were understood.

If connected memory handlers are stale, use the CLI until the connection is restored. Keep unresolved retrieval visible; preserve source authority, ownership and supersession history. Direct file access and bypassed turns are not observed by the connection.
