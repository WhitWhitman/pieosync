# MindMake X2.0 first-run intake

Loading this folder starts setup and intake. Do not finish the first load with only “ready” or “intake pending,” and do not wait for the user to ask a second time. Keep the conversation simple; the assistant handles installation details.

## 1. Check the installation

Read GUARD.md and [the deployment policy](Brain/governance/WORKSPACE_POLICY.md), then run `python3 Brain/tools/mindmake.py boot`. Use the actual extracted folder. If tools or readable sources are unavailable, state the exact blocker; do not simulate successful setup. Missing paths, corrupt sources, missing job folders, or broken maps must be repaired and verified before dependent work.

All 19 Jobs packages ship prebuilt. Every helper, tool and reference needs JOB.md, LGI_ENGINE_CONTRACT.md (the PPI source contract), Products with its PPI source (`.md`), PDF and tests, Skills with its wrapper, Research, Seeds/README.md, and separate Short-term and Long-term folders. Verify the shared Seeds, Brain/Profiles, governance, startup doorways, skill registry and folder-map registry too. Use the catalog to detect an omitted job; never infer completeness only from the folders that happen to exist.

## 2. Begin the conversation (Pre-Verified Release)

Once structural checks pass and the current-session component reads in MINDMAKE.md are complete, start customer intake in this same turn: ask “What name would you like me to call you?” if unknown, or the next unanswered question below. Do not present a technical checklist for the customer to fill out.

All 19 shipped packages have packaging review entries in `Brain/.mindmake/setup-review.json`, with evidence under `Brain/governance/setup-reviews/`. Boot reports which are RECORDED and which are still pending; report pending reviews plainly. `RECORDED` means those reviews match the checked installation. It does not mean the current assistant has loaded any component. Ordinary startup must read the ten `session_loading.components` and their PPI sources in the returned order before intake or a readiness claim. Cartographer is mandatory; GUARD alone is incomplete startup. Reuse unchanged instructions only when already read and available in this conversation. Do not repeat the packaging audit for unchanged sources or load unrelated references and test files. If any required read is unavailable, name the missing source and leave startup incomplete. This is an instruction to the assistant, not a claim that Python can verify comprehension.

If a new package is imported or an existing package source is modified, document and record its review using:

```sh
python3 Brain/tools/mindmake.py record_review --job 'Jobs/Job Name' --evidence 'Brain/governance/setup-reviews/job-name.md' --fingerprint '<fingerprint from boot>'
python3 Brain/tools/mindmake.py update_map --paths 'Brain/governance/setup-reviews/job-name.md' 'Brain/.mindmake/setup-review.json'
python3 Brain/tools/mindmake.py boot
```

These records are an assistant's documented review, not independent proof of comprehension or behavioral compliance. Sources or authored deployment instructions changing invalidate affected records. Generated map refreshes do not.

## 3. Save the user's answers and continue

Ask one question at a time, using known confirmed answers instead of restarting:

1. Preferred name.
2. What the user wants help with first. Offer the 2-minute [First Win Interactive Tutorial](Brain/FIRST_WIN.md) to demonstrate sandbox creation, seed memory, and cross-session continuity. When the customer identifies a project or goal, scaffold their dedicated project sandbox via `python3 Brain/tools/mindmake.py new_job --name "<Project Name>"`.
3. Personal MCP: explain the benefits and GUARD relationship, offer yes/no/later, and check existing compatibility before building.
4. Relevant connections, with benefits and separate read/write scope. Check existing access first.
5. Working preferences, such as level of detail and how proactive to be.
6. Routine actions the user wants handled within those sources.
7. Reminder preferences, cadence, timezone and quiet hours, with optional SMS setup.
8. Optional companion style; no persona is adopted without selection.

The boot result's `intake.next_question` is the next unanswered question. It is derived from [Brain/.mindmake/intake.json](Brain/.mindmake/intake.json); profile-file existence never completes it. Record each explicit response using `python3 Brain/tools/mindmake.py record_intake --field preferred_name --answer 'the supplied answer'`, choosing the returned field name. For an explicit skip, use `--skip` instead of `--answer`. Do not turn silence into an answer. The helper persists structured intake only; then update the corresponding profile prose/status and maps, including `Brain/.mindmake/intake.json`.

Resolve files through Brain/Profiles/profiles.json. Save only explicit answers in the matching profile, mark fields pending/confirmed/skipped as appropriate, and update maps. A confirmed name alone does not complete intake. Mark the user profile confirmed once the required questions have answers or explicit skips. An explicitly skipped optional companion is declined, not a permanent blocker. If the user explicitly asks to defer intake, run `python3 Brain/tools/mindmake.py defer_intake --reason "the user supplied request"`, update maps, and proceed with authorized work. Use `resume_intake` when they ask to resume; an explicit new intake answer also resumes it. Deferred questions remain unanswered, never silently skipped. Never invent interests, personal details or filler seeds.

## 4. Verify that the workflow actually works (The First Win)

Follow [Brain/FIRST_WIN.md](Brain/FIRST_WIN.md) for the 4-step guided tutorial and progress checking via `python3 Brain/tools/mindmake.py tutorial`. Verify that one authorized test artifact can be written, mapped, found through the map and reopened; preserve or clean it up with a corresponding map update. Save real confirmed continuity in the correct shared or job seed pool. On the next session, read it back and resume the actual next step. Report these as separate observed checks; a same-session readback is not a fresh-session test.

Use [the acceptance checklist](Brain/governance/FIRST_RUN_ACCEPTANCE.md). Do not call helpers active unless their instructions were read and applied in the current conversation. Report unavailable tools and unrun behavioral checks explicitly. In-session download processing is available on-demand via `python3 Brain/tools/mindmake.py check_downloads`; the background Downloads watcher daemon is optional. Other background components, timers and guaranteed model injection are not installed.

## 5. Offer the optional personal MCP

Ask the `personal_mcp` question from the helper, explain the benefits, GUARD relationship and local setup using [Personal MCP](Brain/PERSONAL_MCP.md), and record yes, no or later. An explicit skip also permits normal use. A yes triggers the [Personal MCP Builder](Jobs/Personal%20MCP%20Builder/JOB.md): inspect the host and existing connections, reuse verified compatible access, or build and verify the bounded starter if needed within that consent. Do not stop after saving yes. Keep unavailable host access or unfinished connection visible as optional setup pending; do not call it installed or active. Never bundle a customer's answer, runtime or session records in a distributable ZIP.

Whenever offering a personal MCP, including every 30-day Later follow-up, explain the benefits first: easier retrieval of current MindMake and GUARD context, fewer repeated setup explanations, separate session records and visibility into changed files. Keep the limits clear. Later records a due date 30 days ahead; ask on the next load at or after that date. Do not re-ask during the deferral window or invent a background scheduler. No and explicit skip remain declined until the user revisits them.

## Personal assistance setup

Follow [the working procedure](Brain/PERSONAL_ASSISTANT.md). Free-text intake answers record preferences; they do not enable a connector, scheduler or SMS provider. Turn explicit choices into scoped configuration and complete the supported setup steps. Verify account access, one authorized routine operation and actual cadence or delivery separately. Continue useful work while an optional connection is pending. Explain benefits every time a connection is offered.

## Keep the setup conversation on track

Before handing the turn back during unfinished intake, run `python3 Brain/tools/mindmake.py intake_status`. If interaction is ACTIVE, ask its next unanswered question, or keep that question pending if already asked asynchronously. Answer side questions and do useful authorized work, then return to the same pending setup item. Requests such as “be my assistant” or “any suggestions” do not mean “skip the rest of setup.” Never overwrite earlier confirmed answers just to follow the default order.

Ask one concise question at a time. Do not repeat an outstanding question while waiting. Record explicit answers or skips; clarify an ambiguous yes/no/later choice. If interaction is DEFERRED, honor the saved pause without repeated questions until the user resumes. The checkpoint is file-backed guidance, not automatic control of model behavior. If new or modified sources are imported, keep reviews progressing in manageable page batches while input is pending.

Existing host memory may help routing, but cannot supply a new customer's intake answers or consent. Keep knowledge from the host distinct from knowledge supplied by this folder. A fresh-folder test in a personalized host is not an isolated new-customer test.
