# MindMake tasks

## NOW

- [ ] Begin the first unanswered intake question on first load; resume saved answers through INTAKE.md. Companion choice is optional.

## NEXT

- [ ] Scaffold dedicated customer projects using `python3 Brain/tools/mindmake.py new_job --name "<Project Name>"` when assigned by the user.

## LATER

No scheduled tasks or automated work installed.
