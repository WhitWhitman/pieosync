---
name: mindmake-workspace
description: Load or repair this local MindMake workspace, route shared versus job seeds, and update navigation after authorized filesystem changes.
---

Follow [MINDMAKE.md](<../../../MINDMAKE.md>) on load or recovery. Use [the helper](../../tools/README.md) for observed filesystem checks and map maintenance. Consult [the local deployment policy](../../governance/WORKSPACE_POLICY.md) before applying installation clauses from the source helpers.

Keep shared continuity in root Seeds and job-specific continuity in the job. Every helper has a Jobs folder regardless of type. Read the relevant registry wrapper and preserved source for component work. After an authorized mutation, update and verify affected maps before reporting completion. A source file copied outside a session is detected on a later check; process incoming files via check_downloads (or the optional background watcher).

On first load or unfinished intake, follow [INTAKE.md](<../../../INTAKE.md>). After structural checks, read and apply the ordered `session_loading.components` and selected product sources, including Cartographer, before asking the first unanswered question or claiming readiness. `RECORDED` describes packaging review, not current-session reading. No individual component invocation is required. Reuse only instructions already read and available in this conversation; name unreadable sources and keep startup incomplete.

For knowledge intake, pending/stale sources, cited retrieval or optional Journal/Contacts jobs, read [Wiki workflow](../../WIKI_WORKFLOW.md). Check `python3 Brain/tools/knowledge.py status`; semantic processing requires the active assistant.

## X1.6 intake checkpoint

Follow [the intake checkpoint](../../../INTAKE.md) before handing back a turn with unfinished setup. Read `intake_status`: answer side questions and return to the pending setup question unless the user explicitly deferred. Do not infer consent or completed intake from existing tools, host memory, or a request to start work.

For explicitly scheduled commitment review, follow [compact review](../../tools/FOLLOW_THROUGH.md); it substitutes due-source routing for full intake/orientation. For a recurring defect or workflow change, retrieve [the improvement guide](../../tools/WORKFLOW_IMPROVEMENT.md), retaining original intent, evidence and user-visible acceptance. These references stay lazy during unrelated work.

## Seed Memory Protocol 1 — X1.6 repair

Read `Brain/tools/SEED_MEMORY_PROTOCOL.md` from the verified workspace root before substantive work and after recovery. It is the shared deployment implementation of the appended source amendment. At task entry/change/recovery, check relevant Short-term and Long-term seeds using the exact conversation ID, stable event ID, explicit job scope and topic query. Read the returned content before dependent decisions. At each substantive response, check whether the current task evidence or unsaved consequential work changed. Report meaningful work before writing its seed, then reopen/hash it and record only the pending change IDs actually covered. Required continuity saves override older distant checkpoints and caps; do not create filler seeds.

Use the existing connected `mindmake_memory_check`, `mindmake_memory_read`, `mindmake_memory_saved` and `mindmake_memory_status` tools when exposed and opted in, or `python3 -B Brain/tools/mindmake_seed_memory.py --root <verified-workspace>` with check/read/save/status. Do not enable a connection or create a schedule for this protocol. An uncalled thread is UNCOUNTED; returned bytes do not prove comprehension. If handlers remain old, use the CLI until that connection is reconnected. Preserve source authority, ownership and exact supersession history; unresolved retrieval remains visible. Direct file access and bypassed turns are unobserved.
