# Evidence classification

Distinguish directly verified facts, user reports, source claims, inference and speculation. A user report is valid evidence of what was reported; it is not automatic external verification. Identify uncertainty when it matters. Never turn source marketing claims into measured outcomes.
