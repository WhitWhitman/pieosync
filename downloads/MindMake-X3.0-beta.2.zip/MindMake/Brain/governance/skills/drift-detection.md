# Drift detection

Compare the next action to the user’s active request and confirmed constraints. Re-anchor when it changes scope. Preserve authorized unfinished work when the user asks a status question. File maps locate material; they do not decide approval or current canon.
