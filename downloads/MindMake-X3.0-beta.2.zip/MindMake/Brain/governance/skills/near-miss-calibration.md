# Near-miss calibration

When a real error or near miss changes future work, record the verified cause and correction in the owning seed pool. Preserve previous records and link evidence. Avoid speculative counters or invented incident logs.
