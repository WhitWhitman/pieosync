# First-run acceptance — X2.0

The assistant records evidence for these checks; a pending checkbox is not a pass.

- [ ] Extract and relocate the whole archive, including hidden configuration and empty seed folders; boot uses that extracted root.
- [ ] Catalog, Jobs index, skill registry, and all 19 complete job packages agree. All shared host paths exist.
- [ ] Source hashes and navigation links verify. FOLDER_MAP.md is the only root map; every JOB.md is registered.
- [x] All selected PPI sources have been read and their setup requirements reconciled; per-job evidence and fingerprints are recorded under Brain/governance/setup-reviews/ for the reviewed snapshot (19 of 19). Run boot to verify that its fingerprints remain current.
- [ ] On a fresh ordinary load, the assistant actually reads the ten ordered core component instructions, including Cartographer, before intake/readiness even when all packaging reviews are RECORDED. Record observed reads separately from script output.
- [ ] Missing or altered component routes fail; explicit scheduled review stays compact and does not begin intake.
- [ ] The first successful load asks the first unanswered intake question without a second user prompt.
- [ ] Confirmed answers survive readback; skipped or deferred answers remain explicit. Name alone does not complete intake.
- [ ] Optional companion decline does not block ordinary work or intake completion.
- [ ] An authorized artifact is written, mapped, found and reopened; changes update maps before completion.
- [ ] Shared continuity and job continuity use their respective seed pools; no fabricated or duplicate records.
- [ ] A fresh session reads saved continuity and resumes the next unanswered question or task. Until observed, this check remains pending.
- [ ] Current-session helper use is demonstrated separately from filesystem validation. Unrun model batteries remain unrun.
- [ ] Missing tools, sources or folders yield a specific failure, never a false ready/running claim.

Release engineering can prove archive, helper and filesystem behavior. Source review is an evidence-bound attestation for a specific folder snapshot; the customer assistant demonstrates conversational intake and cross-session behavior in its own environment. See [INTAKE.md](<../../INTAKE.md>).

## Optional Personal MCP

Offer benefits on every initial or repeated offer. Verify no/later/skip leave normal MindMake usable; Later is offered again on the next load at least 30 days later. For yes, verify a built launch bundle and actual host tool calls separately. See [procedure](../PERSONAL_MCP.md). Never mark a host connected from file presence.

## Personal assistance acceptance

Verify relevant skill selection, existing account discovery, connection benefit explanation, a real read of the chosen source, separate write permission and a next action linked to the goal. Test deferred connection without blocking ordinary work. Verify a configured scheduler by an actual run. For optional SMS, obtain explicit recipient consent and test delivery; queue or sent is not delivered. Exercise quiet hours, pause, snooze, done and uncertain-send recovery. Resume a saved restart point in a fresh conversation. Record each result separately and leave unrun checks pending.

## X1.6 conversational regression

- [ ] With no answers, ask name; after the goal, offer MCP benefits and yes/no/later before companion style.
- [ ] An existing MCP does not suppress the offer. Yes initiates discovery; reuse requires observed workspace and capability evidence.
- [ ] “Be my assistant” or a side question does not lose unanswered intake. Answer it, then resume the pending question without inventing answers.
- [ ] Explicit deferral persists across a reload; resumption preserves confirmed answers and selects the correct unanswered field.
- [x] Source review is recorded in Brain/.mindmake/setup-review.json (X2.0: 19/19 recorded after the owner's decisions of 2026-10-15). File changes can make records pending; verify current status with boot.
- [ ] Label test conditions: fresh folder in a personalized host, or genuinely isolated new-customer environment. No customer profile or consent is pre-populated; clean intake starts on load.

Record the actual conversation and persisted state. A test report must distinguish automated regression checks, observed first question, remaining intake, source reviews and live optional services. Opening the test folder does not pass these checks.
