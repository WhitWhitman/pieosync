# Local MindMake deployment policy (X3.0)

Current folder rules only. The X1.x and X2.0 amendment history is preserved, unchanged, in [history/WORKSPACE_POLICY_X2.0.md](history/WORKSPACE_POLICY_X2.0.md). Where a helper's own source says something different about setup, storage or startup, this file and [AGENTS.md](../../AGENTS.md) win inside this workspace.

## Where things live

- **Helpers:** each in its own `Jobs/<name>/` package (JOB.md, LGI_ENGINE_CONTRACT.md, Products with the `.md` source, PDF and tests, Skills wrapper, Seeds). The folder names and the contract filename stay so the scripts and plugins keep working. Never route this workspace into another installation's folders.
- **User projects:** `Jobs/<Project>/`, created with `new_job`.
- **Shared seeds:** `Seeds/Short-term` and `Seeds/Long-term`. Project-only work goes in that project's Seeds.
- **Profiles:** resolved through `Brain/Profiles/profiles.json` and INDEX.md. Never infer a user's name, work, relationships or persona from app metadata.
- **Maps:** FOLDER_MAP.md is the one root map, and each JOB.md is its project's map.

## Startup

Startup follows AGENTS.md: GUARD, AGENTS, Brain/MEMORY.md, the boot check, then profile, tasks and relevant seeds. Helpers load on demand. A release review never proves a conversation read a helper; say which files were actually read.

## Seeds

- Seed retrieval is by relevance (Brain/MEMORY.md), not a fixed count.
- Rollover: a warning at 450 Short-term seeds; at 500, boot moves the oldest unpinned seeds to Long-term until 350 remain. A content-hashed plan in `Brain/.mindmake/seed-rollovers/` comes first, archive bytes are verified before a source is removed, and the maps are checked afterwards.
- "Oldest" means filename timestamp order, then lexical order for ties. File modification times are never used, because copying changes them.
- Long-term and Dreams thresholds are advisory. Nothing is pruned automatically.
- macOS AppleDouble sidecars are preserved as named `.appledouble` artifacts during filing and rollover.

## Nothing runs in the background by default

Helpers work only inside a session. The Downloads watcher, Apple Reminders, SMS and the personal MCP are optional and stay off until they're set up and verified. DreamWeaver needs real seeds (at least ten, or a labeled "thin dream" if the user chooses fewer).

## TaskCycle

TaskCycle runs only on "work the list" or an authorized schedule. Within its own runs it may use its DUTY score (lowest of four scores over 10, threshold 0.72), with at most 20 tasks and three levels deep per cycle. A passing score never authorizes a destructive or outside action.

## Setup reviews

Each helper's review covers that helper's own files, and one shared review (`_shared`) covers the shared rules and tools (`review_scheme: per_helper` in runtime.json). Editing a shared rule resets the one shared review, not all 19. Boot lists pending reviews under `helper_reviews` without blocking work; set `require_setup_review` to true for the strict X2.0 behaviour, where pending reviews stop boot.

## Tasks

The root TODO.md, written by `Brain/tools/workspace.py`, is the one task list. Its record lives in `Brain/.mindmake/workspace-state/` and is never part of the folder map. Project pages hold no task list.

## Scheduled review mode

An authorized scheduled commitment review uses `boot --mode review` and [FOLLOW_THROUGH.md](../tools/FOLLOW_THROUGH.md) instead of full startup. It grants no extra permission. Missing ledgers, missing sources and stale reviews block that run; paused assistance sends nothing.
