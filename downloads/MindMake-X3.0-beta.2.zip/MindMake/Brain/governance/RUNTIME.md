# Shared operating rules (X3.0)

These rules now live in [GUARD.md](../../GUARD.md) and [AGENTS.md](../../AGENTS.md), each written once:

- Claims must rest on something read this session: GUARD section 2.
- After a summary or reset, follow AGENTS.md **Recovery**.
- Reversible work goes ahead; irreversible work asks first: GUARD section 9.
- Dates come from the machine's clock: GUARD section 9.
- Look for counter-evidence on costly decisions: GUARD section 2.

The DUTY score and the PIEO self-check were retired in X3.0. TaskCycle may still use DUTY inside its own optional runs. The X2.0 text is preserved in [history/RUNTIME_X2.0.md](history/RUNTIME_X2.0.md).
