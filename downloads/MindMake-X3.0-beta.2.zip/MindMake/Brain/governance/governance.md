# SignalGuard local review

Read [GUARD.md](<../../GUARD.md>) first. Review the user's actual task, evidence and permissions before output or action. Use the specific check when relevant:

- [Epistemic classification](skills/epistemic-classification.md)
- [Drift detection](skills/drift-detection.md)
- [Near-miss calibration](skills/near-miss-calibration.md)

These are assistant review instructions, not independent monitors. File creation does not establish measured token savings or continuous enforcement.
