# Source review: MindMake Guide v0.4 (2026-10-27)

This is an assistant's documented source review and test record. It is not independent behavioral acceptance, and it doesn't prove that a future conversation has loaded the helper.

## Source read

`Jobs/MindMake Guide/Products/MINDMAKE_X2_GUIDE_v0.4.md` (sha256 3a2610998a16d361…), read in full during conversion and testing. The PDF and tests are alongside. Converted from: X2.0 original.

## Requirements

Plain-language reference; must match what the shipped folder contains (checked in batch 9).

## Conflicts

Differences from the X1.6 source are listed in the PPI's changelog: kept, added, changed and dropped. For folder mechanics, the workspace GUARD.md, WORKSPACE_POLICY.md and INTAKE.md take precedence over any setup wording in the source.

## Verification

Reference document; no behavior tests. Method: one run per test, every turn in a fresh context, graded against the written test file. From batch 6 on, the clean-context rule applied.

## Open issues

None.

## Known limits

Guide v0.4 (2026-10-27): PPI spelled out as Portable Plug-in, and a helper can be used as a PDF or installed as a plugin. Builds on v0.3 (2026-10-16): release-candidate wording removed, Claude-only testing and the Python requirement stated, safety section matches safety floor v2.
