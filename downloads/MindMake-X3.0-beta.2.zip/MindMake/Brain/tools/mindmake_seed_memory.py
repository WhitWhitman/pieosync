"""Seed Memory Protocol 1: scoped retrieval and observable per-thread receipts.

No model runner, scheduler or comprehension claim. Only submitted events count.
"""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
from contextlib import contextmanager
import argparse
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import time
from mindmake_seeds import _metadata, _stamp

VERSION = 'seed-memory-1'
MAX_FILES = 2000
MAX_BYTES = 32768
REASONS = {'start', 'task_change', 'recovery', 'lookup', 'turn', 'end'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,160}', value):
        raise ValueError('Use an opaque stable thread/event ID')
    if value.lower() in ('default', 'codex', 'claude', 'gemini'):
        raise ValueError('A shared host name is not a thread identity')
    return value


def within(root, relative):
    root = Path(root).resolve(strict=True)
    rel = Path(relative)
    if rel.is_absolute() or '..' in rel.parts or not relative:
        raise ValueError('Use a scoped workspace-relative path')
    path = root
    for part in rel.parts:
        path = path / part
        if path.is_symlink():
            raise ValueError('Symlink paths are not supported')
    if not path.resolve().is_relative_to(root):
        raise ValueError('Path escapes workspace')
    return path


def pools(root, scope):
    root = Path(root).resolve(strict=True)
    if scope == 'all':
        # X3.0 default: shared seeds plus every project's seeds, so a project seed is never missed.
        result = pools(root, 'general') if (root / 'Seeds' / 'Short-term').is_dir() else []
        jobs = root / 'Jobs'
        for job in sorted(jobs.iterdir()) if jobs.is_dir() else []:
            if job.is_dir() and not job.is_symlink() and not job.name.startswith(('.', '_')) and (job / 'Seeds' / 'Short-term').is_dir():
                result += pools(root, job.relative_to(root).as_posix())
        if not result:
            raise ValueError('No seed pools found')
        return result
    if scope == 'general':
        base = Path(root)
    else:
        if not scope.startswith('Jobs/'):
            raise ValueError('Scope must be all, general or an exact Jobs/... folder')
        base = within(root, scope)
    result = [within(root, (base / 'Seeds' / name).relative_to(root).as_posix())
              for name in ('Short-term', 'Long-term')]
    if not result[0].is_dir():
        raise ValueError('The selected scope has no Short-term seed pool')
    return result


def seed_bytes(root, scope, relative, expected=None):
    path = within(root, relative)
    if path.parent not in pools(root, scope) or path.suffix.lower() not in ('.md', '.txt'):
        raise ValueError('Use a direct seed file in the selected pool')
    if not path.is_file() or path.stat().st_size > MAX_BYTES:
        raise ValueError('Seed missing or larger than 32 KiB; use bounded source inspection')
    data = path.read_bytes()
    if len(data) > MAX_BYTES or not data.decode('utf-8').strip():
        raise ValueError('Seed must be nonempty UTF-8 text within 32 KiB')
    sha = digest(data)
    if expected is not None and sha != expected:
        raise ValueError('Seed changed; inspect current bytes before recording a receipt')
    return data, sha


def search(root, scope, query):
    root = Path(root).resolve(strict=True)
    if not isinstance(query, str) or not query.strip() or len(query) > 300:
        raise ValueError('Supply a short task/topic query, not conversation contents')
    terms = set(re.findall(r'[a-z0-9]{3,}', query.lower())) - {'the', 'and', 'for', 'with', 'this', 'that'}
    if not terms:
        raise ValueError('Query needs at least one searchable term')
    records, warnings, edges, full_edges = {}, [], {}, {}
    # X3.0: a seed is identified by its owner (shared or one project) plus filename, so two
    # projects may use the same filename and a correction never reaches into another project.
    def key(owner, filename): return owner + '::' + filename
    def base(k): return k.split('::', 1)[1]
    for pool in pools(root, scope):
        if not pool.exists():
            continue
        owner = pool.parent.parent.relative_to(root).as_posix()
        for path in sorted(pool.iterdir()):
            if path.name.startswith('.') or path.suffix.lower() not in ('.md', '.txt'):
                continue
            if key(owner, path.name) in records:
                raise ValueError('Duplicate seed filename across active/archive pools: ' + (owner + '/' if owner != '.' else '') + path.name)
            if len(records) >= MAX_FILES:
                raise ValueError('Seed search exceeds 2000 files; narrow or reconcile the pool')
            data, sha = seed_bytes(root, scope, path.relative_to(root).as_posix())
            try:
                meta = _metadata(path)
            except RuntimeError:
                warnings.append('Unparsed legacy seed; inspect manually: ' + path.relative_to(root).as_posix())
                meta = {'path':path, 'status':'unparsed', 'refs':[]}
            words = set(re.findall(r'[a-z0-9]{3,}', (path.name + ' ' + data.decode('utf-8')).lower()))
            records[key(owner, path.name)] = dict(meta, sha256=sha, score=len(terms & words), owner=owner)
    suppressed = set()
    for name, row in records.items():
        edges[name] = []
        full_edges[name] = []
        if row['status'] not in ('active', 'superseded', 'archived'):
            warnings.append('Unknown seed status: ' + name)
        for raw in row['refs']:
            ref, marker, fragment = raw.partition('#')
            if not re.fullmatch(r'\d{4}-\d{2}-\d{2}[^/\\]*\.(?:md|txt)', ref):
                warnings.append('Unresolved supersedes metadata: ' + name)
                continue
            ref = key(row['owner'], ref)  # corrections stay inside their own project
            if ref not in records:
                warnings.append('Missing predecessor: ' + base(ref))
                continue
            if records[ref]['status'] == 'unparsed':
                warnings.append('Unparsed predecessor requires manual reconciliation: ' + ref)
                continue
            # Missing filename times cannot be ordered against timed records on the same date.
            current_stamp, prior_stamp = _stamp(base(name)), _stamp(base(ref))
            if current_stamp[0] == prior_stamp[0] and (current_stamp[1] is None or prior_stamp[1] is None):
                warnings.append('Ambiguous same-day replacement: ' + name + ' -> ' + ref)
                continue
            if current_stamp <= prior_stamp:
                raise ValueError('Ambiguous/cyclic supersession chronology; reconcile before retrieval')
            edges[name].append(ref)
            if marker:
                warnings.append('Partial correction: read both ' + name + ' and ' + ref)
            else:
                full_edges[name].append(ref)
    for name,row in records.items():
        if row['status'] != 'active':
            if full_edges[name]: warnings.append('Inactive replacement requires reconciliation: ' + name)
            continue
        pending=list(full_edges[name])
        while pending:
            ref=pending.pop()
            if ref in suppressed:continue
            suppressed.add(ref)
            pending.extend(full_edges[ref])
    replacements = {}
    for name, row in records.items():
        if row['status'] == 'active' and name not in suppressed:
            pending, ancestors = list(full_edges[name]), set()
            while pending:
                ref = pending.pop()
                if ref in ancestors:
                    continue
                ancestors.add(ref)
                replacements.setdefault(ref, []).append(name)
                pending.extend(full_edges[ref])
    for ref, names in replacements.items():
        if len(names) > 1:
            warnings.append('Competing current replacements for ' + ref + ': ' + ', '.join(names))
    # Older matches transfer to their corrections even when the correction uses different words.
    for name in sorted(records):
        records[name]['score'] = max([records[name]['score']] + [records[r]['score'] for r in edges[name]])
    eligible = [r for n, r in records.items() if n not in suppressed and r['status'] == 'active' and r['score']]
    eligible.sort(key=lambda r: (r['score'], r['path'].name), reverse=True)
    selected = [{'path': r['path'].relative_to(root).as_posix(), 'sha256': r['sha256'], 'match_terms': r['score']}
                for r in eligible[:5]]
    return {'candidates': selected, 'scanned': len(records), 'omitted_matches': max(0, len(eligible)-5),
            'warnings': warnings[:20], 'omitted_warnings': max(0,len(warnings)-20),
            'navigation': [p.relative_to(root).as_posix() for p in pools(root, scope)],
            'selection_hash': digest(json.dumps(selected, sort_keys=True).encode())}


def _snapshot(root,scope):
    result={}
    for pool in pools(root,scope):
        if not pool.exists():continue
        for path in pool.iterdir():
            if path.name.startswith('.') or path.suffix.lower() not in ('.md','.txt'):continue
            if len(result)>=MAX_FILES:raise ValueError('Seed snapshot exceeds bound')
            relative=path.relative_to(Path(root).resolve()).as_posix()
            result[relative]=seed_bytes(root,scope,relative)[1]
    return result


def storage(root):
    prefix = '.mindmake' if (Path(root)/'.mindmake/authority.json').is_file() else 'Brain/.mindmake'
    return within(root, prefix + '/seed-memory/events.sqlite3')


@contextmanager
def database(root, write=False):
    path = storage(root)
    if not path.exists() and not write:
        yield None
        return
    if write:
        path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path if write else path.as_uri() + '?mode=ro', uri=not write, timeout=15)
    try:
        if write:
            db.execute('PRAGMA synchronous=FULL')
            db.execute('BEGIN IMMEDIATE')
            db.execute('CREATE TABLE IF NOT EXISTS sessions (stream TEXT PRIMARY KEY, state TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS events (stream TEXT,event TEXT,payload TEXT,at REAL, PRIMARY KEY(stream,event))')
        yield db
        if write:
            db.commit()
    except Exception:
        if write:
            db.rollback()
        raise
    finally:
        db.close()


def _state(db, stream):
    row = db.execute('SELECT state FROM sessions WHERE stream=?', (stream,)).fetchone() if db else None
    state = json.loads(row[0]) if row else None
    if state is not None and (not isinstance(state,dict) or state.get('version') != VERSION):
        raise ValueError('Seed-memory state is malformed; preserve it for recovery')
    return state


def _event(root, stream, event, payload, update, finish=None):
    identity(stream); identity(event)
    encoded = json.dumps(payload, sort_keys=True)
    with database(root, True) as db:
        prior = db.execute('SELECT payload FROM events WHERE stream=? AND event=?', (stream,event)).fetchone()
        state = _state(db, stream)
        if prior:
            if prior[0] != encoded:
                raise ValueError('Event ID reused for different facts')
        else:
            state = update(state)
            db.execute('INSERT INTO events VALUES (?,?,?,?)', (stream,event,encoded,time.time()))
            db.execute('INSERT OR REPLACE INTO sessions VALUES (?,?)', (stream,json.dumps(state,sort_keys=True)))
        result = finish(state) if finish else state
    return result


def _summary(root, stream, state):
    if state is None:
        return {'status':'UNCOUNTED','stream':stream,'coverage':'No submitted seed-memory checks',
                'reminder':'Check relevant seeds at task entry/change/recovery; verify a save after consequential work.'}
    found = search(root, state['scope'], state['query'])
    receipts = {(x['path'],x['sha256']) for x in state['reads'] if x['epoch']==state['epoch']}
    retrieval = ('RECONCILIATION_REQUIRED' if found['warnings'] or found['omitted_warnings'] else
                 'NO_MATCH' if not found['candidates'] else
                 'CONTENT_RETURNED' if all((x['path'],x['sha256']) in receipts for x in found['candidates']) else 'READ_REQUIRED')
    pending = []
    for event, change in state['changes'].items():
        receipt = change.get('saved')
        try:
            if not receipt: raise ValueError('unsaved')
            seed_bytes(root, change['scope'], receipt['path'], receipt['sha256'])
        except (ValueError, OSError, UnicodeError):
            pending.append(event)
    return {'version':VERSION,'status':'CHECKED','stream':stream,'task':state['task'],'scope':state['scope'],
            'epoch':state['epoch'],'recorded_checks':state['checks'],'retrieval':retrieval,
            'save_status':'SAVE_REQUIRED' if pending else 'SAVED_BYTES_VERIFIED' if state['changes'] else 'NO_REPORTED_CHANGES',
            'pending_changes':pending,'last_check_at':state['last_check_at'],
            'coverage':'Submitted checks only; bypassed turns are not observed',
            'comprehension_verified':False, **found}


def status(root, stream):
    identity(stream)
    with database(root) as db:
        return _summary(root, stream, _state(db, stream))


def check(root, stream, event, task, scope, query, reason='turn', meaningful=False):
    if reason not in REASONS or type(meaningful) is not bool or not isinstance(task,str) or not 1 <= len(task) <= 160:
        raise ValueError('Invalid task/check reason or meaningful-change flag')
    search(root, scope, query)
    payload = dict(operation='check',task=task,scope=scope,query=query,reason=reason,meaningful=meaningful)
    def update(state):
        state = state or dict(version=VERSION,epoch=0,checks=0,reads=[],changes={})
        changed = any(state.get(k)!=payload[k] for k in ('task','scope','query'))
        if changed or reason in ('start','task_change','recovery'):
            state['epoch'] += 1
            state['reads'] = []
        state.update(task=task,scope=scope,query=query,last_check_at=time.time())
        state['checks'] += 1
        if meaningful:
            if len(state['changes']) >= 1000:
                raise ValueError('Thread change history is full; preserve a successor handoff')
            state['changes'][event] = {'scope':scope,'task':task,'saved':None,'baseline':_snapshot(root,scope)}
        return state
    return _summary(root, stream, _event(root,stream,event,payload,update))


def read_seed(root, stream, event, path, expected_sha256):
    def update(state):
        if not state: raise ValueError('Run a seed-memory check before reading')
        data, sha = seed_bytes(root,state['scope'],path,expected_sha256)
        found=search(root,state['scope'],state['query'])
        if path not in [x['path'] for x in found['candidates']]:
            raise ValueError('Seed is not a current candidate; refine the task query')
        receipt={'path':path,'sha256':sha,'epoch':state['epoch']}
        state['reads']=[x for x in state['reads'] if x['path']!=path]+[receipt]
        return state
    def response(state):
        # Prepare the entire response before commit. Failed validation rolls back.
        # This records server content preparation, not an independently observed network receipt.
        data,sha=seed_bytes(root,state['scope'],path,expected_sha256)
        return {'path':path,'sha256':sha,'text':data.decode('utf-8'),'provenance':'CONTENT_RETURNED',
                'delivery_evidence':'Server response prepared; client receipt is unverified',
                'comprehension_verified':False,'memory':_summary(root,stream,state)}
    return _event(root,stream,event,dict(operation='read',path=path,sha256=expected_sha256),update,response)


def record_save(root, stream, event, path, expected_sha256, covers):
    if not isinstance(covers,list) or not covers or len(set(covers))!=len(covers):
        raise ValueError('Name the distinct pending change event IDs this seed covers')
    for value in covers:identity(value)
    def update(state):
        if not state:raise ValueError('No checked task exists')
        for value in covers:
            if value not in state['changes']:raise ValueError('Unknown pending change event')
            seed_bytes(root,state['changes'][value]['scope'],path,expected_sha256)
            if state['changes'][value].get('baseline',{}).get(path)==expected_sha256:
                raise ValueError('Seed bytes predate this reported change; save a current continuity seed')
        for value in covers:
            state['changes'][value]['saved']={'path':path,'sha256':expected_sha256,'provenance':'SAVED_BYTES_VERIFIED'}
        return state
    state=_event(root,stream,event,dict(operation='save',path=path,sha256=expected_sha256,covers=covers),update)
    return _summary(root,stream,state)


def reminder(root, stream):
    try:
        if not stream or stream.lower() in ('default','codex','claude','gemini'):
            return '[Seed memory: UNCOUNTED. Supply the exact thread ID and run a task seed check.]'
        result=status(root,stream)
        if result['status']=='UNCOUNTED':return '[Seed memory: UNCOUNTED. Run a seed check for this task before substantive work.]'
        paths=', '.join(x['path'] for x in result['candidates']) or 'no match; refine scope/query before claiming information is missing'
        return f"[Seed memory: {result['retrieval']}; {result['save_status']}. {paths}. Submitted checks only; content delivery is not comprehension.]"
    except Exception:
        return '[Seed memory: UNAVAILABLE. Preserve state and use scoped manual retrieval; do not claim checked.]'


def default_root(script):
    return script.parents[2] if script.parents[1].name == 'Brain' else script.parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=default_root(Path(__file__).resolve()))
    sub=parser.add_subparsers(dest='operation',required=True)
    for op in ('status','check','read','save'):
        p=sub.add_parser(op);p.add_argument('--stream',required=True)
        if op!='status':p.add_argument('--event',required=True)
        if op=='check':
            p.add_argument('--task',required=True);p.add_argument('--scope',default='all')
            p.add_argument('--query',required=True);p.add_argument('--reason',choices=sorted(REASONS),default='turn')
            p.add_argument('--meaningful',action='store_true')
        if op in ('read','save'):
            p.add_argument('--path',required=True);p.add_argument('--sha256',required=True)
        if op=='save':p.add_argument('--covers',nargs='+',required=True)
    args=vars(parser.parse_args());op=args.pop('operation');root=args.pop('root').resolve(strict=True)
    if 'sha256' in args:args['expected_sha256']=args.pop('sha256')
    try:
        result={'status':status,'check':check,'read':read_seed,'save':record_save}[op](root,**args)
        print(json.dumps(result,indent=2));return 0
    except (ValueError,RuntimeError,OSError,sqlite3.Error,KeyError,TypeError,UnicodeError):
        print(json.dumps({'status':'UNAVAILABLE','error':'Seed check failed; verify scope, identity, seed metadata and current hashes. No checked result.'}));return 1


if __name__=='__main__':raise SystemExit(main())
