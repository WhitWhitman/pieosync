#!/usr/bin/env python3
"""File Downloads with exclusive creation, recoverable receipts and verified maps.

Locks serialize cooperating helpers. Uncooperative writers can still race the final
identity check and unlink; this is not an OS-wide transaction or power-loss guarantee.
Interrupted/changed copies are preserved for review, never deleted or overwritten.
"""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse
import datetime as dt
import errno
import fnmatch
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat as statmod
import subprocess
import sys
import time
import uuid

SPEC = importlib.util.spec_from_file_location('mindmake', Path(__file__).with_name('mindmake.py'))
mm = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mm)
STATE = 'Brain/.mindmake/downloads-watch'
RULES = 'Brain/.mindmake/download-routes.json'
PARTIAL = ('.part', '.partial', '.crdownload', '.download', '.tmp')
CHUNK_SIZE = 1024 * 1024

class LockBusy(ValueError):
    pass

def _acquire(path):
    """Return a held lock; close releases it on both supported backends."""
    lock = path.open('a+b')
    try:
        try:
            import fcntl
        except ImportError:
            try:
                import msvcrt
            except ImportError as exc:
                raise OSError('No supported file locking backend (fcntl or msvcrt)') from exc
            # Windows byte-range locking requires a byte and a fixed offset.
            if os.fstat(lock.fileno()).st_size == 0:
                lock.write(b'0'); lock.flush()
            lock.seek(0)
            try:
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                if exc.errno in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                    raise LockBusy('Another download helper holds ' + path.name) from exc
                raise
        else:
            try:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                if exc.errno in (errno.EACCES, errno.EAGAIN):
                    raise LockBusy('Another download helper holds ' + path.name) from exc
                raise
        return lock
    except BaseException:
        lock.close()
        raise

def _sync_dir(path):
    # Python exposes no portable Windows directory FlushFileBuffers. File fsync
    # and journal readback still apply there; physical power-loss proof is absent.
    if os.name == 'nt':
        return
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def _persist(path, value):
    data = mm.encoded(value)
    mm.atomic(path, data)
    _sync_dir(path.parent)
    if path.read_bytes() != data:
        raise OSError('Transaction readback failed: ' + str(path))

def _state_dir(root):
    path = mm.within(root, STATE)
    path.mkdir(parents=True, exist_ok=True)
    transactions = path / 'transfers'
    transactions.mkdir(exist_ok=True)
    _sync_dir(path)
    _sync_dir(path.parent)
    return path

def _identity(st):
    return [st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns]

def _open_source(path):
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0))
    handle = os.fdopen(fd, 'rb')
    st = os.fstat(handle.fileno())
    if not statmod.S_ISREG(st.st_mode) or path.is_symlink() or _identity(path.stat()) != _identity(st):
        handle.close()
        raise ValueError('Source identity changed or is not a regular file')
    return handle

def _fingerprint(path):
    with _open_source(path) as handle:
        before = os.fstat(handle.fileno())
        remaining = before.st_size
        digest = hashlib.sha256()
        while remaining:
            block = handle.read(min(CHUNK_SIZE, remaining))
            if not block:
                raise ValueError('File shortened during readback')
            digest.update(block); remaining -= len(block)
        if handle.read(1) or _identity(os.fstat(handle.fileno())) != _identity(before) or _identity(path.stat()) != _identity(before):
            raise ValueError('File changed during readback')
    return _identity(before), digest.hexdigest()

def _journal_path(root, txn):
    return mm.within(root, STATE + '/transfers/' + txn['id'] + '.json')

def _save_txn(root, txn):
    _persist(_journal_path(root, txn), txn)

def _source_matches(src, txn):
    identity, digest = _fingerprint(src)
    if identity != txn['source_identity'] or digest != txn['sha256']:
        raise ValueError('Source changed; preserving source and destination for review')

def _destination_matches(dst, txn):
    identity, digest = _fingerprint(dst)
    if identity != txn['destination_identity'] or digest != txn['sha256']:
        raise ValueError('Destination changed; preserving all surviving files for review')

def _metadata_matches(root, txn):
    sidecar_path = mm.within(root, str(Path(txn['source']).with_name('._' + Path(txn['source']).name)))
    sidecar = txn.get('sidecar')
    if sidecar:
        _source_matches(sidecar_path, sidecar)
    elif sidecar_path.exists() or sidecar_path.is_symlink():
        raise ValueError('Source metadata appeared after planning; source preserved')
    elif sys.platform == 'darwin':
        # A native resource fork without AppleDouble is not represented by this
        # byte-copy protocol. Refuse to silently remove it.
        fork = mm.within(root, txn['source']) / '..namedfork' / 'rsrc'
        try:
            if fork.stat().st_size:
                raise ValueError('Native resource fork requires a metadata-aware transfer')
        except OSError as exc:
            if exc.errno not in (errno.ENOENT, errno.ENOTDIR):
                raise

def _destination_pair_matches(root, txn):
    _destination_matches(mm.within(root, txn['destination']), txn)
    if txn.get('sidecar'):
        _destination_matches(mm.within(root, txn['sidecar']['destination']), txn['sidecar'])

def _copy_blob(root, blob, txn):
    src = mm.within(root, blob['source'])
    dst = mm.within(root, blob['destination'])
    _source_matches(src, blob)
    with _open_source(src) as source:
        if _identity(os.fstat(source.fileno())) != blob['source_identity']:
            raise ValueError('Source replaced before copying')
        fd = os.open(dst, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_BINARY', 0), 0o600)
        with os.fdopen(fd, 'wb') as target:
            _sync_dir(dst.parent)
            txn['status'] = 'copying'
            _save_txn(root, txn)
            remaining = blob['source_identity'][2]
            digest = hashlib.sha256()
            while remaining:
                block = source.read(min(CHUNK_SIZE, remaining))
                if not block:
                    raise ValueError('Source shortened while copying; partial copy preserved')
                target.write(block); digest.update(block); remaining -= len(block)
            if source.read(1) or digest.hexdigest() != blob['sha256'] or _identity(os.fstat(source.fileno())) != blob['source_identity']:
                raise ValueError('Source changed while copying; partial copy preserved')
            target.flush(); os.fsync(target.fileno())
            # ExFAT assigns a different inode when an empty file first allocates
            # data. Compare with the held descriptor AFTER allocation/readback.
            identity, digest = _fingerprint(dst)
            if identity != _identity(os.fstat(target.fileno())) or digest != blob['sha256']:
                raise ValueError('Destination replaced or corrupted while copying')
            blob['destination_identity'] = identity
    _source_matches(src, blob)

def _copy_exclusive(root, txn):
    _metadata_matches(root, txn)
    destination = mm.within(root, txn['destination'])
    companion = destination.with_name('._' + destination.name)
    if os.path.lexists(companion):
        raise ValueError('Destination metadata sidecar exists; never overwrite')
    if txn.get('sidecar'):
        backup = mm.within(root, txn['sidecar']['destination'])
        if backup.exists() or backup.is_symlink():
            raise ValueError('AppleDouble backup destination exists; never overwrite')
    _copy_blob(root, txn, txn)
    if txn.get('sidecar'):
        _copy_blob(root, txn['sidecar'], txn)
    _metadata_matches(root, txn)
    txn['status'] = 'copied'
    _save_txn(root, txn)

def _advance(root, txn):
    """Resume only phases whose owned, complete bytes can be proved."""
    try:
        src = mm.within(root, txn['source'])
        dst = mm.within(root, txn['destination'])
        if txn['status'] == 'planned':
            _copy_exclusive(root, txn)
        elif txn['status'] == 'copying':
            raise ValueError('Interrupted partial copy: inspect preserved source and destination')
        if txn['status'] == 'copied':
            _destination_pair_matches(root, txn)
            if src.exists() or src.is_symlink():
                _source_matches(src, txn)
                _metadata_matches(root, txn)
                # Recheck both pathname identities immediately before removal.
                for blob in [txn] + ([txn['sidecar']] if txn.get('sidecar') else []):
                    if _identity(mm.within(root, blob['destination']).stat()) != blob['destination_identity'] or _identity(mm.within(root, blob['source']).stat()) != blob['source_identity']:
                        raise ValueError('Transfer path changed before source removal')
                src.unlink()
                _sync_dir(src.parent)
            txn['status'] = 'filed_map_pending'
            _save_txn(root, txn)
        if txn['status'] == 'filed_map_pending':
            _destination_pair_matches(root, txn)
    except (OSError, ValueError) as exc:
        txn['status'] = 'needs_review'
        txn['reason'] = str(exc)
        _save_txn(root, txn)
    return txn

def _load_transfers(root):
    transfers = []
    for path in sorted(mm.within(root, STATE + '/transfers').glob('*.json')):
        if path.name.startswith('._'):
            continue
        txn = json.loads(path.read_text())
        if not isinstance(txn, dict) or txn.get('schema_version') != 1 or path.stem != txn.get('id'):
            raise ValueError('Invalid download transfer journal: ' + path.name)
        source, destination = Path(txn['source']), Path(txn['destination'])
        if source.parent.as_posix() != 'Downloads' or destination.parts[0] not in ('Brain', 'Jobs', 'Wiki') or source.name != destination.name:
            raise ValueError('Invalid transfer routing in journal: ' + path.name)
        mm.within(root, txn['source']); mm.within(root, txn['destination'])
        phases = ('planned', 'copying', 'copied', 'filed_map_pending', 'filed', 'needs_review')
        identity = txn.get('source_identity')
        digest = txn.get('sha256')
        if txn.get('status') not in phases or not isinstance(identity, list) or len(identity) != 5 or not all(isinstance(n, int) for n in identity) or identity[2] < 0 or not isinstance(digest, str) or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise ValueError('Invalid transfer evidence in journal: ' + path.name)
        if txn['status'] in ('copied', 'filed_map_pending', 'filed') and (not isinstance(txn.get('destination_identity'), list) or len(txn['destination_identity']) != 5):
            raise ValueError('Missing destination identity in journal: ' + path.name)
        if txn.get('sidecar'):
            sidecar = txn['sidecar']
            expected_source = str(source.with_name('._' + source.name))
            if sidecar.get('source') != expected_source or sidecar.get('destination') != txn['destination'] + '.appledouble':
                raise ValueError('Invalid AppleDouble backup paths')
            mm.within(root, sidecar['source']); mm.within(root, sidecar['destination'])
            ident, sha = sidecar.get('source_identity'), sidecar.get('sha256')
            if not isinstance(ident, list) or len(ident) != 5 or not all(isinstance(n, int) for n in ident) or ident[2] < 0 or not isinstance(sha, str) or len(sha) != 64 or any(c not in '0123456789abcdef' for c in sha):
                raise ValueError('Invalid AppleDouble backup evidence')
            if txn['status'] in ('copied', 'filed_map_pending', 'filed') and (not isinstance(sidecar.get('destination_identity'), list) or len(sidecar['destination_identity']) != 5):
                raise ValueError('Missing AppleDouble destination identity')
        if txn['status'] not in ('filed', 'needs_review'):
            _advance(root, txn)
        transfers.append(txn)
    return sorted(transfers, key=lambda txn: (txn.get('planned_at', ''), txn['id']))

def _record(state, txn):
    state['files'][txn['source']] = {
        'status': txn['status'], 'destination': txn['destination'],
        'sha256': txn['sha256'], 'signature': txn['source_identity'][2:4],
        'transaction': txn['id'], **({'metadata_backup': txn['sidecar']['destination'], 'metadata_sha256': txn['sidecar']['sha256']} if txn.get('sidecar') else {}), **({'reason': txn['reason']} if txn.get('reason') else {})}

def _read_state(state_dir):
    path = state_dir / 'state.json'
    state = json.loads(path.read_text()) if path.exists() else {'files': {}, 'last_scan': None}
    for item in state['files'].values():
        if item.get('status') == 'filed_map_pending' and not item.get('transaction'):
            item.update(status='needs_review', reason='Legacy pending receipt has no transfer journal; verify files and maps manually')
    return state

def _new_transfer(root, src, destination):
    identity, digest = _fingerprint(src)
    txn = {'schema_version': 1, 'id': uuid.uuid4().hex,
           'source': src.relative_to(root).as_posix(),
           'destination': destination.relative_to(root).as_posix(),
           'source_identity': identity, 'sha256': digest,
           'status': 'planned', 'planned_at': dt.datetime.now(dt.timezone.utc).isoformat()}
    sidecar = src.with_name('._' + src.name)
    if sidecar.exists() or sidecar.is_symlink():
        side_identity, side_hash = _fingerprint(sidecar)
        txn['sidecar'] = {'source': sidecar.relative_to(root).as_posix(),
                          'destination': destination.relative_to(root).as_posix() + '.appledouble',
                          'source_identity': side_identity, 'sha256': side_hash,
                          'format': 'raw-appledouble-backup-not-reapplied'}
    _metadata_matches(root, txn)
    _save_txn(root, txn)  # flushed and read back before destination creation
    return _advance(root, txn)

def _finish_maps(root, state, transfers, extra_changes=()):
    pending = [t for t in transfers if t['status'] == 'filed_map_pending']
    changes = list(extra_changes)
    for txn in pending:
        changes.extend([txn['source'], txn['destination']])
        if txn.get('sidecar'):
            changes.extend([txn['sidecar']['source'], txn['sidecar']['destination']])
    if changes:
        try:
            rebuilt = mm.rebuild(root, sorted(set(changes)))
            if rebuilt.get('status') != 'PASS' or mm.verify(root).get('status') != 'PASS':
                raise ValueError('Download map verification did not pass')
            for txn in pending:
                _advance(root, txn)
                if txn['status'] == 'filed_map_pending':
                    txn['status'] = 'filed'
                    _save_txn(root, txn)
        except (OSError, ValueError) as exc:
            state['map_error'] = str(exc)
    for txn in transfers:
        if txn['status'] != 'filed' or not mm.within(root, txn['source']).exists():
            _record(state, txn)
    _persist(mm.within(root, STATE + '/state.json'), state)
    return state

def status(root):
    state_dir = mm.within(root, STATE)
    result = _read_state(state_dir)
    result['running'] = False
    if state_dir.exists():
        try:
            with _acquire(state_dir / 'watch.lock'):
                pass
        except LockBusy:
            result['running'] = True
        except OSError as exc:
            result.update(running=None, lock_error=str(exc))
    return result

def scan_once(root, clock=None, force=False):
    now = time.time() if clock is None else clock
    state_dir = _state_dir(root)
    with _acquire(state_dir / 'scan.lock'):
        config = json.loads(mm.within(root, RULES).read_text())
        stable_seconds = float(config.get('stable_seconds', 10))
        if stable_seconds < 1:
            raise ValueError('stable_seconds must be positive')
        state = _read_state(state_dir)
        state.pop('map_error', None)
        state['last_scan'] = dt.datetime.fromtimestamp(now, dt.timezone.utc).isoformat()
        transfers = _load_transfers(root)
        protected = {t['source'] for t in transfers if t['status'] != 'filed'}
        inbox = mm.within(root, 'Downloads')
        for src in sorted(inbox.iterdir()):
            if not src.is_file() or src.is_symlink() or src.name == 'INDEX.md' or src.name.startswith('.') or src.name.lower().endswith(PARTIAL):
                continue
            rel = src.relative_to(root).as_posix()
            if rel in protected:
                continue
            st = src.stat(); signature = [st.st_size, st.st_mtime_ns]
            old = state['files'].get(rel, {})
            initial = min(now, st.st_mtime)
            item = {'signature': signature, 'stable_since': old.get('stable_since', initial) if old.get('signature') == signature else initial, 'status': 'downloading'}
            state['files'][rel] = item
            if not force and now - item['stable_since'] < stable_seconds:
                continue
            rules = [r for r in config.get('rules', []) if fnmatch.fnmatchcase(src.name, r['pattern'])]
            if len(rules) != 1:
                item.update(status='needs_review', reason='No unique routing rule; assistant must classify by purpose')
                continue
            dest_dir = rules[0]['destination']
            if not dest_dir.startswith(('Brain/', 'Jobs/', 'Wiki/')):
                raise ValueError('Destination must be inside Brain, Jobs or Wiki')
            dest = mm.within(root, dest_dir + '/' + src.name)
            if not dest.parent.is_dir() or dest.exists() or dest.is_symlink():
                item.update(status='needs_review', reason='Destination unavailable or already exists; never overwrite')
                continue
            transfers.append(_new_transfer(root, src, dest))
        for name, item in state['files'].items():
            if not (root / name).exists() and item.get('status') in ('downloading', 'needs_review') and not item.get('transaction') and not item.get('destination'):
                item.update(status='removed_from_inbox', reason='No longer present; no destination inferred')
        # Also map new/unclassified inbox files; transaction state itself is excluded.
        extra = []
        try:
            inventory = json.loads((root / mm.INVENTORY).read_text())
            known = {x['path'] for x in inventory['entries'] if x['path'].startswith('Downloads/')}
            actual, _ = mm.scan(root, 'Downloads')
            if known != set(actual) - {'Downloads'}:
                extra.append('Downloads')
        except (OSError, ValueError, KeyError) as exc:
            state['map_error'] = str(exc)
        return _finish_maps(root, state, transfers, extra)

def file_download(root, filename, destination_dir):
    if not filename or not destination_dir:
        raise ValueError('filename and destination_dir are required')
    filename = Path(filename).name
    dest_clean = destination_dir.strip().rstrip('/')
    if not (dest_clean in ('Brain', 'Jobs', 'Wiki') or dest_clean.startswith(('Brain/', 'Jobs/', 'Wiki/'))):
        raise ValueError('Destination must be inside Brain, Jobs or Wiki')
    state_dir = _state_dir(root)
    with _acquire(state_dir / 'scan.lock'):
        state = _read_state(state_dir)
        state.pop('map_error', None)
        state['last_scan'] = mm.now()
        transfers = _load_transfers(root)
        rel_src, rel_dest = 'Downloads/' + filename, dest_clean + '/' + filename
        pending = [t for t in transfers if t['source'] == rel_src and t['status'] != 'filed']
        if pending:
            txn = pending[-1]
            if txn['destination'] != rel_dest:
                raise ValueError('Existing transfer needs review before changing its destination')
        else:
            src = mm.within(root, rel_src)
            dest = mm.within(root, rel_dest)
            if not src.is_file() or src.is_symlink():
                raise ValueError('Source file not found in Downloads: ' + filename)
            if not dest.parent.is_dir():
                raise ValueError('Destination directory does not exist: ' + dest_clean)
            if dest.exists() or dest.is_symlink():
                raise ValueError('Destination file already exists: ' + rel_dest)
            txn = _new_transfer(root, src, dest)
            transfers.append(txn)
        _finish_maps(root, state, transfers)
        return dict(status=txn['status'].upper(), source=rel_src, destination=rel_dest,
                    map_status='PASS' if txn['status'] == 'filed' else 'PENDING',
                    **({'metadata_backup': txn['sidecar']['destination']} if txn.get('sidecar') else {}),
                    **({'error': state['map_error']} if state.get('map_error') else {}),
                    **({'reason': txn['reason']} if txn.get('reason') else {}))

def run(root, interval):
    state_dir = _state_dir(root)
    try:
        lock = _acquire(state_dir / 'watch.lock')
    except LockBusy:
        return {'status': 'ALREADY_RUNNING'}
    with lock:
        _persist(state_dir / 'process.json', {'pid': os.getpid(), 'started_at': mm.now()})
        while not (state_dir / 'stop').exists():
            try:
                scan_once(root)
            except (OSError, ValueError, KeyError) as exc:
                _persist(state_dir / 'last-error.json', {'error': str(exc), 'at': mm.now()})
            time.sleep(interval)
        return {'status': 'STOPPED'}

def start(root, interval):
    state_dir = _state_dir(root)
    # Serialize starters; each daemon must independently hold watch.lock before scanning.
    with _acquire(state_dir / 'start.lock'):
        current = status(root)
        if current.get('lock_error'):
            raise OSError(current['lock_error'])
        if current['running']:
            return {'status': 'ALREADY_RUNNING'}
        (state_dir / 'stop').unlink(missing_ok=True)
        with (state_dir / 'watch.log').open('ab') as log:
            subprocess.Popen([sys.executable, '-B', str(Path(__file__).resolve()), 'run', '--root', str(root), '--interval', str(interval)], stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
        for _ in range(20):
            time.sleep(.1)
            current = status(root)
            if current.get('lock_error'):
                raise OSError(current['lock_error'])
            if current['running']:
                return {'status': 'RUNNING', 'root': str(root)}
        return {'status': 'FAILED_TO_START', 'root': str(root)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['once', 'run', 'start', 'status', 'stop', 'file'])
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--interval', type=float, default=5)
    parser.add_argument('--force', action='store_true')
    parser.add_argument('--file')
    parser.add_argument('--destination')
    args = parser.parse_args()
    root = args.root.resolve()
    if args.interval < 1:
        parser.error('interval must be at least one second')
    try:
        if args.operation == 'once':
            result = scan_once(root, force=args.force)
        elif args.operation == 'file':
            result = file_download(root, args.file, args.destination)
        elif args.operation == 'run':
            result = run(root, args.interval)
        elif args.operation == 'start':
            result = start(root, args.interval)
        elif args.operation == 'status':
            result = status(root)
        else:
            mm.within(root, STATE).mkdir(parents=True, exist_ok=True)
            mm.atomic(root / STATE / 'stop', b'stop\n')
            result = {'status': 'STOP_REQUESTED'}
    except (OSError, ValueError, KeyError) as e:
        result = {'status': 'FAIL', 'error': str(e)}
    print(json.dumps(result, indent=2))
    return 1 if result.get('status') in ('FAIL', 'FAILED_TO_START', 'NEEDS_REVIEW', 'FILED_MAP_PENDING') else 0

if __name__ == '__main__':
    sys.exit(main())
