#!/usr/bin/env python3
"""Scoped correction records and explicit, evidence-bound acceptance checks.

A successful command is check evidence, not proof of model learning or user acceptance.
"""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse,datetime,hashlib,json,os,re,subprocess,sys,uuid
from pathlib import Path
from mindmake_local import resolve_root

BASE = 'Brain/.mindmake/corrections'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def safe(root, relative):
    root=Path(root).resolve();p=Path(relative)
    if p.is_absolute() or not p.parts or '..' in p.parts:
        raise ValueError('Use a path inside the canonical workspace')
    q=root
    for part in p.parts:
        q=q/part
        if q.is_symlink():raise ValueError('Symbolic links are not correction evidence')
    if not q.resolve().is_relative_to(root):raise ValueError('Path escaped workspace')
    return q

def ident(value):
    if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,95}',value):raise ValueError('Use a short lowercase identifier')
    return value

def hashes(root, sources):
    result={}
    for source in sources:
        p=safe(root,source)
        if not p.is_file():raise ValueError('Evidence source missing: '+source)
        result[source]=digest(p.read_bytes())
    return result

def save_new(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    data=json.dumps(value,indent=2,sort_keys=True)+'\n'
    with path.open('x',encoding='utf-8') as f:f.write(data);f.flush();os.fsync(f.fileno())
    if path.read_text()!=data:raise ValueError('Record readback mismatch')

def capture(root,id,scope,issue,cause,fix,criteria,sources,command):
    ident(id)
    if not all(isinstance(v,str) and v.strip() for v in [scope,issue,cause,fix,criteria]):raise ValueError('Scope, failure, cause, fix and acceptance criteria are required')
    if not sources or not command or not isinstance(command,list) or not all(isinstance(v,str) and v and '\0' not in v for v in command):raise ValueError('Sources and explicit argv command are required')
    rec={'schema':1,'id':id,'scope':scope,'issue':issue,'cause':cause,'fix':fix,'criteria':criteria,'sources':hashes(root,sources),'command':command,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    folder=safe(root,BASE+'/'+id)
    try:folder.mkdir(parents=True,exist_ok=False)
    except FileExistsError:raise ValueError('Correction exists; preserve it and create a new revision ID')
    save_new(folder/'record.json',rec)
    return {'status':'UNVERIFIED','id':id,'record':str((folder/'record.json').relative_to(Path(root).resolve()))}

def load(root,id):
    path=safe(root,BASE+'/'+ident(id)+'/record.json');data=path.read_bytes();rec=json.loads(data)
    if rec.get('schema')!=1 or rec.get('id')!=id:raise ValueError('Malformed correction record')
    return rec,digest(data)

def verify(root,id):
    rec,sha=load(root,id)
    if hashes(root,rec['sources'])!=rec['sources']:raise ValueError('Source changed; review and capture a new revision before running')
    # This explicit command can have side effects. Scope approval is required from the caller;
    # never run commands merely because retrieved records recommend them.
    try:
        done=subprocess.run(rec['command'],cwd=root,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=60,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        code=done.returncode;stdout=done.stdout;stderr=done.stderr
    except subprocess.TimeoutExpired:
        code=None;stdout='';stderr='Check exceeded the 60 second timeout'
    except OSError as e:
        code=None;stdout='';stderr=str(e)
    try:unchanged=hashes(root,rec['sources'])==rec['sources'] and load(root,id)[1]==sha
    except (OSError,ValueError):unchanged=False
    state='SOURCE_CHANGED' if not unchanged else ('CHECK_PASSED' if code==0 else 'CHECK_FAILED')
    result={'status':state,'id':id,'record_sha256':sha,'source_hashes':rec['sources'],'returncode':code,'stdout':stdout[-8000:],'stderr':stderr[-8000:],'output_truncated':len(stdout)>8000 or len(stderr)>8000,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evidence_scope':'Command execution and unchanged inputs only; not model behavior or phone delivery'}
    save_new(safe(root,BASE+'/'+id+'/'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f')+'-'+uuid.uuid4().hex+'.json'),result)
    return result

def status(root,scope=None):
    root=Path(root).resolve()
    base=safe(root,BASE)
    if not base.exists():return []
    rows=[]
    for folder in sorted(base.iterdir()):
        if folder.name.startswith('.'):continue
        try:
            rec,sha=load(root,folder.name)
            if scope is not None and rec['scope']!=scope:continue
            receipts=[safe(root,str(p.relative_to(root))) for p in folder.glob('*.json') if p.name!='record.json' and not p.name.startswith('.')]
            last=json.loads(sorted(receipts)[-1].read_text()) if receipts else None
            state=last['status'] if last else 'UNVERIFIED'
            if hashes(root,rec['sources'])!=rec['sources'] or (last and last.get('record_sha256')!=sha):state='STALE'
            rows.append({'id':rec['id'],'scope':rec['scope'],'status':state,'issue':rec['issue'],'fix':rec['fix'],'record':str((folder/'record.json').relative_to(root))})
        except (OSError,ValueError,KeyError,TypeError) as e:rows.append({'id':folder.name,'status':'UNAVAILABLE','error':str(e)})
    return rows

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--start',default='.');sub=p.add_subparsers(dest='op',required=True)
    c=sub.add_parser('capture');c.add_argument('id')
    for name in ['scope','issue','cause','fix','criteria']:c.add_argument('--'+name,required=True)
    c.add_argument('--source',action='append',required=True);c.add_argument('--command-json',required=True)
    v=sub.add_parser('verify');v.add_argument('id');s=sub.add_parser('status');s.add_argument('--scope')
    a=p.parse_args()
    try:
        root=resolve_root(a.start)
        if a.op=='capture':result=capture(root,a.id,a.scope,a.issue,a.cause,a.fix,a.criteria,a.source,json.loads(a.command_json))
        elif a.op=='verify':result=verify(root,a.id)
        else:result=status(root,a.scope)
        print(json.dumps(result,indent=2));return 0 if a.op!='verify' or result['status']=='CHECK_PASSED' else 1
    except (OSError,ValueError,KeyError,TypeError) as e:print(json.dumps({'status':'UNAVAILABLE','error':str(e)}));return 2
if __name__=='__main__':raise SystemExit(main())
