#!/usr/bin/env python3
"""Local active-work context and recoverable TODO projection; never a scheduler.

X3.0 (from ChatGPT's 3.0C, fixed): tasks can be superseded (closed, not done),
the active task never changes silently, and every task gets a permanent number
(shown in TODO.md instead of ids, accepted by --id) that never shifts.

Examples:
  python3 Brain/tools/workspace.py capture --event e1 --text "Book the venue" --next "Ask for dates"
  python3 Brain/tools/workspace.py capture --event e2 --text "Quick: reply to Sam" --next "Draft reply" --tangent
  python3 Brain/tools/workspace.py resume --event e3      # back to the venue; Sam stays on the open list
  python3 Brain/tools/workspace.py capture --event e4 --text "Book venue B instead" --next "Call B" --supersedes 1
  python3 Brain/tools/workspace.py progress --event e5 --id 2 --state done --next "Replied" --evidence "Sent 21 Nov"
  python3 Brain/tools/workspace.py status
  (Task numbers are permanent: 1 is the venue, 2 is Sam, 3 is venue B, even after tasks close.)
"""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys
import uuid
import mindmake as mm

STORE = 'Brain/.mindmake/workspace-state'
BEGIN = '<!-- MINDMAKE TASKS BEGIN -->'
CLOSED = ('done', 'superseded')
OPEN_SQL = "state NOT IN ('done','superseded')"
END = '<!-- MINDMAKE TASKS END -->'


def database(root, create=False):
    path = mm.within(root, STORE+'/state.sqlite3')
    if not path.exists() and not create:
        return None
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(path) if create else path.as_uri()+'?mode=ro', uri=not create, timeout=10)
    db.row_factory = sqlite3.Row
    if create:
        db.execute('PRAGMA synchronous=FULL')
        db.executescript('''CREATE TABLE IF NOT EXISTS tasks(
            id TEXT PRIMARY KEY, request TEXT NOT NULL, project TEXT,
            next_step TEXT NOT NULL, state TEXT NOT NULL, created_at TEXT, updated_at TEXT);
            CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,payload TEXT NOT NULL,
                result TEXT NOT NULL,recorded_at TEXT NOT NULL);''')
        # X3.0: permanent task numbers. A number is never reused or shifted.
        if 'number' not in [r[1] for r in db.execute('PRAGMA table_info(tasks)')]:
            db.execute('ALTER TABLE tasks ADD COLUMN number INTEGER')
            for i, (rid,) in enumerate(db.execute('SELECT rowid FROM tasks ORDER BY rowid').fetchall(), 1):
                db.execute('UPDATE tasks SET number=? WHERE rowid=?', (i, rid))
            db.commit()
    return db


def context(db):
    row = db.execute("SELECT value FROM meta WHERE key='context'").fetchone()
    return json.loads(row['value']) if row else {'active':None,'stack':[],'dirty':False}


def status(root):
    db = database(root)
    if db is None:
        return dict(status='NO_TASKS',active=None,return_to=None,open_tasks=[],projection='CURRENT',errors=[])
    try:
        ctx = context(db)
        tasks = {r['id']:dict(r) for r in db.execute('SELECT * FROM tasks ORDER BY rowid')}
        parked = next((tasks[i] for i in reversed(ctx['stack']) if i in tasks and tasks[i]['state'] not in CLOSED),None)
        return dict(status='RECORDED',active=tasks.get(ctx['active']),return_to=parked,
                    open_tasks=[t for t in tasks.values() if t['state'] not in CLOSED],
                    projection='PENDING' if ctx['dirty'] else 'CURRENT',errors=[],
                    evidence='Operator-attributed task state; not independent outcome or reminder verification')
    finally:
        db.close()


def numbered(db):
    return [dict(r) for r in db.execute('SELECT * FROM tasks WHERE '+OPEN_SQL+' ORDER BY rowid')]


def resolve(db, ref):
    """Accept a task id or the permanent task number shown in TODO.md."""
    if ref is None: return None
    ref = str(ref).strip().lstrip('#')
    if ref.isdigit() and len(ref) < 6:
        row = db.execute('SELECT id FROM tasks WHERE number=?', (int(ref),)).fetchone()
        if not row: raise ValueError('No task number '+ref)
        return row['id']
    if not db.execute('SELECT 1 FROM tasks WHERE id=?',(ref,)).fetchone(): raise ValueError('Unknown task ID')
    return ref


def _text(value, name, allow_empty=False):
    if not isinstance(value,str) or len(value)>8000 or (not value.strip() and not allow_empty):
        raise ValueError(name+' must be explicit text of at most 8000 characters')
    return value.strip()


def mutate(root, operation, event, text=None, next_step=None, project=None,
           tangent=False, task_id=None, task_state=None, evidence=None, switch=False, supersedes=None):
    if not isinstance(event,str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,160}',event):
        raise ValueError('Use a unique opaque event ID; reuse it only for an identical retry')
    if operation=='capture':
        text=_text(text,'Request'); next_step=_text(next_step,'Next action')
        if project:
            if not project.startswith('Jobs/') or project.count('/')!=1:
                raise ValueError('Project must name one registered Jobs folder')
            mm.within(root,project+'/JOB.md').read_text()
            if project not in mm.state(root)['project_maps']:
                raise ValueError('Project is not registered')
    elif operation=='progress':
        if task_state not in ('open','blocked','done','superseded'):
            raise ValueError('Unknown task state (open, blocked, done or superseded)')
        next_step=_text(next_step,'Next action or completion result')
        if task_state in CLOSED: evidence=_text(evidence,'Completion evidence (what shows it is done, or why it was replaced)')
    elif operation!='resume':
        raise ValueError('Unknown operation')
    if operation=='capture' and sum(map(bool,(tangent,switch,supersedes)))>1:
        raise ValueError('Use only one of --tangent, --switch or --supersedes')
    payload=dict(operation=operation,text=text,next_step=next_step,project=project,
                 tangent=tangent,task_id=task_id,task_state=task_state,evidence=evidence)
    if switch: payload['switch']=True
    if supersedes: payload['supersedes']=str(supersedes)
    encoded=json.dumps(payload,sort_keys=True)
    db=database(root,True)
    try:
        db.execute('BEGIN IMMEDIATE')
        prior=db.execute('SELECT * FROM events WHERE id=?',(event,)).fetchone()
        if prior:
            if prior['payload']!=encoded: raise ValueError('Event ID already has different arguments')
            result=json.loads(prior['result']); db.commit()
        else:
            ctx=context(db); stamp=mm.now()
            def usable(identity):
                return identity and db.execute("SELECT 1 FROM tasks WHERE id=? AND "+OPEN_SQL,(identity,)).fetchone()
            def pop_return():
                while ctx['stack']:
                    candidate=ctx['stack'].pop()
                    if usable(candidate): return candidate
                return None
            previous_active=ctx['active'] if usable(ctx['active']) else None
            note=None
            if operation=='capture':
                old=resolve(db,supersedes) if supersedes else None
                if old and not usable(old): raise ValueError('Only an open task can be superseded')
                identity=uuid.uuid5(uuid.NAMESPACE_URL,event).hex[:16]
                number=(db.execute('SELECT COALESCE(MAX(number),0)+1 FROM tasks').fetchone()[0])
                db.execute('INSERT INTO tasks(id,request,project,next_step,state,created_at,updated_at,number) VALUES(?,?,?,?,?,?,?,?)',
                           (identity,text,project,next_step,'open',stamp,stamp,number))
                if old:
                    db.execute('UPDATE tasks SET state=?,next_step=?,updated_at=? WHERE id=?',
                               ('superseded','Replaced by: '+' '.join(text.split()),stamp,old))
                    ctx['stack']=[i for i in ctx['stack'] if i!=old]
                    if previous_active in (None,old): ctx['active']=identity; note='replaced the active task'
                    else: note='replaced an open task; active task unchanged'
                elif tangent:
                    if previous_active: ctx['stack'].append(previous_active)
                    ctx['active']=identity; note='tangent; previous task parked as return point'
                elif switch or not previous_active:
                    ctx['active']=identity; note='now active' + ('; previous task stays open' if previous_active else '')
                else:
                    note='added to the open list; active task unchanged (use --switch or --tangent to change it)'
            elif operation=='progress':
                identity=resolve(db,task_id)
                if identity is None: raise ValueError('progress needs --id (task id or list number)')
                db.execute('UPDATE tasks SET state=?,next_step=?,updated_at=? WHERE id=?',
                           (task_state,next_step,stamp,identity))
                if task_state in CLOSED:
                    ctx['stack']=[i for i in ctx['stack'] if i!=identity]
                    if ctx['active']==identity: ctx['active']=pop_return()
            else:
                task_id=resolve(db,task_id)
                identity=task_id or pop_return()
                if not usable(identity): raise ValueError('No unfinished return point; choose an open task')
                if task_id:
                    ctx['stack']=[i for i in ctx['stack'] if i!=identity]
                    if usable(ctx['active']) and ctx['active']!=identity: ctx['stack'].append(ctx['active'])
                ctx['active']=identity
            ctx['dirty']=True
            result=dict(status='RECORDED',task_id=identity,event=event,errors=[],
                        previous_active=previous_active,active=ctx['active'],
                        active_changed=previous_active!=ctx['active'])
            if note: result['note']=note
            db.execute("INSERT OR REPLACE INTO meta VALUES('context',?)",(json.dumps(ctx),))
            db.execute('INSERT INTO events VALUES(?,?,?,?)',(event,encoded,json.dumps(result),stamp))
            db.commit()
    except BaseException:
        db.rollback(); raise
    finally:
        db.close()
    try:
        result=dict(result,checkpoint=checkpoint(root))
    except (OSError,ValueError,sqlite3.Error) as exc:
        result=dict(result,status='SAVED_CHECKPOINT_PENDING',errors=[str(exc)],
                    recovery='Task data is saved. Run workspace.py checkpoint; do not claim completed filing.')
    return result


def render(root, db, ctx):
    path=mm.within(root,'TODO.md'); old=path.read_bytes() if path.exists() else b''
    text=old.decode('utf-8')
    if text.count(BEGIN)!=text.count(END) or text.count(BEGIN)>1 or (BEGIN in text and text.index(BEGIN)>text.index(END)):
        raise ValueError('Malformed task projection markers; preserve and reconcile TODO.md')
    rows=numbered(db)
    def line(value): return ' '.join(value.split())
    def label(n,t): return f"{t['number']}. {line(t['request'])}" + (' (blocked)' if t['state']=='blocked' else '')
    body=['## NOW']
    active=next((t for t in rows if t['id']==ctx['active']),None)
    if active:
        body += [label(rows.index(active)+1,active), f"   Next: {line(active['next_step'])}"]
        if active['project']: body += ['   Project: '+active['project']]
    else: body += ['No active task.']
    parked=[i for i in ctx['stack'] if any(t['id']==i for t in rows)]
    body += ['','## OPEN (task numbers are permanent and work as --id)']
    for n,t in enumerate(rows,1):
        if t is not active:
            body += [label(n,t)+(' (return point)' if t['id'] in parked else ''), f"   Next: {line(t['next_step'])}"]
    if len(rows)==bool(active): body += ['No other recorded open tasks.']
    block=BEGIN+'\n\n'+'\n'.join(body)+'\n\n'+END
    candidate=(text[:text.index(BEGIN)]+block+text[text.index(END)+len(END):]) if BEGIN in text else text.rstrip()+'\n\n'+block+'\n'
    return path,old,candidate.encode()


def checkpoint(root):
    db=database(root)
    if db is None: return dict(status='CURRENT',errors=[])
    db.close(); db=database(root,True)
    try:
        db.execute('BEGIN IMMEDIATE'); ctx=context(db)
        if not ctx['dirty']:
            db.commit(); return dict(status='CURRENT',errors=[])
        path,old,new=render(root,db,ctx)
        sha=hashlib.sha256(old).hexdigest()
        backup=mm.within(root,STORE+'/todo-backups/'+sha+'.md');backup.parent.mkdir(parents=True,exist_ok=True)
        if backup.exists():
            if backup.read_bytes()!=old: raise ValueError('TODO backup bytes conflict')
        else:
            with backup.open('xb') as handle: handle.write(old)
        if (path.read_bytes() if path.exists() else b'')!=old:
            raise ValueError('TODO changed during checkpoint')
        mm.atomic(path,new)
        mm.rebuild(root,['TODO.md'])
        checked=mm.verify(root)
        if checked['status']!='PASS': raise ValueError('Map checkpoint failed: '+str(checked['errors']))
        ctx['dirty']=False
        db.execute("UPDATE meta SET value=? WHERE key='context'",(json.dumps(ctx),))
        event='checkpoint:'+uuid.uuid4().hex
        db.execute('INSERT INTO events VALUES(?,?,?,?)',
                   (event,json.dumps({'operation':'checkpoint','prior_todo_sha256':sha}),
                    json.dumps({'status':'VERIFIED','map_generation':mm.state(root)['generation_id']}),mm.now()))
        db.commit()
        return dict(status='VERIFIED',prior_todo_sha256=sha,errors=[])
    except BaseException:
        db.rollback();raise
    finally: db.close()


def audit(root):
    db=database(root)
    if db is None:return dict(events=[],errors=[])
    try:
        return dict(events=[dict(id=r['id'],payload=json.loads(r['payload']),result=json.loads(r['result']),
                                 recorded_at=r['recorded_at']) for r in db.execute('SELECT * FROM events ORDER BY rowid')],
                    errors=[],evidence='Recorded operator assertions/actions, not independent semantic verification')
    finally:db.close()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('operation',choices=['status','capture','progress','resume','checkpoint','audit'])
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    for option in ('event','text','next','project','id','state','evidence'):p.add_argument('--'+option)
    p.add_argument('--supersedes',help='task id or list number this new task replaces')
    p.add_argument('--tangent',action='store_true');p.add_argument('--switch',action='store_true');a=p.parse_args();root=a.root.resolve()
    try:
        if a.operation=='status':result=status(root)
        elif a.operation=='audit':result=audit(root)
        elif a.operation=='checkpoint':result=checkpoint(root)
        else:result=mutate(root,a.operation,a.event,a.text,getattr(a,'next'),a.project,a.tangent,a.id,a.state,a.evidence,a.switch,a.supersedes)
    except (OSError,ValueError,sqlite3.Error) as exc:result=dict(status='FAIL',errors=[str(exc)])
    print(json.dumps(result,indent=2));return bool(result.get('errors'))

if __name__=='__main__':sys.exit(main())
