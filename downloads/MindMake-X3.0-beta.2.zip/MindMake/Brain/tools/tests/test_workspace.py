"""Actual disk/restart/checkpoint tests; no model or reminder acceptance implied."""
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import workspace as w
mm=w.mm

class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        for rel,text in {'FOLDER_MAP.md':'# Home\n','Jobs/Test/JOB.md':'# Project\n',
                         'Jobs/INDEX.md':'# Jobs\n','Seeds/SEEDS_MAP.md':'# Seeds\n',
                         'Seeds/Index/seed-index.md':'# Seeds\n','TODO.md':'# User notes\nKeep my authored paragraph.\n'}.items():
            p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
        for rel in ['Seeds/Short-term','Seeds/Long-term','Jobs/Test/Seeds/Short-term','Jobs/Test/Seeds/Long-term']:
            (self.root/rel).mkdir(parents=True)
        (self.root/mm.REGISTRY).parent.mkdir(parents=True,exist_ok=True)
        (self.root/mm.REGISTRY).write_text(json.dumps(dict(root_map='FOLDER_MAP.md',project_maps={'Jobs/Test':'Jobs/Test/JOB.md'},generation_id='initial')))
        (self.root/mm.INVENTORY).write_text(json.dumps(dict(entries=[],generation_id='initial')))
        mm.rebuild(self.root)

    def capture(self,event='main',text='Finish the project',step='Review the existing draft',**kw):
        result=w.mutate(self.root,'capture',event,text=text,next_step=step,**kw)
        self.assertEqual([],result['errors']);return result['task_id']

    # X3.0 fixes to the 3.0C tool
    def test_x3_supersede_closes_old_task_without_marking_done(self):
        old=self.capture('a','Book venue A','Call A')
        new=self.capture('b','Book venue B instead','Call B',supersedes='1')
        with w.database(self.root) as db:
            states={r['id']:r['state'] for r in db.execute('SELECT id,state FROM tasks')}
        self.assertEqual('superseded',states[old]); self.assertEqual('open',states[new])
        st=w.status(self.root)
        self.assertEqual(new,st['active']['id']); self.assertEqual([new],[t['id'] for t in st['open_tasks']])
        self.assertNotIn('Book venue A',(self.root/'TODO.md').read_text())

    def test_x3_capture_never_swaps_active_task_silently(self):
        first=self.capture('a','Main job','Step one')
        r=w.mutate(self.root,'capture','b',text='Side idea',next_step='Think')
        self.assertEqual(first,r['active']); self.assertFalse(r['active_changed']); self.assertIn('unchanged',r['note'])
        r=w.mutate(self.root,'capture','c',text='Urgent thing',next_step='Do it',switch=True)
        self.assertTrue(r['active_changed']); self.assertEqual(first,r['previous_active'])
        self.assertIn(first,[t['id'] for t in w.status(self.root)['open_tasks']])

    def test_x3_todo_has_list_numbers_not_ids_and_numbers_work_as_id(self):
        first=self.capture('a','Main job','Step one')
        self.capture('b','Side errand','Go',tangent=True)
        todo=(self.root/'TODO.md').read_text()
        self.assertNotIn(first,todo); self.assertNotIn('id:',todo)
        self.assertIn('1. Main job',todo); self.assertIn('(return point)',todo)
        w.mutate(self.root,'progress','c',task_id='2',task_state='done',next_step='Done',evidence='Receipt seen')
        self.assertEqual(first,w.status(self.root)['active']['id'])

    def test_x3_superseded_via_progress_needs_reason(self):
        self.capture('a','Old plan','Step')
        with self.assertRaisesRegex(ValueError,'Completion evidence'):
            w.mutate(self.root,'progress','b',task_id='1',task_state='superseded',next_step='Dropped')

    def test_x3_task_numbers_are_permanent_after_closing_earlier_tasks(self):
        a=self.capture('a','First','Go'); b=self.capture('b','Second','Go',switch=True); c=self.capture('c','Third','Go',switch=True)
        w.mutate(self.root,'progress','d',task_id='1',task_state='done',next_step='Done',evidence='Seen')
        w.mutate(self.root,'progress','e',task_id='3',task_state='blocked',next_step='Waiting on Sam')
        with w.database(self.root) as db:
            states={r['id']:r['state'] for r in db.execute('SELECT id,state FROM tasks')}
        self.assertEqual('blocked',states[c]); self.assertEqual('open',states[b])  # #3 still means Third
        todo=(self.root/'TODO.md').read_text()
        self.assertIn('2. Second',todo); self.assertIn('3. Third (blocked)',todo); self.assertNotIn('1. ',todo.split('## NOW')[1])

    def test_empty_status_is_readonly(self):
        self.assertEqual('NO_TASKS',w.status(self.root)['status'])
        self.assertFalse((self.root/w.STORE).exists())

    def test_request_next_action_project_and_audit_survive_process_restart(self):
        identity=self.capture(project='Jobs/Test')
        result=subprocess.run([sys.executable,'-B',str(Path(w.__file__)),'status','--root',str(self.root)],capture_output=True,text=True,check=True)
        active=json.loads(result.stdout)['active']
        self.assertEqual(identity,active['id']);self.assertEqual('Review the existing draft',active['next_step'])
        self.assertEqual('Jobs/Test',active['project'])
        self.assertEqual('Finish the project',w.audit(self.root)['events'][0]['payload']['text'])

    def test_identical_retry_is_idempotent_and_conflicting_retry_refused(self):
        identity=self.capture();self.assertEqual(identity,self.capture())
        self.assertEqual(1,len(w.status(self.root)['open_tasks']))
        self.assertEqual(1,len([e for e in w.audit(self.root)['events'] if e['id']=='main']))
        with self.assertRaisesRegex(ValueError,'different arguments'):self.capture(text='Different request')

    def test_nested_tangent_returns_without_losing_the_original(self):
        main=self.capture();side=self.capture('side','Research a side idea','Check sources',tangent=True)
        third=self.capture('third','Another thought','Capture the idea',tangent=True)
        self.assertEqual(side,w.status(self.root)['return_to']['id'])
        self.assertEqual('RECORDED',w.mutate(self.root,'resume','return1')['status'])
        self.assertEqual(side,w.status(self.root)['active']['id'])
        w.mutate(self.root,'resume','return2')
        self.assertEqual(main,w.status(self.root)['active']['id'])
        self.assertEqual(3,len(w.status(self.root)['open_tasks']))

    def test_done_tangent_restores_parent_and_requires_evidence(self):
        main=self.capture();side=self.capture('side',tangent=True)
        with self.assertRaisesRegex(ValueError,'Completion evidence'):
            w.mutate(self.root,'progress','done-no-proof',task_id=side,task_state='done',next_step='Completed')
        w.mutate(self.root,'progress','done-side',task_id=side,task_state='done',next_step='Completed',evidence='Operator reviewed the output in fixture')
        self.assertEqual(main,w.status(self.root)['active']['id'])
        event=next(e for e in w.audit(self.root)['events'] if e['id']=='done-side')
        self.assertIn('Operator reviewed',event['payload']['evidence'])

    def test_blocked_task_retains_its_reason(self):
        identity=self.capture()
        w.mutate(self.root,'progress','block',task_id=identity,task_state='blocked',next_step='Waiting for the user-selected date')
        active=w.status(self.root)['active'];self.assertEqual('blocked',active['state'])
        self.assertIn('date',active['next_step'])

    def test_failed_checkpoint_keeps_saved_work_and_recovers_maps(self):
        with patch.object(mm,'rebuild',side_effect=OSError('Simulated interrupted map update')):
            result=w.mutate(self.root,'capture','interrupted',text='Keep this decision',next_step='Resume safely')
        self.assertEqual('SAVED_CHECKPOINT_PENDING',result['status'])
        self.assertEqual('PENDING',w.status(self.root)['projection'])
        self.assertEqual('Keep this decision',w.status(self.root)['active']['request'])
        self.assertEqual('VERIFIED',w.checkpoint(self.root)['status'])
        self.assertEqual('CURRENT',w.status(self.root)['projection'])
        self.assertEqual('PASS',mm.verify(self.root)['status'])

    def test_authored_todo_and_prior_bytes_are_preserved(self):
        before=(self.root/'TODO.md').read_bytes();self.capture()
        self.assertIn('Keep my authored paragraph.',(self.root/'TODO.md').read_text())
        backups=list((self.root/w.STORE/'todo-backups').glob('*.md'))
        self.assertTrue(any(p.read_bytes()==before for p in backups))
        self.assertTrue(mm.excluded(w.STORE+'/state.sqlite3'))
        self.assertNotIn('state.sqlite3',(self.root/mm.INVENTORY).read_text())

    def test_malformed_projection_does_not_destroy_user_text(self):
        p=self.root/'TODO.md';p.write_text(p.read_text()+w.BEGIN+'\nUnfinished authored marker\n')
        before=p.read_bytes()
        result=w.mutate(self.root,'capture','malformed',text='Keep task',next_step='Repair only with evidence')
        self.assertEqual('SAVED_CHECKPOINT_PENDING',result['status']);self.assertEqual(before,p.read_bytes())
        self.assertEqual('PENDING',w.status(self.root)['projection'])

    def test_project_escape_unregistered_and_invalid_ids_are_refused(self):
        for project in ('../outside','Jobs/../../outside','Jobs/Missing','/tmp'):
            with self.subTest(project=project),self.assertRaises((ValueError,OSError)):
                self.capture(project=project)
        with self.assertRaises(ValueError):w.mutate(self.root,'capture','bad event',text='Work',next_step='Next')
        with self.assertRaises(ValueError):w.mutate(self.root,'resume','nothing')

    def test_private_store_symlink_is_not_followed(self):
        with tempfile.TemporaryDirectory() as other:
            (self.root/w.STORE).symlink_to(other,target_is_directory=True)
            with self.assertRaises(ValueError):w.status(self.root)
            self.assertFalse(list(Path(other).iterdir()))

    def test_concurrent_requests_are_not_lost(self):
        # Initialize schema first; concurrent task transactions still use separate connections.
        self.capture()
        def record(index):
            return w.mutate(self.root,'capture','parallel-'+str(index),text='Task '+str(index),next_step='Next '+str(index))
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(record,range(2)))
        self.assertTrue(all(r['status'] in ('RECORDED','SAVED_CHECKPOINT_PENDING') for r in results))
        w.checkpoint(self.root)
        self.assertEqual(3,len(w.status(self.root)['open_tasks']))

if __name__=='__main__':unittest.main()
