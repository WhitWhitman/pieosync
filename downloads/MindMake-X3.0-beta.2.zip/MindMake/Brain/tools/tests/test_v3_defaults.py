"""X3.0 defaults: helpers load on demand and editing shared rules never blocks boot."""
import importlib.util, json, shutil, tempfile, unittest
from pathlib import Path
ROOT = Path(__file__).parents[3]
SPEC = importlib.util.spec_from_file_location('mm_v3', ROOT/'Brain/tools/mindmake.py')
mm = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(mm)

class V3Defaults(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)/'Fresh customer folder'
        shutil.copytree(ROOT, self.root, ignore=shutil.ignore_patterns('__pycache__','map-history','._*','map.lock'))
        mm.rebuild(self.root)

    def test_startup_is_on_demand_and_not_blocked(self):
        result = mm.boot(self.root, allow_maintenance=False)
        self.assertNotEqual('FAIL', result['status'], result['errors'])
        self.assertNotEqual('SETUP_REVIEW_PENDING', result['status'])
        self.assertFalse(result['next_action'].startswith('Read and apply'))
        self.assertEqual('on_demand', result['session_loading']['mode'])
        self.assertIn('Brain/MEMORY.md', result['startup_files_verified'])

    def test_editing_shared_rules_does_not_create_a_review_wall(self):
        guard = self.root/'GUARD.md'
        guard.write_text(guard.read_text() + '\n<!-- fixture edit -->\n')
        mm.rebuild(self.root)
        result = mm.boot(self.root, allow_maintenance=False)
        self.assertNotEqual('SETUP_REVIEW_PENDING', result['status'])

    def test_intake_never_outranks_the_users_work(self):
        result = mm.boot(self.root, allow_maintenance=False)
        self.assertIn("user's work first", result['next_action'])

    def test_x3_file_waiting_in_downloads_does_not_fail_boot(self):
        (self.root/'Downloads/receipt.pdf').write_bytes(b'%PDF-1.4 fixture')
        result = mm.boot(self.root, allow_maintenance=False)
        self.assertNotEqual('FAIL', result['status'], result['errors'])
        self.assertEqual(['Downloads/receipt.pdf'], result['downloads_waiting'])
        self.assertIn('check_downloads', result['next_action'])
        mm.rebuild(self.root, ['TODO.md'])  # unrelated map updates still work

    def test_x3_per_helper_reviews_one_shared_edit_resets_one_review(self):
        status = mm.setup_review(self.root)
        self.assertEqual(20, status['total'])  # 19 helpers + 1 shared-rules review
        ev = self.root/'Brain/governance/setup-reviews/fixture.md'; ev.parent.mkdir(parents=True, exist_ok=True)
        ev.write_text('## Source read\nx\n## Requirements\nx\n## Conflicts\nx\n## Verification\nx\n## Open issues\nNone.\n')
        for item in status['pending']:
            mm.record_setup_review(self.root, item['job'], 'Brain/governance/setup-reviews/fixture.md', item['fingerprint'])
        self.assertEqual(20, mm.setup_review(self.root)['reviewed'])
        guard = self.root/'GUARD.md'; guard.write_text(guard.read_text() + '\n<!-- edit -->\n')
        pending = mm.setup_review(self.root)['pending']
        self.assertEqual(['_shared'], [p['job'] for p in pending])
        job = self.root/'Jobs/MindMake DreamWeaver/LGI_ENGINE_CONTRACT.md'
        job.write_text(job.read_text() + '\nedit\n')
        self.assertEqual({'_shared', 'Jobs/MindMake DreamWeaver'}, {p['job'] for p in mm.setup_review(self.root)['pending']})

    def test_x3_map_changes_logged_now_checked_at_task_end(self):
        f = self.root/'Jobs/MindMake Guide/Research/note.md'; f.parent.mkdir(parents=True, exist_ok=True); f.write_text('x')
        self.assertEqual('NOTED', mm.note_change(self.root, ['Jobs/MindMake Guide/Research/note.md'])['status'])
        self.assertEqual('FAIL', mm.verify(self.root)['status'])  # not yet mapped mid-task
        r = mm.update_noted(self.root)
        self.assertEqual(['Jobs/MindMake Guide/Research/note.md'], r['applied_noted_paths'])
        self.assertEqual('PASS', mm.verify(self.root)['status'])
        self.assertFalse((self.root/mm.CHANGE_LOG).exists())

if __name__ == '__main__':
    unittest.main()
