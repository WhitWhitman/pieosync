"""Filesystem acceptance probes; all mutations stay in disposable fixtures."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('mindmake', Path(__file__).parents[1]/'mindmake.py')
mm = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mm)


class MapAcceptance(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.write('My Brain/INDEX.md', '# Authored home\n\nKeep this approved wording.\n')
        self.write('Jobs/Test/JOB.md', '# Authored job\n\nApproval comes from the signed record.\n')
        self.write('Jobs/INDEX.md', '# Jobs\n')
        self.write('Seeds/SEEDS_MAP.md', '# Seeds\n')
        self.write('Seeds/Index/seed-index.md', '# Index\n')
        self.write('Jobs/Test/Products/old.md', 'DRAFT: newest file is not approved\n')
        self.write('Jobs/Test/Products/approved.md', 'APPROVED: signed version\n')
        for p in ['Seeds/Short-term','Seeds/Long-term','Jobs/Test/Seeds/Short-term','Jobs/Test/Seeds/Long-term']:
            (self.root/p).mkdir(parents=True)
        self.write(mm.REGISTRY,json.dumps(dict(root_map='My Brain/INDEX.md',project_maps={'Jobs/Test':'Jobs/Test/JOB.md'},generation_id='initial')))
        self.write(mm.INVENTORY,json.dumps(dict(entries=[],generation_id='initial')))
        self.build()

    def write(self,rel,text):
        p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)

    def build(self):
        result=mm.rebuild(self.root)
        self.assertEqual('PASS',result['status'])
        self.assertEqual('PASS',mm.verify(self.root)['status'])
        return result

    def test_existing_index_and_status_preserved(self):
        self.build()
        self.assertIn('Keep this approved wording.',(self.root/'My Brain/INDEX.md').read_text())
        self.assertFalse((self.root/'FOLDER_MAP.md').exists())
        self.assertEqual('DRAFT: newest file is not approved\n',(self.root/'Jobs/Test/Products/old.md').read_text())
        self.assertEqual('APPROVED: signed version\n',(self.root/'Jobs/Test/Products/approved.md').read_text())

    def test_confirmed_move_removes_old_generated_route(self):
        old=self.root/'Jobs/Test/Products/old.md';new=self.root/'Jobs/Test/Products/new.md'
        old.rename(new)
        result=mm.rebuild(self.root,['Jobs/Test/Products/old.md','Jobs/Test/Products/new.md'])
        self.assertEqual('scoped',result['coverage'])
        text=(self.root/'Jobs/Test/JOB.md').read_text()
        self.assertNotIn('Products/old.md',text)
        self.assertIn('Products/new.md',text)
        self.assertEqual('PASS',mm.verify(self.root)['status'])

    def test_missing_map_restores_real_authored_backup(self):
        (self.root/'My Brain/INDEX.md').unlink()
        self.build()
        self.assertIn('Keep this approved wording.',(self.root/'My Brain/INDEX.md').read_text())

    def test_interruption_leaves_journal_and_rolls_back(self):
        before=(self.root/mm.REGISTRY).read_bytes()
        original=mm.atomic
        def interrupted(path,data):
            original(path,data)
            if path == self.root/'Jobs/Test/JOB.md':
                raise OSError('fixture interruption between maps and registry')
        with patch.object(mm,'atomic',side_effect=interrupted):
            with self.assertRaises(OSError):mm.rebuild(self.root)
        self.assertTrue((self.root/mm.PENDING).exists())
        self.assertEqual(before,(self.root/mm.REGISTRY).read_bytes())
        self.assertEqual('FAIL',mm.verify(self.root)['status'])
        self.assertEqual('PASS',mm.recover(self.root)['status'])
        self.assertEqual('PASS',mm.verify(self.root)['status'])

    def test_concurrent_edit_is_preserved(self):
        original=mm.atomic
        changed=self.root/'Jobs/Test/JOB.md'
        def concurrent(path,data):
            original(path,data)
            if path==self.root/mm.PENDING:
                changed.write_text(changed.read_text()+'\nUser wrote this during commit.\n')
        with patch.object(mm,'atomic',side_effect=concurrent):
            with self.assertRaisesRegex(ValueError,'Concurrent edit'):
                mm.rebuild(self.root)
        self.assertIn('User wrote this during commit.',changed.read_text())
        with self.assertRaisesRegex(ValueError,'preserves a concurrent edit'):
            mm.recover(self.root)
        self.assertTrue((self.root/mm.PENDING).exists())

    def test_unreadable_scan_keeps_registration(self):
        before=(self.root/mm.REGISTRY).read_bytes()
        with patch.object(mm,'scan',side_effect=PermissionError('fixture inaccessible')):
            with self.assertRaises(PermissionError):mm.rebuild(self.root)
        self.assertEqual(before,(self.root/mm.REGISTRY).read_bytes())
        self.assertFalse((self.root/mm.PENDING).exists())

    def test_external_symlink_is_reported_not_followed(self):
        with tempfile.TemporaryDirectory() as outside:
            p=Path(outside)/'private.txt';p.write_text('not in authorized scope')
            (self.root/'linked').symlink_to(outside,target_is_directory=True)
            result=self.build()
            self.assertEqual(['linked'],result['excluded_symlinks'])
            inventory=(self.root/mm.INVENTORY).read_text()
            self.assertNotIn('private.txt',inventory)

    def test_no_watcher_external_addition_detected_on_check(self):
        self.write('Jobs/Test/Products/outside-session.md','new source')
        self.assertEqual('FAIL',mm.verify(self.root)['status'])
        mm.rebuild(self.root,['Jobs/Test/Products/outside-session.md'])
        self.assertEqual('PASS',mm.verify(self.root)['status'])

    def test_invalid_markers_and_escape_do_not_commit(self):
        before=(self.root/mm.REGISTRY).read_bytes()
        p=self.root/'Jobs/Test/JOB.md'
        p.write_text(p.read_text().replace(mm.END,''))
        with self.assertRaisesRegex(ValueError,'markers'):mm.rebuild(self.root)
        self.assertEqual(before,(self.root/mm.REGISTRY).read_bytes())
        with self.assertRaises(ValueError):mm.within(self.root,'../outside')

    def test_nested_created_file_adds_parent_route(self):
        self.write('New Area/Nested/note.md','a new note')
        mm.rebuild(self.root,['New Area/Nested/note.md'])
        self.assertIn('New Area',(self.root/'My Brain/INDEX.md').read_text())
        self.assertEqual('PASS',mm.verify(self.root)['status'])

    def test_boot_pending_intake_is_read_only_and_source_changes_fail(self):
        self.write('.mindmake-home',str(self.root))
        self.write('Brain/Profiles/user.md','Intake pending; no name inferred.\n')
        self.write('Brain/Profiles/profiles.json',json.dumps({'user':{'path':'Brain/Profiles/user.md','status':'pending'}}))
        for name in ['wonder','hobby']:
            self.write(f'Brain/Profiles/{name}-list.json',json.dumps({'status':'empty','items':[]}))
        self.write('TODO.md','# NOW\n\n- [ ] Pending intake\n')
        (self.root/'Seeds/Dreams').mkdir()
        seed='Seeds/Short-term/2026-09-05-confirmed.md'
        self.write(seed,'User confirmed this shared decision.\n')
        source='Jobs/Test/Products/approved.md'
        self.write('Brain/.mindmake/source-catalog.json',json.dumps({'sources':[{'sha256':{source:mm.digest((self.root/source).read_bytes())}}]}))
        self.write('Brain/.mindmake/runtime.json',json.dumps({'required_paths':['Brain/Profiles/user.md','TODO.md'], 'startup_order':['TODO.md'],'last_thread_seed_count':1}))
        self.build()
        before={p.relative_to(self.root).as_posix():p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        result=mm.boot(self.root)
        after={p.relative_to(self.root).as_posix():p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        self.assertEqual('READY_INTAKE_PENDING',result['status'])
        self.assertEqual([seed],result['seed_read_order'])
        self.assertEqual(before,after)
        # A released folder must boot after relocation, even from another cwd.
        self.write('.mindmake-home','.\n')
        import os
        previous_cwd = Path.cwd()
        with tempfile.TemporaryDirectory() as unrelated:
            try:
                os.chdir(unrelated)
                relocated = mm.boot(self.root)
            finally:
                os.chdir(previous_cwd)
        self.assertEqual('READY_INTAKE_PENDING', relocated['status'])
        self.write('.mindmake-home','../wrong-home\n')
        self.assertEqual('FAIL', mm.boot(self.root)['status'])
        self.write('.mindmake-home','.\n')
        self.write(source,'Unverified source replacement')
        self.assertEqual('FAIL',mm.boot(self.root)['status'])

    def test_rebuild_recreates_missing_generated_inventory(self):
        (self.root/mm.INVENTORY).unlink()
        result = mm.rebuild(self.root)
        self.assertEqual('PASS', result['status'])
        self.assertEqual('PASS', mm.verify(self.root)['status'])

    def test_new_shared_seed_requires_map_update(self):
        self.write('Seeds/Short-term/new.md','A consequential shared decision')
        self.assertEqual('FAIL',mm.verify(self.root)['status'])
        mm.rebuild(self.root,['Seeds/Short-term/new.md'])
        self.assertEqual('PASS',mm.verify(self.root)['status'])


if __name__=='__main__':
    unittest.main(verbosity=2)
