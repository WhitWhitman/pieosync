"""X3.0 pre-ship: a first boot on a fresh copy leaves no cache files, even when Python
is run without -B (plain `python3 Brain/tools/mindmake.py boot`)."""
import hashlib, os, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]


def tree(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


class NoBytecode(unittest.TestCase):
    def test_first_boot_writes_no_pycache(self):
        tmp = tempfile.TemporaryDirectory(); self.addCleanup(tmp.cleanup)
        root = Path(tmp.name)/'Fresh copy'
        shutil.copytree(ROOT, root, ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache', '_*', 'map.lock'))
        env = {k: v for k, v in os.environ.items() if k != 'PYTHONDONTWRITEBYTECODE'}
        r = subprocess.run([sys.executable, str(root/'Brain/tools/mindmake.py'), 'boot', '--no-maintenance', '--root', str(root)],
                           capture_output=True, text=True, env=env)
        self.assertIn('"status"', r.stdout, r.stderr)
        self.assertEqual([], [p.as_posix() for p in root.rglob('__pycache__')])
        self.assertEqual([], [p.as_posix() for p in root.rglob('*.pyc')])

    def test_tools_switch_off_bytecode_before_importing_siblings(self):
        for name in ('mindmake.py', 'workspace.py', 'mindmake_routines.py', 'assistant.py', 'knowledge.py'):
            self.assertIn('sys.dont_write_bytecode = True', (ROOT/'Brain/tools'/name).read_text(), name)


if __name__ == '__main__':
    unittest.main(verbosity=2)
