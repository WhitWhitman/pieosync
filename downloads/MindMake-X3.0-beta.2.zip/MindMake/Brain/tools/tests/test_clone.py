import json
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import mindmake_clone as mc


class CloneSafety(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'MINDMAKE X3.0'
        for d in ['Seeds/Short-term', 'Jobs/Helper/Seeds/Short-term', 'Wiki', 'Downloads', 'Brain/.mindmake', 'Brain/Profiles']:
            (self.root / d).mkdir(parents=True)
        (self.root / 'Brain/.mindmake/intake.json').write_text(json.dumps({'schema_version': 1, 'answers': {}}))
        (self.root / 'Brain/Profiles/user.md').write_text('# User\n\nStatus: pending.\n')
        (self.root / 'Jobs/Helper/JOB.md').write_text('# Helper\n\nType: Helper.\n')
        (self.root / 'Wiki/INDEX.md').write_text('# Wiki\n')

    def test_clean_workspace_passes(self):
        self.assertEqual([], mc.dirty_reasons(self.root))

    def test_personal_state_blocks_template(self):
        (self.root / 'Seeds/Short-term/2026-11-21_x.md').write_text('seed')
        (self.root / 'Brain/.mindmake/intake.json').write_text(json.dumps({'schema_version': 1, 'answers': {'preferred_name': {}}}))
        (self.root / 'Brain/.mindmake/workspace-state').mkdir()
        (self.root / 'Downloads/file.pdf').write_text('x')
        (self.root / 'Brain/Profiles/user.md').write_text('# User\n\nName: Sam\n')
        (self.root / 'Jobs/Acme').mkdir(); (self.root / 'Jobs/Acme/JOB.md').write_text('Type: User Project.')
        (self.root / 'Brain/notes.md').write_text('api_key = abcdefghijklmnop\n')
        reasons = ' | '.join(mc.dirty_reasons(self.root))
        for part in ['Seeds/Short-term', 'intake', 'task records', 'Downloads', 'user.md', 'Jobs/Acme', 'credential']:
            self.assertIn(part, reasons)
        self.assertEqual('REFUSED', mc.make_template(self.root)['status'])
        self.assertFalse((self.root / mc.TEMPLATE_DIR / mc.TEMPLATE_ZIP).exists())

    def test_runtime_state_and_template_never_packed(self):
        for rel in ['Brain/.mindmake/workspace-state/x', 'Brain/.mindmake/map-history/x', '_Clean Template/x', 'a/__pycache__/x.pyc']:
            self.assertFalse(mc.keep(rel), rel)
        self.assertTrue(mc.keep('Brain/.mindmake/runtime.json'))

    def test_clone_refuses_without_template_bad_name_or_existing_folder(self):
        self.assertEqual('REFUSED', mc.clone(self.root, 'Business 1')['status'])
        self.assertEqual('REFUSED', mc.clone(self.root, '../escape')['status'])
        (self.root / mc.TEMPLATE_DIR).mkdir()
        with zipfile.ZipFile(self.root / mc.TEMPLATE_DIR / mc.TEMPLATE_ZIP, 'w') as z:
            z.writestr('README.md', 'x')
        (self.root.parent / 'MINDMAKE X3.0 (Business 1)').mkdir()
        result = mc.clone(self.root, 'Business 1')
        self.assertEqual('REFUSED', result['status'])
        self.assertIn('already exists', result['reasons'][0])


    def test_allowlist_blocks_private_files_and_credentials(self):
        self.assertEqual('REFUSED', mc.approve(self.root, False)['status'])
        self.assertEqual('APPROVED', mc.approve(self.root, True)['status'])
        self.assertEqual('CREATED', mc.make_template(self.root)['status'])
        (self.root / '.env').write_text('OPENAI_API_KEY=sk-abcdefghijklmnopqrstuvwxyz123456\n')
        (self.root / 'private-notes.md').write_text('My private plans\n')
        (self.root / 'Brain/credentials').write_text('token: abcdefgh12345678\n')
        (self.root / 'Wiki/INDEX.md').write_text('# Wiki, edited\n')  # generated file may differ
        (self.root / 'Brain/Profiles/user.md').write_text('# User\n\nStatus: pending. Edited.\n')
        reasons = ' | '.join(mc.dirty_reasons(self.root) + mc.allowlist_reasons(self.root))
        for part in ['.env', 'private-notes.md', 'Brain/credentials', 'changed since approval: Brain/Profiles/user.md']:
            self.assertIn(part, reasons)
        self.assertNotIn('Wiki/INDEX.md', reasons)
        before = (self.root / mc.TEMPLATE_DIR / mc.TEMPLATE_ZIP).read_bytes()
        self.assertEqual('REFUSED', mc.make_template(self.root)['status'])
        self.assertEqual(before, (self.root / mc.TEMPLATE_DIR / mc.TEMPLATE_ZIP).read_bytes())
        names = zipfile.ZipFile(self.root / mc.TEMPLATE_DIR / mc.TEMPLATE_ZIP).namelist()
        self.assertFalse(any(n.endswith(('.env', 'private-notes.md', 'credentials')) for n in names))

    def test_private_text_added_to_generated_files_never_reaches_the_zip(self):
        (self.root / 'TODO.md').write_text('# Tasks\n\nNo active task.\n')
        self.assertEqual('APPROVED', mc.approve(self.root, True)['status'])
        (self.root / 'TODO.md').write_text('# Tasks\n\nNo active task.\nPRIVATE: call my doctor about results\n')
        (self.root / 'Wiki/INDEX.md').write_text('# Wiki\nPRIVATE salary notes\n')
        self.assertEqual('CREATED', mc.make_template(self.root)['status'])
        z = zipfile.ZipFile(self.root / mc.TEMPLATE_DIR / mc.TEMPLATE_ZIP)
        blob = b''.join(z.read(n) for n in z.namelist() if not n.endswith('/'))
        self.assertNotIn(b'PRIVATE', blob)
        self.assertEqual(b'# Tasks\n\nNo active task.\n', z.read('TODO.md'))
        self.assertEqual(1, z.namelist().count('TODO.md'))

    def test_template_needs_an_allowlist(self):
        result = mc.make_template(self.root)
        self.assertEqual('REFUSED', result['status'])
        self.assertIn('allowlist', ' '.join(result['reasons']))


if __name__ == '__main__':
    unittest.main(verbosity=2)
