from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import mindmake_clean as mc


class BrainClean(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.write('Jobs/Acme/JOB.md', '# Acme\n\nType: User Project.\n\n[Notes](<Notes/a.md>)\n')
        self.write('Jobs/Acme/Notes/a.md', '# Plan A\n\nSome text about the plan.\n')
        self.write('Seeds/Short-term/2026-11-01_100000_first.md', '---\nassertion: "x"\n---\nBody\n')

    def write(self, rel, text):
        p = self.root / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text); return p

    def test_clean_workspace_reports_clean_and_changes_nothing(self):
        before = {p: p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        result = mc.scan(self.root)
        self.assertEqual('CLEAN', result['status'], result)
        self.assertEqual(before, {p: p.read_bytes() for p in self.root.rglob('*') if p.is_file()})

    def test_finds_each_problem(self):
        self.write('Wiki/x.md', 'See [gone](missing.md), [ok](<../Jobs/Acme/Notes/a.md>), [web](https://a.b) and [space](../Jobs/Acme/Notes/a%2Emd).\n')
        self.write('Jobs/Acme/Notes/a copy.md', '# Plan A\n\nSome text about the plan.\n')
        self.write('Jobs/Acme/Notes/2026-11-02_a.md', '# Plan A\n\nSome text about the plan!\n')
        self.write('Jobs/Acme/Notes/empty.md', '   \n')
        self.write('Jobs/Acme/Notes/bad.md', '---\ntitle: never closed\n\n```\ncode\n')
        self.write('Jobs/Acme/Notes/markers.md', '<!-- MINDMAKE FOLDER MAP BEGIN -->\n')
        self.write('Seeds/Short-term/2026-11-02_100000_fix.md', '---\nsupersedes: "gone.md"\nlinks: ["also-gone.md"]\n---\nBody\n')
        self.write('Seeds/Short-term/2026-11-03_100000_nofm.md', 'No front matter\n')
        self.write('Jobs/Switch to MindMake/LEDGER.csv', 'source_path,sha256,destination,dest_sha256,workspace,status,note\n'
                   'Originals/x.md,abc,Jobs/Acme/Notes/vanished.md,def,,imported,\n')
        r = mc.scan(self.root)
        c = r['counts']
        self.assertEqual(1, c['broken_links'], r['findings'].get('broken_links'))
        self.assertEqual(1, c['duplicates'])
        self.assertGreaterEqual(c['near_duplicates'], 1)
        self.assertEqual(1, c['empty_files'])
        problems = ' | '.join(m['problem'] for m in r['findings']['malformed'])
        for part in ['never closes', 'code block', 'markers', 'no front matter']:
            self.assertIn(part, problems)
        self.assertEqual(2, c['orphaned_seeds'])
        self.assertEqual(1, c['missing_files'])

    def test_originals_and_template_folders_are_skipped(self):
        self.write('Jobs/Switch to MindMake/Originals/Vault/a.md', '[[Old link]] [x](nowhere.md)\n')
        self.write('_Clean Template/README.md', '[x](nowhere.md)\n')
        self.assertEqual('CLEAN', mc.scan(self.root)['status'])


    def test_seed_supersedes_resolves_in_own_project_and_images_checked(self):
        self.write('Jobs/Beta/Seeds/Short-term/2026-11-01_100000_only-here.md', '---\nassertion: "b"\n---\nBody\n')
        self.write('Jobs/Acme/Seeds/Short-term/2026-11-02_100000_fix.md', '---\nsupersedes: "2026-11-01_100000_only-here.md"\n---\nBody\n')
        self.write('Wiki/pic.md', '![chart](missing.png) ![ok](../Jobs/Acme/Notes/a.md)\n')
        r = mc.scan(self.root)
        self.assertEqual(1, r['counts']['orphaned_seeds'], r['findings'])
        self.assertIn('Jobs/Acme/Seeds', r['findings']['orphaned_seeds'][0]['problem'])
        self.assertEqual(['missing.png'], [f['link'] for f in r['findings']['broken_links']])


if __name__ == '__main__':
    unittest.main(verbosity=2)
