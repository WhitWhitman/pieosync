"""Crash/race probes use disposable byte fixtures; no watcher daemon is launched."""
import builtins
import errno
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('safe_watch', Path(__file__).parents[1] / 'downloads_watch.py')
watch = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(watch)

class DownloadSafety(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        for rel in ['Downloads', 'Wiki/References', 'Brain/.mindmake']:
            (self.root / rel).mkdir(parents=True)
        (self.root / watch.RULES).write_text(json.dumps({'stable_seconds': 10, 'rules': [{'pattern': '*.pdf', 'destination': 'Wiki/References'}]}))
        (self.root / watch.mm.INVENTORY).write_text('{"entries": []}')
        self.src = self.root / 'Downloads/example.pdf'
        self.dst = self.root / 'Wiki/References/example.pdf'
        self.src.write_bytes(b'original document')
        for name, value in [('rebuild', {'status': 'PASS'}), ('verify', {'status': 'PASS'}), ('state', {})]:
            mock = patch.object(watch.mm, name, return_value=value)
            mock.start(); self.addCleanup(mock.stop)

    def file(self):
        return watch.file_download(self.root, self.src.name, 'Wiki/References')

    def test_manual_map_failure_stays_pending(self):
        with patch.object(watch.mm, 'rebuild', side_effect=ValueError('map busy')):
            try: self.file()
            except ValueError: pass
        state = json.loads((self.root / watch.STATE / 'state.json').read_text())
        self.assertEqual('filed_map_pending', state['files']['Downloads/example.pdf']['status'])

    def test_scan_lock_conflict_is_not_ignored(self):
        with patch('fcntl.flock', side_effect=BlockingIOError(errno.EAGAIN, 'locked')):
            with self.assertRaises((OSError, ValueError)):
                watch.scan_once(self.root, force=True)
        self.assertTrue(self.src.exists()); self.assertFalse(self.dst.exists())

    def test_watch_lock_conflict_never_enters_scan(self):
        with patch('fcntl.flock', side_effect=BlockingIOError(errno.EAGAIN, 'locked')), patch.object(watch, 'scan_once', side_effect=AssertionError('second daemon entered scan')):
            self.assertEqual('ALREADY_RUNNING', watch.run(self.root, 1)['status'])

    def test_manual_detects_source_change_before_removal(self):
        # Existing code hashes destination then unlinks without rechecking source.
        original = Path.read_bytes
        def change(path):
            data = original(path)
            if path == self.dst:
                self.src.write_bytes(b'new user bytes')
            return data
        fingerprint = getattr(watch, '_fingerprint', None)
        def changed_fingerprint(path):
            value = fingerprint(path)
            if path == self.dst:
                self.src.write_bytes(b'new user bytes')
            return value
        from contextlib import ExitStack
        with ExitStack() as stack:
            stack.enter_context(patch.object(Path, 'read_bytes', change))
            if fingerprint:
                stack.enter_context(patch.object(watch, '_fingerprint', changed_fingerprint))
            try: self.file()
            except (ValueError, OSError): pass
        self.assertTrue(self.src.exists(), 'changing source was removed')

    def test_exclusive_reservation_preserves_competitor(self):
        original = os.open
        def racing(path, flags, *args, **kwargs):
            if Path(path) == self.dst and flags & os.O_EXCL:
                self.dst.write_bytes(b'competing user document')
            return original(path, flags, *args, **kwargs)
        # The old hard-link fallback reproducer plus the replacement's O_EXCL race.
        def unsupported(src, dst):
            Path(dst).write_bytes(b'competing user document')
            raise OSError(errno.ENOTSUP, 'no hard links')
        with patch.object(watch.os, 'link', side_effect=unsupported), patch.object(watch.os, 'open', side_effect=racing):
            try: self.file()
            except (ValueError, OSError): pass
        self.assertEqual(b'competing user document', self.dst.read_bytes())
        self.assertTrue(self.src.exists())

    def test_existing_destination_os_sidecar_is_preserved(self):
        metadata = self.dst.with_name('._' + self.dst.name)
        metadata.write_bytes(b'existing destination metadata')
        result = self.file()
        self.assertEqual('NEEDS_REVIEW', result['status'])
        self.assertTrue(self.src.exists()); self.assertFalse(self.dst.exists())
        self.assertEqual(b'existing destination metadata', metadata.read_bytes())

    def transactions(self):
        return [json.loads(p.read_text()) for p in (self.root / watch.STATE / 'transfers').glob('*.json') if not p.name.startswith('._')]

    def interrupt_after(self, phase):
        save = watch._save_txn
        def interrupted(root, txn):
            save(root, txn)
            if txn['status'] == phase:
                raise KeyboardInterrupt('simulated interruption after ' + phase)
        with patch.object(watch, '_save_txn', interrupted):
            with self.assertRaises(KeyboardInterrupt):
                self.file()

    def test_planned_journal_exists_before_exclusive_create(self):
        original = os.open
        seen = []
        def checked(path, flags, *args, **kwargs):
            if Path(path) == self.dst and flags & os.O_EXCL:
                txns = self.transactions()
                self.assertEqual(1, len(txns))
                self.assertEqual('planned', txns[0]['status'])
                self.assertEqual(watch.hashlib.sha256(self.src.read_bytes()).hexdigest(), txns[0]['sha256'])
                seen.append(True)
            return original(path, flags, *args, **kwargs)
        with patch.object(watch.os, 'open', checked), patch.object(watch.os, 'link', side_effect=OSError(errno.ENOTSUP, 'ExFAT simulation')):
            self.assertEqual('FILED', self.file()['status'])
        self.assertEqual([True], seen)
        self.assertEqual(b'original document', self.dst.read_bytes())

    def test_journal_failure_prevents_destination_creation(self):
        with patch.object(watch, '_save_txn', side_effect=OSError('journal disk full')):
            with self.assertRaises(OSError): self.file()
        self.assertTrue(self.src.exists()); self.assertFalse(self.dst.exists())

    def test_plan_interruption_resumes_once(self):
        self.interrupt_after('planned')
        self.assertTrue(self.src.exists()); self.assertFalse(self.dst.exists())
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('filed', result['files']['Downloads/example.pdf']['status'])
        self.assertFalse(self.src.exists())
        self.assertEqual(1, len(self.transactions()))

    def test_partial_interruption_preserves_both_files(self):
        self.interrupt_after('copying')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertTrue(self.src.exists()); self.assertTrue(self.dst.exists())
        self.assertEqual(b'', self.dst.read_bytes())

    def test_complete_copy_interruption_resumes_removal_and_maps(self):
        self.interrupt_after('copied')
        self.assertTrue(self.src.exists()); self.assertEqual(self.src.read_bytes(), self.dst.read_bytes())
        self.assertEqual('FILED', self.file()['status'])
        self.assertFalse(self.src.exists()); self.assertEqual(1, len(self.transactions()))

    def test_interruption_after_unlink_recovers_from_copied_record(self):
        unlink = Path.unlink
        def interrupted(path, *args, **kwargs):
            result = unlink(path, *args, **kwargs)
            if path == self.src:
                raise KeyboardInterrupt('interrupted after unlink')
            return result
        with patch.object(Path, 'unlink', interrupted):
            with self.assertRaises(KeyboardInterrupt): self.file()
        self.assertFalse(self.src.exists()); self.assertEqual('copied', self.transactions()[0]['status'])
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('filed', result['files']['Downloads/example.pdf']['status'])

    def test_recovery_preserves_conflicting_destination(self):
        self.interrupt_after('copied')
        self.dst.write_bytes(b'user replacement')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertEqual(b'user replacement', self.dst.read_bytes())
        self.assertEqual(b'original document', self.src.read_bytes())

    def test_recovery_preserves_replaced_source_even_same_content(self):
        self.interrupt_after('copied')
        self.src.unlink(); self.src.write_bytes(b'original document')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertTrue(self.src.exists()); self.assertTrue(self.dst.exists())

    def test_planned_existing_destination_is_not_adopted(self):
        self.interrupt_after('planned')
        self.dst.write_bytes(b'original document')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertTrue(self.src.exists()); self.assertTrue(self.dst.exists())

    def test_map_verification_failure_never_reports_filed(self):
        with patch.object(watch.mm, 'verify', return_value={'status': 'FAIL'}):
            result = self.file()
        self.assertEqual('FILED_MAP_PENDING', result['status'])
        self.assertEqual('filed_map_pending', self.transactions()[0]['status'])
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('filed', result['files']['Downloads/example.pdf']['status'])

    def test_pending_map_recovery_detects_destination_corruption(self):
        with patch.object(watch.mm, 'rebuild', side_effect=ValueError('map busy')):
            self.file()
        self.dst.write_bytes(b'changed after copy')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertEqual(b'changed after copy', self.dst.read_bytes())

    def test_source_growth_during_copy_is_bounded_and_preserved(self):
        save = watch._save_txn
        def growing(root, txn):
            save(root, txn)
            if txn['status'] == 'copying':
                with self.src.open('ab') as source:
                    source.write(b'additional data' * 100)
        with patch.object(watch, '_save_txn', growing), patch.object(watch, 'CHUNK_SIZE', 4):
            result = self.file()
        self.assertEqual('NEEDS_REVIEW', result['status'])
        self.assertTrue(self.src.exists())
        self.assertLessEqual(self.dst.stat().st_size, len(b'original document'))

    def test_both_entrypoints_share_real_scan_lock(self):
        state = watch._state_dir(self.root)
        with watch._acquire(state / 'scan.lock'):
            with self.assertRaises(watch.LockBusy): self.file()
            with self.assertRaises(watch.LockBusy): watch.scan_once(self.root, force=True)
        self.assertTrue(self.src.exists()); self.assertFalse(self.dst.exists())

    def test_unsupported_lock_backend_fails_closed(self):
        imported = builtins.__import__
        def unavailable(name, *args, **kwargs):
            if name in ('fcntl', 'msvcrt'): raise ImportError('mock unavailable')
            return imported(name, *args, **kwargs)
        with patch('builtins.__import__', unavailable):
            with self.assertRaises(OSError): self.file()
            with self.assertRaises(OSError): watch.scan_once(self.root, force=True)
        self.assertTrue(self.src.exists()); self.assertFalse(self.dst.exists())

    def test_windows_lock_branch_with_mock_backend(self):
        imported = builtins.__import__
        calls = []
        backend = types.SimpleNamespace(LK_NBLCK=2, locking=lambda *args: calls.append(args))
        def windows(name, *args, **kwargs):
            if name == 'fcntl': raise ImportError('mock Windows')
            if name == 'msvcrt': return backend
            return imported(name, *args, **kwargs)
        state = watch._state_dir(self.root)
        with patch('builtins.__import__', windows):
            with watch._acquire(state / 'probe.lock') as lock:
                self.assertEqual([(lock.fileno(), 2, 1)], calls)
            backend.locking = lambda *args: (_ for _ in ()).throw(OSError(errno.EACCES, 'mock locked'))
            with self.assertRaises(watch.LockBusy): watch._acquire(state / 'probe.lock')

    def test_start_never_spawns_when_lock_support_fails(self):
        with patch.object(watch, '_acquire', side_effect=OSError('unsupported lock')), patch.object(watch.subprocess, 'Popen') as launch:
            with self.assertRaises(OSError): watch.start(self.root, 1)
            launch.assert_not_called()

    def test_scan_exclusive_collision_preserves_source_and_competitor(self):
        original = os.open
        def racing(path, flags, *args, **kwargs):
            if Path(path) == self.dst and flags & os.O_EXCL:
                self.dst.write_bytes(b'competing scan document')
            return original(path, flags, *args, **kwargs)
        with patch.object(watch.os, 'open', racing):
            result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertEqual(b'competing scan document', self.dst.read_bytes()); self.assertTrue(self.src.exists())

    def test_new_inbox_file_does_not_inherit_old_filed_receipt(self):
        self.file()
        self.src.write_bytes(b'another download')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertTrue(self.src.exists())

    def test_corrupt_journal_stops_without_filing(self):
        self.interrupt_after('planned')
        path = next(p for p in (self.root / watch.STATE / 'transfers').glob('*.json') if not p.name.startswith('._'))
        txn = json.loads(path.read_text()); txn['sha256'] = 'broken'; path.write_text(json.dumps(txn))
        with self.assertRaises(ValueError): watch.scan_once(self.root, force=True)
        self.assertTrue(self.src.exists()); self.assertFalse(self.dst.exists())

    def test_completed_receipts_do_not_override_latest_filing(self):
        first = self.file()
        (self.root / 'Wiki/Other').mkdir()
        self.src.write_bytes(b'second document')
        second = watch.file_download(self.root, self.src.name, 'Wiki/Other')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual(second['destination'], result['files']['Downloads/example.pdf']['destination'])
        self.assertNotEqual(first['destination'], second['destination'])

    def test_legacy_map_pending_requires_review_without_journal(self):
        state_dir = watch._state_dir(self.root)
        self.src.unlink()
        self.dst.write_bytes(b'old transfer')
        (state_dir / 'state.json').write_text(json.dumps({'files': {'Downloads/example.pdf': {
            'status': 'filed_map_pending', 'destination': 'Wiki/References/example.pdf', 'sha256': watch.hashlib.sha256(b'old transfer').hexdigest()}}}))
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertEqual(b'old transfer', self.dst.read_bytes())

    def metadata(self):
        path = self.src.with_name('._' + self.src.name)
        if not path.exists(): path.write_bytes(b'opaque metadata fixture')
        return path

    def test_appledouble_bytes_preserved_in_mapped_backup(self):
        metadata = self.metadata(); expected = metadata.read_bytes()
        result = self.file()
        self.assertEqual('FILED', result['status'])
        backup = self.root / result['metadata_backup']
        self.assertEqual(expected, backup.read_bytes())
        txn = self.transactions()[0]
        self.assertEqual(watch.hashlib.sha256(expected).hexdigest(), txn['sidecar']['sha256'])
        self.assertIn(backup.relative_to(self.root).as_posix(), watch.mm.rebuild.call_args.args[1])
        self.assertFalse(self.src.exists())

    def test_appledouble_backup_collision_preserves_originals(self):
        metadata = self.metadata(); expected = metadata.read_bytes()
        backup = self.dst.with_name(self.dst.name + '.appledouble')
        backup.write_bytes(b'customer backup')
        result = self.file()
        self.assertEqual('NEEDS_REVIEW', result['status'])
        self.assertTrue(self.src.exists()); self.assertEqual(expected, metadata.read_bytes())
        self.assertEqual(b'customer backup', backup.read_bytes())
        self.assertFalse(self.dst.exists())

    def test_changed_source_appledouble_blocks_primary_removal(self):
        metadata = self.metadata()
        self.interrupt_after('copied')
        metadata.write_bytes(b'changed user metadata')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertTrue(self.src.exists()); self.assertEqual(b'changed user metadata', metadata.read_bytes())

    def test_corrupt_appledouble_backup_blocks_recovery(self):
        self.metadata(); self.interrupt_after('copied')
        backup = self.dst.with_name(self.dst.name + '.appledouble')
        backup.write_bytes(b'changed customer backup')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('needs_review', result['files']['Downloads/example.pdf']['status'])
        self.assertTrue(self.src.exists()); self.assertEqual(b'changed customer backup', backup.read_bytes())

    def test_appledouble_pair_recovers_after_primary_unlink(self):
        metadata = self.metadata(); expected = metadata.read_bytes()
        unlink = Path.unlink
        def interrupted(path, *args, **kwargs):
            result = unlink(path, *args, **kwargs)
            if path == self.src: raise KeyboardInterrupt('after primary removal')
            return result
        with patch.object(Path, 'unlink', interrupted):
            with self.assertRaises(KeyboardInterrupt): self.file()
        result = watch.scan_once(self.root, force=True)
        item = result['files']['Downloads/example.pdf']
        self.assertEqual('filed', item['status'])
        self.assertEqual(expected, (self.root / item['metadata_backup']).read_bytes())

    def test_appledouble_journal_sidecars_are_not_transactions(self):
        self.interrupt_after('planned')
        (self.root / watch.STATE / 'transfers' / '._invalid.json').write_bytes(b'\xffopaque AppleDouble')
        result = watch.scan_once(self.root, force=True)
        self.assertEqual('filed', result['files']['Downloads/example.pdf']['status'])
        self.assertEqual(1, len(self.transactions()))

if __name__ == '__main__': unittest.main(verbosity=2)
