import importlib.util,sys,tempfile,unittest,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
class RouteTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('mindmake_skill_routes'),'Routing evidence helper missing')
  import mindmake_skill_routes as m
  self.m=m
 def test_cases_have_three_categories(self):
  cases=self.m.load_cases();self.assertGreaterEqual(len(cases),18)
  for skill in {x['target'] for x in cases}:self.assertEqual({'obvious','paraphrase','negative'},{x['kind'] for x in cases if x['target']==skill})
 def test_missing_observation_cannot_pass(self):
  cases=[{'id':'a','target':'test','kind':'obvious','expected':['test']}]
  x=self.m.score(cases,[], 'h','h');self.assertEqual('INCOMPLETE',x['status'])
 def test_wrong_positive_and_negative_fail(self):
  cases=[{'id':'a','target':'test','kind':'negative','expected':[]}]
  x=self.m.score(cases,[{'id':'a','selected':['test']}],'h','h');self.assertEqual('FAIL',x['status'])
 def test_changed_description_invalidates_observation(self):
  x=self.m.score([{'id':'a','expected':[]}],[{'id':'a','selected':[]}],'old','new');self.assertEqual('STALE',x['status'])
 def test_unknown_or_duplicate_case_refused(self):
  cases=[{'id':'a','expected':[]}]
  for obs in [[{'id':'b','selected':[]}],[{'id':'a','selected':[]},{'id':'a','selected':[]}]]:
   with self.assertRaises(ValueError):self.m.score(cases,obs,'h','h')
 def test_observed_correct_choices_pass(self):
  x=self.m.score([{'id':'a','expected':['test']}],[{'id':'a','selected':['test']}],'h','h');self.assertEqual('PASS',x['status']);self.assertEqual(1,x['passed'])
 def test_actual_packaged_catalog_and_targets(self):
  root=Path(__file__).resolve().parents[3]
  catalog=self.m.descriptions(root); names={row['name'] for row in catalog}
  self.assertGreaterEqual(len(names),19)
  self.assertEqual([],self.m.audit(root)['missing_paths'])
  cases=self.m.load_cases();self.assertGreaterEqual(len({c['target'] for c in cases}),8)
  self.assertTrue(all(c['target'] in names and set(c['expected']) <= names for c in cases))
  self.assertEqual({'obvious','paraphrase','negative'}, {c['kind'] for c in cases})
 def test_symlink_wrapper_refused(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp).resolve();(root/'Brain').mkdir();(root/'real.md').write_text('fixture')
   (root/'alias.md').symlink_to(root/'real.md')
   (root/'Brain/SKILLS.md').write_text('### Example\n- Trigger: example\n- Wrapper: [Example](<../alias.md>).\n')
   with self.assertRaises(ValueError):self.m.descriptions(root)
 def test_malformed_observation_refused(self):
  for rows in (None, {}, 'invalid', [None], [{'id':[],'selected':[]}], [{'id':'a','selected':[],'extra':1}]):
   with self.subTest(rows=rows), self.assertRaises(ValueError):
    self.m.score([{'id':'a','expected':[]}], rows,'h','h')
if __name__=='__main__':unittest.main()
