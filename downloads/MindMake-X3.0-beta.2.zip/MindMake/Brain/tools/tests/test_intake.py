"""X.1 first-run probes on disposable copies; never claims real PDF review."""
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).parents[3]
SPEC = importlib.util.spec_from_file_location('mm_x1', ROOT/'Brain/tools/mindmake.py')
mm = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mm)


def use_strict_review_mode(root):
    """3.0Claude ships with reviews off and helpers on demand; these tests exercise the optional strict X2.0 mode."""
    import json as _j
    p=root/'Brain/.mindmake/runtime.json'; d=_j.loads(p.read_text())
    d['require_setup_review']=True; d.pop('session_loading_mode',None); d.pop('review_scheme',None)
    p.write_text(_j.dumps(d))

class IntakeAcceptance(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)/'Renamed customer folder'
        shutil.copytree(ROOT, self.root, ignore=shutil.ignore_patterns('__pycache__', 'map-history', '._*', 'map.lock'))
        # Each test chooses pending/reviewed state explicitly; release defaults are not fixtures.
        (self.root/mm.REVIEW).write_text(json.dumps({'schema_version':1,'records':{}}))
        use_strict_review_mode(self.root)
        mm.rebuild(self.root)

    def evidence(self, job):
        rel='Brain/governance/setup-reviews/'+Path(job).name+'.md'
        p=self.root/rel
        p.write_text('# Disposable test fixture, not an actual source review\n\n'
                     '## Source read\nSynthetic fixture.\n\n## Requirements\nFixture only.\n\n'
                     '## Conflicts\nNone in this fixture.\n\n## Verification\nUnit test fixture.\n\n'
                     '## Open issues\nNone\n')
        return rel

    def record_one(self):
        item=mm.setup_review(self.root)['pending'][0]
        rel=self.evidence(item['job'])
        mm.record_setup_review(self.root,item['job'],rel,item['fingerprint'])
        return item,rel

    def test_first_boot_pending_readonly_and_actionable(self):
        # The once-a-day run log (work-records/last-run.json) is boot's one designed write; everything else stays untouched.
        log='Brain/.mindmake/work-records/'
        hashes=lambda:{p.relative_to(self.root).as_posix():mm.digest(p.read_bytes()) for p in self.root.rglob('*') if p.is_file() and not p.relative_to(self.root).as_posix().startswith(log)}
        before=hashes(); result=mm.boot(self.root)
        self.assertEqual('SETUP_REVIEW_PENDING',result['status'])
        self.assertEqual(19,len(result['setup_review']['pending']))
        self.assertEqual(0,result['setup_review']['reviewed'])
        self.assertIn('offer the next unanswered question',result['next_action'])
        self.assertEqual(10,len(result['session_components']))
        self.assertEqual(before,hashes())

    def test_boot_honors_deferred_intake_while_reviews_remain_pending(self):
        mm.set_intake_conversation(self.root,True,'Finish setup later')
        mm.rebuild(self.root)
        result=mm.boot(self.root)
        self.assertEqual('DEFERRED',result['intake']['interaction'])
        self.assertEqual('SETUP_REVIEW_PENDING',result['status'])
        self.assertIn('resume intake when the user asks',result['next_action'])
        self.assertEqual(19,len(result['setup_review']['pending']))

    def test_completed_review_is_evidence_bound(self):
        item,rel=self.record_one()
        self.assertEqual(1,mm.setup_review(self.root)['reviewed'])
        (self.root/rel).write_text('Evidence replaced after review')
        self.assertEqual(0,mm.setup_review(self.root)['reviewed'])

    def test_source_or_policy_edit_invalidates_review(self):
        item,rel=self.record_one()
        p=self.root/'Brain/governance/WORKSPACE_POLICY.md';old=p.read_text();p.write_text(old+'\nChanged rule\n')
        self.assertEqual(0,mm.setup_review(self.root)['reviewed'])
        p.write_text(old)
        self.assertEqual(1,mm.setup_review(self.root)['reviewed'])
        p=self.root/item['source'];p.write_bytes(p.read_bytes()+b'changed')
        self.assertEqual(0,mm.setup_review(self.root)['reviewed'])
        self.assertEqual('FAIL',mm.boot(self.root)['status'])

    def test_active_filing_and_acceptance_inputs_invalidate_review(self):
        self.record_one()
        for rel in ['Brain/tools/downloads_watch.py', 'Brain/DOWNLOADS_WATCHER.md', 'Brain/FIRST_WIN.md', 'Brain/governance/FIRST_RUN_ACCEPTANCE.md']:
            path=self.root/rel; original=path.read_bytes()
            with self.subTest(path=rel):
                path.write_bytes(original+b'\nchanged deployment input\n')
                self.assertEqual(0, mm.setup_review(self.root)['reviewed'])
                path.write_bytes(original)
                self.assertEqual(1, mm.setup_review(self.root)['reviewed'])

    def test_generated_map_updates_keep_review_valid(self):
        item,rel=self.record_one()
        mm.rebuild(self.root)
        self.assertEqual(1,mm.setup_review(self.root)['reviewed'])
        self.assertEqual('PASS',mm.verify(self.root)['status'])

    def test_stale_or_unfinished_evidence_cannot_record(self):
        item=mm.setup_review(self.root)['pending'][0]
        rel=self.evidence(item['job'])
        with self.assertRaisesRegex(ValueError,'inputs changed'):
            mm.record_setup_review(self.root,item['job'],rel,'old-fingerprint')
        p=self.root/rel;p.write_text(p.read_text().replace('## Open issues\nNone','## Open issues\nMissing setup'))
        with self.assertRaisesRegex(ValueError,'Unresolved'):
            mm.record_setup_review(self.root,item['job'],rel,item['fingerprint'])
        self.assertEqual(0,mm.setup_review(self.root)['reviewed'])

    def test_missing_job_never_reports_ready(self):
        item=mm.setup_review(self.root)['pending'][0]
        shutil.rmtree(self.root/item['job'])
        # CLI converts an inaccessible required path into FAIL, not readiness.
        import subprocess,sys
        r=subprocess.run([sys.executable,str(self.root/'Brain/tools/mindmake.py'),'boot'],capture_output=True,text=True)
        self.assertNotEqual(0,r.returncode)
        self.assertEqual('FAIL',json.loads(r.stdout)['status'])

    def test_all_records_still_require_personal_intake(self):
        for item in mm.setup_review(self.root)['pending']:
            rel=self.evidence(item['job'])
            mm.record_setup_review(self.root,item['job'],rel,item['fingerprint'])
        mm.rebuild(self.root)
        result=mm.boot(self.root)
        self.assertEqual('READY_INTAKE_PENDING',result['status'])
        self.assertEqual(19,result['setup_review']['reviewed'])
        profiles=json.loads((self.root/'Brain/Profiles/profiles.json').read_text())
        profiles['user']['status']='confirmed';profiles['companion']['status']='declined'
        (self.root/'Brain/Profiles/profiles.json').write_text(json.dumps(profiles))
        self.assertEqual('READY_INTAKE_PENDING',mm.boot(self.root)['status'])
        for field, _ in mm.INTAKE_QUESTIONS:
            mm.record_intake(self.root,field,None,skip=True)
        self.assertEqual('READY',mm.boot(self.root)['status'])

class IntakeStateAcceptance(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        (self.root/'Brain/.mindmake').mkdir(parents=True)
        (self.root/mm.INTAKE).write_text(json.dumps({'schema_version':1,'answers':{}}))

    def test_name_alone_then_skip_resume_and_persistence(self):
        result=mm.record_intake(self.root,'preferred_name','Test Customer')
        self.assertEqual('switch_from',result['intake']['next_question']['field'])
        self.assertEqual('PENDING',result['intake']['status'])
        mm.record_intake(self.root,'switch_from','no')
        self.assertEqual('personal_mcp',mm.intake_status(self.root)['next_question']['field'])
        import subprocess,sys
        check="import json,sys; from pathlib import Path; data=json.loads(Path(sys.argv[1]).read_text()); assert data['answers']['preferred_name']['answer']=='Test Customer'"
        subprocess.run([sys.executable,'-c',check,str(self.root/mm.INTAKE)],check=True)
        mm.record_intake(self.root,'working_preferences','Concise')
        mm.record_intake(self.root,'companion',None,skip=True)
        for field in ['connections','bluntness','routine_actions','reminders','current_work']:
            mm.record_intake(self.root,field,None,skip=True)
        mm.record_intake(self.root,'personal_mcp','later')
        self.assertEqual('COMPLETE',mm.intake_status(self.root)['status'])

    def test_empty_or_ambiguous_answer_cannot_complete_intake(self):
        for answer,skip in [('',False),('answer',True)]:
            with self.assertRaises(ValueError):mm.record_intake(self.root,'preferred_name',answer,skip)
        self.assertEqual('preferred_name',mm.intake_status(self.root)['next_question']['field'])

    def test_explicit_session_target_clamps_to_actual_metadata(self):
        records=[]
        for i in range(18):
            p=self.root/f'seed-{i:02}.md'
            p.write_text(f'---\nsession_id: fixture-a\ncreated_at: 2026-09-01T12:{i:02}:00+00:00\n---\nFixture')
            records.append(p)
        result=mm.seed_load_target(records,{})
        self.assertEqual(18,result['target'])
        self.assertEqual(18,result['previous_session_count'])
        for p in records:p.write_text('---\ndate: 2026-09-01\n---\nDate only')
        self.assertEqual(10,mm.seed_load_target(records,{})['target'])

    def test_timestamp_cluster_uses_gap_not_copied_mtime(self):
        records=[]
        for i in range(14):
            p=self.root/f'seed-{i:02}.md'
            p.write_text(f'---\ncreated_at: 2026-09-01T12:{i:02}:00+00:00\n---\nFixture')
            records.append(p)
        p=self.root/'old.md';p.write_text('---\ncreated_at: 2026-08-01T12:00:00+00:00\n---\nOld fixture');records.append(p)
        result=mm.seed_load_target(records,{})
        self.assertEqual(14,result['target'])
        self.assertIn('estimate',result['method'])

    def test_work_preference_does_not_erase_mcp_or_connections(self):
        mm.record_intake(self.root,'preferred_name','Fixture')
        mm.record_intake(self.root,'current_work','Write books')
        mm.record_intake(self.root,'switch_from','no')
        mm.record_intake(self.root,'working_preferences','Be my assistant')
        result=mm.intake_status(self.root)
        self.assertEqual('personal_mcp',result['next_question']['field'])
        self.assertEqual('ACTIVE',result['interaction'])
        self.assertIn('connections',[x['field'] for x in result['pending']])
        before=(self.root/mm.INTAKE).read_bytes()
        self.assertEqual(result,mm.intake_status(self.root))
        self.assertEqual(before,(self.root/mm.INTAKE).read_bytes())

    def test_deferral_preserves_answers_and_resumes_after_reload(self):
        mm.record_intake(self.root,'preferred_name','Fixture')
        with self.assertRaises(ValueError): mm.set_intake_conversation(self.root,True,'')
        mm.set_intake_conversation(self.root,True,'Let us finish setup later')
        again=mm.intake_status(self.root)
        self.assertEqual('DEFERRED',again['interaction'])
        self.assertEqual('PENDING',again['status'])
        self.assertEqual('switch_from',again['next_question']['field'])
        self.assertEqual('switch_from',again['deferral']['checkpoint']['field'])
        mm.set_intake_conversation(self.root,False)
        self.assertEqual('ACTIVE',mm.intake_status(self.root)['interaction'])
        self.assertEqual('Fixture',json.loads((self.root/mm.INTAKE).read_text())['answers']['preferred_name']['answer'])

    def test_explicit_intake_answer_resumes_without_skipping_other_questions(self):
        mm.set_intake_conversation(self.root,True,'Not now')
        mm.record_intake(self.root,'current_work','A fixture goal')
        self.assertEqual('ACTIVE',mm.intake_status(self.root)['interaction'])
        self.assertEqual('preferred_name',mm.intake_status(self.root)['next_question']['field'])

    def test_mcp_yes_routes_discovery_and_connections_before_companion(self):
        mm.record_intake(self.root,'preferred_name','Fixture')
        mm.record_intake(self.root,'current_work','A fixture goal')
        mm.record_intake(self.root,'switch_from','no')
        result=mm.record_intake(self.root,'personal_mcp','yes')
        self.assertEqual('INSPECT_EXISTING_MCP',result['optional_setup'])
        self.assertEqual('reminders',result['intake']['next_question']['field'])
        self.assertFalse((self.root/'Brain/MCP/generated').exists())

    def test_switch_question_follows_name_and_can_be_skipped(self):
        mm.record_intake(self.root,'preferred_name','Fixture')
        question=mm.intake_status(self.root)['next_question']
        self.assertEqual('switch_from',question['field'])
        self.assertIn('second brain',question['question'])
        mm.record_intake(self.root,'switch_from',None,skip=True)
        self.assertEqual('personal_mcp',mm.intake_status(self.root)['next_question']['field'])

    def test_bluntness_question_follows_working_preferences_and_is_skippable(self):
        for field,answer in [('preferred_name','F'),('current_work','G'),('switch_from','no'),('personal_mcp','no'),('reminders','in chat'),('connections','none'),('working_preferences','short')]:
            mm.record_intake(self.root,field,answer)
        question=mm.intake_status(self.root)['next_question']
        self.assertEqual('bluntness',question['field'])
        self.assertIn('strongest objection',question['question'])
        mm.record_intake(self.root,'bluntness',None,skip=True)
        self.assertEqual('routine_actions',mm.intake_status(self.root)['next_question']['field'])

    def test_setup_comes_first_and_first_goal_after_it(self):
        # Beta finding (2026-11-22): set things up first, then ask what to help with first. One order, same as INTAKE.md.
        order=[f for f,_ in mm.INTAKE_QUESTIONS]
        self.assertEqual(['preferred_name','switch_from','personal_mcp','reminders','working_preferences','bluntness','connections','routine_actions','current_work','companion'],order)
        intake=(ROOT/'INTAKE.md').read_text()
        steps=[intake.index(s) for s in ('1. **What should I call you?**','2. **Do you already have another second brain','3. **How should I nudge you?**','4. **How should I work with you?**','5. **How blunt','6. **Which accounts','7. **What do you want help with first?**','8. **Optional extras')]
        self.assertEqual(sorted(steps),steps)

if __name__=='__main__': unittest.main(verbosity=2)
