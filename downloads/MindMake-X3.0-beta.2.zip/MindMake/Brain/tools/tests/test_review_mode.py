import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import mindmake_review as review

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        for name in review.REQUIRED:
            p = self.root/name; p.parent.mkdir(parents=True, exist_ok=True); p.write_text('governance')
        (self.root/'.mindmake-home').write_text('.\n')
        self.config = self.root/'Brain/.mindmake/assistant.json'
        self.config.parent.mkdir(parents=True, exist_ok=True)
        self.config.write_text(json.dumps({'enabled': True}))
        self.ledger = self.root/'Brain/.mindmake/assistant-state/state.sqlite3'
        self.ledger.parent.mkdir(); self.ledger.write_bytes(b'fixture')
        self.raw = {'enabled':True,'scheduler_health':{'status':'OBSERVED','last_run':None},'next_action':None,'reviews_due':[],'open_actions':[]}
    def status(self):
        with patch.object(review, 'read_status', return_value=self.raw):
            return review.followthrough(self.root)
    def test_missing_ledger_fails_without_creating_it(self):
        self.ledger.unlink()
        self.assertEqual(self.status()['status'],'UNAVAILABLE')
        self.assertFalse(self.ledger.exists())
    def test_paused_default_needs_no_ledger_and_never_calls_helper(self):
        self.config.write_text('{"enabled":false}'); self.ledger.unlink()
        with patch.object(review, 'read_status', side_effect=AssertionError('helper called')):
            self.assertEqual(review.followthrough(self.root)['status'],'PAUSED')
    def test_malformed_payloads_fail(self):
        for raw in ({'enabled':True},dict(self.raw,reviews_due=['missing']),dict(self.raw,open_actions=[{}]),dict(self.raw,scheduler_health=[])):
            self.raw=raw; self.assertEqual(self.status()['status'],'UNAVAILABLE')
    def test_due_sources_and_receipts_are_bounded(self):
        for i in range(25):
            p=self.root/f'source{i}.md';p.write_text('evidence')
        self.raw.update(reviews_due=[str(i) for i in range(25)],open_actions=[{'id':str(i),'source':f'source{i}.md'} for i in range(25)])
        self.raw['scheduler_health']['last_run']={'run_id':'r','outcome':'unchanged','recorded_at':'now','note':'x'*100000}
        got=self.status();self.assertEqual(20,len(got['review_sources']));self.assertEqual(5,got['review_sources_omitted'])
        self.assertLess(len(json.dumps(got)),5000)
    def test_missing_or_escaped_source_fails(self):
        for source in ['missing.md','../outside','/tmp/outside']:
            self.raw.update(reviews_due=['a'],open_actions=[{'id':'a','source':source}])
            self.assertEqual('UNAVAILABLE',self.status()['status'])
    def test_duplicate_ids_or_unknown_next_action_fails(self):
        for changes in [dict(open_actions=[{'id':'a','source':'GUARD.md'}]*2),dict(next_action={'id':'missing'})]:
            self.raw.update(changes);self.assertEqual('UNAVAILABLE',self.status()['status'])
    def test_review_does_not_call_full_boot_or_read_seeds(self):
        with patch.object(review.mm,'boot',side_effect=AssertionError('full boot')),patch.object(review.mm,'verify',return_value={'status':'PASS','errors':[]}),patch.object(review.mm,'setup_review',return_value={'status':'RECORDED','pending':[]}),patch.object(review,'read_status',return_value=self.raw):
            got=review.boot(self.root)
        self.assertEqual('READY',got['status']);self.assertEqual([],got['seed_read_order'])
        self.assertNotIn('TODO.md',got['required_read']);self.assertEqual([],got['routing_read'])
    def test_stale_setup_review_blocks(self):
        with patch.object(review.mm,'verify',return_value={'status':'PASS','errors':[]}),patch.object(review.mm,'setup_review',return_value={'status':'PENDING','pending':[{'job':'changed'}]}):
            self.assertEqual('FAIL',review.boot(self.root)['status'])

if __name__=='__main__': unittest.main()
