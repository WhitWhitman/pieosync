import sys, tempfile, unittest, importlib.util
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
class LocalAuthorityTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('mindmake_local'), 'Package authority resolver missing')
  from mindmake_local import resolve_root
  self.resolve=resolve_root; self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name).resolve();(self.root/'.mindmake-home').write_text('.\n')
  (self.root/'Brain/tools').mkdir(parents=True);(self.root/'Brain/tools/helper.py').write_text('')
 def test_root_nested_and_file_start(self):
  for path in (self.root,self.root/'Brain/tools',self.root/'Brain/tools/helper.py'):
   self.assertEqual(self.root,self.resolve(path))
 def test_missing_or_external_locator_refused(self):
  for value in ('..',str(self.root),'', '{"authority_file":"elsewhere.json"}'):
   (self.root/'.mindmake-home').write_text(value)
   with self.assertRaises(ValueError):self.resolve(self.root)
  (self.root/'.mindmake-home').unlink()
  with self.assertRaises(ValueError):self.resolve(self.root)
 def test_symlink_locator_and_start_refused(self):
  (self.root/'other').write_text('.');(self.root/'.mindmake-home').unlink();(self.root/'.mindmake-home').symlink_to(self.root/'other')
  with self.assertRaises(ValueError):self.resolve(self.root)
  (self.root/'.mindmake-home').unlink();(self.root/'.mindmake-home').write_text('.')
  (self.root/'alias').symlink_to(self.root/'Brain')
  with self.assertRaises(ValueError):self.resolve(self.root/'alias/tools')
if __name__=='__main__':unittest.main()
