import importlib.util,json,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).parents[3]
sys.path.insert(0,str(ROOT/'Brain/tools'))
import mindmake as mm
import personal_mcp as builder
spec=importlib.util.spec_from_file_location('personal_core',ROOT/'Brain/MCP/personal_mcp_server.py')
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
class PersonalMCPTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve()
        for rel in core.ALIASES.values():
            p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('fixture context')
        (self.root/'Brain/.mindmake').mkdir(parents=True)
        self.choice('yes')
    def choice(self,value):
        (self.root/mm.INTAKE).write_text(json.dumps({'schema_version':1,'answers':{'personal_mcp':{'status':'confirmed','answer':value}}}))
    def test_no_later_pending_do_not_build_or_start(self):
        for value in ['no','later','pending']:
            self.choice(value)
            before=list(self.root.rglob('*'))
            with self.assertRaises(ValueError):builder.build(self.root)
            with self.assertRaises(ValueError):core.workspace_status(self.root)
            self.assertEqual(before,list(self.root.rglob('*')))
    def test_context_is_bounded_and_hash_matches(self):
        x=core.read_context(self.root,'guard');self.assertEqual(core.sha(self.root/'GUARD.md'),x['sha256'])
        for alias in ['../../private','/etc/passwd','profiles']:
            with self.assertRaises(ValueError):core.read_context(self.root,alias)
    def test_symlink_and_oversize_rejected(self):
        p=self.root/'GUARD.md';p.unlink();p.symlink_to(self.root/'INTAKE.md')
        with self.assertRaises(ValueError):core.read_context(self.root,'guard')
        p.unlink();p.write_text('x'*(core.LIMIT+1))
        with self.assertRaises(ValueError):core.read_context(self.root,'guard')
    def test_idempotent_turn_and_isolated_sessions(self):
        core.record_turn(self.root,'conversation-a','turn-1',now=100)
        self.assertEqual(1,core.record_turn(self.root,'conversation-a','turn-1',now=110)['recorded_turns'])
        self.assertEqual(0,core.session_status(self.root,'conversation-b',now=110)['recorded_turns'])
        core.record_turn(self.root,'conversation-b','turn-1',now=110)
        self.assertEqual(1,core.session_status(self.root,'conversation-a',now=120)['recorded_turns'])
        with self.assertRaises(ValueError):core.record_turn(self.root,'conversation-a','turn-1','emotional',now=120)
    def test_entrainment_window_survives_one_task_turn(self):
        for i in range(12):
            core.record_turn(self.root,'conv-w',f'e{i}','task' if i==5 else 'emotional',now=100+i*60)
        x=core.session_status(self.root,'conv-w',now=100+12*60)
        self.assertEqual(11,x['assistant_reported_emotional_in_last_12'])
        self.assertLess(x['assistant_reported_emotional_streak'],10)
        self.assertTrue(any('entrainment window' in r for r in x['reminders']))
    def test_stale_and_resumed_gap_not_continuous_use(self):
        core.record_turn(self.root,'a','one',now=100)
        x=core.session_status(self.root,'a',now=900000)
        self.assertEqual('STALE',x['state']);self.assertEqual([],x['reminders'])
        x=core.record_turn(self.root,'a','two',now=900000)
        self.assertEqual([],x['reminders'])
    def test_guard_change_is_reported(self):
        core.record_turn(self.root,'a','one',now=100)
        (self.root/'GUARD.md').write_text('changed fixture')
        self.assertTrue(core.session_status(self.root,'a',now=110)['guard_changed'])
        self.assertTrue(core.record_turn(self.root,'a','two',now=110)['guard_changed'])
    def test_revoking_consent_stops_existing_tools(self):
        core.record_turn(self.root,'a','one',now=100);self.choice('no')
        for call in [lambda:core.session_status(self.root,'a'),lambda:core.record_turn(self.root,'a','two'),lambda:core.read_context(self.root,'guard')]:
            with self.assertRaises(ValueError):call()
    def test_corrupt_state_is_error_not_fresh(self):
        p=self.root/'Brain/.mindmake/personal-mcp-state/session.sqlite3';p.parent.mkdir();p.write_text('broken database')
        with self.assertRaises(Exception):core.session_status(self.root,'a')
    def test_state_symlink_rejected(self):
        p=self.root/'Brain/.mindmake/personal-mcp-state';p.symlink_to(self.root,target_is_directory=True)
        with self.assertRaises(ValueError):core.record_turn(self.root,'a','one')
    def test_intake_requires_real_choice_and_routes_yes(self):
        with self.assertRaises(ValueError):mm.record_intake(self.root,'personal_mcp','maybe')
        result=mm.record_intake(self.root,'personal_mcp','yes')
        self.assertEqual('INSPECT_EXISTING_MCP',result['optional_setup'])
        for choice in ['no','later']:
            self.assertEqual('NONE',mm.record_intake(self.root,'personal_mcp',choice)['optional_setup'])
    def test_later_due_date_and_repeated_deferral(self):
        for field,_ in mm.INTAKE_QUESTIONS:
            mm.record_intake(self.root,field,None,skip=True)
        mm.record_intake(self.root,'personal_mcp','later')
        import datetime as dt
        data=json.loads((self.root/mm.INTAKE).read_text());after=data['answers']['personal_mcp']['revisit_after']
        delta=dt.datetime.fromisoformat(after)-dt.datetime.now(dt.timezone.utc)
        self.assertGreater(delta.total_seconds(),29.99*86400)
        self.assertEqual('COMPLETE',mm.intake_status(self.root)['status'])
        data['answers']['personal_mcp']['revisit_after']=(dt.datetime.now(dt.timezone.utc)-dt.timedelta(seconds=1)).isoformat()
        (self.root/mm.INTAKE).write_text(json.dumps(data))
        question=mm.intake_status(self.root)['next_question']
        self.assertEqual('personal_mcp',question['field']);self.assertIn('save repeated',question['question'])
        mm.record_intake(self.root,'personal_mcp','later')
        self.assertEqual('COMPLETE',mm.intake_status(self.root)['status'])
        mm.record_intake(self.root,'personal_mcp','no')
        self.assertNotIn('revisit_after',json.loads((self.root/mm.INTAKE).read_text())['answers']['personal_mcp'])
    def test_clock_skew_not_long_session(self):
        core.record_turn(self.root,'a','one',now=100)
        x=core.session_status(self.root,'a',now=1);self.assertEqual('CLOCK_SKEW',x['state']);self.assertEqual([],x['reminders'])
    def test_seed_memory_reminder_and_consent(self):
        self.assertIn('UNCOUNTED',core.session_status(self.root,'seed-thread')['seed_memory_reminder'])
        (self.root/'Jobs/Book/Seeds/Short-term').mkdir(parents=True)
        args=dict(stream='seed-thread',event='begin',task='book',scope='Jobs/Book',query='launch approval',meaningful=True)
        result=core.memory_operation(self.root,'check',**args)
        self.assertEqual('SAVE_REQUIRED',result['save_status'])
        self.assertIn('SAVE_REQUIRED',core.record_turn(self.root,'seed-thread','turn')['seed_memory_reminder'])
        self.choice('no')
        with self.assertRaises(ValueError):core.memory_operation(self.root,'status',stream='seed-thread')
        with self.assertRaises(ValueError):core.memory_operation(self.root,'check',**dict(args,event='denied'))
    def test_seed_state_is_not_a_map_input(self):
        self.assertTrue(mm.excluded('Brain/.mindmake/seed-memory/events.sqlite3'))
        self.assertTrue(mm.excluded('Brain/.mindmake/seed-memory/notes.json'))
if __name__=='__main__':unittest.main()

class Compatibility(unittest.TestCase):
    def test_core_and_mcp_python_requirements_are_separate(self):
        import personal_mcp as pm
        old = pm.compatibility((3, 8), 'darwin')
        self.assertFalse(old['core_ok']); self.assertFalse(old['compatible'])
        core_only = pm.compatibility((3, 9), 'darwin')
        self.assertTrue(core_only['core_ok']); self.assertFalse(core_only['mcp_ok']); self.assertFalse(core_only['compatible'])
        self.assertIn('3.10', core_only['reasons'][0])
        self.assertTrue(pm.compatibility((3, 12), 'darwin')['compatible'])
        self.assertFalse(pm.compatibility((3, 12), 'win32')['compatible'])

