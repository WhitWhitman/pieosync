import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
ROOT=Path(__file__).parents[3]
sys.path.insert(0,str(ROOT/'Brain/tools'))
import assistant as a

class Fake:
    def __init__(self, fail=False):self.calls=0;self.fail=fail
    def send(self, body):
        self.calls+=1
        if self.fail:raise TimeoutError('private provider response')
        return {'sid':'SM'+'a'*32,'status':'queued'}
    def poll(self, sid):return {'sid':sid,'status':'delivered'}

class AssistantAcceptance(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);(self.root/'Brain/.mindmake').mkdir(parents=True)
        self.c=json.loads((ROOT/a.CONFIG).read_text());self.c['enabled']=True;self.c['sms']['consented']=True
        self.save();self.at=a.stamp('2026-09-07T14:00:00+00:00')
        (self.root/'TODO.md').write_text('Take the next small step.\n')
        a.capture(self.root,'action','Take the next small step','TODO.md',due='2026-09-07T12:00:00+00:00',review_after='2026-09-06T12:00:00+00:00')
    def save(self):(self.root/a.CONFIG).write_text(json.dumps(self.c))
    def queued(self, name='reminder'):
        a.queue(self.root,name,'action','Your next step is ready.','2026-09-07T12:00:00+00:00')
    def test_twilio_http_request_encoding_and_status(self):
        import io
        from urllib.parse import parse_qs
        env={'TWILIO_ACCOUNT_SID':'AC'+'a'*32,'TWILIO_AUTH_TOKEN':'fixture-only','TWILIO_FROM_NUMBER':'+12025550100','MINDMAKE_SMS_TO':'+12025550101'}
        self.c['sms']['recipient_sha256']=a.hashlib.sha256(env['MINDMAKE_SMS_TO'].encode()).hexdigest()
        requests=[]
        def fake_open(request, timeout):
            requests.append(request)
            return io.BytesIO(json.dumps({'sid':'SM'+'a'*32,'status':'queued' if request.data else 'delivered'}).encode())
        with patch.dict(a.os.environ,env,clear=True),patch.object(a,'urlopen',fake_open):
            wire=a.Twilio(self.c)
            self.assertEqual('queued',wire.send('A&B + next step')['status'])
            self.assertEqual('delivered',wire.poll('SM'+'a'*32)['status'])
        self.assertEqual('POST',requests[0].get_method())
        self.assertEqual('GET',requests[1].get_method())
        self.assertEqual(['A&B + next step'],parse_qs(requests[0].data.decode())['Body'])
        self.assertTrue(requests[0].full_url.endswith('/Messages.json'))
        self.assertTrue(requests[1].full_url.endswith('/Messages/SM'+'a'*32+'.json'))
    def test_future_reminder_does_not_send(self):
        a.queue(self.root,'future','action','Later step','2026-09-10T12:00:00Z')
        f=Fake();self.assertEqual('NOT_DUE',a.send(self.root,'future',self.at,f)['status']);self.assertEqual(0,f.calls)
    def test_package_defaults_do_not_authorize_anything(self):
        c=json.loads((ROOT/a.CONFIG).read_text());self.assertFalse(c['enabled']);self.assertFalse(c['sms']['consented']);self.assertEqual({},c['connections']);self.assertEqual([],c['approved_sources'])
    def test_queue_never_sends_and_duplicate_id_preserves_payload(self):
        self.queued();self.queued();self.assertEqual('prepared',a.status(self.root,self.at)['reminders'][0]['state'])
        with self.assertRaises(ValueError):a.queue(self.root,'reminder','action','Different text','2026-09-07T12:00:00+00:00')
    def test_provider_acceptance_is_not_delivery_and_retry_is_idempotent(self):
        self.queued();fake=Fake()
        self.assertEqual('queued',a.send(self.root,'reminder',self.at,fake)['status'])
        self.assertEqual('queued',a.send(self.root,'reminder',self.at,fake)['status']);self.assertEqual(1,fake.calls)
        self.assertEqual('delivered',a.poll(self.root,'reminder',fake)['status'])
    def test_uncertain_send_never_automatically_repeats(self):
        self.queued();fake=Fake(True)
        self.assertEqual('unknown',a.send(self.root,'reminder',self.at,fake)['status'])
        self.assertEqual('unknown',a.send(self.root,'reminder',self.at,fake)['status']);self.assertEqual(1,fake.calls)
        self.assertNotIn('private provider response',json.dumps(a.status(self.root)))
    def test_crash_after_attempt_record_prevents_repeat(self):
        self.queued()
        with a.database(self.root) as db,db:db.execute("UPDATE reminders SET state='attempting',attempted_at=?",(self.at.isoformat(),))
        f=Fake();self.assertEqual('attempting',a.send(self.root,'reminder',self.at,f)['status']);self.assertEqual(0,f.calls)
    def test_quiet_hours_timezone_and_dst(self):
        self.queued();self.c['timezone']='America/New_York';self.save();f=Fake()
        self.assertEqual('QUIET_HOURS',a.send(self.root,'reminder',a.stamp('2026-09-08T01:00:00Z'),f)['status'])
        self.assertTrue(a.quiet(self.c,a.stamp('2026-12-08T02:00:00Z')));self.assertEqual(0,f.calls)
    def test_done_suppresses_prepared_reminder(self):
        self.queued();a.change(self.root,'action','done');f=Fake()
        self.assertEqual('canceled',a.send(self.root,'reminder',self.at,f)['status']);self.assertEqual(0,f.calls)
        self.assertIsNone(a.status(self.root,self.at)['next_action'])
    def test_snooze_suppresses_until_chosen_time(self):
        self.queued();a.change(self.root,'action','snooze','2026-09-08T12:00:00Z');f=Fake()
        self.assertEqual('NOT_DUE',a.send(self.root,'reminder',self.at,f)['status']);self.assertIsNone(a.status(self.root,self.at)['next_action'])
        a.change(self.root,'action','resume');self.assertEqual('queued',a.send(self.root,'reminder',self.at,f)['status'])
    def test_pause_and_revocation_prevent_dispatch(self):
        self.queued();f=Fake();self.c['enabled']=False;self.save()
        self.assertEqual('PAUSED_OR_NOT_AUTHORIZED',a.send(self.root,'reminder',self.at,f)['status'])
        self.c['enabled']=True;self.c['sms']['consented']=False;self.save()
        self.assertEqual('PAUSED_OR_NOT_AUTHORIZED',a.send(self.root,'reminder',self.at,f)['status']);self.assertEqual(0,f.calls)
    def test_daily_limit_counts_uncertain_attempts(self):
        self.c['max_sms_per_day']=1;self.save();self.queued();a.send(self.root,'reminder',self.at,Fake(True));self.queued('second');f=Fake()
        self.assertEqual('DAILY_LIMIT',a.send(self.root,'second',self.at,f)['status']);self.assertEqual(0,f.calls)
    def test_review_due_is_independent_of_file_hash(self):
        self.assertEqual(['action'],a.status(self.root,self.at)['reviews_due'])
        self.assertEqual('Take the next small step',a.status(self.root,self.at)['next_action']['step'])
    def test_timezone_is_required_and_bad_config_fails(self):
        with self.assertRaises(ValueError):a.add(self.root,'naive','step','source',due='2026-09-07T12:00:00')
        self.c['sms']['consented']='yes';self.save()
        with self.assertRaises(ValueError):a.config(self.root)
    def test_destination_change_requires_new_verification(self):
        env={'TWILIO_ACCOUNT_SID':'AC'+'a'*32,'TWILIO_AUTH_TOKEN':'fixture-only','TWILIO_FROM_NUMBER':'+12025550100','MINDMAKE_SMS_TO':'+12025550101'}
        self.c['sms']['recipient_sha256']=a.hashlib.sha256(env['MINDMAKE_SMS_TO'].encode()).hexdigest()
        with patch.dict(a.os.environ,env,clear=True):a.Twilio(self.c)
        env['MINDMAKE_SMS_TO']='+12025550102'
        with patch.dict(a.os.environ,env,clear=True):
            with self.assertRaisesRegex(ValueError,'destination'):a.Twilio(self.c)
    def test_provider_poll_cannot_substitute_another_message(self):
        self.queued();a.send(self.root,'reminder',self.at,Fake())
        f=Fake();f.poll=lambda sid:{'sid':'SM'+'b'*32,'status':'delivered'}
        self.assertEqual('CHECK_FAILED',a.poll(self.root,'reminder',f)['status']);self.assertEqual('queued',a.status(self.root)['reminders'][0]['state'])
    def test_symlink_runtime_is_rejected(self):
        with tempfile.TemporaryDirectory() as outside:
            state=self.root/'Brain/.mindmake/assistant-state'
            import shutil
            shutil.rmtree(state);state.symlink_to(outside,target_is_directory=True)
            with self.assertRaises(ValueError):a.status(self.root)
    def test_empty_status_does_not_create_runtime(self):
        import shutil
        state=self.root/'Brain/.mindmake/assistant-state';shutil.rmtree(state)
        self.assertIsNone(a.status(self.root)['next_action']);self.assertFalse(state.exists())

if __name__=='__main__':unittest.main()
