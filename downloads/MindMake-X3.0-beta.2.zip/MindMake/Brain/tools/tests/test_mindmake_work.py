import copy, importlib.util, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

class WorkRecords(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(importlib.util.find_spec('mindmake_work'), 'Intent/outcome helper not implemented')
        import mindmake_work
        self.m = mindmake_work
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root/'request.md').write_text('Keep phone confirmation pending')
        (self.root/'proof.md').write_text('Local tests passed; phone observation not yet provided')
        self.definition = {'id':'trial','request':'Remember the unfinished phone check','owner':'Fixture owner','scope':'This workspace only','constraints':['No SMS','Do not infer phone delivery'], 'sources':['request.md'], 'criteria':[{'id':'local','outcome':'Local check passes','check':'Run local regression','kind':'check'},{'id':'phone','outcome':'Fixture owner observes phone alert','check':'Read explicit phone observation','kind':'user_observation'}]}
    def init(self):
        return self.m.initialize(self.root,self.definition)
    def observation(self, criterion='local', state='observed', kind='check', event='one', **kw):
        return self.m.record_result(self.root,'trial',{'id':event,'criterion':criterion,'state':state,'kind':kind,'observer':'test operator','note':'Evidence reviewed','evidence':['proof.md'],**kw})
    def test_missing_criteria_cannot_be_complete(self):
        self.init(); self.observation()
        s=self.m.status(self.root,'trial'); self.assertEqual('PENDING',s['status']); self.assertEqual('pending',s['criteria']['phone']['state'])
    def test_request_and_definition_are_preserved(self):
        self.init(); self.assertEqual(self.definition['request'],self.m.status(self.root,'trial')['request'])
        with self.assertRaises(ValueError): self.init()
    def test_artifact_check_cannot_satisfy_phone_observation(self):
        self.init()
        with self.assertRaises(ValueError): self.observation('phone')
    def test_unknown_or_empty_criteria_refused(self):
        d=copy.deepcopy(self.definition);d['criteria']=[]
        with self.assertRaises(ValueError):self.m.initialize(self.root,d)
        self.init()
        with self.assertRaises(ValueError): self.observation('unknown')
    def test_result_needs_evidence_and_unknown_is_not_observed(self):
        self.init()
        with self.assertRaises(ValueError):self.observation(evidence=[])
        with self.assertRaises(ValueError):self.observation(state='done')
    def test_latest_pending_reopens_observed(self):
        self.init();self.observation();self.observation('phone',kind='user_observation',event='two')
        self.assertEqual('OBSERVED',self.m.status(self.root,'trial')['status'])
        self.observation('phone',state='pending',kind='user_observation',event='three')
        self.assertEqual('PENDING',self.m.status(self.root,'trial')['status'])
    def test_source_and_result_evidence_drift_invalidate_observation(self):
        self.init(); self.observation();(self.root/'proof.md').write_text('changed')
        self.assertEqual('STALE',self.m.status(self.root,'trial')['status'])
        (self.root/'request.md').write_text('changed request')
        with self.assertRaises(ValueError):self.observation(event='two')
    def test_failed_outcome_creates_proposal_without_execution(self):
        self.init();r=self.observation(state='failed',cause='UNKNOWN',suggestion='Investigate adapter readback')
        s=self.m.status(self.root,'trial');self.assertEqual('FAILED',s['status']);self.assertEqual('PROPOSED',s['proposals'][0]['status']);self.assertFalse(s['proposals'][0]['authorized']);self.assertEqual('Run local regression',s['proposals'][0]['regression'])
        self.observation(state='failed',cause='UNKNOWN',suggestion='Investigate adapter readback')
        self.assertEqual(1,len(self.m.status(self.root,'trial')['proposals']))
    def test_event_id_cannot_replace_evidence(self):
        self.init();self.observation()
        with self.assertRaises(ValueError):self.observation(note='different claim')
    def sample(self,id='window',start='2026-09-14T00:00:00-04:00',end='2026-09-14T01:00:00-04:00',**kwargs):
        return self.m.record_attention(self.root,'trial',{'id':id,'start':start,'end':end,'observer':'operator','evidence':['proof.md'],'counts':{k:0 for k in self.m.METRICS},**kwargs})
    def test_absence_of_attention_sample_is_not_zero(self):
        self.init();self.assertEqual('NOT_MEASURED',self.m.status(self.root,'trial')['attention']['status'])
        self.sample();a=self.m.status(self.root,'trial')['attention'];self.assertEqual('RECORDED',a['status']);self.assertEqual(3600,a['observed_seconds']);self.assertEqual(0,a['counts']['missed_followups'])
    def test_attention_overlap_duplicates_and_negative_counts(self):
        self.init();self.sample();self.sample()
        self.assertEqual(1,self.m.status(self.root,'trial')['attention']['samples'])
        with self.assertRaises(ValueError):self.sample(id='overlap')
        counts={k:0 for k in self.m.METRICS};counts['missed_followups']=-1
        with self.assertRaises(ValueError):self.sample(id='bad',counts=counts)
    def test_timezone_and_future_attention_refused(self):
        self.init()
        with self.assertRaises(ValueError):self.sample(start='2026-09-14T00:00:00')
        with self.assertRaises(ValueError):self.sample(start='2999-01-01T00:00:00Z',end='2999-01-02T00:00:00Z')
    def test_malformed_saved_event_is_not_ignored(self):
        self.init();folder=self.root/'Brain/.mindmake/work-records/trial/events';folder.mkdir(exist_ok=True);(folder/'broken.json').write_text('{}')
        with self.assertRaises(ValueError):self.m.status(self.root,'trial')
    def test_paths_reject_symlink_and_escape(self):
        self.definition['sources']=['../outside']
        with self.assertRaises(ValueError):self.init()
        self.definition['sources']=['alias'];(self.root/'alias').symlink_to(self.root/'request.md')
        with self.assertRaises(ValueError):self.init()

    def test_saved_observer_and_note_required(self):
        import json
        self.init();self.observation()
        p=self.root/'Brain/.mindmake/work-records/trial/events/one.json';r=json.loads(p.read_text());del r['body']['observer'];p.write_text(json.dumps(r))
        with self.assertRaises(ValueError):self.m.status(self.root,'trial')
    def test_saved_attention_cannot_bypass_future_or_overlap_checks(self):
        import json
        self.init();self.sample();p=self.root/'Brain/.mindmake/work-records/trial/events/window.json';r=json.loads(p.read_text());r['body']['id']='duplicate';(p.parent/'duplicate.json').write_text(json.dumps(r))
        with self.assertRaises(ValueError):self.m.status(self.root,'trial')
        (p.parent/'duplicate.json').unlink();r['body']['id']='window';r['body']['start']='2999-01-01T00:00:00Z';r['body']['end']='2999-01-02T00:00:00Z';p.write_text(json.dumps(r))
        with self.assertRaises(ValueError):self.m.status(self.root,'trial')
    def test_symlink_definition_refused(self):
        self.init();p=self.root/'Brain/.mindmake/work-records/trial/definition.json';outside=self.root/'copied.json';outside.write_bytes(p.read_bytes());p.unlink();p.symlink_to(outside)
        with self.assertRaises(ValueError):self.m.status(self.root,'trial')
    def test_non_object_inputs_refused(self):
        self.init()
        for value in [None,[],"not an object"]:
            with self.assertRaises(ValueError):self.m.record_result(self.root,'trial',value)
            with self.assertRaises(ValueError):self.m.record_attention(self.root,'trial',value)

    def test_context_invalid_journal_refuses_both_append_routes(self):
        import json
        self.init();self.observation()
        p=self.root/'Brain/.mindmake/work-records/trial/events/one.json';original=json.loads(p.read_text())
        for field,value in [('criterion','missing'),('kind','user_observation')]:
            row=copy.deepcopy(original);row['body'][field]=value;p.write_text(json.dumps(row))
            with self.assertRaises(ValueError):self.observation(event='new')
            with self.assertRaises(ValueError):self.sample()
            self.assertFalse((p.parent/'new.json').exists());self.assertFalse((p.parent/'window.json').exists())
    def test_future_event_timestamp_refuses_status_and_new_writes(self):
        import json
        self.init();self.observation(state='failed',suggestion='Investigate')
        p=self.root/'Brain/.mindmake/work-records/trial/events/one.json';r=json.loads(p.read_text());r['recorded_at']='2999-01-01T00:00:00Z';p.write_text(json.dumps(r))
        with self.assertRaises(ValueError):self.m.status(self.root,'trial')
        with self.assertRaises(ValueError):self.observation(event='later')
        with self.assertRaises(ValueError):self.sample()
        self.assertEqual(1,len(list(p.parent.glob('*.json'))))
    def test_proposal_scope_mismatch_refuses_append(self):
        import json
        self.init();self.observation(state='failed',suggestion='Investigate')
        p=self.root/'Brain/.mindmake/work-records/trial/events/one.json';r=json.loads(p.read_text());r['body']['proposal']['scope']='Unrelated account';p.write_text(json.dumps(r))
        with self.assertRaises(ValueError):self.observation(event='new')
        with self.assertRaises(ValueError):self.sample()

if __name__=='__main__':unittest.main()
