"""Watcher acceptance against isolated customer folders."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT=Path(__file__).parents[3]
SPEC=importlib.util.spec_from_file_location('watch',ROOT/'Brain/tools/downloads_watch.py')
watch=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(watch)

class DownloadsAcceptance(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)/'Customer folder'
        shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('map-history','__pycache__','._*','downloads-watch'))
        (self.root/'Wiki/Example/Sources').mkdir(parents=True,exist_ok=True)
        (self.root/'Wiki/Example/INDEX.md').write_text('# Fixture reference topic\n')
        (self.root/watch.RULES).write_text(json.dumps({'stable_seconds':10,'rules':[{'pattern':'reference-*.pdf','destination':'Wiki/Example/Sources'}]}))
        watch.mm.rebuild(self.root)

    def source(self,name='reference-one.pdf'):
        p=self.root/'Downloads'/name;p.write_bytes(b'Disposable reference fixture');return p

    def test_stable_file_routes_with_maps_and_receipt(self):
        source=self.source()
        first=watch.scan_once(self.root,clock=100)
        self.assertEqual('downloading',first['files']['Downloads/reference-one.pdf']['status'])
        result=watch.scan_once(self.root,clock=111)
        self.assertFalse(source.exists())
        self.assertEqual(b'Disposable reference fixture',(self.root/'Wiki/Example/Sources/reference-one.pdf').read_bytes())
        self.assertEqual('filed',result['files']['Downloads/reference-one.pdf']['status'])
        self.assertEqual('PASS',watch.mm.verify(self.root)['status'])
        self.assertIn('reference-one.pdf',(self.root/'Wiki/INDEX.md').read_text())

    def test_partial_and_ambiguous_downloads_are_preserved(self):
        partial=self.source('reference-one.pdf.crdownload');unknown=self.source('unknown.pdf')
        watch.scan_once(self.root,clock=100);result=watch.scan_once(self.root,clock=111)
        self.assertTrue(partial.exists());self.assertTrue(unknown.exists())
        self.assertNotIn('Downloads/reference-one.pdf.crdownload',result['files'])
        self.assertEqual('needs_review',result['files']['Downloads/unknown.pdf']['status'])

    def test_collision_never_overwrites(self):
        source=self.source();dest=self.root/'Wiki/Example/Sources'/source.name;dest.write_bytes(b'Existing customer content')
        watch.scan_once(self.root,clock=100);result=watch.scan_once(self.root,clock=111)
        self.assertEqual(b'Existing customer content',dest.read_bytes());self.assertTrue(source.exists())
        self.assertEqual('needs_review',result['files']['Downloads/reference-one.pdf']['status'])

    def test_failed_map_update_remains_pending_then_recovers(self):
        self.source();watch.scan_once(self.root,clock=100)
        with patch.object(watch.mm,'rebuild',side_effect=ValueError('Fixture locked map')):
            result=watch.scan_once(self.root,clock=111)
        self.assertEqual('filed_map_pending',result['files']['Downloads/reference-one.pdf']['status'])
        result=watch.scan_once(self.root,clock=120)
        self.assertEqual('filed',result['files']['Downloads/reference-one.pdf']['status'])
        self.assertEqual('PASS',watch.mm.verify(self.root)['status'])

    def test_changes_reset_stability_window(self):
        p=self.source();watch.scan_once(self.root,clock=100)
        p.write_bytes(b'A larger incomplete download')
        result=watch.scan_once(self.root,clock=111)
        self.assertTrue(p.exists());self.assertEqual('downloading',result['files']['Downloads/reference-one.pdf']['status'])

    def test_background_start_is_idempotent_and_stop_is_cooperative(self):
        cmd=[sys.executable,'-B',str(self.root/'Brain/tools/downloads_watch.py')]
        def call(op):
            return json.loads(subprocess.run(cmd+[op,'--interval','1'],capture_output=True,text=True,check=True).stdout)
        try:
            self.assertEqual('RUNNING',call('start')['status'])
            self.assertEqual('ALREADY_RUNNING',call('start')['status'])
            self.assertTrue(call('status')['running'])
        finally:
            call('stop')
            for _ in range(30):
                if not call('status')['running']:break
                time.sleep(.1)
        self.assertFalse(call('status')['running'])

if __name__=='__main__':unittest.main(verbosity=2)
