"""Startup routing regressions; mutations and synthetic reviews stay in fixtures."""
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).parents[3]
SPEC = importlib.util.spec_from_file_location('startup_mm', ROOT/'Brain/tools/mindmake.py')
mm = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mm)


def use_strict_review_mode(root):
    """3.0Claude ships with reviews off and helpers on demand; these tests exercise the optional strict X2.0 mode."""
    import json as _j
    p=root/'Brain/.mindmake/runtime.json'; d=_j.loads(p.read_text())
    d['require_setup_review']=True; d.pop('session_loading_mode',None); d.pop('review_scheme',None)
    p.write_text(_j.dumps(d))

class SessionLoading(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)/'Relocated customer folder'
        shutil.copytree(ROOT, self.root, ignore=shutil.ignore_patterns('__pycache__','map-history','._*','map.lock'))
        use_strict_review_mode(self.root)
        mm.rebuild(self.root)

    def config(self, change):
        p = self.root/'Brain/.mindmake/runtime.json'
        data = json.loads(p.read_text()); change(data)
        p.write_text(json.dumps(data)); mm.rebuild(self.root)

    def test_preverified_package_requires_session_reads_before_intake(self):
        # Synthetic fixture review is never production/model acceptance.
        for item in mm.setup_review(self.root)['pending']:
            evidence = 'Brain/governance/setup-reviews/session-fixture.md'
            (self.root/evidence).write_text('# Synthetic fixture\n## Source read\nFixture only\n## Requirements\nFixture only\n## Conflicts\nNone\n## Verification\nFixture only\n## Open issues\nNone\n')
            mm.record_setup_review(self.root,item['job'],evidence,item['fingerprint'])
        mm.rebuild(self.root)
        before = {p.relative_to(self.root).as_posix():mm.digest(p.read_bytes()) for p in self.root.rglob('*') if p.is_file()}
        result = mm.boot(self.root, allow_maintenance=False)
        self.assertEqual('RECORDED',result['setup_review']['status'])
        self.assertTrue(result['next_action'].startswith('Read and apply'), result['next_action'])
        loading = result.get('session_loading', {})
        self.assertEqual('READ_REQUIRED',loading.get('status'))
        self.assertEqual(10,len(loading['components']))
        cartographer = loading['components'][1]
        self.assertEqual('Jobs/MindMake Cartographer',cartographer['job'])
        self.assertEqual(cartographer['source'],cartographer['read_order'][-1])
        self.assertFalse(loading['model_activation_verified'])
        self.assertEqual(before,{p.relative_to(self.root).as_posix():mm.digest(p.read_bytes()) for p in self.root.rglob('*') if p.is_file()})

    def test_missing_empty_and_reordered_core_routes_fail(self):
        original=(self.root/'Brain/.mindmake/runtime.json').read_text()
        for kind in ('missing','empty','reordered','duplicate','flags_removed','malformed'):
            with self.subTest(kind=kind):
                (self.root/'Brain/.mindmake/runtime.json').write_text(original)
                def change(d):
                    if kind=='missing': d.pop('session_components')
                    elif kind=='empty': d['session_components']=[]
                    elif kind=='reordered': d['session_components'].reverse()
                    elif kind=='flags_removed':
                        d.pop('session_components'); d.pop('require_setup_review')
                    elif kind=='malformed': d['session_components']=['bad row']
                    else: d['session_components'][1]=d['session_components'][0]
                self.config(change)
                result=mm.boot(self.root,allow_maintenance=False)
                self.assertEqual('FAIL',result['status'])
                self.assertTrue(any('Session component' in e for e in result['errors']))

    def test_wrong_source_wrapper_and_escape_fail(self):
        original=(self.root/'Brain/.mindmake/runtime.json').read_text()
        for field,value in [('source','GUARD.md'),('wrapper','CLAUDE.md'),('source','../outside.pdf')]:
            with self.subTest(field=field,value=value):
                (self.root/'Brain/.mindmake/runtime.json').write_text(original)
                self.config(lambda d:d['session_components'][1].__setitem__(field,value))
                result=mm.boot(self.root,allow_maintenance=False)
                self.assertEqual('FAIL',result['status'])
                self.assertTrue(any('Session component' in e for e in result['errors']))

    def test_completed_intake_does_not_skip_session_reads(self):
        for field,_ in mm.INTAKE_QUESTIONS: mm.record_intake(self.root,field,None,skip=True)
        mm.rebuild(self.root)
        result=mm.boot(self.root,allow_maintenance=False)
        self.assertEqual('READ_REQUIRED',result.get('session_loading',{}).get('status'))
        self.assertTrue(result['next_action'].startswith('Read and apply'))

    def test_missing_wrapper_blocks(self):
        cfg=json.loads((self.root/'Brain/.mindmake/runtime.json').read_text())
        (self.root/cfg['session_components'][1]['wrapper']).unlink()
        result=mm.boot(self.root,allow_maintenance=False)
        self.assertEqual('FAIL',result['status'])
        self.assertEqual('BLOCKED',result.get('session_loading',{}).get('status'))

if __name__=='__main__': unittest.main()
