"""X3.0 release review (ChatGPT veto, 2026-11-21): the human guide and the migration
rules must not promise what MindMake can't guarantee."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[3]


def text(rel):
    return (ROOT/rel).read_text()


class ReleaseClaims(unittest.TestCase):
    def test_guide_makes_no_unconditional_promises(self):
        guide = text('MindMake X3.0 Guide.md')
        for claim in ('always work', 'notices and catches up', 'It never makes up', 'it saves its place',
                      'Removes what you shared', 'It never moves or deletes',
                      'only the last few minutes', 'nothing was lost'):
            self.assertNotIn(claim, guide)
        # The real limits are stated instead.
        self.assertIn('once you say yes', guide)
        self.assertIn("can't erase what your AI app", guide)
        self.assertIn('only when it can read the old system directly', guide)
        self.assertIn('Python 3.10 or newer', guide)
        self.assertIn('resumes from the last verified checkpoint', guide)
        self.assertIn("couldn't verify or carry over", guide)
        self.assertIn('Made for Apple computers', guide)
        self.assertIn('results may vary', guide)

    def test_migration_claims_saved_only_after_readback(self):
        migration = text('Brain/MIGRATION.md')
        self.assertNotIn('I saved our place', migration)
        self.assertIn('counts as saved only after a readback', migration)
        self.assertIn('checkpoint **during** the work', migration)

    def test_intake_states_separate_python_needs_and_checks_mcp_first(self):
        intake = text('INTAKE.md')
        self.assertIn('Python 3.9 or newer', intake)
        self.assertIn('3.10 or newer', intake)
        self.assertIn('personal_mcp.py check', intake)


    def test_always_on_page_is_optional_and_states_its_limits(self):
        guide = text('MindMake X3.0 Guide.md')
        page = guide[guide.index('## 9. Optional: the always-on setup'):]
        for must in ('optional, not the default', 'has to stay on, awake and online', 'One AI writing at a time',
                     "don't prevent it", 'Not yet tested by MindMake'):
            self.assertIn(must, page)

if __name__ == '__main__':
    unittest.main(verbosity=2)
