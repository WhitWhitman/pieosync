import copy
import pathlib
import sys
import unittest
from unittest.mock import patch

TOOLS = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))
MODEL = {'identity': 'test-model', 'revision': 'r1', 'host': 'test-host'}


class TaskEvalTests(unittest.TestCase):
    def helper(self):
        self.assertTrue((TOOLS / 'mindmake_task_eval.py').is_file(), 'task eval helper is not implemented')
        import mindmake_task_eval
        return mindmake_task_eval

    def observed(self, m, packet):
        return {'fingerprint': packet['fingerprint'], 'model': MODEL,
                'observations': [{'id': c['id'], 'decision': c['expected'], 'rationale': 'Observed fixture evidence supports this decision.'}
                                 for c in m.corpus()['cases']]}

    def test_blind_packet_and_complete_scoring(self):
        m = self.helper()
        packet = m.packet(MODEL)
        self.assertEqual(5, len(packet['cases']))
        self.assertTrue(all('expected' not in c for c in packet['cases']))
        self.assertEqual('PASS', m.score(self.observed(m, packet), MODEL)['status'])

    def test_missing_duplicate_invalid_wrong_and_stale_fail(self):
        m = self.helper()
        good = self.observed(m, m.packet(MODEL))
        variants = []
        x = copy.deepcopy(good); x['observations'].pop(); variants.append(x)
        x = copy.deepcopy(good); x['observations'].append(x['observations'][0]); variants.append(x)
        x = copy.deepcopy(good); x['observations'][0]['decision'] = 'nonsense'; variants.append(x)
        x = copy.deepcopy(good); x['observations'][0]['decision'] = 'close'; variants.append(x)
        x = copy.deepcopy(good); x['fingerprint'] = 'stale'; variants.append(x)
        x = copy.deepcopy(good); x['model']['revision'] = 'r2'; variants.append(x)
        x = copy.deepcopy(good); x['observations'][0]['rationale'] = ''; variants.append(x)
        for value in variants:
            with self.subTest(value=value): self.assertNotEqual('PASS', m.score(value, MODEL)['status'])

    def test_fingerprint_invalidates_model_and_content_changes(self):
        m = self.helper()
        base = m.packet(MODEL)['fingerprint']
        other = dict(MODEL, revision='r2')
        self.assertNotEqual(base, m.packet(other)['fingerprint'])
        manifest = {'model': MODEL, 'hashes': {'skill': 'a'}}
        self.assertNotEqual(m.fingerprint(manifest), m.fingerprint(dict(manifest, hashes={'skill': 'b'})))
        unknown = m.packet(dict(MODEL, revision='unknown'))
        self.assertFalse(unknown['provenance']['model_revision_known'])

    def test_source_skill_corpus_and_implementation_drift_invalidates_observations(self):
        m = self.helper()
        observed = self.observed(m, m.packet(MODEL))
        actual_digest = m.digest
        for relative in ('Brain/PERSONAL_ASSISTANT.md', 'Brain/skills/mindmake-workspace/SKILL.md',
                         'Brain/tools/task-eval-cases.json', 'Brain/tools/mindmake_task_eval.py'):
            with self.subTest(relative=relative):
                changed = m.ROOT / relative
                with patch.object(m, 'digest', side_effect=lambda path: '0' * 64 if path == changed else actual_digest(path)):
                    self.assertEqual('STALE', m.score(observed, MODEL)['status'])

    def test_active_procedures_and_review_changes_invalidate_packet(self):
        m = self.helper()
        observed = self.observed(m, m.packet(MODEL))
        actual_digest = m.digest
        for relative in ('Brain/tools/FOLLOW_THROUGH.md',
                         'Brain/tools/WORKFLOW_IMPROVEMENT.md',
                         'Brain/governance/RUNTIME.md', 'Brain/tools/mindmake_review.py'):
            with self.subTest(relative=relative):
                changed = m.ROOT / relative
                self.assertTrue(changed.is_file(), 'Active provenance source missing')
                with patch.object(m, 'digest', side_effect=lambda path: '0' * 64 if path == changed else actual_digest(path)):
                    self.assertEqual('STALE', m.score(observed, MODEL)['status'])

    def test_malformed_observations_cannot_pass(self):
        m = self.helper()
        good = self.observed(m, m.packet(MODEL))
        for rows in (None, {}, 'invalid', [None], [{'id': []}], [{'id': 'restart', 'decision': [], 'rationale': 'x'}]):
            with self.subTest(rows=rows):
                changed = dict(good, observations=rows)
                self.assertEqual('FAIL', m.score(changed, MODEL)['status'])
        for value in ([], None, 'invalid'):
            self.assertEqual('FAIL', m.score(value, MODEL)['status'])

    def test_real_helper_fixture_workflows(self):
        m = self.helper()
        result = m.run_fixtures()
        self.assertEqual('PASS', result['status'], result)
        self.assertEqual({'restart', 'source_drift', 'reminder_import_once', 'paused', 'capture_idempotency', 'reminder_conflict'}, {c['id'] for c in result['checks']})
        self.assertTrue(all(c['passed'] for c in result['checks']))
        self.assertEqual('UNTESTED', result['live_phone_acceptance'])


class PackageProvenanceTests(unittest.TestCase):
    def test_engine_refuses_symlink_parent(self):
        import tempfile
        import mindmake_task_eval as m
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp).resolve(); (root/'.mindmake-home').write_text('.')
            actual=root/'actual';actual.mkdir()
            (root/'Brain').mkdir(); (root/'Brain/tools').symlink_to(actual)
            for name in ('assistant.py','mindmake.py','apple_reminders.py','apple_reminders.jxa','apple_reminders.applescript'):
                (actual/name).write_text('fixture')
            with patch.object(m,'ROOT',root), self.assertRaises(ValueError):m.engine()
    def test_provenance_uses_only_this_package(self):
        self.assertTrue((TOOLS / 'mindmake_task_eval.py').is_file(), 'task eval helper is not implemented')
        import mindmake_task_eval as m
        path, hashes = m.engine()
        self.assertEqual(TOOLS, path)
        self.assertEqual({'assistant.py','mindmake.py','apple_reminders.py','apple_reminders.jxa','apple_reminders.applescript'},set(hashes))
        p=m.provenance(MODEL)
        self.assertEqual('Brain/tools',p['engine_path'])
        self.assertNotIn('Cartographer',str(p))
        self.assertNotIn('authority.json',str(p))
        self.assertIn('Brain/tools/mindmake_local.py',p['hashes'])
if __name__ == '__main__': unittest.main()
