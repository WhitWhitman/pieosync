import datetime as dt
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))
import mindmake_routines as mr

MON = dt.date(2026, 11, 16)  # a Monday


class Routines(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root/'Brain/tools').mkdir(parents=True)
        shutil.copy(TOOLS/'mindmake_clean.py', self.root/'Brain/tools/mindmake_clean.py')

    def test_first_chat_of_day_runs_clean_once_and_lists_due_routines(self):
        first = mr.startup(self.root, MON)
        self.assertEqual('CLEAN', first['brain_clean']['status'])
        self.assertEqual(['overdue_check', 'weekly_recap', 'dreamweaver'], [d['routine'] for d in first['due']])
        second = mr.startup(self.root, MON)
        self.assertEqual('SKIPPED', second['brain_clean']['status'])

    def test_marking_skips_until_next_day_or_week(self):
        mr.startup(self.root, MON)
        for r in ('overdue_check', 'weekly_recap', 'dreamweaver'):
            mr.mark(self.root, r, MON)
        self.assertEqual([], mr.due(self.root, MON))
        self.assertEqual(['deepsleep_clean', 'overdue_check'], mr.due(self.root, MON + dt.timedelta(days=2)))
        self.assertEqual(set(mr.DAILY + mr.WEEKLY), set(mr.due(self.root, MON + dt.timedelta(days=7))))

    def test_one_shared_log_and_unknown_routine_refused(self):
        mr.mark(self.root, 'weekly_recap', MON)
        mr.mark(self.root, 'overdue_check', MON)
        log = json.loads((self.root/mr.LOG).read_text())
        self.assertEqual({'weekly_recap', 'overdue_check'}, set(log))
        self.assertEqual('2026-W47', log['weekly_recap']['period'])
        with self.assertRaises(ValueError):
            mr.mark(self.root, 'anything', MON)

    def test_read_only_boot_never_writes(self):
        result = mr.startup(self.root, MON, allow_write=False)
        self.assertEqual('NOT_RUN', result['brain_clean']['status'])
        self.assertFalse((self.root/mr.LOG).exists())

    def test_switch_check_listed_only_while_switch_running(self):
        self.assertEqual(['downloads intake'], mr.startup(self.root, MON)['every_chat'])
        (self.root/'Jobs/Switch to MindMake').mkdir(parents=True)
        (self.root/'Jobs/Switch to MindMake/PLAN.md').write_text('# Plan\n')
        self.assertEqual(2, len(mr.startup(self.root, MON)['every_chat']))


    def test_startup_shows_overrides(self):
        shutil.copy(TOOLS/'mindmake_overrides.py', self.root/'Brain/tools/mindmake_overrides.py')
        self.assertEqual(dict(active=[], review_due=[]), mr.startup(self.root, MON)['overrides'])
        sys.path.insert(0, str(self.root/'Brain/tools'))
        import mindmake_overrides as mo
        n = mo.start(self.root, 'short-replies')['pending']
        mo.answer(self.root, n, 'detail please'); mo.answer(self.root, n, 'for good'); mo.answer(self.root, n, 'permanent')
        self.assertEqual(mo.OVERRIDABLE['short-replies'], mr.startup(self.root, MON)['overrides']['active'][0]['rule'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
