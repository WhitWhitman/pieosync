"""Onboarding proof boundaries and project creation, using disposable files."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('onboarding_mm', Path(__file__).parents[1]/'mindmake.py')
mm = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mm)

class TutorialProofBoundary(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root/'Brain/.mindmake').mkdir(parents=True)
        (self.root/'Brain/.mindmake/source-catalog.json').write_text('{"sources": []}')
        self.seeds = self.root/'Jobs/Example/Seeds/Short-term'
        self.seeds.mkdir(parents=True)
        self.registry = {'project_maps':{'Jobs/Example':'Jobs/Example/JOB.md'}}

    def tutorial(self):
        with patch.object(mm, 'state', return_value=self.registry), patch.object(mm, 'verify', return_value={'status':'PASS'}), patch.object(mm, 'boot', return_value={'status':'READY_INTAKE_PENDING','errors':[]}):
            return mm.tutorial_status(self.root)

    def test_empty_seed_does_not_complete_seed_step(self):
        (self.seeds/'empty.md').write_text('   \n')
        result = self.tutorial()
        self.assertEqual('PENDING', result['steps'][1]['status'])
        self.assertNotEqual('COMPLETED', result['status'])

    def test_file_checks_never_claim_cross_session_acceptance(self):
        (self.seeds/'decision.md').write_text('Decision: blue cover. Next: review the title.')
        result = self.tutorial()
        self.assertEqual('FILESYSTEM_READY', result['status'])
        self.assertEqual(3, result['completed_count'])
        self.assertEqual('PENDING', result['steps'][3]['status'])
        self.assertNotIn('continuity is verified', result['message'])

    def test_tutorial_does_not_call_mutating_boot(self):
        (self.seeds/'decision.md').write_text('Decision: blue cover. Next: review the title.')
        with patch.object(mm,'state',return_value=self.registry), patch.object(mm,'verify',return_value={'status':'PASS'}), patch.object(mm,'boot') as boot:
            mm.tutorial_status(self.root)
            if boot.called:
                self.assertIs(boot.call_args.kwargs.get('allow_maintenance'), False)

class NewProjectBoundary(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        (self.root/'Brain/.mindmake').mkdir(parents=True)
        (self.root/'Jobs').mkdir()
        for name in ['FOLDER_MAP.md','Jobs/INDEX.md','Seeds/SEEDS_MAP.md','Seeds/Index/seed-index.md']:
            p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('# Map\n')
        (self.root/mm.REGISTRY).write_text(json.dumps({'root_map':'FOLDER_MAP.md','project_maps':{},'generation_id':'initial'}))
        (self.root/mm.INVENTORY).write_text(json.dumps({'entries':[],'generation_id':'initial'}))
        mm.rebuild(self.root)

    def test_new_project_registers_and_does_not_overwrite_existing(self):
        result=mm.create_new_job(self.root,'Example','A scoped test')
        self.assertEqual('CREATED',result['status'])
        self.assertEqual('PASS',mm.verify(self.root)['status'])
        for name in ['Research','Notes','Seeds/Short-term','Seeds/Long-term']:
            self.assertTrue((self.root/'Jobs/Example'/name).is_dir())
        source=self.root/'Jobs/Example/JOB.md';old=source.read_bytes()
        with self.assertRaises(ValueError):mm.create_new_job(self.root,'Example','Replacement')
        self.assertEqual(old,source.read_bytes())

    def test_escape_name_never_creates_outside_jobs(self):
        with self.assertRaises(ValueError):mm.create_new_job(self.root,'../escape')
        self.assertFalse((self.root/'escape').exists())

if __name__=='__main__':unittest.main()
