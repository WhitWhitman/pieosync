import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    import mindmake_seed_memory as memory
except ImportError:
    memory = None


class SeedMemoryTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(memory, 'Seed memory helper is missing')
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for pool in ('Short-term', 'Long-term'):
            (self.root/'Jobs/Book/Seeds'/pool).mkdir(parents=True)
        (self.root/'Brain/.mindmake').mkdir(parents=True)

    def seed(self, name, content, pool='Short-term'):
        path = self.root/'Jobs/Book/Seeds'/pool/name
        path.write_text(content)
        return path.relative_to(self.root).as_posix(), hashlib.sha256(path.read_bytes()).hexdigest()

    def check(self, event='e1', **kw):
        args = dict(stream='thread-one', event=event, task='book-launch', scope='Jobs/Book',
                    query='launch approval', reason='start', meaningful=False)
        args.update(kw)
        return memory.check(self.root, **args)

    def test_x3_default_scope_finds_project_seeds(self):
        path, _ = self.seed('2026-11-01_launch.md', 'Launch approval requires the producer.')
        result = self.check(scope='all')
        self.assertIn(path, [c['path'] for c in result['candidates']])

    def test_x3_same_filename_in_two_projects_and_no_cross_project_correction(self):
        for pool in ('Short-term', 'Long-term'): (self.root/'Jobs/Cabin/Seeds'/pool).mkdir(parents=True)
        book, _ = self.seed('2026-11-01_launch.md', 'Launch approval requires the producer.')
        cabin = self.root/'Jobs/Cabin/Seeds/Short-term/2026-11-01_launch.md'
        cabin.write_text('Launch approval for the cabin needs the owner.')
        fix = self.root/'Jobs/Cabin/Seeds/Short-term/2026-11-02_fix.md'
        fix.write_text('---\nsupersedes: 2026-11-01_launch.md\n---\nCabin launch approval now needs the agent.')
        found = [c['path'] for c in self.check(scope='all')['candidates']]
        self.assertIn(book, found)  # the Cabin correction must not hide the Book seed
        self.assertNotIn('Jobs/Cabin/Seeds/Short-term/2026-11-01_launch.md', found)
        self.assertIn('Jobs/Cabin/Seeds/Short-term/2026-11-02_fix.md', found)

    def test_uncalled_status_is_read_only_and_uncounted(self):
        self.assertEqual('UNCOUNTED', memory.status(self.root, 'unseen')['status'])
        self.assertFalse((self.root/'Brain/.mindmake/seed-memory').exists())

    def test_older_relevant_seed_beats_new_noise(self):
        old, _ = self.seed('2026-01-01_launch.md', 'Launch approval requires the producer.', 'Long-term')
        for i in range(12): self.seed(f'2026-09-16_1200{i:02d}_noise.md', 'Unrelated lunch menu')
        result = self.check()
        self.assertEqual(old, result['candidates'][0]['path'])
        self.assertEqual('READ_REQUIRED', result['retrieval'])

    def test_actual_content_return_then_recovery_requires_new_read(self):
        path, sha = self.seed('2026-01-01_launch.md', 'Launch approval is pending.')
        self.check()
        result = memory.read_seed(self.root, 'thread-one', 'read1', path, sha)
        self.assertIn('pending', result['text'])
        self.assertEqual('CONTENT_RETURNED', result['provenance'])
        self.assertEqual('CONTENT_RETURNED', memory.status(self.root, 'thread-one')['retrieval'])
        self.assertFalse(result['comprehension_verified'])
        self.assertEqual('READ_REQUIRED', self.check('recover', reason='recovery')['retrieval'])

    def test_changed_and_missing_bytes_invalidate_receipt(self):
        path, sha = self.seed('2026-01-01_launch.md', 'Launch approval pending.')
        self.check(); memory.read_seed(self.root, 'thread-one', 'r1', path, sha)
        (self.root/path).write_text('Launch approval revoked.')
        self.assertEqual('READ_REQUIRED', memory.status(self.root, 'thread-one')['retrieval'])
        with self.assertRaises(ValueError): memory.read_seed(self.root, 'thread-one', 'r2', path, sha)
        (self.root/path).unlink()
        self.assertEqual('NO_MATCH', memory.status(self.root, 'thread-one')['retrieval'])

    def test_superseding_correction_follows_old_relevance(self):
        old, _ = self.seed('2026-01-01_launch.md', 'Launch approval granted.', 'Long-term')
        self.check()
        new, _ = self.seed('2026-09-17_correction.md', '---\nstatus: active\nsupersedes: 2026-01-01_launch.md\n---\nPause all work.')
        result = self.check('correction', reason='lookup')
        self.assertEqual(new, result['candidates'][0]['path'])
        self.assertNotIn(old, [x['path'] for x in result['candidates']])

    def test_save_clears_only_named_pending_changes(self):
        self.check(meaningful=True)
        self.check('e2', reason='end', meaningful=True)
        path, sha = self.seed('2026-09-17_launch.md', 'Launch decision and remaining work.')
        result = memory.record_save(self.root, 'thread-one', 'save1', path, sha, ['e1'])
        self.assertEqual(['e2'], result['pending_changes'])
        self.assertEqual('SAVE_REQUIRED', result['save_status'])
        result = memory.record_save(self.root, 'thread-one', 'save2', path, sha, ['e2'])
        self.assertEqual('SAVED_BYTES_VERIFIED', result['save_status'])
        (self.root/path).write_text('Changed after receipt')
        self.assertEqual('SAVE_REQUIRED', memory.status(self.root, 'thread-one')['save_status'])

    def test_save_requires_real_current_nonempty_seed(self):
        self.check(meaningful=True)
        with self.assertRaises(ValueError): memory.record_save(self.root,'thread-one','s','Jobs/Book/Seeds/Short-term/missing.md','0'*64,['e1'])
        path, sha = self.seed('2026-09-17_launch.md', '')
        with self.assertRaises(ValueError): memory.record_save(self.root,'thread-one','s',path,sha,['e1'])

    def test_retries_do_not_duplicate_or_reset_state(self):
        self.check(meaningful=True); self.check(meaningful=True)
        self.assertEqual(['e1'], memory.status(self.root,'thread-one')['pending_changes'])
        self.assertEqual(1, memory.status(self.root,'thread-one')['recorded_checks'])
        with self.assertRaises(ValueError): self.check(query='different')

    def test_threads_with_same_long_prefix_are_isolated(self):
        a='a'*50+'-one'; b='a'*50+'-two'
        self.check(stream=a, meaningful=True)
        self.check(stream=b)
        self.assertEqual(['e1'],memory.status(self.root,a)['pending_changes'])
        self.assertEqual([],memory.status(self.root,b)['pending_changes'])

    def test_task_change_requires_retrieval_and_preserves_unsaved_work(self):
        path,sha=self.seed('2026-01-01_launch.md','Launch approval pending.')
        self.check(meaningful=True);memory.read_seed(self.root,'thread-one','r1',path,sha)
        result=self.check('next',task='other',reason='task_change')
        self.assertEqual('READ_REQUIRED',result['retrieval'])
        self.assertEqual(['e1'],result['pending_changes'])

    def test_path_escape_and_symlinks_refused(self):
        with self.assertRaises(ValueError):self.check(scope='../outside')
        outside=self.root/'outside.md';outside.write_text('Launch approval secret')
        target=self.root/'Jobs/Book/Seeds/Short-term/2026-01-01_link.md';target.symlink_to(outside)
        with self.assertRaises((ValueError,RuntimeError)):self.check()

    def test_no_generic_shared_thread_identity(self):
        for stream in ('', 'default', 'codex', 'claude'):
            with self.assertRaises(ValueError):self.check(stream=stream)

    def test_pulse_status_reminds_an_uncounted_thread(self):
        if importlib.util.find_spec('mindmake_pulse') is None:
            self.skipTest('Pulse is a canonical host integration, not a customer dependency')
        import mindmake_pulse as pulse
        self.assertIn('Seed memory: UNCOUNTED',pulse.status_text(self.root,'thread-one'))

    def test_old_unchanged_seed_cannot_clear_new_work(self):
        path,sha=self.seed('2026-01-01_launch.md','Launch decision from old work.')
        self.check(meaningful=True)
        with self.assertRaises(ValueError):memory.record_save(self.root,'thread-one','s1',path,sha,['e1'])
        self.assertEqual('SAVE_REQUIRED',memory.status(self.root,'thread-one')['save_status'])

    def test_inactive_correction_does_not_silently_hide_active_history(self):
        old,_=self.seed('2026-01-01_launch.md','Launch approval granted.')
        self.seed('2026-09-17_correction.md','---\nstatus: archived\nsupersedes: 2026-01-01_launch.md\n---\nPause.')
        result=self.check()
        self.assertIn(old,[x['path'] for x in result['candidates']])
        self.assertEqual('RECONCILIATION_REQUIRED',result['retrieval'])

    def test_partial_correction_never_claims_fully_retrieved(self):
        self.seed('2026-01-01_launch.md','---\nstatus: superseded\n---\nLaunch approval granted.')
        path,sha=self.seed('2026-09-17_correction.md','---\nstatus: active\nsupersedes: 2026-01-01_launch.md#approval\n---\nPause approval.')
        self.check();memory.read_seed(self.root,'thread-one','r1',path,sha)
        self.assertEqual('RECONCILIATION_REQUIRED',memory.status(self.root,'thread-one')['retrieval'])

    def test_portable_default_root_uses_workspace_not_brain(self):
        self.assertEqual(Path('/tmp/example'), memory.default_root(Path('/tmp/example/Brain/tools/mindmake_seed_memory.py')))
        self.assertEqual(Path('/tmp/example'), memory.default_root(Path('/tmp/example/tools/mindmake_seed_memory.py')))

    def test_undated_legacy_seed_requires_reconciliation_without_hiding_valid_matches(self):
        self.seed('HANDOFF.md','Launch approval older handoff.')
        path,_=self.seed('2026-01-01_launch.md','Launch approval current decision.')
        result=self.check()
        self.assertIn(path,[x['path'] for x in result['candidates']])
        self.assertEqual('RECONCILIATION_REQUIRED',result['retrieval'])
        self.assertTrue(any('HANDOFF.md' in w for w in result['warnings']))

    def test_failed_read_response_cannot_leave_a_success_receipt(self):
        path,sha=self.seed('2026-01-01_launch.md','Launch approval pending.')
        self.check()
        with patch.object(memory,'_summary',side_effect=RuntimeError('concurrent metadata failure')):
            with self.assertRaises(RuntimeError):memory.read_seed(self.root,'thread-one','r1',path,sha)
        self.assertEqual('READ_REQUIRED',memory.status(self.root,'thread-one')['retrieval'])

    def test_competing_current_replacements_require_reconciliation(self):
        self.seed('2026-01-01_launch.md','Launch approval originally granted.')
        for date,decision in [('2026-02-02','Hold'),('2026-03-03','Proceed')]:
            self.seed(date+'_correction.md','---\nstatus: active\nsupersedes: 2026-01-01_launch.md\n---\n'+decision)
        self.assertEqual('RECONCILIATION_REQUIRED',self.check()['retrieval'])

    def test_transitive_fork_requires_review_until_explicitly_merged(self):
        self.seed('2026-01-01_launch.md','Launch approval originally granted.')
        for name,refs,decision in [('2026-02-02_a.md','2026-01-01_launch.md','Go'),('2026-03-03_b.md','2026-01-01_launch.md','Stop'),('2026-04-04_c.md','2026-02-02_a.md','Ship')]:
            self.seed(name,'---\nstatus: active\nsupersedes: '+refs+'\n---\n'+decision)
        self.assertEqual('RECONCILIATION_REQUIRED',self.check()['retrieval'])
        self.seed('2026-05-05_merged.md','---\nstatus: active\nsupersedes: [2026-03-03_b.md, 2026-04-04_c.md]\n---\nHold pending review.')
        result=self.check('merged',reason='lookup')
        self.assertEqual('READ_REQUIRED',result['retrieval'])
        self.assertEqual(1,len(result['candidates']))


if __name__ == '__main__': unittest.main()
