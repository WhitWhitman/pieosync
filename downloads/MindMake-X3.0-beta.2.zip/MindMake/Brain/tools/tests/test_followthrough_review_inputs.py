import unittest
from pathlib import Path
import tempfile
import sys
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import mindmake as mm
class ReviewInputs(unittest.TestCase):
    def test_optional_phone_helper_changes_invalidate_review(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'Brain/tools').mkdir(parents=True)
            item={'sha256':{},'job':'Jobs/Fixture'}
            with patch.object(mm,'read',side_effect=lambda p:p.read_bytes() if p.is_file() else b'fixture'):
                before=mm.review_fingerprint(root,item)
                p=root/'Brain/tools/apple_reminders.applescript';p.write_text('first implementation')
                first=mm.review_fingerprint(root,item)
                self.assertNotEqual(before,first)
                p.write_text('changed implementation')
                self.assertNotEqual(first,mm.review_fingerprint(root,item))
    def test_compact_review_governance_is_fingerprint_bound(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'Brain/tools').mkdir(parents=True)
            (root/'Brain/tools/mindmake_review.py').write_text('review')
            target=root/'Brain/governance/RUNTIME.md';target.parent.mkdir(parents=True);target.write_text('before')
            item={'sha256':{},'job':'Jobs/Fixture'}
            with patch.object(mm,'read',side_effect=lambda p:p.read_bytes() if p.is_file() else b'fixture'):
                before=mm.review_fingerprint(root,item)
                target.write_text('after')
                self.assertNotEqual(before,mm.review_fingerprint(root,item))
if __name__=='__main__':unittest.main()
