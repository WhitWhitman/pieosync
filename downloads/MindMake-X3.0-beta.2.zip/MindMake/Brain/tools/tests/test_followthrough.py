import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).parents[3]
sys.path.insert(0, str(ROOT / 'Brain/tools'))
import assistant as a


class Followthrough(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        cfg = self.root / a.CONFIG
        cfg.parent.mkdir(parents=True)
        self.c = json.loads((ROOT / a.CONFIG).read_text())
        self.save()
        (self.root / 'TODO.md').write_text('Submit the reviewed draft.\n')
        self.sha = hashlib.sha256((self.root / 'TODO.md').read_bytes()).hexdigest()

    def save(self):
        (self.root / a.CONFIG).write_text(json.dumps(self.c))

    def capture(self):
        return a.capture(self.root, 'draft', 'Review the draft', 'TODO.md#draft',
                         project='book', owner='Ken')

    def test_capture_restart_history_and_closed_id(self):
        self.assertTrue(callable(getattr(a, 'capture', None)), 'capture API missing')
        self.capture()
        self.assertEqual('UNCHANGED', self.capture()['status'])
        result = subprocess.run([sys.executable, str(ROOT/'Brain/tools/assistant.py'),
                                 '--root', str(self.root), 'actions'], capture_output=True, text=True)
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)
        self.assertEqual('Ken', json.loads(result.stdout)[0]['owner'])
        a.change(self.root, 'draft', 'done')
        self.capture()
        self.assertEqual('done', a.actions(self.root)[0]['status'])
        reopened = subprocess.run([sys.executable, str(ROOT/'Brain/tools/assistant.py'),
                                    '--root', str(self.root), 'actions'], capture_output=True, text=True)
        self.assertEqual(0, reopened.returncode, reopened.stdout + reopened.stderr)
        self.assertEqual('done', json.loads(reopened.stdout)[0]['status'])
        with a.database(self.root) as db:
            self.assertEqual(2, db.execute('SELECT COUNT(*) FROM events').fetchone()[0])

    def test_missing_and_drifting_sources_require_fresh_review(self):
        self.assertTrue(callable(getattr(a, 'capture', None)), 'capture API missing')
        self.capture()
        a.review(self.root, 'draft', self.sha, 'open', 'Read draft; final paragraph still needs editing.',
                 next_review='2099-01-01T00:00:00Z')
        self.assertEqual('CURRENT', a.status(self.root)['open_actions'][0]['review_freshness'])
        (self.root/'TODO.md').write_text('Changed draft.')
        row = a.status(self.root)['open_actions'][0]
        self.assertTrue(row['source_stale'])
        self.assertIn('draft', a.status(self.root)['reviews_due'])
        with self.assertRaises(ValueError):
            a.review(self.root, 'draft', self.sha, 'done', 'Old evidence must not complete changed work.')
        (self.root/'TODO.md').unlink()
        self.assertTrue(a.status(self.root)['open_actions'][0]['source_missing'])
        with self.assertRaises(ValueError):
            a.review(self.root, 'draft', self.sha, 'done', 'Missing evidence must fail closed.')

    def test_capture_rejects_missing_and_outside_source(self):
        self.assertTrue(callable(getattr(a, 'capture', None)), 'capture API missing')
        for source in ('absent.md', '../outside.md', '/etc/hosts', 'https://example.com'):
            with self.assertRaises(ValueError):
                a.capture(self.root, 'bad', 'Do work', source)

    def test_snooze_resume_and_review_completion(self):
        self.assertTrue(callable(getattr(a, 'capture', None)), 'capture API missing')
        self.capture()
        a.queue(self.root, 'remind', 'draft', 'A next step is ready.', '2020-01-01T00:00:00Z')
        a.change(self.root, 'draft', 'snooze', '2099-01-01T00:00:00Z')
        self.assertIsNone(a.status(self.root)['next_action'])
        self.assertEqual(1, len(a.status(self.root)['open_actions']))
        reopened = subprocess.run([sys.executable, str(ROOT/'Brain/tools/assistant.py'),
                                    '--root', str(self.root), 'status'], capture_output=True, text=True)
        self.assertEqual(0, reopened.returncode, reopened.stdout + reopened.stderr)
        self.assertIsNone(json.loads(reopened.stdout)['next_action'])
        a.change(self.root, 'draft', 'resume')
        with self.assertRaises(ValueError):
            a.review(self.root, 'draft', self.sha, 'done', '')
        a.review(self.root, 'draft', self.sha, 'done', 'User verified the submitted draft in the source.')
        self.assertEqual('canceled', a.status(self.root)['reminders'][0]['state'])

    def test_scheduler_requires_observed_receipt_and_expires(self):
        self.assertTrue(callable(getattr(a, 'record_run', None)), 'record_run API missing')
        self.c['scheduler'] = {'status': 'ACTIVE', 'id': 'schedule-1', 'max_age_hours': 24,
                               'last_success_at': '2099-01-01T00:00:00Z'}
        self.save()
        self.assertEqual('CONFIGURED_UNVERIFIED', a.status(self.root)['scheduler_health']['status'])
        receipt = a.record_run(self.root, 'run-1', 'schedule-1', 'success',
                               'Read TODO and checked the next action.', ['TODO.md'])
        self.assertEqual('RECORDED', receipt['status'])
        self.assertEqual('UNCHANGED', a.record_run(self.root, 'run-1', 'schedule-1', 'success',
                         'Read TODO and checked the next action.', ['TODO.md'])['status'])
        with self.assertRaises(ValueError):
            a.record_run(self.root, 'run-1', 'schedule-1', 'failed', 'Different receipt.', ['TODO.md'])
        self.assertEqual('OBSERVED', a.status(self.root)['scheduler_health']['status'])
        self.assertEqual('STALE', a.status(self.root, a.stamp('2099-01-01T00:00:00Z'))['scheduler_health']['status'])
        with a.database(self.root) as db:
            row = db.execute('SELECT * FROM scheduler_runs').fetchone()
            self.assertEqual(self.sha, json.loads(row['source_refs'])[0]['sha256'])

    def test_concurrent_duplicate_capture_is_single_event(self):
        self.assertTrue(callable(getattr(a, 'capture', None)), 'capture API missing')
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(lambda _: self.capture(), range(8)))
        self.assertEqual(1, sum(r['status'] == 'RECORDED' for r in results))
        with a.database(self.root) as db:
            self.assertEqual(1, db.execute('SELECT COUNT(*) FROM events').fetchone()[0])

    def test_source_drift_blocks_sms_dispatch(self):
        self.capture()
        self.c['enabled'] = True
        self.c['sms']['consented'] = True
        self.c['quiet_hours'] = {'start': '00:00', 'end': '00:00'}
        self.save()
        a.queue(self.root, 'remind', 'draft', 'A next step is ready.', '2020-01-01T00:00:00Z')
        (self.root/'TODO.md').write_text('Task changed or superseded.')
        class Transport:
            def send(self, body):
                raise AssertionError('Stale source must not send')
        self.assertEqual('SOURCE_REVIEW_REQUIRED', a.send(self.root, 'remind', transport=Transport())['status'])

    def test_old_database_migrates_without_losing_actions(self):
        path = self.root/a.DB
        path.parent.mkdir(parents=True)
        with sqlite3.connect(path) as db:
            db.execute('CREATE TABLE actions (id TEXT PRIMARY KEY,step TEXT,source TEXT,due TEXT,review_after TEXT,status TEXT,snoozed_until TEXT,created_at TEXT)')
            db.execute("INSERT INTO actions VALUES ('old','Legacy action','legacy://source',NULL,NULL,'open',NULL,'2026-01-01T00:00:00Z')")
        self.assertEqual('old', a.actions(self.root)[0]['id'])
        self.capture()
        self.assertEqual({'old', 'draft'}, {r['id'] for r in a.actions(self.root)})

    def test_review_expires_with_unchanged_source(self):
        self.capture()
        a.review(self.root, 'draft', self.sha, 'open', 'Read source; action remains unfinished.')
        self.assertEqual('OVERDUE', a.status(self.root, a.stamp('2099-01-01T00:00:00Z'))['open_actions'][0]['review_freshness'])

    def test_canonical_layout_creates_no_brain_directory(self):
        original = (a.CONFIG, a.DB)
        try:
            import shutil
            shutil.rmtree(self.root/'Brain')
            (self.root/'.mindmake').mkdir()
            (self.root/'.mindmake/authority.json').write_text('{}')
            a.configure_layout(self.root)
            self.assertEqual('.mindmake/assistant.json', a.CONFIG)
            self.capture()
            self.assertTrue((self.root/'.mindmake/assistant-state/state.sqlite3').is_file())
            self.assertFalse((self.root/'Brain').exists())
        finally:
            a.CONFIG, a.DB = original

    def test_legacy_unverified_source_cannot_dispatch(self):
        a.add(self.root, 'legacy', 'Read the source', 'fixture://source')
        self.c['enabled'] = True
        self.c['sms']['consented'] = True
        self.c['quiet_hours'] = {'start': '00:00', 'end': '00:00'}
        self.save()
        a.queue(self.root, 'legacy-reminder', 'legacy', 'Next step ready.', '2020-01-01T00:00:00Z')
        self.assertEqual('UNVERIFIED_SOURCE', a.status(self.root)['open_actions'][0]['review_freshness'])
        class Transport:
            def send(self, body):
                raise AssertionError('Unverified source must not send')
        self.assertEqual('SOURCE_REVIEW_REQUIRED', a.send(self.root, 'legacy-reminder', transport=Transport())['status'])

    def test_scheduler_age_rejects_zero_negative_and_nonfinite(self):
        for value in (0, -1, float('nan'), float('inf'), True, 'oops'):
            self.c['scheduler']['max_age_hours'] = value
            self.save()
            with self.assertRaises(ValueError):
                a.config(self.root)

    def test_online_snapshot_is_complete_and_integrity_checked(self):
        self.assertTrue(callable(getattr(a, 'snapshot', None)), 'snapshot API missing')
        self.capture()
        receipt = a.snapshot(self.root, 'backup.sqlite3')
        self.assertEqual('ok', receipt['integrity_check'])
        with sqlite3.connect(self.root / receipt['path']) as db:
            self.assertEqual('draft', db.execute('SELECT id FROM actions').fetchone()[0])
            self.assertEqual('ok', db.execute('PRAGMA integrity_check').fetchone()[0])
        self.assertEqual(receipt['sha256'], hashlib.sha256((self.root/receipt['path']).read_bytes()).hexdigest())
        with self.assertRaises(ValueError):
            a.snapshot(self.root, 'backup.sqlite3')

    @unittest.skipUnless(str(ROOT).startswith('/Volumes/') and ROOT.is_dir(), 'External volume unavailable')
    def test_actual_external_volume_wal_restart_concurrent_and_snapshot(self):
        with tempfile.TemporaryDirectory(prefix='followthrough-storage-test-', dir=ROOT/'Brain/.mindmake') as tmp, patch.object(a, 'CONFIG', '.mindmake/assistant.json'), patch.object(a, 'DB', '.mindmake/assistant-state/state.sqlite3'):
            root = Path(tmp)
            (root/'.mindmake').mkdir()
            (root/'.mindmake/authority.json').write_text('{}')
            (root/'TODO.md').write_text('External volume fixture.')
            def capture_in_process(i):
                result = subprocess.run([sys.executable, str(ROOT/'Brain/tools/assistant.py'), '--root', str(root),
                                         'capture', 'task-'+str(i), '--step', 'Check fixture', '--source', 'TODO.md'], capture_output=True, text=True)
                self.assertEqual(0, result.returncode, result.stdout + result.stderr)
                return result
            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                results = list(pool.map(capture_in_process, range(8)))
            self.assertEqual(8, len(results))
            a.change(root, 'task-0', 'done')
            with a.database(root) as db:
                self.assertEqual('wal', db.execute('PRAGMA journal_mode').fetchone()[0])
                self.assertEqual(2, db.execute('PRAGMA synchronous').fetchone()[0])
                self.assertEqual('ok', db.execute('PRAGMA integrity_check').fetchone()[0])
                self.assertEqual(8, db.execute('SELECT COUNT(*) FROM actions').fetchone()[0])
            result = subprocess.run([sys.executable, str(ROOT/'Brain/tools/assistant.py'), '--root', str(root), 'actions'], capture_output=True, text=True)
            self.assertEqual(0, result.returncode, result.stdout + result.stderr)
            self.assertEqual(8, len(json.loads(result.stdout)))
            self.assertEqual('ok', a.snapshot(root)['integrity_check'])
            self.assertFalse((root/'Brain').exists())

    def test_canonical_pause_does_not_create_brain(self):
        import shutil
        shutil.rmtree(self.root/'Brain')
        (self.root/'.mindmake').mkdir()
        (self.root/'.mindmake/authority.json').write_text('{}')
        self.c['enabled'] = True
        (self.root/'.mindmake/assistant.json').write_text(json.dumps(self.c))
        result = subprocess.run([sys.executable, str(ROOT/'Brain/tools/assistant.py'), '--root', str(self.root), 'pause'], capture_output=True, text=True)
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)
        self.assertFalse(json.loads((self.root/'.mindmake/assistant.json').read_text())['enabled'])
        self.assertFalse((self.root/'Brain').exists())


if __name__ == '__main__':
    unittest.main()
