import datetime as dt
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import mindmake_overrides as mo
ROOT = Path(__file__).resolve().parents[3]

TZ = dt.timezone(dt.timedelta(hours=-5))
NOW = dt.datetime(2026, 11, 21, 15, 0, tzinfo=TZ)


def through_questions(root, rule_id, reason, scope, now):
    """The only way to switch an override on: the three questions."""
    n = mo.start(root, rule_id, now)['pending']
    mo.answer(root, n, reason, now)
    if scope == 'today':
        return mo.answer(root, n, 'today', now)
    mo.answer(root, n, 'for good', now)
    return mo.answer(root, n, 'week' if scope == 'trial' else 'permanent', now)


class Overrides(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_today_override_expires_at_midnight(self):
        r = through_questions(self.root, 'short-replies', 'I want detail today', 'today', NOW)
        self.assertEqual('RECORDED', r['status'])
        self.assertEqual(1, len(mo.active(self.root, NOW.replace(hour=23, minute=59))['active']))
        self.assertEqual([], mo.active(self.root, NOW + dt.timedelta(hours=9))['active'])

    def test_trial_ends_by_itself_after_seven_days_without_nagging(self):
        through_questions(self.root, 'one-question-at-a-time', 'I batch answers', 'trial', NOW)
        self.assertEqual(1, len(mo.active(self.root, NOW + dt.timedelta(days=6))['active']))
        later = mo.active(self.root, NOW + dt.timedelta(days=8))
        self.assertEqual([], later['active'])      # the rule is back
        self.assertEqual([], later['review_due'])  # nobody is asked to renew
        self.assertEqual(1, sum(e['event'] == 'override' for e in mo.read(self.root)))  # history kept

    def test_guard_floor_outranks_requests_and_answers_are_the_users_own(self):
        guard = (ROOT/'GUARD.md').read_text()
        self.assertNotIn("the user's request govern", guard)
        self.assertIn("then GUARD's floor (section 10). Within those, the user's request directs the work", guard)
        self.assertIn('A blanket "ignore permission checks"', guard)
        self.assertIn("Each answer must be the user's own reply", guard)
        self.assertIn('ends by itself after seven days', guard)
        self.assertIsNone(mo.check_rule('reliance-check'))   # Whit can adjust it
        self.assertIsNotNone(mo.check_rule('crisis'))        # never

    def test_permanent_stays_and_history_keeps_reasons(self):
        through_questions(self.root, 'weekly-recap', 'I review on paper', 'permanent', NOW)
        self.assertEqual(1, len(mo.active(self.root, NOW + dt.timedelta(days=400))['active']))
        mo.end(self.root, 1, 'changed my mind', NOW)
        history = mo.read(self.root)
        self.assertEqual(['pending-start', 'pending-answer', 'pending-answer', 'override', 'end'],
                         [e['event'] for e in history])
        self.assertEqual('I review on paper', history[3]['reason'])

    def test_floor_rules_never_bend(self):
        for rule in ['crisis', 'yes-before-delete', 'yes-before-send', 'yes-before-purchase',
                     'yes-before-schedule', 'no-made-up-memories', 'honest-status', 'app-safety']:
            self.assertEqual('REFUSED', mo.start(self.root, rule, NOW)['status'], rule)
        self.assertEqual([], mo.read(self.root))

    def test_reworded_protected_rules_are_refused(self):
        # ChatGPT's veto: keyword blocking let these through. Only listed ids pass now.
        for rule in ['Ask before erasing files', 'Never manufacture memories',
                     'Distinguish configured from running', 'Short replies (section 3)', '', None]:
            self.assertEqual('REFUSED', mo.start(self.root, rule, NOW)['status'], rule)
        self.assertEqual([], mo.read(self.root))

    def test_old_free_text_entries_are_never_active(self):
        log = self.root/mo.LOG
        log.parent.mkdir(parents=True)
        log.write_text(json.dumps(dict(event='override', id=1, rule='Ask before erasing files', reason='x',
                                       scope='permanent', at=NOW.isoformat(), until=None)) + '\n')
        self.assertEqual([], mo.active(self.root, NOW)['active'])

    def test_no_direct_add_command(self):
        # ChatGPT recheck #6: an override must never switch on without the three questions.
        self.assertFalse(hasattr(mo, 'add'))
        import subprocess, sys as _sys
        r = subprocess.run([_sys.executable, '-B', mo.__file__, 'add', '--rule-id', 'short-replies',
                            '--reason', 'x', '--root', str(self.root)], capture_output=True, text=True)
        self.assertNotEqual(0, r.returncode)
        self.assertEqual([], mo.read(self.root))

    def test_only_clear_answers_are_accepted(self):
        mo.start(self.root, 'short-replies', NOW)
        mo.answer(self.root, 1, 'detail please', NOW)
        for unclear in ['not today', 'maybe', 'today or tomorrow', 'forever-ish', 'no']:
            with self.assertRaises(ValueError, msg=unclear):
                mo.answer(self.root, 1, unclear, NOW)
        self.assertEqual('duration', mo._pending_state(self.root)[1]['stage'])
        self.assertEqual([], mo.active(self.root, NOW)['active'])
        mo.answer(self.root, 1, 'For good.', NOW)
        for unclear in ['not permanent', 'a week or so maybe', 'not now']:
            with self.assertRaises(ValueError, msg=unclear):
                mo.answer(self.root, 1, unclear, NOW)
        self.assertEqual('RECORDED', mo.answer(self.root, 1, 'Permanent', NOW)['status'])

    def test_last_answer_and_override_are_one_record(self):
        # ChatGPT recheck #2: no gap between saving the last answer and switching the override on.
        mo.start(self.root, 'short-replies', NOW)
        mo.answer(self.root, 1, 'detail please', NOW)
        mo.answer(self.root, 1, 'for good', NOW)
        before = len(mo.read(self.root))
        r = mo.answer(self.root, 1, 'week', NOW)
        events = mo.read(self.root)
        self.assertEqual(before + 1, len(events))
        self.assertEqual('override', events[-1]['event'])
        self.assertEqual('week', events[-1]['answers']['trial'])
        self.assertEqual(1, events[-1]['pending'])
        self.assertEqual('RECORDED', r['status'])
        # An interruption that cut the final write short loses the whole line, never half of it:
        log = self.root/mo.LOG
        log.write_text(log.read_text()[:-20])
        state = mo._pending_state(self.root)
        self.assertEqual('trial', state[1]['stage'])
        self.assertEqual([], mo.active(self.root, NOW)['active'])
        # ...and once it's written, a new chat never asks again.
        log.write_text('\n'.join(json.dumps(e, sort_keys=True) for e in events) + '\n')
        self.assertEqual({}, mo._pending_state(self.root))
        self.assertTrue(mo.start(self.root, 'short-replies', NOW)['status'] == 'PENDING'
                        and mo.start(self.root, 'short-replies', NOW)['stage'] == 'why')

    def test_summary_is_empty_when_nothing_overridden(self):
        self.assertEqual(dict(active=[], review_due=[]), mo.summary(self.root, NOW))

    def test_three_questions_resume_after_an_interruption(self):
        r = mo.start(self.root, 'short-replies', NOW)
        self.assertEqual(('PENDING', 'why'), (r['status'], r['stage']))
        r = mo.answer(self.root, r['pending'], 'I want detail while I learn this', NOW)
        self.assertEqual('duration', r['stage'])
        r = mo.answer(self.root, 1, 'for good', NOW)
        self.assertEqual('trial', r['stage'])
        # The chat ends here. A new chat resumes at the trial question, without asking again.
        r = mo.start(self.root, 'short-replies', NOW + dt.timedelta(days=1))
        self.assertTrue(r['resumed'])
        self.assertEqual('trial', r['stage'])
        self.assertEqual(dict(why='I want detail while I learn this', duration='for good'), r['answers'])
        self.assertEqual(mo.QUESTIONS['trial'], mo.summary(self.root, NOW)['pending'][0]['next_question'])
        r = mo.answer(self.root, 1, 'check back in a week', NOW + dt.timedelta(days=1))
        self.assertEqual(('RECORDED', 'trial'), (r['status'], r['scope']))
        self.assertEqual('I want detail while I learn this', r['reason'])
        self.assertEqual({}, mo._pending_state(self.root))
        self.assertNotIn('pending', mo.summary(self.root, NOW + dt.timedelta(days=1)))

    def test_today_answer_finishes_after_two_questions(self):
        mo.start(self.root, 'quiet-startup', NOW)
        mo.answer(self.root, 1, 'I like the full status', NOW)
        r = mo.answer(self.root, 1, 'just for today', NOW)
        self.assertEqual(('RECORDED', 'today'), (r['status'], r['scope']))

    def test_unclear_or_empty_answers_change_nothing_and_cancel_keeps_the_rule(self):
        mo.start(self.root, 'short-replies', NOW)
        with self.assertRaises(ValueError):
            mo.answer(self.root, 1, '   ', NOW)
        mo.answer(self.root, 1, 'reason', NOW)
        with self.assertRaises(ValueError):
            mo.answer(self.root, 1, 'maybe', NOW)
        self.assertEqual('duration', mo._pending_state(self.root)[1]['stage'])
        mo.cancel(self.root, 1, NOW)
        self.assertEqual({}, mo._pending_state(self.root))
        self.assertEqual([], mo.active(self.root, NOW)['active'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
