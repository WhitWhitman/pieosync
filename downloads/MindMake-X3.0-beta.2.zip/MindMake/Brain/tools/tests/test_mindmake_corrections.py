from pathlib import Path
import importlib.util,sys,tempfile,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
class CorrectionTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('mindmake_corrections'),'Durable correction helper missing')
  import mindmake_corrections as m
  self.m=m;self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.r=Path(self.tmp.name);(self.r/'evidence.txt').write_text('source');(self.r/'check.py').write_text('print("verified")')
 def record(self,id='lesson',command=None):
  return self.m.capture(self.r,id,'release','Repair archives leaked','Missing exclusion','Exclude repair-history','Archive contains no repair-history entries',['evidence.txt','check.py'],command or [sys.executable,'check.py'])
 def test_capture_is_unverified_and_immutable(self):
  self.record();self.assertEqual('UNVERIFIED',self.m.status(self.r)[0]['status'])
  with self.assertRaises(ValueError):self.record()
 def test_success_requires_actual_execution(self):
  self.record();x=self.m.verify(self.r,'lesson');self.assertEqual('CHECK_PASSED',x['status']);self.assertIn('verified',x['stdout']);self.assertEqual('CHECK_PASSED',self.m.status(self.r)[0]['status'])
 def test_failed_command_does_not_pass(self):
  self.record(command=[sys.executable,'-c','raise SystemExit(3)']);x=self.m.verify(self.r,'lesson');self.assertEqual('CHECK_FAILED',x['status'])
 def test_changed_source_invalidates_saved_pass(self):
  self.record();self.m.verify(self.r,'lesson');(self.r/'evidence.txt').write_text('changed');self.assertEqual('STALE',self.m.status(self.r)[0]['status'])
  with self.assertRaises(ValueError):self.m.verify(self.r,'lesson')
 def test_source_changes_during_check_do_not_pass(self):
  self.record(command=[sys.executable,'-c','from pathlib import Path;Path("evidence.txt").write_text("changed")']);self.assertEqual('SOURCE_CHANGED',self.m.verify(self.r,'lesson')['status'])
 def test_reject_escape_and_symlinks(self):
  with self.assertRaises(ValueError):self.m.capture(self.r,'bad','release','issue','cause','fix','criterion',['../other'],[sys.executable,'check.py'])
  (self.r/'alias').symlink_to(self.r/'evidence.txt')
  with self.assertRaises(ValueError):self.m.capture(self.r,'bad','release','issue','cause','fix','criterion',['alias'],[sys.executable,'check.py'])
 def test_scope_limits_discovery(self):
  self.record();self.assertEqual([],self.m.status(self.r,'film'));self.assertEqual(1,len(self.m.status(self.r,'release')))
 def test_sidecars_do_not_become_receipts(self):
  self.record();self.m.verify(self.r,'lesson');(self.r/'Brain/.mindmake/corrections/lesson/._record.json').write_text('binary sidecar')
  self.assertEqual('CHECK_PASSED',self.m.status(self.r)[0]['status'])
 def test_binary_failed_output_replaces_prior_success(self):
  import os
  from unittest.mock import patch
  self.record(command=[sys.executable,'-c','import os,sys;sys.stdout.buffer.write(bytes([255]) if os.getenv("MINDMAKE_BINARY_PROBE") else b"ok");sys.exit(3 if os.getenv("MINDMAKE_BINARY_PROBE") else 0)'])
  self.assertEqual('CHECK_PASSED',self.m.verify(self.r,'lesson')['status'])
  with patch.dict(os.environ,{'MINDMAKE_BINARY_PROBE':'1'}):
   self.assertEqual('CHECK_FAILED',self.m.verify(self.r,'lesson')['status'])
  self.assertEqual('CHECK_FAILED',self.m.status(self.r)[0]['status'])
if __name__=='__main__':unittest.main()
