"""Rollover interruption and preservation probes on disposable fixtures only."""
import json
import os
import unittest
from pathlib import Path
from unittest.mock import patch
import test_mindmake
mm = test_mindmake.mm


class RolloverAcceptance(unittest.TestCase):
    setUp = test_mindmake.MapAcceptance.setUp
    write = test_mindmake.MapAcceptance.write
    build = test_mindmake.MapAcceptance.build
    def logical_seeds(self):
        return sorted(p for p in (self.root/'Seeds/Short-term').glob('*.md') if not p.name.startswith('.'))

    def seeds(self, count=5):
        for i in range(count):
            self.write(f'Seeds/Short-term/{i:03}.md', f'original seed {i}\n')
            os.utime(self.root/f'Seeds/Short-term/{i:03}.md', ns=(1, 1))
        self.build()

    def test_filename_chronology_ignores_copied_mtime(self):
        self.seeds(0)
        for i, name in enumerate(['2026-09-01_090000_old.md', '2026-09-02_090000_mid.md', '2026-09-03_090000_new.md']):
            self.write('Seeds/Short-term/' + name, name)
            os.utime(self.root/'Seeds/Short-term'/name, ns=(10-i, 10-i))
        self.build()
        mm.rollover_seed_pool(self.root, 'Seeds', target=1, cap=3)
        self.assertEqual(['2026-09-03_090000_new.md'], [p.name for p in self.logical_seeds()])

    def test_malformed_optional_startup_state_prevents_maintenance(self):
        self.seeds(); self.boot_fixture()
        self.write('Brain/.mindmake/assistant.json', '{malformed')
        self.build()
        with self.assertRaises(ValueError): mm.boot(self.root)
        self.assertEqual(5, len(list(self.logical_seeds())))
        self.assertFalse((self.root/mm.ROLLOVER_MANIFEST_DIR).exists())

    def test_missing_startup_order_prevents_maintenance(self):
        self.seeds(); self.boot_fixture()
        config = json.loads((self.root/'Brain/.mindmake/runtime.json').read_text())
        del config['startup_order']
        self.write('Brain/.mindmake/runtime.json', json.dumps(config)); self.build()
        with self.assertRaises((KeyError, ValueError)): mm.boot(self.root)
        self.assertEqual(5, len(list(self.logical_seeds())))
        self.assertFalse((self.root/mm.ROLLOVER_MANIFEST_DIR).exists())

    def test_unreadable_shared_seed_prevents_maintenance(self):
        self.seeds(); self.boot_fixture()
        (self.root/'Seeds/Short-term/004.md').write_bytes(b'\xff')
        self.build()
        with self.assertRaises(UnicodeError): mm.boot(self.root)
        self.assertEqual(5, len(list(self.logical_seeds())))
        self.assertFalse((self.root/mm.ROLLOVER_MANIFEST_DIR).exists())

    def test_sidecar_appearing_after_plan_preserves_original(self):
        self.seeds()
        original = mm._exclusive_rollover_write
        def add_metadata(root, rel, data):
            original(root, rel, data)
            if rel.startswith(mm.ROLLOVER_MANIFEST_DIR + '/'):
                (root/'Seeds/Short-term/._000.md').write_bytes(b'new metadata')
        with patch.object(mm, '_exclusive_rollover_write', side_effect=add_metadata):
            with self.assertRaisesRegex(ValueError, 'metadata|sidecar|bytes changed'):
                mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertTrue((self.root/'Seeds/Short-term/000.md').exists())
        self.assertEqual(b'new metadata', (self.root/'Seeds/Short-term/._000.md').read_bytes())

    @unittest.skipUnless(os.name == 'posix' and os.uname().sysname == 'Darwin', 'native macOS resource fork')
    def test_native_resource_fork_without_sidecar_is_preserved(self):
        self.seeds()
        source = self.root/'Seeds/Short-term/000.md'
        import subprocess
        subprocess.run(['xattr', '-wx', 'com.apple.ResourceFork', b'actual native fork'.hex(), str(source)], check=True)
        if source.with_name('._' + source.name).exists():
            self.skipTest('Filesystem represents resource fork with a sidecar; covered by paired-copy tests')
        with self.assertRaisesRegex(ValueError, 'resource fork'):
            mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual(b'actual native fork', (source/'..namedfork/rsrc').read_bytes())
        self.assertEqual(5, len(mm._rollover_records(self.root, 'Seeds')))

    def pending(self):
        return [json.loads(p.read_text()) for p in (self.root/mm.ROLLOVER_MANIFEST_DIR).glob('rollover-*.json')]

    def test_plan_is_durable_before_first_move_and_hashes_every_file(self):
        self.seeds()
        original = Path.unlink
        def interrupted(path, *args, **kwargs):
            if path.parent == self.root/'Seeds/Short-term':
                plans = self.pending()
                self.assertEqual(1, len(plans))
                self.assertEqual('pending', plans[0]['status'])
                self.assertTrue(all(len(e['sha256']) == 64 for e in plans[0]['files']))
                raise OSError('fixture power loss before source removal')
            return original(path, *args, **kwargs)
        with patch.object(Path, 'unlink', interrupted):
            with self.assertRaisesRegex(OSError, 'power loss'):
                mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual(5, len(list(self.logical_seeds())))
        result = mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertTrue(result['applied'])
        self.assertEqual('complete', self.pending()[0]['status'])
        self.assertEqual('PASS', mm.verify(self.root)['status'])

    def test_resume_pending_below_cap(self):
        self.seeds()
        original = Path.unlink
        moved = []
        def interrupted(path, *args, **kwargs):
            result = original(path, *args, **kwargs)
            if path.parent == self.root/'Seeds/Short-term':
                moved.append(path)
                if len(moved) == 1: raise OSError('fixture interrupted after removal')
            return result
        with patch.object(Path, 'unlink', interrupted):
            with self.assertRaises(OSError): mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        result = mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertTrue(result['applied'])
        self.assertEqual(2, result['count_after'])

    def test_invalid_target_and_path_do_not_move(self):
        self.seeds()
        for target in [-1, 5, 6, True]:
            with self.assertRaises(ValueError): mm.rollover_seed_pool(self.root, 'Seeds', target=target, cap=5)
        for pool in ['../outside', 'Jobs', 'Seeds/Short-term']:
            with self.assertRaises(ValueError): mm.rollover_seed_pool(self.root, pool, target=2, cap=5)
        self.assertEqual(5, len(list(self.logical_seeds())))

    def test_all_pinned_is_failure_and_mtime_ties_are_deterministic(self):
        self.seeds()
        for p in self.logical_seeds(): p.write_text('pinned: true\nkeep')
        result = mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertTrue(result.get('errors'))
        for p in self.logical_seeds():
            p.write_text('unpinned'); os.utime(p, ns=(1, 1))
        result = mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual(['003.md', '004.md'], sorted(p.name for p in self.logical_seeds()))

    def boot_fixture(self):
        self.write('.mindmake-home', '.\n')
        self.write('Brain/Profiles/user.md', 'pending')
        self.write('Brain/Profiles/profiles.json', json.dumps({'user': {'path':'Brain/Profiles/user.md', 'status':'pending'}}))
        for name in ['wonder', 'hobby']:
            self.write(f'Brain/Profiles/{name}-list.json', json.dumps({'items':[], 'status':'empty'}))
        self.write('TODO.md', '- [ ] authorized work\n')
        (self.root/'Seeds/Dreams').mkdir(exist_ok=True)
        source = 'Jobs/Test/Products/approved.md'
        self.write('Brain/.mindmake/source-catalog.json', json.dumps({'sources':[{'sha256':{source:mm.digest((self.root/source).read_bytes())}}]}))
        self.write('Brain/.mindmake/runtime.json', json.dumps({'required_paths':['TODO.md'], 'startup_order':['TODO.md'], 'seed_rollover_cap':5, 'seed_rollover_target':2}))
        self.build()

    def test_source_change_after_copy_preserves_changed_source(self):
        self.seeds()
        original = mm._exclusive_rollover_write
        def change(root, rel, data):
            original(root, rel, data)
            if rel == 'Seeds/Long-term/000.md':
                (root/'Seeds/Short-term/000.md').write_text('new user bytes')
        with patch.object(mm, '_exclusive_rollover_write', side_effect=change):
            with self.assertRaisesRegex(ValueError, 'bytes changed'):
                mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual('new user bytes', (self.root/'Seeds/Short-term/000.md').read_text())
        self.assertEqual('original seed 0\n', (self.root/'Seeds/Long-term/000.md').read_text())
        self.assertEqual('pending', self.pending()[0]['status'])

    def test_destination_appearing_at_exclusive_create_is_preserved(self):
        self.seeds()
        original = mm._exclusive_rollover_write
        def conflict(root, rel, data):
            if rel == 'Seeds/Long-term/000.md': (root/rel).write_text('concurrent destination')
            return original(root, rel, data)
        with patch.object(mm, '_exclusive_rollover_write', side_effect=conflict):
            with self.assertRaises(FileExistsError): mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual('concurrent destination', (self.root/'Seeds/Long-term/000.md').read_text())
        self.assertEqual('original seed 0\n', (self.root/'Seeds/Short-term/000.md').read_text())
        with self.assertRaisesRegex(ValueError, 'bytes changed'): mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)

    def test_sidecar_hash_and_existing_destination_are_preserved(self):
        self.seeds()
        self.write('Seeds/Short-term/._000.md', 'resource fork')
        self.write('Seeds/Long-term/000.md', 'existing archive')
        self.build()
        mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual('existing archive', (self.root/'Seeds/Long-term/000.md').read_text())
        plan = self.pending()[0]
        sidecar = [e for e in plan['files'] if '/._' in e['source']][0]
        self.assertEqual(mm.digest(b'resource fork'), sidecar['sha256'])
        self.assertEqual(b'resource fork', (self.root/sidecar['destination']).read_bytes())

    def test_symlink_seed_or_tier_is_refused(self):
        self.seeds()
        (self.root/'Seeds/Short-term/000.md').unlink()
        (self.root/'Seeds/Short-term/000.md').symlink_to(self.root/'TODO.md')
        with self.assertRaisesRegex(ValueError, 'Symbolic link'):
            mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertFalse((self.root/mm.ROLLOVER_MANIFEST_DIR).exists())

    def test_pool_lock_blocks_second_writer(self):
        self.seeds()
        folder = self.root/mm.ROLLOVER_MANIFEST_DIR
        folder.mkdir()
        lock_rel = mm.ROLLOVER_MANIFEST_DIR + '/pool-' + mm.digest(b'Seeds')[:24] + '.lock'
        with mm.acquire(self.root, lock_rel):
            with self.assertRaisesRegex(ValueError, 'holds the lock'):
                mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual([], self.pending())

    def test_interrupted_map_requires_recover_then_finishes_pending_plan(self):
        self.seeds()
        original = mm.atomic
        def interrupted(path, data):
            original(path, data)
            if path == self.root/'Jobs/Test/JOB.md': raise OSError('map interruption')
        with patch.object(mm, 'atomic', side_effect=interrupted):
            with self.assertRaises(OSError): mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual('pending', self.pending()[0]['status'])
        with self.assertRaisesRegex(ValueError, 'recover_map'): mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        # Rollback can report stale links because rollover already moved originals; the journal is recovered.
        mm.recover(self.root)
        self.assertFalse((self.root/mm.PENDING).exists())
        result = mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual('PASS', result['status'])
        self.assertEqual('complete', self.pending()[0]['status'])

    def test_boot_no_maintenance_and_failed_preflight_leave_seeds_unchanged(self):
        self.seeds(); self.boot_fixture()
        with patch.object(mm, 'rollover_seed_pool', side_effect=AssertionError('must not maintain')):
            result = mm.boot(self.root, allow_maintenance=False)
            self.assertNotEqual('FAIL', result['status'])
            self.write('Jobs/Test/Products/approved.md', 'changed source')
            self.assertEqual('FAIL', mm.boot(self.root)['status'])
        self.assertFalse((self.root/mm.ROLLOVER_MANIFEST_DIR).exists())
        self.assertEqual(5, len(list(self.logical_seeds())))

    def test_boot_selects_remaining_paths_and_resumes_below_cap(self):
        self.seeds(); self.boot_fixture()
        original = Path.unlink
        def interrupted(path, *args, **kwargs):
            result = original(path, *args, **kwargs)
            if path == self.root/'Seeds/Short-term/000.md': raise OSError('interrupt')
            return result
        with patch.object(Path, 'unlink', interrupted):
            with self.assertRaises(OSError): mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual(4, len(list(self.logical_seeds())))
        result = mm.boot(self.root)
        self.assertNotEqual('FAIL', result['status'], result['errors'])
        self.assertEqual(2, result['shared_seed_count'])
        self.assertTrue(all((self.root/p).is_file() for p in result['seed_read_order']))
        self.assertEqual('PASS', mm.verify(self.root)['status'])

    def test_pending_plan_does_not_mask_unrelated_map_failure(self):
        self.seeds(); self.boot_fixture()
        original = mm._exclusive_rollover_write
        def interrupted(root, rel, data):
            original(root, rel, data)
            if rel == 'Seeds/Long-term/000.md': raise OSError('interruption')
        with patch.object(mm, '_exclusive_rollover_write', side_effect=interrupted):
            with self.assertRaises(OSError): mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual('pending', self.pending()[0]['status'])
        self.write('Jobs/Test/Products/unmapped.md', 'unrelated')
        with patch.object(mm, 'rollover_seed_pool', side_effect=AssertionError('must not maintain')):
            self.assertEqual('FAIL', mm.boot(self.root)['status'])

    def test_sidecars_are_archived_before_primary_unlink_and_os_metadata_is_separate(self):
        self.seeds()
        raw = b'original raw AppleDouble resource bytes'
        self.write('Seeds/Short-term/._000.md', raw.decode())
        self.build()
        original_write, original_unlink = mm._exclusive_rollover_write, Path.unlink
        generated = b'OS-generated destination metadata'
        def write(root, rel, data):
            original_write(root, rel, data)
            if rel == 'Seeds/Long-term/000.md':
                (root/'Seeds/Long-term/._000.md').write_bytes(generated)
        def unlink(path, *args, **kwargs):
            if path == self.root/'Seeds/Short-term/000.md':
                plan = self.pending()[0]
                sidecar = next(e for e in plan['files'] if e['source'] == 'Seeds/Short-term/._000.md')
                self.assertEqual('copied', sidecar['state'])
                self.assertEqual(raw, (self.root/sidecar['destination']).read_bytes())
                # Simulate macOS removing the companion when its primary is removed.
                companion = path.with_name('._' + path.name)
                if companion.exists(): original_unlink(companion)
            return original_unlink(path, *args, **kwargs)
        with patch.object(mm, '_exclusive_rollover_write', side_effect=write), patch.object(Path, 'unlink', unlink):
            result = mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual('PASS', result['status'])
        self.assertEqual(raw, (self.root/'Seeds/Long-term/000.md.appledouble').read_bytes())
        self.assertEqual(generated, (self.root/'Seeds/Long-term/._000.md').read_bytes())

    def test_existing_raw_sidecar_archive_and_new_sidecar_conflict_are_preserved(self):
        self.seeds()
        self.write('Seeds/Short-term/._000.md', 'original companion')
        self.write('Seeds/Long-term/000.md.appledouble', 'existing unrelated companion')
        self.build()
        original = mm._exclusive_rollover_write
        def conflict(root, rel, data):
            if rel.endswith('.appledouble'):
                (root/rel).write_bytes(b'new user conflict')
            return original(root, rel, data)
        with patch.object(mm, '_exclusive_rollover_write', side_effect=conflict):
            with self.assertRaises(FileExistsError): mm.rollover_seed_pool(self.root, 'Seeds', target=2, cap=5)
        self.assertEqual('existing unrelated companion', (self.root/'Seeds/Long-term/000.md.appledouble').read_text())
        self.assertEqual('original seed 0\n', (self.root/'Seeds/Short-term/000.md').read_text())
        self.assertEqual('original companion', (self.root/'Seeds/Short-term/._000.md').read_text())
        sidecar = next(e for e in self.pending()[0]['files'] if e['source'] == 'Seeds/Short-term/._000.md')
        self.assertEqual(b'new user conflict', (self.root/sidecar['destination']).read_bytes())
