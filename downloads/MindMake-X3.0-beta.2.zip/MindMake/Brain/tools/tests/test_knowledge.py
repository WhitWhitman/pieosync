"""Disposable source-processing acceptance probes; no real review is implied."""
import importlib.util,json,shutil,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).parents[3]
spec=importlib.util.spec_from_file_location('knowledge_test',ROOT/'Brain/tools/knowledge.py')
k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k);mm=k.mm

def use_strict_review_mode(root):
    """3.0Claude ships with reviews off and helpers on demand; these tests exercise the optional strict X2.0 mode."""
    import json as _j
    p=root/'Brain/.mindmake/runtime.json'; d=_j.loads(p.read_text())
    d['require_setup_review']=True; d.pop('session_loading_mode',None); d.pop('review_scheme',None)
    p.write_text(_j.dumps(d))

class KnowledgeAcceptance(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name)/'Renamed workspace'
  shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__','map-history','._*','map.lock'))
  (self.root/mm.REVIEW).write_text(json.dumps({'schema_version':1,'records':{}}))
  use_strict_review_mode(self.root)
  self.source='Wiki/Example/Sources/original.txt';p=self.root/self.source;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('Section A: synthetic fixture states the sample value is 7.\n')
  self.meta=dict(title='Synthetic fixture',creator=None,source_url=None,captured_at='2026-09-06T19:00:00-04:00',published_at=None,epistemic_status='test fixture')
  mm.rebuild(self.root);self.key=k.register(self.root,self.source,self.meta)['id']
 def outputs(self):
  seed='Wiki/Example/Seeds/example.md';page='Wiki/Example/Pages/example.md'
  for path,text in [(seed,'Example fixture\n[Original](../Sources/original.txt)\nEpistemic: synthetic fixture\nLoad when: testing example value\n'),(page,'# Example\n\nThe fixture reports value 7. [Original, Section A](../Sources/original.txt)\n')]:
   p=self.root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
  return dict(read_coverage='Synthetic fixture Section A; not an actual content review',retrieval_seed=seed,wiki_pages=[page],claim_evidence=[{'claim':'fixture value 7','source_location':'Section A'}],conflicts=[],open_issues=[])
 def test_x3_one_command_ingest_builds_evidence_from_inline_citations(self):
  self.outputs()
  r=k.ingest(self.root,self.source,self.meta,'Wiki/Example/Seeds/example.md',['Wiki/Example/Pages/example.md'],'Whole file (one line)')
  self.assertEqual('VERIFIED',r['status']);self.assertEqual(1,r['claims_cited'])
  ev=k.state(self.root)['items'][self.key]['evidence']
  self.assertIn('Section A',ev['claim_evidence'][0]['locator']);self.assertFalse(k.status(self.root)['pending'])
 def test_x3_ingest_keeps_checks_open_issue_and_missing_citation(self):
  self.outputs();page=self.root/'Wiki/Example/Pages/example.md'
  page.write_text(page.read_text()+'\n- Open issue: page 2 unreadable\n')
  r=k.ingest(self.root,self.source,self.meta,'Wiki/Example/Seeds/example.md',['Wiki/Example/Pages/example.md'],'Page 1 only')
  self.assertEqual('PROCESSING',r['status']);self.assertEqual('processing',k.status(self.root)['pending'][0]['status'])
  page.write_text('# Example\n\nNo citation here.\n')
  with self.assertRaisesRegex(ValueError,'cite the original'):
   k.ingest(self.root,self.source,self.meta,'Wiki/Example/Seeds/example.md',['Wiki/Example/Pages/example.md'],'Page 1')
  with self.assertRaisesRegex(ValueError,'--read'):
   k.ingest(self.root,self.source,self.meta,'Wiki/Example/Seeds/example.md',['Wiki/Example/Pages/example.md'],'')
 def test_x3_ingest_maps_brand_new_subject_files_itself(self):
  src='Wiki/Fresh/Sources/new.txt';seed='Wiki/Fresh/Seeds/new.md';page='Wiki/Fresh/Pages/new.md'
  for rel,text in [(src,'Section B: the answer is 9.\n'),(seed,'Fresh\n[Original](../Sources/new.txt)\nEpistemic: test\nLoad when: testing fresh\n'),(page,'# Fresh\n\nThe answer is 9. [Section B](../Sources/new.txt)\n')]:
   p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
  r=k.ingest(self.root,src,dict(self.meta,title='Fresh'),seed,[page],'Whole file')
  self.assertEqual('VERIFIED',r['status']);self.assertEqual('PASS',mm.verify(self.root)['status'])
 def test_x3_new_page_for_verified_source_is_checked_not_skipped(self):
  self.outputs();seed='Wiki/Example/Seeds/example.md';page='Wiki/Example/Pages/example.md'
  self.assertEqual('VERIFIED',k.ingest(self.root,self.source,self.meta,seed,[page],'Whole file')['status'])
  self.assertEqual('ALREADY_VERIFIED',k.ingest(self.root,self.source,self.meta,seed,[page],'Whole file')['status'])
  extra=self.root/'Wiki/Example/Pages/extra.md'
  extra.write_text('# Extra\n\nMore on value 7. [Section A](../Sources/original.txt)\n- Open issue: page 3 not read\n')
  mm.rebuild(self.root,['Wiki/Example/Pages/extra.md'])
  r=k.ingest(self.root,self.source,self.meta,seed,['Wiki/Example/Pages/extra.md'],'Section A')
  self.assertEqual('PROCESSING',r['status']);self.assertTrue(k.status(self.root)['pending'])
  extra.write_text('# Extra\n\nMore on value 7. [Section A](../Sources/original.txt)\n')
  r=k.ingest(self.root,self.source,self.meta,seed,['Wiki/Example/Pages/extra.md'],'Section A')
  self.assertEqual('VERIFIED',r['status'])
  self.assertEqual({page,'Wiki/Example/Pages/extra.md'},set(k.state(self.root)['items'][self.key]['evidence']['wiki_pages']))
 def test_end_to_end_and_duplicate(self):
  self.assertEqual('new',k.status(self.root)['pending'][0]['status'])
  k.begin(self.root,self.key);e=self.outputs();self.assertEqual('VERIFIED',k.commit(self.root,self.key,e)['status'])
  self.assertFalse(k.status(self.root)['pending']);self.assertEqual('PASS',mm.verify(self.root)['status'])
  self.assertEqual('EXISTS',k.register(self.root,self.source,self.meta)['status'])
  self.assertEqual('ALREADY_VERIFIED',k.begin(self.root,self.key)['status'])
 def test_unread_or_unfinished_stays_pending(self):
  e=self.outputs()
  with self.assertRaisesRegex(ValueError,'Begin'):k.commit(self.root,self.key,e)
  k.begin(self.root,self.key);e['open_issues']=['Unread pages']
  with self.assertRaisesRegex(ValueError,'Unresolved'):k.commit(self.root,self.key,e)
  self.assertEqual('processing',k.status(self.root)['pending'][0]['status'])
 def test_source_change_never_promoted(self):
  k.begin(self.root,self.key);e=self.outputs();(self.root/self.source).write_text('Changed original')
  with self.assertRaisesRegex(ValueError,'Source changed'):k.commit(self.root,self.key,e)
 def test_changed_verified_output_is_stale(self):
  k.begin(self.root,self.key);e=self.outputs();k.commit(self.root,self.key,e)
  p=self.root/e['wiki_pages'][0];p.write_text(p.read_text()+'Unreviewed change\n')
  self.assertEqual('stale',k.status(self.root)['pending'][0]['status'])
 def test_missing_direct_source_link_or_long_seed_rejected(self):
  k.begin(self.root,self.key);e=self.outputs();p=self.root/e['wiki_pages'][0];old=p.read_text();p.write_text('# No citation')
  with self.assertRaisesRegex(ValueError,'directly'):k.commit(self.root,self.key,e)
  p.write_text(old);p=self.root/e['retrieval_seed'];p.write_text(p.read_text()+'Sixth\nSeventh\n')
  with self.assertRaisesRegex(ValueError,'five'):k.commit(self.root,self.key,e)
 def test_map_failure_is_pending_and_can_resume(self):
  k.begin(self.root,self.key);e=self.outputs()
  with patch.object(mm,'rebuild',side_effect=ValueError('map failure')):
   with self.assertRaisesRegex(ValueError,'map failure'):k.commit(self.root,self.key,e)
  self.assertEqual('mapped_pending',k.status(self.root)['pending'][0]['status'])
  k.begin(self.root,self.key);self.assertEqual('VERIFIED',k.commit(self.root,self.key,e)['status'])
 def test_last_map_failure_not_reported_verified(self):
  k.begin(self.root,self.key);e=self.outputs();real=mm.rebuild;calls=0
  def failure(root,paths=None):
   nonlocal calls
   calls+=1
   if calls==2:
    raise ValueError('final map failure')
   return real(root,paths)
  with patch.object(mm,'rebuild',side_effect=failure):
   with self.assertRaisesRegex(ValueError,'final map'):k.commit(self.root,self.key,e)
  self.assertEqual('mapped_pending',k.status(self.root)['pending'][0]['status'])
 def test_add_ordinary_job_and_preserve_catalog_requirements(self):
  job=self.root/'Jobs/Journal'
  for rel in ['Products','Research','Seeds/Short-term','Seeds/Long-term']:(job/rel).mkdir(parents=True,exist_ok=True)
  (job/'JOB.md').write_text('# Journal\nExplicitly requested user job.\n')
  (job/'Seeds/README.md').write_text('# Journal continuity\n')
  mm.rebuild(self.root);result=mm.boot(self.root)
  self.assertEqual('SETUP_REVIEW_PENDING',result['status']);self.assertEqual(len(json.loads((self.root/'Brain/.mindmake/source-catalog.json').read_text())['sources'])+1,result['jobs'])
  catalog=self.root/'Brain/.mindmake/source-catalog.json';data=json.loads(catalog.read_text())
  data['sources'].append({'job':'Jobs/Unregistered LGI','sha256':{}});catalog.write_text(json.dumps(data))
  self.assertEqual('FAIL',mm.boot(self.root)['status'])
if __name__=='__main__':unittest.main(verbosity=2)
