"""Release boundary tests use synthetic reviewed packages; never touch releases."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
import zipfile

TOOL = Path(__file__).resolve().parents[1] / 'mindmake_release.py'
INPUTS = '''AGENTS.md MINDMAKE.md INTAKE.md GUARD.md Brain/governance/WORKSPACE_POLICY.md Brain/tools/mindmake.py Brain/tools/downloads_watch.py Brain/DOWNLOADS_WATCHER.md Brain/FIRST_WIN.md Brain/governance/FIRST_RUN_ACCEPTANCE.md Brain/WIKI_WORKFLOW.md Brain/tools/knowledge.py Brain/PERSONAL_ASSISTANT.md Brain/CAPABILITIES.md Brain/tools/assistant.py Brain/PERSONAL_MCP.md Brain/tools/personal_mcp.py Brain/MCP/personal_mcp_server.py Jobs/Demo/JOB.md Jobs/Demo/LGI_ENGINE_CONTRACT.md Jobs/Demo/Products/source.pdf'''.split()
BEGIN = '<!-- MINDMAKE FOLDER MAP BEGIN -->'
END = '<!-- MINDMAKE FOLDER MAP END -->'
def sha(data): return hashlib.sha256(data).hexdigest()
def enc(value): return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name).resolve()
        self.root = self.base/'reviewed'
        self.root.mkdir()
        if TOOL.exists():
            spec = importlib.util.spec_from_file_location('release_tool_test', TOOL)
            self.module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.module)
        else:
            self.module = None
        for rel in INPUTS: self.write(rel, 'reviewed content\n')
        self.write('Brain/tools/mindmake.py', '''import sys,json\nfrom pathlib import Path\nroot=Path(sys.argv[sys.argv.index('--root')+1])\nprint(json.dumps({'status':'READY_INTAKE_PENDING' if sys.argv[1]=='boot' else 'PASS','root':str(root),'errors':[]}))\n''')
        self.write('FOLDER_MAP.md', BEGIN+'\ngeneration-1\n'+END+'\n')
        self.write('Jobs/Demo/JOB.md', 'reviewed content\n'+BEGIN+'\ngeneration-1\n'+END+'\n')
        self.write_json('Brain/.mindmake/intake.json', {'answers':{}})
        self.write_json('Brain/.mindmake/assistant.json', {'enabled':False,'connections':{},'sms':{'consented':False,'recipient_sha256':None},'scheduler':{'status':'NOT_CONFIGURED','id':None,'last_success_at':None},'goals':[],'approved_sources':[],'routine_actions':[]})
        self.write_json('Brain/.mindmake/runtime.json', {'release':'MINDMAKE fixture'})
        self.write_json('Brain/.mindmake/source-catalog.json', {'sources':[{'job':'Jobs/Demo','selected_pdf':'Jobs/Demo/Products/source.pdf','sha256':{'Jobs/Demo/Products/source.pdf':sha((self.root/'Jobs/Demo/Products/source.pdf').read_bytes())}}]})
        for rel in ['Seeds/Short-term','Seeds/Long-term','Jobs/Demo/Research','Jobs/Demo/Seeds/Short-term','Jobs/Demo/Seeds/Long-term']: (self.root/rel).mkdir(parents=True,exist_ok=True)
        self.write_json('Brain/.mindmake/folder-map.json', {'generation_id':'generation-1','root_map':'FOLDER_MAP.md','project_maps':{'Jobs/Demo':'Jobs/Demo/JOB.md'},'specialist_maps':[],'inventory_path':'Brain/.mindmake/folder-inventory.json','map_hashes':{p:sha((self.root/p).read_bytes()) for p in ['FOLDER_MAP.md','Jobs/Demo/JOB.md']}})
        self.write_json('Brain/.mindmake/folder-inventory.json', {'generation_id':'generation-1','entries':[]})
        self.refresh_review()
        for rel in ['FOLDER_MAP.md','Jobs/Demo/JOB.md','Brain/.mindmake/folder-map.json','Brain/.mindmake/folder-inventory.json']: self.write('Brain/.mindmake/map-history/generation-1/committed/'+rel,(self.root/rel).read_bytes())

    def write(self, rel, data):
        path=self.root/rel; path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data if isinstance(data,bytes) else data.encode())
    def write_json(self,rel,value): self.write(rel,enc(value))
    def refresh_review(self):
        hashes={}
        for rel in sorted(set(INPUTS) | {p.relative_to(self.root).as_posix() for p in (self.root/'Jobs/Demo/Skills').glob('*/SKILL.md')}):
            data=(self.root/rel).read_bytes()
            if rel.endswith('/JOB.md'):
                text=data.decode(); data=(text[:text.index(BEGIN)]+text[text.index(END)+len(END):]).strip().encode()
            hashes[rel]=sha(data)
        self.write('Brain/governance/setup-reviews/demo.md','review evidence\n')
        self.write_json('Brain/.mindmake/setup-review.json', {'schema_version':1,'records':{'Jobs/Demo':{'fingerprint':sha(enc(hashes)),'reviewed_at':'2026-09-14','evidence':'Brain/governance/setup-reviews/demo.md','evidence_sha256':sha(b'review evidence\n')}}})
    def build(self,name='result.zip',**kwargs):
        self.assertIsNotNone(self.module, 'Reusable release tool is missing')
        return self.module.package(self.root,self.base/name,'MindMake fixture',**kwargs)
    def rejected(self,**kwargs):
        self.assertIsNotNone(self.module, 'Reusable release tool is missing')
        with self.assertRaises((ValueError,OSError)): self.build(**kwargs)
        self.assertFalse((self.base/'result.zip').exists())

    def test_deterministic_archive_manifest_and_empty_directories(self):
        first=self.build(); second=self.build('second.zip')
        self.assertEqual((self.base/'result.zip').read_bytes(),(self.base/'second.zip').read_bytes())
        self.assertEqual(first,second)
        self.assertEqual(json.loads((self.base/'result.manifest.json').read_text()),first)
        self.assertEqual(first['archive_sha256'],sha((self.base/'result.zip').read_bytes()))
        inventory={p.relative_to(self.root).as_posix():sha(p.read_bytes()) if p.is_file() else None for p in self.root.rglob('*')}
        self.assertEqual(first['source_tree_sha256'],sha(enc(dict(sorted(inventory.items())))))
        with zipfile.ZipFile(self.base/'result.zip') as z:
            self.assertIn('MindMake fixture/Jobs/Demo/Research/',z.namelist())
            self.assertIn('MindMake fixture/Brain/.mindmake/map-history/generation-1/committed/FOLDER_MAP.md',z.namelist())
            self.assertEqual(len(z.namelist()),len(set(z.namelist())))
        self.assertEqual(first['verification'],'STATIC_ONLY')
    def test_excludes_runtime_history_sidecars_and_caches(self):
        for rel in ['Brain/.mindmake/assistant-state/tasks.sqlite3','Brain/.mindmake/repair-history/old','Brain/.mindmake/map-history/old/committed/a','Brain/.mindmake/map-history/generation-1/preimage','Brain/.mindmake/personal-mcp-runtime/server','Brain/.mindmake/downloads-watch/state','__pycache__/x.pyc','._hidden','.DS_Store','_old-release/file']: self.write(rel,'excluded')
        result=self.build()
        self.assertFalse(any(any(t in p for t in ('sqlite3','repair-history','preimage','/old/','__pycache__','._','_old-release')) for p in result['files']))
    def test_new_personal_record_stores_excluded(self):
        for base in ('Brain/.mindmake/work-records','Brain/.mindmake/corrections','.mindmake/work-records','.mindmake/corrections','reports'):
            self.write(base+'/private.json','personal sample')
        result=self.build()
        self.assertFalse(any('private.json' in p for p in result['files']))
    def test_new_work_helper_invalidates_old_review(self):
        self.write('Brain/tools/mindmake_work.py','new behavior')
        self.rejected()
    def test_seed_memory_private_state_excluded(self):
        self.assertFalse(self.module.included('Brain/.mindmake/seed-memory/notes.json','generation'))

    def test_seed_memory_helper_is_fingerprint_bound(self):
        self.write('Brain/tools/mindmake_seed_memory.py','original')
        item=json.loads((self.root/'Brain/.mindmake/source-catalog.json').read_text())['sources'][0]
        before=self.module.fingerprint(self.root,item)
        self.write('Brain/tools/mindmake_seed_memory.py','changed')
        self.assertNotEqual(before,self.module.fingerprint(self.root,item))

    def test_compact_review_shared_runtime_is_fingerprint_bound(self):
        self.write('Brain/tools/mindmake_review.py','review')
        self.write('Brain/SKILLS.md','catalog')
        self.write('Brain/skills/mindmake-workspace/SKILL.md','workflow')
        self.write('Brain/governance/RUNTIME.md','before')
        item=json.loads((self.root/'Brain/.mindmake/source-catalog.json').read_text())['sources'][0]
        before=self.module.fingerprint(self.root,item)
        self.write('Brain/governance/RUNTIME.md','after')
        self.assertNotEqual(before,self.module.fingerprint(self.root,item))
    def test_catalog_tamper_fails(self): self.write('Jobs/Demo/Products/source.pdf','changed'); self.rejected()
    def test_stale_review_fails(self): self.write('GUARD.md','changed'); self.rejected()
    def test_evidence_tamper_fails(self): self.write('Brain/governance/setup-reviews/demo.md','changed'); self.rejected()
    def test_review_evidence_must_be_markdown(self):
        self.write('Brain/governance/setup-reviews/demo.tmp','review evidence\n')
        p=self.root/'Brain/.mindmake/setup-review.json'; data=json.loads(p.read_text())
        data['records']['Jobs/Demo']['evidence']='Brain/governance/setup-reviews/demo.tmp'
        self.write_json(str(p.relative_to(self.root)),data); self.rejected()
    def test_review_evidence_must_survive_exclusions(self):
        self.write('Brain/governance/setup-reviews/__pycache__/demo.md','review evidence\n')
        p=self.root/'Brain/.mindmake/setup-review.json'; data=json.loads(p.read_text())
        data['records']['Jobs/Demo']['evidence']='Brain/governance/setup-reviews/__pycache__/demo.md'
        self.write_json(str(p.relative_to(self.root)),data); self.rejected()
    def test_review_fingerprint_inputs_must_survive_exclusions(self):
        self.write('Jobs/Demo/Skills/__pycache__/SKILL.md','reviewed skill')
        self.refresh_review(); self.rejected()
    def test_current_map_dependencies_must_survive_exclusions(self):
        rel='Brain/.mindmake/folder-map.json'; data=json.loads((self.root/rel).read_text())
        old=data['root_map']; new='generated/FOLDER_MAP.md'
        self.write(new,(self.root/old).read_bytes())
        data['root_map']=new; data['map_hashes'][new]=data['map_hashes'].pop(old)
        self.write_json(rel,data)
        self.write('Brain/.mindmake/map-history/generation-1/committed/'+new,(self.root/new).read_bytes())
        self.write('Brain/.mindmake/map-history/generation-1/committed/'+rel,(self.root/rel).read_bytes())
        self.rejected()
    def test_catalog_requires_selected_pdf(self):
        p=self.root/'Brain/.mindmake/source-catalog.json'; data=json.loads(p.read_text())
        del data['sources'][0]['selected_pdf']
        self.write_json(str(p.relative_to(self.root)),data); self.rejected()
    def test_selected_pdf_must_have_a_catalog_hash(self):
        self.write('Jobs/Demo/Products/unregistered.pdf','different publication')
        p=self.root/'Brain/.mindmake/source-catalog.json'; data=json.loads(p.read_text())
        data['sources'][0]['selected_pdf']='Jobs/Demo/Products/unregistered.pdf'
        self.write_json(str(p.relative_to(self.root)),data); self.rejected()
    def test_selected_pdf_must_exist(self):
        (self.root/'Jobs/Demo/Products/source.pdf').unlink(); self.rejected()
    def test_selected_pdf_rejects_traversal(self):
        p=self.root/'Brain/.mindmake/source-catalog.json'; data=json.loads(p.read_text())
        data['sources'][0]['selected_pdf']='../external.pdf'
        self.write_json(str(p.relative_to(self.root)),data); self.rejected()
    def test_nonempty_intake_fails(self): self.write_json('Brain/.mindmake/intake.json',{'answers':{'name':'someone'}}); self.rejected()
    def test_enabled_services_fail(self): self.write_json('Brain/.mindmake/assistant.json',{'enabled':True}); self.rejected()
    def test_personal_connection_fails(self):
        p=self.root/'Brain/.mindmake/assistant.json'; x=json.loads(p.read_text()); x['connections']={'phone':{}}; self.write_json(str(p.relative_to(self.root)),x); self.rejected()
    def test_missing_required_helper_fails(self): self.rejected(required_helpers=['Brain/tools/new_helper.py'])
    def test_missing_current_recovery_snapshot_fails(self): shutil.rmtree(self.root/'Brain/.mindmake/map-history'); self.rejected()
    def test_pending_transaction_fails(self): self.write('Brain/.mindmake/folder-map.pending.json','{}'); self.rejected()
    def test_existing_archive_never_overwritten(self):
        p=self.base/'result.zip'; p.write_bytes(b'preserve'); self.assertIsNotNone(self.module)
        with self.assertRaises((ValueError,OSError)): self.build()
        self.assertEqual(p.read_bytes(),b'preserve')
    def test_existing_manifest_never_overwritten(self): (self.base/'result.manifest.json').write_text('preserve'); self.rejected()
    def test_source_self_inclusion_fails(self): self.rejected(name='reviewed/new.zip')
    def test_symlink_source_and_output_aliases_fail(self):
        (self.base/'alias').symlink_to(self.root,target_is_directory=True); self.assertIsNotNone(self.module)
        with self.assertRaises((ValueError,OSError)): self.module.package(self.base/'alias',self.base/'result.zip','fixture')
        self.rejected(name='alias/result.zip')
    def test_symlinks_even_in_excluded_state_fail(self):
        (self.root/'__pycache__').mkdir(); (self.root/'__pycache__/escape').symlink_to(self.base/'outside'); self.rejected()
    def test_hardlinked_source_fails(self):
        os.link(self.root/'GUARD.md',self.root/'alias.md'); self.rejected()
    def test_traversal_labels_fail(self):
        self.assertIsNotNone(self.module)
        for label in ['../outside','/absolute','a/b','a\\b','C:drive','..','', 'name.']:
            with self.subTest(label=label), self.assertRaises((ValueError,OSError)): self.module.package(self.root,self.base/'result.zip',label)
    def test_portable_names_reject_dot_and_windows_metacharacters(self):
        self.assertIsNotNone(self.module)
        for value in ['.','file?.txt','file*.txt','name|pipe','name<angle','name>angle','name"quote']:
            with self.subTest(value=value), self.assertRaises(ValueError): self.module.safe_relative(value)
    def test_catalog_traversal_fails(self):
        self.write_json('Brain/.mindmake/source-catalog.json',{'sources':[{'job':'Jobs/Demo','sha256':{'../outside':'0'*64}}]}); self.rejected()
    def test_no_package_code_execution_by_default(self):
        self.write('Brain/tools/mindmake.py','raise RuntimeError("must not execute")\n'); self.refresh_review(); self.build()
        self.assertFalse(list(self.root.rglob('__pycache__')))
    def test_opt_in_relocated_boot_is_readonly(self):
        before={str(p.relative_to(self.root)):sha(p.read_bytes()) for p in self.root.rglob('*') if p.is_file()}
        result=self.build(verify_package_code=True)
        self.assertEqual(result['verification'],'RELOCATED_BOOT_AND_MAP_PASS')
        self.assertEqual([x['status'] for x in result['checks']],['READY_INTAKE_PENDING','PASS'])
        after={str(p.relative_to(self.root)):sha(p.read_bytes()) for p in self.root.rglob('*') if p.is_file()}
        self.assertEqual(before,after)
    def test_opt_in_detects_helper_writes(self):
        self.write('Brain/tools/mindmake.py', 'import sys,json\nfrom pathlib import Path\nroot=Path(sys.argv[sys.argv.index("--root")+1])\nPath(__file__).with_name("changed").write_text("bad")\nprint(json.dumps({"status":"READY_INTAKE_PENDING","root":str(root),"errors":[]}))\n'); self.refresh_review(); self.rejected(verify_package_code=True)

if __name__=='__main__': unittest.main()
