-- Single make Apple event with initial properties. Caller records attempting
-- durably before invocation and never automatically retries an uncertain result.
use framework "Foundation"
on run argv
    if (count of argv) is not 4 then error "Invalid reminder arguments"
    set listName to item 1 of argv
    set markerText to item 2 of argv
    set titleText to item 3 of argv
    if listName is not "MindMake" then error "Invalid list scope"
    if markerText does not start with "mindmake:" then error "Invalid marker"
    if (length of titleText) < 1 or (length of titleText) > 120 then error "Invalid title"
    set alertDate to (current application's NSDate's dateWithTimeIntervalSince1970:((item 4 of argv) as real)) as date
    tell application "Reminders"
        set selectedAccounts to every account whose name is "iCloud"
        if (count of selectedAccounts) is not 1 then error "Ambiguous iCloud account"
        set selectedAccount to item 1 of selectedAccounts
        set selectedLists to every list of selectedAccount whose name is listName
        if (count of selectedLists) is not 1 then error "Missing or ambiguous MindMake list"
        set selectedList to item 1 of selectedLists
        set existingItems to every reminder of selectedList whose body is markerText
        if (count of existingItems) is not 0 then error "Existing reminder requires reconciliation"
        set createdItem to make new reminder at end of reminders of selectedList with properties {name:titleText, body:markerText, due date:alertDate, remind me date:alertDate}
        return id of createdItem
    end tell
end run
