# Seed Memory Protocol 1

Purpose: consult relevant saved decisions during work and preserve consequential changes before they are lost. A seed on disk, a startup list and a successful tool call are different facts. No receipt proves comprehension.

## When to read

At the start of substantive project work, on a task or scope change, after recovery/compaction, and before saying prior information cannot be found, run a seed-memory check with the exact conversation ID, a stable event ID, a short task ID, explicit scope and topic query. A new conversation gets a new ID. Do not use shared names such as default, codex or claude. Keep IDs through recovery; if lost, declare earlier coverage unavailable and start a new ID.

Read the returned relevant seed content before dependent decisions. Search both the scoped Short-term and Long-term pools; older relevant decisions may outrank newer unrelated notes. Superseding corrections must be reconciled. A missing match means refine the query and check the relevant map/source; it does not mean the information does not exist. Omitted matches, malformed metadata and uncertain replacements remain visible and require scoped follow-up. Preserve source/owner locks; a retrieved seed does not authorize its historical next steps.

During ongoing work, perform a brief check before each substantive response: are the task/scope and governing seed evidence still current, and did consequential work occur? Reuse unchanged content already read in the current context. Do not reread every seed every turn. A new task or recovery requires a new check and current-context read. A normal chat aside does not require a new seed.

## When to save

Save immediately after a consequential decision, correction, completed work, changed blocker, or a handoff/recovery that changes what a successor must do. At meaningful turn end, report unsaved changes through the check's meaningful flag, write a concise seed using the existing authorized filesystem workflow, reopen it and verify its hash, then record which pending change IDs it covers. Persist the decision, relevant source, remaining uncertainty and exact next action. Save job work in that job's pool; cross-job architecture in the general pool.

Report the meaningful change before writing its seed: the helper snapshots current seed hashes at that check. A save must have new bytes or a new path relative to each covered change's snapshot. Never clear all pending changes because one seed exists, and never reuse an unchanged old seed to clear new work. A save receipt names only the changes actually represented. A change arriving during a save stays pending until covered. Empty or unrelated filler does not count. Saved byte verification is observable; the assistant's assertion that the prose covers a decision still requires substantive review. Original seeds remain append-only. New corrections reference exact predecessors; do not overwrite prior seeds to make the history look clean.

This event-based rule replaces conflicting 15,000-word, 250K-token or fixed per-thread cap rules **for required continuity saves** in the installed workflow. Do not wait for a distant checkpoint or suppress a consequential save because an old cap was reached. Consolidate related changes concisely and avoid duplicate/filler seeds. Time alone is not a reason to invent a memory. Other governance rules and bounded retrieval remain in force.

## Existing tool path and fallback

When the connected Pulse MCP exposes memory_check, memory_read, memory_saved and memory_status, use them. Existing session_turn/session_status responses include a compact seed reminder in the updated server. The optional packaged personal MCP exposes equivalent mindmake_memory_* tools under its existing opt-in. Do not enable a customer connection without consent. No new schedule, background agent or third-party service is required.

If the host still has older MCP handlers or has no MCP, use the same local helper. Canonical Cartographer runs `python3 -B tools/mindmake_seed_memory.py`; an extracted MindMake package runs `python3 -B Brain/tools/mindmake_seed_memory.py`. Supply `--root` with the already verified workspace. Do not redirect a customer installation to the authoring machine.

Example using nonprivate opaque IDs and an existing project (substitute actual IDs, paths and the SHA-256 returned by the check):

```sh
python3 -B tools/mindmake_seed_memory.py --root "$PWD" check --stream THREAD_ID --event TURN_1_BEGIN --task launch --scope Jobs/Book --query 'launch approval' --reason start
python3 -B tools/mindmake_seed_memory.py --root "$PWD" read --stream THREAD_ID --event TURN_1_READ --path Jobs/Book/Seeds/Short-term/SEED.md --sha256 CURRENT_HASH
python3 -B tools/mindmake_seed_memory.py --root "$PWD" check --stream THREAD_ID --event TURN_1_END --task launch --scope Jobs/Book --query 'launch approval' --reason end --meaningful
python3 -B tools/mindmake_seed_memory.py --root "$PWD" save --stream THREAD_ID --event TURN_1_SAVED --path Jobs/Book/Seeds/Short-term/NEW_SEED.md --sha256 SAVED_HASH --covers TURN_1_END
```

The save command verifies a file that was already written; it does not write the seed. Use a distinct event ID for each check/read/save and reuse it only when retrying the identical operation. Event counts count submitted checks, not measured human turns. Per-thread state belongs in .mindmake/seed-memory or Brain/.mindmake/seed-memory and is excluded from customer ZIPs.

## Honest states and recovery

- UNCOUNTED: no submitted check for this exact conversation. Never label it healthy.
- READ_REQUIRED: current candidates have not all been returned in this task/context epoch.
- CONTENT_RETURNED: the helper prepared its response with current candidate bytes; client delivery is unverified. The assistant must still read and apply them; comprehension is unverified.
- NO_MATCH: no match in the bounded selected scope/query, not a global absence claim.
- RECONCILIATION_REQUIRED: metadata/history needs review, including partial corrections or inactive replacements. Read original relevant history through the existing scoped source workflow; returned current candidates alone cannot clear this state.
- SAVE_REQUIRED: a reported consequential change has no current verified covering seed.
- SAVED_BYTES_VERIFIED: recorded covering files still match; semantic completeness remains an attributed assertion.
- NO_REPORTED_CHANGES: no meaningful-change report, not proof nothing happened.
- UNAVAILABLE: scope, storage, identity or metadata could not be checked. Preserve evidence and use scoped manual retrieval; never fabricate receipts.

Existing MCP processes can retain old code until their own connection restarts. Verify the actual tools and returned protocol before claiming live integration. Never restart unrelated threads or apps to hide a deployment gap. Direct shell calls and hosts that bypass this protocol remain unobserved. A reminder returned only when called cannot guarantee every thread remembers; use actual invocation evidence and a relevant-seed recovery test to assess the host.

## Acceptance

Test an older relevant decision among newer irrelevant seeds, task change/resume, a superseding correction, missing/changed files, unsaved changes across restart, retry deduplication, concurrent distinct threads, and uncalled/bypassed coverage. Separately observe a fresh assistant retrieve the decision and state the correct next action without the user supplying it again. Tests of bytes and counters do not substitute for that behavioral check.
