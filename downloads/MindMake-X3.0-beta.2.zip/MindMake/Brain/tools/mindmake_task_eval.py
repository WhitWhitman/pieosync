#!/usr/bin/env python3
"""Repeatable fixture checks and strictly scored, recorded blind task decisions."""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

from mindmake_local import resolve_root

ROOT = Path(__file__).resolve().parents[2]
SCOPED_FILES = (
    'Brain/tools/mindmake_task_eval.py', 'Brain/tools/task-eval-cases.json',
    'Brain/tools/tests/test_task_eval.py', 'Brain/tools/TASK_EVAL.md',
    'Brain/tools/mindmake_local.py', 'Brain/tools/mindmake_review.py',
    'Brain/PERSONAL_ASSISTANT.md', 'Brain/tools/FOLLOW_THROUGH.md',
    'Brain/tools/WORKFLOW_IMPROVEMENT.md', 'Brain/governance/RUNTIME.md',
    'Brain/skills/mindmake-workspace/SKILL.md', 'Brain/SKILLS.md',
    'Brain/governance/WORKSPACE_POLICY.md', 'GUARD.md', 'AGENTS.md', 'MINDMAKE.md',
    '.mindmake-home',
)


def digest(path):
    if any(p.is_symlink() for p in (path, *path.parents)) or not path.is_file():
        raise ValueError('Required provenance file unavailable or symlink: ' + str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def corpus():
    data = json.loads((ROOT / 'Brain/tools/task-eval-cases.json').read_text())
    ids = set()
    if data.get('schema_version') != 1 or not 4 <= len(data['cases']) <= 6:
        raise ValueError('Invalid task corpus')
    for case in data['cases']:
        if case['id'] in ids or case['expected'] not in case['choices']:
            raise ValueError('Invalid or duplicate corpus case')
        ids.add(case['id'])
    return data


def engine():
    root = resolve_root(ROOT)
    if root != ROOT:
        raise ValueError('Helper must reside in package authority')
    path = root / 'Brain/tools'
    pins = {name: digest(path / name) for name in
            ('assistant.py', 'mindmake.py', 'apple_reminders.py', 'apple_reminders.jxa', 'apple_reminders.applescript')}
    return path, pins


def provenance(model):
    if not isinstance(model, dict) or set(model) != {'identity', 'revision', 'host'} or any(not isinstance(v, str) or not v.strip() for v in model.values()):
        raise ValueError('Model identity, revision and host required; use explicit unknown when unavailable')
    path, pins = engine()
    hashes = {name: digest(ROOT / name) for name in SCOPED_FILES}
    hashes.update({'engine/' + name: value for name, value in pins.items()})
    return {'schema_version': 1, 'model': model, 'model_revision_known': model['revision'].lower() != 'unknown',
            'model_provenance_kind': 'operator reported; not independently attested',
            'engine_path': str(path.relative_to(ROOT)), 'hashes': hashes}


def packet(model):
    prov = provenance(model)
    return {'schema_version': 1, 'fingerprint': fingerprint(prov), 'provenance': prov,
            'instructions': 'Use only this packet. For every case choose one choice key and explain your decision. Return JSON with fingerprint, model copied from provenance, and observations: [{id, decision, rationale}]. Do not read the corpus, implementation, tests or answer key. These are recorded decisions, not commands to perform side effects.',
            'cases': [{key: value for key, value in c.items() if key != 'expected'} for c in corpus()['cases']]}


def score(observed, model):
    current = packet(model)
    result = {'status': 'FAIL', 'fingerprint': current['fingerprint'], 'model': model,
              'scope': 'Recorded task decision observations only; no automatic model execution, general reliability, model equivalence or live phone acceptance claim.', 'errors': [], 'checks': []}
    if not isinstance(observed, dict):
        result['errors'].append('Observation document must be an object'); return result
    if observed.get('fingerprint') != current['fingerprint'] or observed.get('model') != model:
        result['status'] = 'STALE'; result['errors'].append('Corpus, implementation, skill, engine or model provenance differs'); return result
    rows = observed.get('observations')
    if not isinstance(rows, list):
        result['errors'].append('Observations must be a list'); return result
    expected = {c['id']: c for c in corpus()['cases']}
    seen = set()
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'id', 'decision', 'rationale'} or not isinstance(row.get('id'), str):
            result['errors'].append('Invalid observation schema'); continue
        key = row['id']
        if key not in expected or key in seen:
            result['errors'].append('Unknown or duplicate observation: ' + key); continue
        seen.add(key)
        valid = isinstance(row['decision'], str) and row['decision'] in expected[key]['choices'] and isinstance(row['rationale'], str) and bool(row['rationale'].strip())
        result['checks'].append({'id': key, 'passed': valid and row['decision'] == expected[key]['expected']})
    if seen != set(expected): result['errors'].append('Missing required observations')
    if not result['errors'] and all(c['passed'] for c in result['checks']): result['status'] = 'PASS'
    return result


# This code only receives a fresh TemporaryDirectory and a previously verified engine.
# NativeReminders is never constructed: an explicit in-memory transport is passed.
PHONE_FIXTURE = r'''
import json, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
import assistant as a
import apple_reminders as p
root=Path(sys.argv[2]); a.configure_layout(root)
class Simulated:
    def __init__(self): self.rows=[]; self.calls=0
    def inspect(self,*args): self.calls+=1; return {'status':'READY'}
    def list_owned(self,*args): self.calls+=1; return [dict(r) for r in self.rows]
    def create(self,list_name,marker,when,title):
        self.calls+=1; row=dict(id='fixture-'+str(len(self.rows)),marker=marker,when=when,completed=False); self.rows.append(row); return dict(row)
    def update(self,*args): raise AssertionError('Unexpected simulated update')
s=Simulated()
p.enroll(root,'phone','2099-09-15T16:00:00+00:00')
first=p.sync(root,transport=s)
s.rows[0]['completed']=True
second=p.sync(root,transport=s)
third=p.sync(root,transport=s)
with a.database(root) as db: done_count=db.execute("SELECT count(*) FROM events WHERE action_id='phone' AND kind='done'").fetchone()[0]
checks=[dict(id='reminder_import_once',passed=next(r for r in a.actions(root) if r['id']=='phone')['status']=='done' and done_count==1 and len(s.rows)==1,done_events=done_count,simulated_reminders=len(s.rows),sync_statuses=[first['status'],second['status'],third['status']])]
a.capture(root,'conflict','Resolve reminder time','TASK.md',owner='Fixture owner')
p.enroll(root,'conflict','2099-09-15T16:00:00+00:00')
p.sync(root,transport=s)
a.change(root,'conflict','snooze',until='2099-09-16T16:00:00+00:00')
# Find by marker through actual link state; mutate only simulated remote data.
with a.database(root) as db: marker=db.execute("SELECT marker FROM apple_links WHERE action_id='conflict'").fetchone()[0]
for r in s.rows:
    if r['marker']==marker: r['when']='2099-09-17T16:00:00+00:00'
conflict=p.sync(root,transport=s)
checks.append(dict(id='reminder_conflict',passed=any(r['id']=='conflict' and r['state']=='conflict' for r in conflict['results']),sync_result=conflict))
a.pause(root); before=s.calls
paused=p.sync(root,transport=s); again=p.sync(root,transport=s)
checks.append(dict(id='paused',passed=paused['status']=='PAUSED' and again==paused and s.calls==before,transport_calls_while_paused=s.calls-before,sync_status=paused['status']))
print(json.dumps(checks))
'''


def run_fixtures():
    path, pins = engine()
    def call(root, *args):
        result = subprocess.run([sys.executable, '-B', str(path / 'assistant.py'), '--root', str(root), *args], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=30)
        return result.returncode, json.loads(result.stdout)
    checks = []
    with tempfile.TemporaryDirectory(prefix='mindmake-task-eval-') as tmp:
        root = Path(tmp); (root / 'Brain/.mindmake').mkdir(parents=True)
        (root / '.mindmake-home').write_text('.\n')
        # Package pause refreshes local maps; build only disposable fixture maps.
        (root / 'Brain/.mindmake/folder-map.json').write_text(json.dumps({'root_map':'FOLDER_MAP.md','project_maps':{},'generation_id':'fixture-initial'}))
        for relative in ('FOLDER_MAP.md','Jobs/INDEX.md','Seeds/SEEDS_MAP.md','Seeds/Index/seed-index.md'):
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text('# Temporary evaluation map\n')
        (root / 'Brain/.mindmake/assistant.json').write_text(json.dumps({'schema_version': 1, 'enabled': True, 'timezone': 'UTC', 'quiet_hours': {'start': '21:00', 'end': '09:00'}, 'max_sms_per_day': 1, 'sms': {'consented': False}, 'apple_reminders': {'enabled': True, 'list_name': 'MindMake', 'workspace_id': '00000000-0000-4000-8000-000000000001'}}))
        source = root / 'TASK.md'; source.write_text('Owner Fixture owner. Confirm phone alert; Mac creation is not phone acceptance.\n')
        captured = call(root, 'capture', 'restart', '--step', 'Confirm phone alert', '--source', 'TASK.md', '--project', 'Example project', '--owner', 'Fixture owner')
        restarted = call(root, 'actions')
        row = restarted[1][0]
        checks.append({'id': 'restart', 'passed': captured[0] == 0 and restarted[0] == 0 and row['status'] == 'open' and row['owner'] == 'Fixture owner' and row['step'] == 'Confirm phone alert' and row['project'] == 'Example project', 'evidence': {k: row[k] for k in ('status','owner','step','project')}})
        repeated = call(root, 'capture', 'restart', '--step', 'Confirm phone alert', '--source', 'TASK.md', '--project', 'Example project', '--owner', 'Fixture owner')
        checks.append({'id': 'capture_idempotency', 'passed': repeated[0] == 0 and repeated[1]['status'] == 'UNCHANGED' and len(call(root, 'actions')[1]) == 1, 'repeat_result': repeated[1], 'action_count': len(call(root, 'actions')[1])})
        source.write_text(source.read_text() + 'Playback and owner acceptance also remain unresolved.\n')
        refused = call(root, 'review', 'restart', '--expected-source-sha256', row['source_hash'], '--outcome', 'done', '--note', 'Old source claims completion')
        checks.append({'id': 'source_drift', 'passed': refused[0] != 0 and call(root, 'actions')[1][0]['status'] == 'open', 'review_result': refused[1]})
        call(root, 'capture', 'phone', '--step', 'Simulated reminder completion', '--source', 'TASK.md', '--owner', 'Fixture owner')
        run = subprocess.run([sys.executable, '-B', '-c', PHONE_FIXTURE, str(path), str(root)], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=30)
        if run.returncode:
            raise ValueError('Simulated reminder fixture failed: ' + run.stderr[-2000:])
        checks.extend(json.loads(run.stdout))
    return {'status': 'PASS' if all(c['passed'] for c in checks) else 'FAIL', 'checks': checks, 'engine_hashes': pins,
            'scope': 'Real helper functions/CLI in temporary fixtures; reminder adapter simulated in memory; fresh process is not fresh model context.',
            'live_phone_acceptance': 'UNTESTED', 'model_outcomes': 'UNTESTED'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['run', 'packet', 'score'])
    p.add_argument('--model', required=True); p.add_argument('--revision', required=True); p.add_argument('--host', required=True)
    p.add_argument('--observations', type=Path)
    args = p.parse_args()
    model = {'identity': args.model, 'revision': args.revision, 'host': args.host}
    try:
        if args.command == 'packet': result = packet(model)
        elif args.command == 'score':
            if not args.observations: raise ValueError('score requires --observations')
            result = score(json.loads(args.observations.read_text()), model)
        else:
            before = provenance(model)
            result = run_fixtures()
            if provenance(model) != before: raise ValueError('Inputs changed during fixture execution')
            result.update(provenance=before, fingerprint=fingerprint(before), recorded_at=dt.datetime.now(dt.timezone.utc).isoformat())
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0 if result.get('status', 'PASS') == 'PASS' else 1
    except (ValueError, KeyError, OSError, TypeError, subprocess.SubprocessError) as exc:
        print(json.dumps({'status': 'UNAVAILABLE', 'error': str(exc)})); return 1


if __name__ == '__main__': raise SystemExit(main())
