#!/usr/bin/env python3
"""Prepare blind skill-choice probes and score recorded choices; not a runtime router."""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse,hashlib,json,re
from urllib.parse import unquote
from pathlib import Path
from mindmake_local import resolve_root
CASES=Path(__file__).with_name('skill-routing-cases.json')

def load_cases():
    return json.loads(CASES.read_text())['cases']

def fingerprint(root):
    data=(Path(root)/'Brain/SKILLS.md').read_bytes()+b'\0'+CASES.read_bytes()
    return hashlib.sha256(data).hexdigest()

def descriptions(root):
    root=Path(root)
    catalog=root/'Brain/SKILLS.md'
    text=catalog.read_text();rows=[]
    def location(link):
        # Catalog links are relative to Brain, and legitimately start ../Jobs.
        raw=unquote(link.strip('<>'))
        p=catalog.parent/raw
        if any(part.is_symlink() for part in (p,*p.parents)):
            raise ValueError('Symbolic skill wrapper refused')
        normalized=p.resolve()
        if not normalized.is_relative_to(root.resolve()):
            raise ValueError('Skill wrapper escaped this package')
        rel=normalized.relative_to(root.resolve())
        from mindmake_corrections import safe
        safe(root,str(rel))
        return str(rel)
    for m in re.finditer(r'^### ([^\n]+)\n(.*?)(?=^#{2,3} |\Z)',text,re.M|re.S):
        body=m[2]
        trigger=re.search(r'^- Triggers?: (.+)$',body,re.M)
        wrapper=re.search(r'^- Wrapper: \[[^\]]+\]\((<[^>]+>|[^)]+)\)',body,re.M)
        if trigger and wrapper:
            rows.append({'name':m[1].strip(),'description':trigger[1].strip(),'location':location(wrapper[1])})
    for m in re.finditer(r'^- \[([^\]]+)\]\((<[^>]+>|[^)]+)\): (.+)$',text,re.M):
        if m[2].strip('<>').endswith('/SKILL.md'):
            rows.append({'name':m[1],'description':m[3],'location':location(m[2])})
    if not rows or len({r['name'] for r in rows})!=len(rows):
        raise ValueError('Empty or duplicate package skill catalog')
    return rows

def packet(root):
    return {'schema':1,'fingerprint':fingerprint(root),'instructions':'For each request choose the primary task skill from this catalog, or [] for no task skill. Governance may still apply. Do not execute the requested work. Return observed choices, not guesses about a hidden answer key. This tests selection, not actual host tool invocation or task completion.','skills':descriptions(root),'cases':[{'id':x['id'],'prompt':x['prompt']} for x in load_cases()]}

def score(cases,observations,expected_hash,current_hash):
    if expected_hash!=current_hash:return {'status':'STALE','reason':'Descriptions or probe criteria changed; rerun'}
    if not isinstance(observations,list):raise ValueError('Observations must be a list')
    by_id={c['id']:c for c in cases};got={}
    if len(by_id)!=len(cases):raise ValueError('Duplicate expected case')
    for row in observations:
        if not isinstance(row,dict) or set(row)!={'id','selected'} or not isinstance(row.get('id'),str):raise ValueError('Invalid observation schema')
        id=row['id'];selection=row['selected']
        if id not in by_id or id in got:raise ValueError('Unknown or duplicate observation')
        if not isinstance(selection,list) or not all(isinstance(x,str) for x in selection) or len(selection)!=len(set(selection)):raise ValueError('Selected must be unique skill names')
        got[id]=selection
    results=[{'id':id,'passed':set(got[id])==set(c['expected']),'selected':got[id],'expected':c['expected']} for id,c in by_id.items() if id in got]
    missing=sorted(set(by_id)-set(got));failed=[x['id'] for x in results if not x['passed']]
    return {'status':'INCOMPLETE' if missing else ('FAIL' if failed else 'PASS'),'passed':len(results)-len(failed),'total':len(cases),'missing':missing,'failed':failed,'results':results,'scope':'Recorded model skill choices; not live host invocation, task quality or cross-model equivalence'}

def audit(root):
    rows=descriptions(root);exact={};overlaps=[]
    for row in rows:
        for phrase in re.findall(r'[`\"]([^`\"]+)[`\"]',row['description']):exact.setdefault(phrase.casefold(),[]).append(row['name'])
    for phrase,names in exact.items():
        if len(set(names))>1:overlaps.append({'trigger':phrase,'skills':sorted(set(names))})
    missing=[r['location'] for r in rows if not (Path(root)/r['location']).is_file()]
    return {'skills':len(rows),'exact_trigger_overlaps':overlaps,'missing_paths':missing,'scope':'Static discovery aid; overlap is a review candidate, not proof of bad routing'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--start',default='.');s=p.add_subparsers(dest='op',required=True);s.add_parser('packet');s.add_parser('audit');q=s.add_parser('score');q.add_argument('--observations',required=True);a=p.parse_args()
    try:
        root=resolve_root(a.start)
        if a.op=='packet':result=packet(root)
        elif a.op=='audit':result=audit(root)
        else:
            obs=json.loads(Path(a.observations).read_text());result=score(load_cases(),obs['observations'],obs['fingerprint'],fingerprint(root))
        print(json.dumps(result,indent=2));return 0 if result.get('status','PASS')=='PASS' else 1
    except (OSError,ValueError,KeyError,TypeError) as e:print(json.dumps({'status':'INVALID','error':str(e)}));return 2
if __name__=='__main__':raise SystemExit(main())
