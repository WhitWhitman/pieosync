#!/usr/bin/env python3
"""macOS iCloud Reminders bridge; explicit enrollment, generic lock-screen text.

Transport contract (all dates timezone-aware ISO strings):
  inspect(list_name) -> {status: READY|LIST_MISSING, list_name}
  ensure_list(list_name) -> same; verification only, missing list requires explicit setup
  list_owned(list_name, prefix) -> [{id, marker, completed: bool, when: str|None}]
  create(list_name, marker, when, title=TITLE) -> reminder record
  update(list_name, native_id, marker, completed, when, expected_remote) -> reminder record
    expected_remote is the last observed {completed, when}; divergence raises NativeConflict
No operation reads reminder contents outside the named list or deletes anything.
"""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time
import uuid
import unicodedata
import assistant as a

TITLE = 'MindMake: your next step'

class NativeConflict(RuntimeError):
    """Native state changed after the sync read; no overwrite permitted."""

class NativeReminders:
    def _call(self, operation, list_name, _timeout=25, **values):
        if sys.platform != 'darwin':
            raise RuntimeError('Apple Reminders requires macOS')
        try:
            result = subprocess.run(['/usr/bin/osascript', '-l', 'JavaScript',
                str(Path(__file__).with_suffix('.jxa')),
                json.dumps(dict(operation=operation,list_name=list_name,**values))],
                capture_output=True, text=True, timeout=_timeout, check=True)
            value=json.loads(result.stdout)
            if not isinstance(value,(dict,list)): raise ValueError()
            if isinstance(value,dict) and value.get('error')=='conflict': raise NativeConflict('Native reminder changed; reconcile the conflict')
            if isinstance(value,dict) and value.get('error'): raise ValueError()
            return value
        except NativeConflict: raise
        except Exception:
            raise RuntimeError('Apple Reminders unavailable or operation uncertain; check macOS access and iCloud list') from None
    def inspect(self, list_name='MindMake'): return self._call('inspect',list_name)
    def ensure_list(self, list_name='MindMake'): return self.inspect(list_name)
    def list_owned(self,list_name,prefix): return self._call('list_owned',list_name,prefix=prefix)
    def create(self,list_name,marker,when,title=TITLE):
        if sys.platform!='darwin': raise RuntimeError('Apple Reminders requires macOS')
        title=checked_title(title); epoch=str(a.stamp(when).timestamp())
        if list_name!='MindMake' or not __import__('re').fullmatch(r'mindmake:[0-9a-f-]{36}:[0-9a-f]{64}',marker):
            raise ValueError('Invalid reminder scope')
        started=time.monotonic()
        try:
            result=subprocess.run(['/usr/bin/osascript','-l','AppleScript',
                str(Path(__file__).with_suffix('.applescript')),list_name,marker,title,epoch],
                capture_output=True,text=True,timeout=20,check=True)
            native_id=result.stdout.strip()
            if not native_id: raise ValueError()
            return self._call('read_one',list_name,native_id=native_id,marker=marker,
                              _timeout=max(0.1,25-(time.monotonic()-started)))
        except Exception:
            raise RuntimeError('Apple Reminders creation uncertain; reconcile before any retry') from None
    def update(self,list_name,native_id,marker,completed,when,expected_remote):
        return self._call('update',list_name,native_id=native_id,marker=marker,completed=completed,when=when,expected_remote=expected_remote)

def settings(root):
    c=a.config(root); r=c.get('apple_reminders',{})
    if r.get('list_name','MindMake') != 'MindMake': raise ValueError('Use the dedicated MindMake list')
    try: workspace=str(uuid.UUID(r['workspace_id']))
    except (KeyError,ValueError,TypeError,AttributeError): raise ValueError('Apple Reminders needs a stable workspace UUID') from None
    return c,r,'mindmake:'+workspace+':'

def schema(db):
    db.executescript('''
      CREATE TABLE IF NOT EXISTS apple_links (
        action_id TEXT PRIMARY KEY, marker TEXT UNIQUE NOT NULL, native_id TEXT,
        last_local TEXT, last_remote TEXT, state TEXT NOT NULL, enrolled_when TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS apple_sync_lock (
        singleton INTEGER PRIMARY KEY CHECK(singleton=1), pid INTEGER NOT NULL, token TEXT NOT NULL);
    ''')
    db.execute('BEGIN IMMEDIATE')
    if 'title' not in {r[1] for r in db.execute('PRAGMA table_info(apple_links)')}:
        db.execute("ALTER TABLE apple_links ADD COLUMN title TEXT NOT NULL DEFAULT 'MindMake: your next step'")
    db.commit()

def checked_title(title):
    if not isinstance(title,str) or any(unicodedata.category(ch).startswith('C') for ch in title):
        raise ValueError('Reminder title must be plain text without control characters')
    title=title.strip()
    if not 1<=len(title)<=120: raise ValueError('Reminder title must contain 1 to 120 characters')
    return title

def _all_actions(root):
    if hasattr(a,'actions'): return a.actions(root)
    with a.database(root) as db: return [dict(r) for r in db.execute('SELECT * FROM actions')]

def _action(root,action_id):
    return next((r for r in _all_actions(root) if r['id']==action_id),None)

def enroll(root,action_id,when,title=None):
    """Record explicit reminder consent/date for one open action; never dispatch."""
    a.ident(action_id); when=a.stamp(when).replace(microsecond=0).isoformat(); c,_,prefix=settings(root)
    if a.quiet(c,a.stamp(when)): raise ValueError('Choose a reminder date outside configured quiet hours')
    if title is not None: title=checked_title(title)
    action=_action(root,action_id)
    if not action or action['status']!='open': raise ValueError('Reminder enrollment needs an open action')
    marker=prefix+hashlib.sha256(action_id.encode()).hexdigest()
    with a.database(root) as db:
        schema(db)
        with db:
            prior=db.execute('SELECT * FROM apple_links WHERE action_id=?',(action_id,)).fetchone()
            if prior and prior['marker']!=marker: raise ValueError('Workspace identity changed; reconcile existing reminder')
            if prior and title is not None and title!=prior['title'] and (prior['native_id'] or prior['last_local'] is not None):
                raise ValueError('Reminder title is immutable after submission')
            title=title if title is not None else (prior['title'] if prior else TITLE)
            db.execute('INSERT INTO apple_links (action_id,marker,state,enrolled_when,title) VALUES (?,?,?,?,?) '
                       'ON CONFLICT(action_id) DO UPDATE SET enrolled_when=excluded.enrolled_when,title=excluded.title',
                       (action_id,marker,'prepared',when,title))
    return {'status':'ENROLLED','id':action_id,'when':when,'title':title}

def status(root):
    c,r,_=settings(root)
    result=dict(enabled=c['enabled'] and r.get('enabled') is True, platform='macOS iCloud Reminders',links=[])
    path=Path(root)/a.DB
    if not path.exists(): return result
    with sqlite3.connect(path) as db:
        db.row_factory=sqlite3.Row
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='apple_links'").fetchone():
            columns={r[1] for r in db.execute('PRAGMA table_info(apple_links)')}
            title_column="title" if 'title' in columns else "'MindMake: your next step' AS title"
            result['links']=[dict(x) for x in db.execute('SELECT action_id,native_id,state,enrolled_when,'+title_column+' FROM apple_links ORDER BY action_id')]
    return result

def _local(action,row):
    return dict(completed=action['status']=='done', when=a.stamp(action.get('snoozed_until') or row['enrolled_when']).replace(microsecond=0).isoformat())

def _remote(value,marker):
    if value.get('marker')!=marker or not isinstance(value.get('id'),str) or not value['id'] or type(value.get('completed')) is not bool:
        raise ValueError('Invalid native reminder response')
    return dict(completed=value['completed'],when=a.stamp(value['when']).replace(microsecond=0).isoformat() if value.get('when') else None)

def _fp(value): return json.dumps(value,sort_keys=True)

def _save(root,action_id,**values):
    with a.database(root) as db,db:
        db.execute('UPDATE apple_links SET '+','.join(k+'=?' for k in values)+' WHERE action_id=?',(*values.values(),action_id))

def _acquire(root):
    token=uuid.uuid4().hex
    with a.database(root) as db:
        schema(db); db.execute('BEGIN IMMEDIATE')
        old=db.execute('SELECT * FROM apple_sync_lock WHERE singleton=1').fetchone()
        if old:
            try: os.kill(old['pid'],0)
            except ProcessLookupError: pass
            except PermissionError: return None
            else: return None
        db.execute('INSERT OR REPLACE INTO apple_sync_lock VALUES (1,?,?)',(os.getpid(),token)); db.commit()
    return token

def _import_remote(root,row,action,observed):
    """Compare, apply, log and baseline atomically; preserve concurrent local edits."""
    with a.database(root) as db:
        db.execute('BEGIN IMMEDIATE')
        current=db.execute('SELECT * FROM actions WHERE id=?',(row['action_id'],)).fetchone()
        link=db.execute('SELECT * FROM apple_links WHERE action_id=?',(row['action_id'],)).fetchone()
        if not current or not link or dict(current)!=action or dict(link)!=row: return False
        change='done' if observed['completed'] else 'snooze'
        state='done' if change=='done' else current['status']
        until=None if change=='done' else observed['when']
        db.execute('UPDATE actions SET status=?,snoozed_until=? WHERE id=?',(state,until,row['action_id']))
        a.event(db,row['action_id'],change,dict(previous_status=current['status'],status=state,until=until,note='Explicit Apple Reminders change'))
        if change=='done':
            db.execute("UPDATE reminders SET state='canceled' WHERE action_id=? AND state='prepared'",(row['action_id'],))
        updated=dict(current); updated.update(status=state,snoozed_until=until)
        db.execute('UPDATE apple_links SET last_local=?,last_remote=? WHERE action_id=?',
                   (_fp(_local(updated,row)),_fp(observed),row['action_id']))
        db.commit()
        return True

def sync(root,transport=None):
    """Synchronize enrolled actions only. Paused configuration forbids imports/writes.

    SQLite's durable process lock serializes cooperating sync runs, including while
    native calls run. Local imports compare and commit atomically. A dead process
    lock is recoverable.
    Uncertain creates stay unknown until the exact native marker can be read back.
    Conflicts require human reconciliation and are never resolved by overwriting.
    """
    c,r,prefix=settings(root)
    if not c['enabled'] or r.get('enabled') is not True: return {'status':'PAUSED','results':[]}
    token=_acquire(root)
    if not token: return {'status':'BUSY','results':[]}
    results=[]; native=transport or NativeReminders()
    try:
        with a.database(root) as db: rows=[dict(x) for x in db.execute('SELECT * FROM apple_links ORDER BY action_id')]
        if not rows: return {'status':'SYNCED','results':[]}
        # List creation requires explicit setup via ensure_list; sync never broadens setup.
        if native.inspect('MindMake').get('status')!='READY': return {'status':'SETUP_PENDING','results':[]}
        remote=native.list_owned('MindMake',prefix)
        for row in rows:
            action=_action(root,row['action_id'])
            if not action or row['state']=='conflict': continue
            # Observe pause again between bounded native operations.
            current,options,_=settings(root)
            if not current['enabled'] or options.get('enabled') is not True: break
            health=a.source_health(root,action,a.utc()) if hasattr(a,'source_health') else {}
            stale=not action.get('source_hash') or health.get('source_missing') or health.get('source_stale')
            local=_local(action,row); matches=[v for v in remote if v.get('marker')==row['marker']]
            outcome='linked'
            if len(matches)>1: outcome='conflict'
            elif not matches:
                if row['native_id']: outcome='missing'
                elif row['state'] not in ('prepared','source_review_required','blocked','quiet_hours'): outcome='unknown'
                elif action['status']=='blocked': outcome='blocked'
                elif a.quiet(current,a.stamp(local['when'])) or (a.stamp(local['when'])<=a.utc() and a.quiet(current,a.utc())): outcome='quiet_hours'
                elif stale: outcome='source_review_required'
                elif local['completed']: outcome='closed'
                else:
                    _save(root,row['action_id'],state='attempting',last_local=_fp(local))
                    try:
                        value=native.create('MindMake',row['marker'],local['when'],row['title'])
                        observed=_remote(value,row['marker'])
                        if observed!=local: raise ValueError()
                        _save(root,row['action_id'],native_id=value['id'],last_local=_fp(local),last_remote=_fp(observed),state='linked')
                    except Exception: outcome='unknown'
            else:
                value=matches[0]; observed=_remote(value,row['marker'])
                if row['native_id'] and row['native_id']!=value['id']: outcome='conflict'
                elif row['last_remote'] is None:
                    # First readback after an uncertain create: never erase a phone edit.
                    if _fp(local)!=row['last_local'] or observed!=local: outcome='conflict'
                    else: _save(root,row['action_id'],native_id=value['id'],last_local=_fp(local),last_remote=_fp(observed))
                else:
                    local_changed=_fp(local)!=row['last_local']; remote_changed=_fp(observed)!=row['last_remote']
                    if local_changed and remote_changed and local!=observed: outcome='conflict'
                    elif local_changed and local!=observed and action['status']=='blocked':
                        outcome='blocked'
                    elif local_changed and local!=observed and not local['completed'] and a.quiet(current,a.stamp(local['when'])):
                        outcome='quiet_hours'
                    elif local_changed and local!=observed and stale and not local['completed']:
                        outcome='source_review_required'
                    elif local_changed and local!=observed:
                        try:
                            verified=_remote(native.update('MindMake',value['id'],row['marker'],local['completed'],local['when'],observed),row['marker'])
                            if verified!=local: raise ValueError()
                            _save(root,row['action_id'],last_local=_fp(local),last_remote=_fp(verified))
                        except NativeConflict: outcome='conflict'
                        except Exception: outcome='unknown_update'
                    elif remote_changed and local!=observed:
                        if not observed['completed'] and (local['completed'] or not observed['when']): outcome='conflict'
                        elif not _import_remote(root,row,action,observed): outcome='conflict'
                    else: _save(root,row['action_id'],last_local=_fp(local),last_remote=_fp(observed))
            _save(root,row['action_id'],state=outcome)
            results.append(dict(id=row['action_id'],state=outcome))
        return {'status':'SYNCED','results':results}
    except Exception:
        return {'status':'CHECK_FAILED','results':results,'error':'Apple Reminders could not be verified; no automatic create retry'}
    finally:
        with a.database(root) as db,db: db.execute('DELETE FROM apple_sync_lock WHERE token=?',(token,))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('status');sub.add_parser('sync')
    q=sub.add_parser('enroll');q.add_argument('id');q.add_argument('--when',required=True);q.add_argument('--title')
    args=p.parse_args(); root=args.root.resolve()
    if hasattr(a,'configure_layout'): a.configure_layout(root)
    try:
        result=enroll(root,args.id,args.when,args.title) if args.command=='enroll' else globals()[args.command](root)
        print(json.dumps(result,indent=2)); return 0
    except Exception:
        print(json.dumps({'status':'ERROR','error':'Reminder operation failed; verify configuration, enrollment and local state'})); return 1
if __name__=='__main__': raise SystemExit(main())
