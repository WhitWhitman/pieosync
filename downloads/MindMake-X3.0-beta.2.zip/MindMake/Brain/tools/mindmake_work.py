#!/usr/bin/env python3
"""Record intent, observed outcomes and attention costs. No execution or approval."""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse
import datetime as dt
import json
import re
from pathlib import Path

from mindmake_local import resolve_root
from mindmake_corrections import digest, hashes, ident, safe, save_new

BASE = 'Brain/.mindmake/work-records'
METRICS = ('repeated_explanations', 'unnecessary_questions', 'missed_followups', 'reopened_mistakes')
KINDS = ('check', 'artifact', 'deployment', 'user_observation')


def now():
    return dt.datetime.now(dt.timezone.utc)


def text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name + ' must be nonempty text')
    return value


def timestamp(value):
    value = dt.datetime.fromisoformat(text(value, 'timestamp').replace('Z', '+00:00'))
    if value.tzinfo is None:
        raise ValueError('Timestamp needs timezone offset')
    return value.astimezone(dt.timezone.utc)


def evidence(root, paths):
    if not isinstance(paths, list) or not paths or not all(isinstance(x, str) for x in paths):
        raise ValueError('Provide existing canonical evidence paths')
    if len(paths) != len(set(paths)):
        raise ValueError('Duplicate evidence path')
    return hashes(root, paths)


def folder(root, work):
    return safe(root, BASE + '/' + ident(work))


def validate_definition(d):
    if not isinstance(d, dict):
        raise ValueError('Work definition must be an object')
    ident(d.get('id', ''))
    for key in ('request', 'owner', 'scope'):
        text(d.get(key), key)
    if not isinstance(d.get('constraints'), list) or not all(isinstance(x, str) and x.strip() for x in d['constraints']):
        raise ValueError('Constraints must be a list of explicit text; [] means none stated')
    cs = d.get('criteria')
    if not isinstance(cs, list) or not cs:
        raise ValueError('At least one acceptance criterion is required')
    ids = []
    for c in cs:
        if not isinstance(c, dict):
            raise ValueError('Criterion must be an object')
        ids.append(ident(c.get('id', '')))
        text(c.get('outcome'), 'desired outcome'); text(c.get('check'), 'acceptance check')
        if c.get('kind') not in KINDS:
            raise ValueError('Criterion needs an explicit acceptance kind')
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate criterion ID')


def initialize(root, definition):
    validate_definition(definition)
    record = {k: definition[k] for k in ('id', 'request', 'owner', 'scope', 'constraints', 'criteria')}
    record.update(schema=1, sources=evidence(root, definition.get('sources')), created_at=now().isoformat())
    path = folder(root, record['id'])
    try:
        path.mkdir(parents=True, exist_ok=False)
    except FileExistsError as e:
        raise ValueError('Work exists; retain the definition and use a new revision ID') from e
    save_new(path/'definition.json', record)
    return {'id':record['id'], 'status':'PENDING', 'path':str(path/'definition.json')}


def load(root, work):
    path = safe(root, BASE + '/' + ident(work) + '/definition.json')
    data = path.read_bytes(); record = json.loads(data)
    validate_definition(record)
    if record.get('schema') != 1 or record['id'] != work or not isinstance(record.get('sources'), dict) or not record['sources']:
        raise ValueError('Invalid saved work definition')
    return record, digest(data)


def events(root, work):
    root = Path(root).resolve()
    path = safe(root, BASE + '/' + ident(work) + '/events')
    if not path.exists():
        return []
    definition, _ = load(root, work)
    criteria_by_id = {c['id']: c for c in definition['criteria']}
    result = []
    for f in sorted(path.iterdir()):
        if f.name.startswith('.'):
            continue
        f = safe(root, str(f.relative_to(Path(root).resolve())))
        if f.suffix != '.json' or not f.is_file():
            raise ValueError('Unexpected journal entry')
        row = json.loads(f.read_text())
        if (not isinstance(row, dict) or row.get('schema') != 1 or row.get('type') not in ('result', 'attention')
                or not isinstance(row.get('body'), dict) or not isinstance(row.get('definition_sha256'), str)):
            raise ValueError('Malformed work event: ' + f.name)
        ident(row['body'].get('id', ''))
        if timestamp(row.get('recorded_at')) > now():
            raise ValueError('Saved event is dated in the future; check clock and journal')
        body = row['body']
        text(body.get('observer'), 'saved observer')
        proof = body.get('evidence')
        if not isinstance(proof, dict) or not proof or any(not isinstance(k, str) or not isinstance(v, str) or not re.fullmatch(r'[a-f0-9]{64}', v) for k,v in proof.items()):
            raise ValueError('Invalid saved evidence hashes')
        if row['type'] == 'result':
            text(body.get('note'), 'saved observation note')
            if body.get('state') not in ('observed', 'pending', 'failed') or body.get('kind') not in KINDS:
                raise ValueError('Invalid saved observation kind/state')
            ident(body.get('criterion', ''))
            criterion = criteria_by_id.get(body['criterion'])
            if criterion is None or body['kind'] != criterion['kind']:
                raise ValueError('Saved result does not match a work criterion')
            if body['state'] == 'failed':
                proposal = body.get('proposal')
                if not isinstance(proposal, dict) or proposal.get('status') != 'PROPOSED' or proposal.get('authorized') is not False:
                    raise ValueError('Invalid saved repair proposal')
                for key in ('owner', 'scope', 'issue', 'cause', 'suggestion', 'regression', 'criterion'):
                    text(proposal.get(key), 'proposal ' + key)
                if (proposal['owner'] != definition['owner'] or proposal['scope'] != definition['scope']
                        or proposal['criterion'] != criterion['id'] or proposal['regression'] != criterion['check']
                        or proposal['issue'] != body['note']):
                    raise ValueError('Saved proposal does not match its work and criterion')
        else:
            start, end = timestamp(body.get('start')), timestamp(body.get('end'))
            if end <= start or end > now():
                raise ValueError('Invalid saved attention interval')
            counts = body.get('counts')
            if not isinstance(counts, dict) or set(counts) != set(METRICS) or any(type(v) is not int or v < 0 for v in counts.values()):
                raise ValueError('Invalid saved attention counts')
        if row['body']['id'] + '.json' != f.name:
            raise ValueError('Event ID mismatch')
        result.append(row)
    windows = sorted((timestamp(x['body']['start']), timestamp(x['body']['end'])) for x in result if x['type'] == 'attention')
    if any(left[1] > right[0] for left, right in zip(windows, windows[1:])):
        raise ValueError('Saved attention windows overlap')
    return sorted(result, key=lambda x: (timestamp(x['recorded_at']), x['body']['id']))


def current_definition(root, work):
    record, sha = load(root, work)
    if hashes(root, record['sources']) != record['sources']:
        raise ValueError('Intent source changed; review and create a new work revision')
    return record, sha


def append(root, work, kind, body, sha):
    path = safe(root, BASE + '/' + ident(work) + '/events/' + ident(body['id']) + '.json')
    if path.exists():
        old = json.loads(path.read_text())
        if old.get('type') == kind and old.get('body') == body and old.get('definition_sha256') == sha:
            return old
        raise ValueError('Event ID already used for different evidence')
    row = {'schema':1, 'type':kind, 'body':body, 'definition_sha256':sha, 'recorded_at':now().isoformat()}
    save_new(path, row)
    return row


def record_result(root, work, observation):
    if not isinstance(observation, dict):
        raise ValueError('Observation must be an object')
    record, sha = current_definition(root, work)
    events(root, work)  # Refuse appending behind a malformed journal.
    criterion = next((c for c in record['criteria'] if c['id'] == observation.get('criterion')), None)
    if criterion is None:
        raise ValueError('Unknown acceptance criterion')
    if observation.get('state') not in ('observed', 'pending', 'failed'):
        raise ValueError('Use observed, pending or failed')
    if observation.get('kind') != criterion['kind']:
        raise ValueError('Evidence kind does not satisfy the requested acceptance kind')
    body = {k: observation.get(k) for k in ('id', 'criterion', 'state', 'kind', 'observer', 'note')}
    ident(body['id']); text(body['observer'], 'observer'); text(body['note'], 'observation note')
    body['evidence'] = evidence(root, observation.get('evidence'))
    if body['state'] == 'failed':
        body['proposal'] = {'status':'PROPOSED', 'authorized':False, 'owner':record['owner'], 'scope':record['scope'],
                           'issue':body['note'], 'cause':text(observation.get('cause', 'UNKNOWN'), 'cause'),
                           'suggestion':text(observation.get('suggestion'), 'suggested repair'),
                           'regression':criterion['check'], 'criterion':criterion['id']}
    return append(root, work, 'result', body, sha)


def record_attention(root, work, sample):
    if not isinstance(sample, dict):
        raise ValueError('Attention sample must be an object')
    _, sha = current_definition(root, work)
    start, end = timestamp(sample.get('start')), timestamp(sample.get('end'))
    if end <= start or end > now():
        raise ValueError('Use an elapsed, nonempty observation interval')
    counts = sample.get('counts')
    if not isinstance(counts, dict) or set(counts) != set(METRICS) or any(type(v) is not int or v < 0 for v in counts.values()):
        raise ValueError('All four counts must be explicit nonnegative integers')
    body = {'id':ident(sample.get('id', '')), 'start':start.isoformat(), 'end':end.isoformat(),
            'observer':text(sample.get('observer'), 'observer'), 'counts':counts, 'evidence':evidence(root, sample.get('evidence'))}
    for row in events(root, work):
        old = row['body']
        if row['type'] == 'attention' and old['id'] != body['id']:
            if start < timestamp(old['end']) and end > timestamp(old['start']):
                raise ValueError('Observation windows overlap; do not double-count')
    return append(root, work, 'attention', body, sha)


def intact(root, row, sha):
    try:
        proof = row['body']['evidence']
        return bool(proof) and row['definition_sha256'] == sha and hashes(root, proof) == proof
    except (OSError, KeyError, TypeError, ValueError):
        return False


def status(root, work):
    root = Path(root).resolve()
    record, sha = load(root, work)
    rows = events(root, work)
    try:
        definition_stale = hashes(root, record['sources']) != record['sources']
    except (OSError, ValueError):
        definition_stale = True
    latest = {}; samples = []
    valid_ids = {c['id'] for c in record['criteria']}
    for row in rows:
        body = row['body']
        if row['type'] == 'result':
            if body.get('criterion') not in valid_ids or body.get('state') not in ('observed', 'pending', 'failed'):
                raise ValueError('Invalid saved outcome')
            criterion = next(c for c in record['criteria'] if c['id'] == body['criterion'])
            if body.get('kind') != criterion['kind']:
                raise ValueError('Saved outcome kind mismatch')
            if body['state'] == 'failed':
                p = body['proposal']
                if p['owner'] != record['owner'] or p['scope'] != record['scope'] or p['criterion'] != criterion['id'] or p['regression'] != criterion['check'] or p['issue'] != body['note']:
                    raise ValueError('Saved proposal does not match its work and criterion')
            latest[body['criterion']] = row
        else:
            if set(body.get('counts', {})) != set(METRICS) or any(type(v) is not int or v < 0 for v in body['counts'].values()):
                raise ValueError('Invalid saved attention counts')
            if timestamp(body['end']) <= timestamp(body['start']):
                raise ValueError('Invalid saved attention interval')
            samples.append(row)
    criteria = {}; proposals = []
    for c in record['criteria']:
        row = latest.get(c['id'])
        state = row['body']['state'] if row else 'pending'
        stale = definition_stale or (row is not None and not intact(root, row, sha))
        criteria[c['id']] = {'outcome':c['outcome'], 'check':c['check'], 'kind':c['kind'], 'state':'stale' if stale else state,
                             'event':row['body']['id'] if row else None}
        if row and state == 'failed':
            proposal = row['body'].get('proposal')
            if not isinstance(proposal, dict) or proposal.get('authorized') is not False:
                raise ValueError('Invalid saved repair proposal')
            proposals.append({**proposal, 'status':'STALE' if stale else 'PROPOSED', 'event':row['body']['id']})
    states = {x['state'] for x in criteria.values()}
    summary = 'STALE' if 'stale' in states else 'FAILED' if 'failed' in states else 'PENDING' if 'pending' in states else 'OBSERVED'
    sample_stale = definition_stale or any(not intact(root, row, sha) for row in samples)
    attention = {'status':'NOT_MEASURED', 'samples':len(samples), 'counts':None, 'observed_seconds':None}
    if samples and sample_stale:
        attention['status'] = 'STALE'
    elif samples:
        attention.update(status='RECORDED', counts={k:sum(s['body']['counts'][k] for s in samples) for k in METRICS},
                         observed_seconds=sum((timestamp(s['body']['end'])-timestamp(s['body']['start'])).total_seconds() for s in samples))
    return {'id':work, 'request':record['request'], 'scope':record['scope'], 'owner':record['owner'], 'constraints':record['constraints'],
            'status':summary, 'criteria':criteria, 'proposals':proposals, 'attention':attention,
            'evidence_scope':'Attributed observations with current file hashes; no automatic semantic validation, user acceptance, execution or approval'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start', default='.')
    sub = parser.add_subparsers(dest='op', required=True)
    p = sub.add_parser('init'); p.add_argument('--file', required=True)
    for op in ('result', 'attention'):
        p = sub.add_parser(op); p.add_argument('work'); p.add_argument('--file', required=True)
    p = sub.add_parser('status'); p.add_argument('work')
    args = parser.parse_args()
    try:
        root = resolve_root(args.start)
        data = json.loads(Path(args.file).read_text()) if hasattr(args, 'file') else None
        if args.op == 'init':
            output = initialize(root, data)
        elif args.op == 'result':
            output = record_result(root, args.work, data)
        elif args.op == 'attention':
            output = record_attention(root, args.work, data)
        else:
            output = status(root, args.work)
        print(json.dumps(output, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({'status':'UNAVAILABLE', 'error':str(error)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
