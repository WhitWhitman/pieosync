#!/usr/bin/env python3
"""Compact read-only orientation for registered commitment reviews."""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import json
from pathlib import Path
import subprocess
import sys
import mindmake as mm
from mindmake_local import resolve_root

REQUIRED = ['GUARD.md', 'Brain/governance/RUNTIME.md', 'Brain/governance/WORKSPACE_POLICY.md',
            'Brain/tools/FOLLOW_THROUGH.md']

def read_status(root):
    helper = mm.within(root, 'Brain/tools/assistant.py')
    run = subprocess.run([sys.executable, '-B', str(helper), 'status', '--root', str(root)],
                         capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=15)
    if run.returncode:
        raise ValueError('Assistant status failed')
    return json.loads(run.stdout)

def followthrough(root):
    try:
        config = json.loads(mm.within(root, 'Brain/.mindmake/assistant.json').read_text())
        if type(config.get('enabled')) is not bool:
            raise ValueError('Invalid assistant enabled state')
        if not config['enabled']:
            return {'status':'PAUSED', 'review_sources':[], 'reviews_due_count':0,
                    'review_sources_omitted':0, 'scope':'No helper, source dispatch or native sync while paused'}
        ledger = mm.within(root, 'Brain/.mindmake/assistant-state/state.sqlite3')
        if not ledger.is_file():
            raise ValueError('Registered task ledger is missing')
        data = read_status(root)
        if not isinstance(data, dict) or data.get('enabled') is not True:
            raise ValueError('Invalid helper enabled state')
        if not all(k in data for k in ('scheduler_health','next_action','reviews_due','open_actions')):
            raise ValueError('Incomplete helper result')
        health, item, actions, due = (data[k] for k in ('scheduler_health','next_action','open_actions','reviews_due'))
        if not isinstance(health,dict) or not isinstance(health.get('status'),str):
            raise ValueError('Invalid scheduler health')
        last = health.get('last_run')
        if last is not None and not isinstance(last,dict):
            raise ValueError('Invalid scheduler receipt')
        if not isinstance(actions,list) or not all(isinstance(a,dict) and isinstance(a.get('id'),str) and isinstance(a.get('source'),str) for a in actions):
            raise ValueError('Invalid actions')
        ids = [a['id'] for a in actions]
        if len(ids) != len(set(ids)) or not isinstance(due,list) or not all(isinstance(d,str) for d in due) or len(due)!=len(set(due)) or not set(due).issubset(ids):
            raise ValueError('Invalid due action IDs')
        if item is not None and (not isinstance(item,dict) or item.get('id') not in ids):
            raise ValueError('Invalid next action')
        sources = sorted({a['source'] for a in actions if a['id'] in due})
        for source in sources:
            if not mm.within(root,source.split('#',1)[0]).is_file():
                raise ValueError('Registered review source is missing')
        return {'status':'ENABLED','reviews_due_count':len(due),
                'review_sources':sources[:20],'review_sources_omitted':max(0,len(sources)-20),
                'scheduler_health':{'status':health['status'][:120],
                    'last_run':{k:str(last[k])[:120] for k in ('run_id','outcome','recorded_at') if k in last} if last else None},
                'next_action':{k:str(item.get(k,''))[:240] for k in ('id','step','source')} if item else None,
                'detail_command':'python3 Brain/tools/assistant.py status'}
    except (OSError, ValueError, TypeError, KeyError, subprocess.TimeoutExpired) as exc:
        return {'status':'UNAVAILABLE','reason':str(exc)[:300]}

def boot(root):
    root = Path(root).resolve()
    errors = []
    try:
        if resolve_root(root) != root:
            raise ValueError('Local home locator conflicts with selected root')
        for rel in REQUIRED:
            mm.within(root,rel).read_text()
        check = mm.verify(root)
        errors.extend(check['errors'])
        if not errors and mm.setup_review(root)['status'] != 'RECORDED':
            errors.append('Source or deployment review is stale; reconcile before reviewing commitments')
        state = followthrough(root) if not errors else {'status':'UNAVAILABLE','reason':'Structural check failed'}
        if state['status'] == 'UNAVAILABLE':
            errors.append(state['reason'])
    except (OSError, ValueError, KeyError, TypeError) as exc:
        errors.append(str(exc)); state={'status':'UNAVAILABLE'}
    return {'status':'FAIL' if errors else 'READY','mode':'review','root':str(root),
            'required_read':REQUIRED,'routing_read':state.get('review_sources',[]) if state['status']=='ENABLED' else [],
            'seed_read_order':[], 'followthrough':state,'maintenance':'not performed',
            'lazy':['Global TODO, profiles, indexes and unrelated seeds; retrieve detailed evidence only for registered commitments'],
            'scope':'Read-only orientation; no native sync, task execution, intake conversation or maintenance',
            'errors':errors}
