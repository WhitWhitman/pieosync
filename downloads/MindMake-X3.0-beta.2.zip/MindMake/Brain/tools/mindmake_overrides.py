#!/usr/bin/env python3
"""Override log for GUARD section 10 ("three yeses"). X3.0.

Only rules on the OVERRIDABLE list below can be overridden, by their id. Floor rules and
any id not on that list are refused, however the request is worded.

  python3 Brain/tools/mindmake_overrides.py rules                      # ids that can be overridden
  python3 Brain/tools/mindmake_overrides.py start --rule-id <id>       # begin the three questions
  python3 Brain/tools/mindmake_overrides.py answer --pending <n> --text "<the user's answer>"
  python3 Brain/tools/mindmake_overrides.py pending                    # unfinished ones, with the next question
  python3 Brain/tools/mindmake_overrides.py cancel --pending <n>       # user dropped it; the rule stays
  python3 Brain/tools/mindmake_overrides.py active                     # what is overridden right now
  python3 Brain/tools/mindmake_overrides.py history                    # every event, to spot patterns
  python3 Brain/tools/mindmake_overrides.py end --id <n> --reason "<why>"   # put a rule back

There is no way to switch an override on without the three questions. Each answer is
saved as soon as it is given, so an interrupted chat resumes at the next unanswered
question. The last answer and the override itself are one record, so an interruption
can never leave the last answer saved but the override missing (or ask it again).
  why       the user's reason (after you say in one line what the rule protects)
  duration  exactly "today" or "for good"     (today ends at midnight, local time)
  trial     exactly "week" or "permanent"     (only asked after "for good")
Anything else ("not today", "maybe", "forever-ish") is refused; ask the question again once.
If the answer is still unclear, the rule stays as it is.

trial      lasts one week, then ends by itself and the rule comes back. The history keeps it.
           Nobody is asked to renew it; the user can start a new override any time.

The log is append-only (one JSON line per event) in Brain/.mindmake/work-records/overrides.jsonl.
This is a record, not a permission: GUARD's three questions come first.
"""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import sys

LOG = 'Brain/.mindmake/work-records/overrides.jsonl'
SCOPES = ('today', 'trial', 'permanent')

# The only rules that can be overridden. Anything else is refused.
OVERRIDABLE = {
    'critique-first': 'GUARD 2: give the strongest outside critique before agreeing',
    'counter-evidence': 'GUARD 2: look for evidence against a costly premise',
    'no-vague-stalls': 'GUARD 2: name exactly what is missing instead of "you decide"',
    'short-replies': 'GUARD 3: short sentences, answer first, one idea per line',
    'one-next-action': 'GUARD 3: one next action per reply (urgent items are still shown)',
    'three-choices-max': 'GUARD 3: at most three choices at a time',
    'no-plumbing': 'GUARD 3: no internal plumbing in chat',
    'reliance-check': 'GUARD 6: the reliance check after about ten emotional messages',
    'professional-note': 'GUARD 8: the note that legal, medical and financial calls stay with professionals',
    'one-question-at-a-time': 'AGENTS: ask one question at a time',
    'quiet-startup': 'AGENTS: startup reply of three lines at most',
    'weekly-recap': 'AGENTS: the weekly recap',
}

# Named so the refusal can say why. Never overridable (GUARD section 10's floor, plus
# the honesty, privacy and permission rules that protect it).
PROTECTED = {
    'app-safety', 'no-made-up-memories', 'no-made-up-sources', 'honest-status', 'attempted-not-done',
    'independent-check', 'quote-to-count', 'yes-before-delete', 'yes-before-overwrite', 'yes-before-send',
    'yes-before-purchase', 'yes-before-publish', 'yes-before-schedule', 'yes-before-install',
    'out-of-scope-ask', 'crisis', 'privacy-secrets', 'privacy-others', 'stop-and-forget',
    'not-a-person', 'clock-rule', 'material-not-orders',
}

QUESTIONS = {
    'why': 'Say in one line what the rule protects, then ask why they want to override it.',
    'duration': 'Ask: "Just for today, or for good?"',
    'trial': 'Ask: "Should I check back in a week, or make it permanent now?"',
}


def _now():
    return dt.datetime.now().astimezone()


def read(root):
    path = root/LOG
    if not path.is_file():
        return []
    events = []
    for line in path.read_text().splitlines():
        try:
            events.append(json.loads(line))
        except ValueError:
            continue
    return events


def _append(root, event):
    path = root/LOG
    path.parent.mkdir(parents=True, exist_ok=True)
    line = (json.dumps(event, sort_keys=True) + '\n').encode()
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        os.write(fd, line)  # one append of one whole line
        os.fsync(fd)
    finally:
        os.close(fd)


def check_rule(rule_id):
    """None if the id can be overridden, else the refusal reason."""
    rid = (rule_id or '').strip().lower()
    if rid in OVERRIDABLE:
        return None
    if rid in PROTECTED:
        return 'Protected rule: part of GUARD\'s floor or what keeps it honest; it never bends (GUARD section 10)'
    return 'Unknown rule id. Only these can be overridden: ' + ', '.join(sorted(OVERRIDABLE))


def _until(scope, now):
    if scope == 'today':
        return dt.datetime.combine(now.date() + dt.timedelta(days=1), dt.time(0), now.tzinfo).isoformat()
    if scope == 'trial':
        return (now + dt.timedelta(days=7)).isoformat(timespec='seconds')
    return None


def _activate(root, rule_id, reason, scope, now=None, answers=None, pending=None):
    now = now or _now()
    refused = check_rule(rule_id)
    if refused:
        return dict(status='REFUSED', rule_id=(rule_id or '').strip(), reason=refused)
    if scope not in SCOPES:
        raise ValueError('scope must be today, trial or permanent')
    if not (reason or '').strip():
        raise ValueError('An override needs the user\'s reason')
    rid = rule_id.strip().lower()
    number = 1 + sum(1 for e in read(root) if e.get('event') == 'override')
    event = dict(event='override', id=number, rule_id=rid, rule=OVERRIDABLE[rid], reason=reason.strip(),
                 scope=scope, at=now.isoformat(timespec='seconds'), until=_until(scope, now))
    if answers:
        event['answers'] = answers
    if pending:
        event['pending'] = pending
    _append(root, event)
    return dict(status='RECORDED', **event)


def _pending_state(root):
    """Unfinished three-question flows: {n: dict(rule_id, answers, stage)}."""
    flows = {}
    for e in read(root):
        kind, n = e.get('event'), e.get('pending')
        if kind == 'pending-start':
            flows[n] = dict(pending=n, rule_id=e['rule_id'], rule=OVERRIDABLE.get(e['rule_id'], ''),
                            answers={}, started=e['at'])
        elif kind == 'pending-answer' and n in flows:
            flows[n]['answers'][e['stage']] = e['text']
        elif kind in ('pending-cancel', 'override') and n in flows:
            del flows[n]
    for f in flows.values():
        f['stage'] = _next_stage(f['answers'])
        f['next_question'] = QUESTIONS[f['stage']]
    return flows


def _next_stage(answers):
    if 'why' not in answers:
        return 'why'
    if 'duration' not in answers:
        return 'duration'
    return 'trial'


def start(root, rule_id, now=None):
    now = now or _now()
    refused = check_rule(rule_id)
    if refused:
        return dict(status='REFUSED', rule_id=(rule_id or '').strip(), reason=refused)
    rid = rule_id.strip().lower()
    for f in _pending_state(root).values():
        if f['rule_id'] == rid:  # resume, never ask again what was answered
            return dict(status='PENDING', resumed=True, **f)
    n = 1 + sum(1 for e in read(root) if e.get('event') == 'pending-start')
    _append(root, dict(event='pending-start', pending=n, rule_id=rid, at=now.isoformat(timespec='seconds')))
    return dict(status='PENDING', resumed=False, **_pending_state(root)[n])


DURATION = {'today': 'today', 'just for today': 'today', 'for today': 'today',
            'for good': 'for good', 'good': 'for good'}
TRIAL = {'week': 'week', 'a week': 'week', 'in a week': 'week', 'check back in a week': 'week',
         'permanent': 'permanent', 'permanent now': 'permanent', 'make it permanent': 'permanent',
         'make it permanent now': 'permanent'}


def _normalize(stage, text):
    t = ' '.join(''.join(c for c in text.lower() if c.isalnum() or c.isspace()).split())
    if stage == 'duration':
        if t not in DURATION:
            raise ValueError('Not a clear answer. Ask once more: "Just for today, or for good?"')
        return DURATION[t]
    if stage == 'trial':
        if t not in TRIAL:
            raise ValueError('Not a clear answer. Ask once more: "Should I check back in a week, or make it permanent now?"')
        return TRIAL[t]
    return text.strip()


def answer(root, pending, text, now=None):
    now = now or _now()
    flows = _pending_state(root)
    if pending not in flows:
        raise ValueError('No unfinished override with that number')
    if not (text or '').strip():
        raise ValueError('An empty answer is not an answer; the rule stays as it is')
    f = flows[pending]
    stage = f['stage']
    value = _normalize(stage, text)
    answers = dict(f['answers'], **{stage: value})
    # The final answer is written inside the override record itself: one line, one write.
    if stage == 'duration' and value == 'today':
        return _activate(root, f['rule_id'], answers['why'], 'today', now, answers, pending)
    if stage == 'trial':
        scope = 'trial' if value == 'week' else 'permanent'
        return _activate(root, f['rule_id'], answers['why'], scope, now, answers, pending)
    _append(root, dict(event='pending-answer', pending=pending, stage=stage, text=value,
                       at=now.isoformat(timespec='seconds')))
    f['answers'] = answers
    nxt = _next_stage(f['answers'])
    return dict(status='PENDING', pending=pending, rule_id=f['rule_id'], answers=f['answers'],
                stage=nxt, next_question=QUESTIONS[nxt])


def cancel(root, pending, now=None):
    now = now or _now()
    if pending not in _pending_state(root):
        raise ValueError('No unfinished override with that number')
    _append(root, dict(event='pending-cancel', pending=pending, at=(now or _now()).isoformat(timespec='seconds')))
    return dict(status='CANCELLED', pending=pending)


def end(root, number, reason, now=None):
    now = now or _now()
    if not any(e.get('event') == 'override' and e.get('id') == number for e in read(root)):
        raise ValueError('No override with that number')
    event = dict(event='end', id=number, reason=(reason or 'ended by user').strip(), at=now.isoformat(timespec='seconds'))
    _append(root, event)
    return dict(status='ENDED', **event)


def active(root, now=None):
    now = now or _now()
    events = read(root)
    ended = {e['id'] for e in events if e.get('event') == 'end'}
    live, review_due = [], []
    for e in events:
        if e.get('event') != 'override' or e['id'] in ended:
            continue
        if check_rule(e.get('rule_id')):  # old free-text or protected entries never count
            continue
        until = dt.datetime.fromisoformat(e['until']) if e.get('until') else None
        if e['scope'] in ('today', 'trial') and until and now >= until:
            continue  # expired: the rule is back. The history keeps the record.
        live.append(e)
    return dict(active=live, review_due=review_due)  # review_due stays empty: trials never nag


def summary(root, now=None):
    """For boot: a short view, empty when nothing is overridden or pending."""
    a = active(root, now)
    out = dict(active=[dict(id=e['id'], rule=e['rule'], scope=e['scope']) for e in a['active']],
               review_due=[dict(id=e['id'], rule=e['rule']) for e in a['review_due']])
    pend = [dict(pending=f['pending'], rule=f['rule'], next_question=f['next_question'])
            for f in _pending_state(root).values()]
    if pend:
        out['pending'] = pend
    return out


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('operation', choices=['rules', 'start', 'answer', 'pending', 'cancel', 'active',
                                         'history', 'end'])
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    p.add_argument('--rule-id'); p.add_argument('--reason')
    p.add_argument('--text'); p.add_argument('--pending', type=int); p.add_argument('--id', type=int)
    a = p.parse_args()
    root = a.root.resolve()
    try:
        if a.operation == 'rules':
            result = dict(status='OK', overridable=OVERRIDABLE)
        elif a.operation == 'start':
            result = start(root, a.rule_id)
        elif a.operation == 'answer':
            result = answer(root, a.pending, a.text or '')
        elif a.operation == 'pending':
            result = dict(status='OK', pending=list(_pending_state(root).values()))
        elif a.operation == 'cancel':
            result = cancel(root, a.pending)
        elif a.operation == 'end':
            result = end(root, a.id, a.reason)
        elif a.operation == 'active':
            result = dict(status='OK', **active(root))
        else:
            result = dict(status='OK', history=read(root))
    except ValueError as exc:
        result = dict(status='ERROR', error=str(exc))
    print(json.dumps(result, indent=2))
    return 0 if result['status'] in ('RECORDED', 'ENDED', 'OK', 'PENDING', 'CANCELLED') else 1


if __name__ == '__main__':
    sys.exit(main())
