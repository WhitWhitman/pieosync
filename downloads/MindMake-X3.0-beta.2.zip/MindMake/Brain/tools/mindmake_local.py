"""Resolve an extracted MindMake workspace through its package-local locator.

The literal '.' locator identifies only its containing folder. No external
Cartographer authority, seed map or absolute authoring-machine path is followed.
"""
from pathlib import Path


def resolve_root(start='.'):
    path = Path(start).absolute()
    for part in (path, *path.parents):
        if part.is_symlink():
            raise ValueError('Symbolic links cannot identify package authority')
    if not path.exists():
        raise ValueError('Workspace start does not exist')
    path = path.resolve()
    if path.is_file():
        path = path.parent
    for root in (path, *path.parents):
        locator = root / '.mindmake-home'
        if locator.is_symlink():
            raise ValueError('Symbolic locator refused')
        if locator.exists():
            if not locator.is_file() or locator.read_text().strip() != '.':
                raise ValueError('Package locator must contain only a local dot')
            return root
    raise ValueError('No package-local .mindmake-home found')
