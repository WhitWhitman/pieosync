#!/usr/bin/env python3
"""Brain clean: a read-only health report for a MindMake workspace.

X3.0. Run on demand ("brain clean", "check my brain") or quietly at the end of a
session, never in the middle of the user's work:

  python3 Brain/tools/mindmake_clean.py            # full report (JSON)
  python3 Brain/tools/mindmake_clean.py --limit 5  # fewer examples per finding
Boot runs it automatically once a day, at the first chat of the day, through
Brain/tools/mindmake_routines.py (the shared "last run" log).

It finds:
  broken_links      Markdown links and images pointing to files that don't exist
  missing_files     switch-ledger destinations that are gone
  duplicates        exact copies (same bytes) in the user's own areas
  near_duplicates   files with the same name idea and almost the same text
  malformed         unclosed front matter, unpaired map markers, unclosed code
                    blocks, text that isn't UTF-8, seeds without front matter
  empty_files       files with nothing in them
  orphaned_seeds    seeds whose `supersedes` names a seed missing from their own project
                    (or shared Seeds), or whose `links` name a missing seed

It changes nothing. What to do with the report:
  - Fix only reversible things without asking: a broken link whose target is
    clearly just renamed (log the change with note_change, then update_map).
  - Everything else waits for a yes: merging or removing duplicates, deleting
    empty files, editing a seed (seeds are append-only; correct with a new seed).
  - Tell the user in at most three lines: what's healthy, what needs them, one next action.
Kit files (helpers in Jobs/, Brain/governance/history, Plugin, PDFs) are skipped for
duplicates, because the kit ships some files twice on purpose.
"""
import argparse
import csv
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys
from urllib.parse import unquote

SKIP_PARTS = {'__pycache__', '.pytest_cache', '.git', 'Originals', 'map-history', 'repair-history'}
SKIP_PREFIXES = ('Brain/governance/history/', 'Plugin/')
LINK = re.compile(r'!?\[[^\]\n]*\]\((<[^>\n]+>|[^)\s]+)(?:\s+"[^"\n]*")?\)')
BEGIN, END = '<!-- MINDMAKE FOLDER MAP BEGIN -->', '<!-- MINDMAKE FOLDER MAP END -->'
SEED_POOLS = ('Short-term', 'Long-term')


def skipped(rel):
    parts = rel.split('/')
    return parts[0].startswith('_') or any(p in SKIP_PARTS for p in parts) or rel.startswith(SKIP_PREFIXES) \
        or any(p.startswith('.') for p in parts[:-1] if p != '.mindmake') or parts[-1] == '.DS_Store'


def all_files(root):
    for p in sorted(root.rglob('*')):
        rel = p.relative_to(root).as_posix()
        if p.is_file() and not p.is_symlink() and not skipped(rel):
            yield rel, p


def user_areas(root):
    """Seeds, Wiki, Downloads and the user's own projects: where duplicates matter."""
    areas = ['Seeds/', 'Wiki/', 'Downloads/']
    jobs = root/'Jobs'
    for job in sorted(jobs.iterdir()) if jobs.is_dir() else []:
        page = job/'JOB.md'
        if page.is_file() and 'Type: User Project' in page.read_text(errors='replace'):
            areas.append(job.relative_to(root).as_posix() + '/')
    return tuple(areas)


def front_matter(text):
    if not text.startswith('---\n'):
        return None
    end = text.find('\n---', 4)
    return text[4:end] if end != -1 else False


def fm_value(fm, key):
    m = re.search(r'^' + key + r':\s*(.+)$', fm, re.M)
    return m.group(1).strip().strip('"\'') if m else None


def is_seed(rel):
    parts = rel.split('/')
    return rel.endswith('.md') and len(parts) >= 3 and parts[-2] in SEED_POOLS and 'Seeds' in parts \
        and parts[-1] not in ('README.md', 'INDEX.md')


def scope_of(rel):
    parts = rel.split('/')
    return '/'.join(parts[:parts.index('Seeds') + 1])


def stem_key(name):
    s = Path(name).stem.lower()
    s = re.sub(r'^\d{4}-\d{2}-\d{2}[_ -]?(\d{6}[_ -]?)?', '', s)
    s = re.sub(r'\(\d+\)|copy|\b\d+\b|[^a-z0-9]+', ' ', s)
    return ' '.join(s.split())


def scan(root, limit=20):
    findings = {k: [] for k in ('broken_links', 'missing_files', 'duplicates', 'near_duplicates',
                                'malformed', 'empty_files', 'orphaned_seeds')}
    files = list(all_files(root))
    # Seeds resolve within their own scope: a project's seeds, or the shared Seeds folder.
    seed_scope = {}
    for rel, _ in files:
        if is_seed(rel):
            seed_scope.setdefault(scope_of(rel), set()).add(Path(rel).name)
    areas = user_areas(root)
    by_hash, by_stem = {}, {}
    for rel, p in files:
        data = p.read_bytes()
        if not data.strip() and p.name not in ('.mindmake-home', 'map.lock'):
            findings['empty_files'].append(rel)
            continue
        if rel.startswith(areas) and p.name not in ('INDEX.md', 'README.md'):
            by_hash.setdefault(hashlib.sha256(data).hexdigest(), []).append(rel)
            if p.suffix.lower() in ('.md', '.txt') and len(data) < 200_000:
                by_stem.setdefault(stem_key(p.name), []).append((rel, data))
        if p.suffix.lower() != '.md':
            continue
        try:
            text = data.decode('utf-8')
        except UnicodeDecodeError:
            findings['malformed'].append(dict(file=rel, problem='not UTF-8 text'))
            continue
        fm = front_matter(text)
        if fm is False:
            findings['malformed'].append(dict(file=rel, problem='front matter never closes'))
        if is_seed(rel) and fm is None:
            findings['malformed'].append(dict(file=rel, problem='seed has no front matter'))
        if sum(1 for line in text.splitlines() if line.lstrip().startswith('```')) % 2:
            findings['malformed'].append(dict(file=rel, problem='a code block is never closed'))
        body = re.sub(r'```.*?```', '', text, flags=re.S)
        body = re.sub(r'`[^`\n]*`', '', body)
        # Only real marker lines count, not markers quoted in prose or code.
        lines = [line.strip() for line in body.splitlines()]
        if lines.count(BEGIN) != lines.count(END) or lines.count(BEGIN) > 1:
            findings['malformed'].append(dict(file=rel, problem='folder map markers are not one matched pair'))
        for m in LINK.finditer(body):
            target = m.group(1).strip('<>')
            if re.match(r'^[a-z][a-z0-9+.-]*:', target, re.I) or target.startswith('#'):
                continue
            target = unquote(target.split('#')[0])
            if target and '<' not in target and not (p.parent/target).exists():
                findings['broken_links'].append(dict(file=rel, link=target))
        if is_seed(rel) and fm:
            own = seed_scope.get(scope_of(rel), set())
            value = fm_value(fm, 'supersedes')
            if value and value.lower() != 'none' and Path(value).name not in own:
                findings['orphaned_seeds'].append(dict(seed=rel, problem='supersedes a seed not in its own ' + scope_of(rel) + ': ' + value))
            links = fm_value(fm, 'links')
            for name in re.findall(r'[\w .-]+\.md', links or ''):
                if name.strip() not in own | seed_scope.get('Seeds', set()):
                    findings['orphaned_seeds'].append(dict(seed=rel, problem='links to a missing seed: ' + name.strip()))
    for rels in by_hash.values():
        if len(rels) > 1:
            findings['duplicates'].append(rels)
    exact = {r for group in findings['duplicates'] for r in group}
    for key, items in by_stem.items():
        if not key or len(items) < 2:
            continue
        for i in range(len(items)):
            for j in range(i + 1, len(items)):
                (a, da), (b, db) = items[i], items[j]
                if a in exact and b in exact:
                    continue
                if difflib.SequenceMatcher(None, da[:20000], db[:20000]).quick_ratio() >= 0.9 and \
                        difflib.SequenceMatcher(None, da[:20000], db[:20000]).ratio() >= 0.9:
                    findings['near_duplicates'].append([a, b])
    for ledger in sorted((root/'Jobs').glob('*/LEDGER.csv')):
        with ledger.open(newline='') as f:
            for row in csv.DictReader(f):
                dest = (row.get('destination') or '').strip()
                if row.get('status', '').strip() == 'imported' and dest and not (root/dest).exists() \
                        and not (root.parent/dest).exists():
                    findings['missing_files'].append(dict(ledger=ledger.relative_to(root).as_posix(), destination=dest))
    counts = {k: len(v) for k, v in findings.items()}
    total = sum(counts.values())
    return dict(status='CLEAN' if total == 0 else 'ISSUES_FOUND', counts=counts, files_checked=len(files),
                findings={k: v[:limit] for k, v in findings.items() if v},
                changed_nothing=True,
                coverage='Whole workspace except Originals, folders starting with _, history, caches and Plugin',
                next_action='Nothing to do' if total == 0 else
                'Report in three lines; fix only clearly reversible link renames; ask before anything else')


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    p.add_argument('--limit', type=int, default=20)
    a = p.parse_args()
    root = a.root.resolve()
    print(json.dumps(scan(root, a.limit), indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
