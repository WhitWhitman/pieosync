# Reusable MindMake release packaging

`mindmake_release.py` packages an **already prepared and reviewed** MindMake distribution. It does not prepare a new version, change labels inside files, renew review attestations, approve a release, update a release pointer, or publish anything. Keep source preparation and release approval in their existing governed workflow.

This helper is included in Brain/tools for preparing local releases. It reads a selected distribution and writes only a **new** ZIP and adjacent `.manifest.json` outside that source. Existing output paths are refused. Choose a report folder for verification copies; choose a release destination only when the exact release action is authorized.

## Usage

Use an existing output directory and a single portable root folder label:

```bash
python3 -B Brain/tools/mindmake_release.py \
  --source '/absolute/path/to/reviewed-distribution' \
  --output '/absolute/path/to/report/MINDMAKE-verification-copy.zip' \
  --root-label 'MINDMAKE reviewed version' \
  --require-helper Brain/tools/assistant.py \
  --require-helper Brain/tools/apple_reminders.py \
  --require-helper Brain/tools/apple_reminders.jxa \
  --require-helper Brain/tools/apple_reminders.applescript
```

Repeat `--require-helper` for required additions. Paths must identify files under `Brain/tools/`; they are checked for presence and inclusion. They do not create review approval or change the existing review fingerprint contract. The ZIP root label is packaging metadata only: the helper never substitutes this label into the source.

By default, no source or extracted Python is imported or executed. `verification: STATIC_ONLY` means static review/map/configuration checks and extraction byte/directory comparison passed. It does **not** claim executable boot acceptance.

For code that has already been reviewed and is trusted to execute, add:

```bash
--verify-package-code
```

This explicitly executes the extracted copy's `Brain/tools/mindmake.py boot --root ... --no-maintenance` and `check_map --root ...`, using `python3 -B` and `PYTHONDONTWRITEBYTECODE=1`. The copy is moved beneath a different parent and folder name first. Each command must pass, boot must resolve that moved root, and the complete extracted tree must remain byte-identical after each operation. Success reports `RELOCATED_BOOT_AND_MAP_PASS`.

**Execution is not sandboxed.** The flag is suitable for trusted reviewed package code. A malicious helper could affect files outside its extracted tree; the readback checks are validation, not containment. The helper never runs the original source's Python, the package's test suite, onboarding, background services, or native Apple scripts automatically.

## Checks and contents

The supported distribution layout is `Brain/.mindmake` with a schema-1 setup-review ledger and the current authored review-input contract. The static validator recomputes source hashes, review fingerprints and evidence hashes; rejects unanswered-intake violations and configured personal services; verifies map hashes/generation; and requires a matching current committed recovery snapshot. Every file used by those static checks must survive the packaging filter, including review evidence, fingerprint inputs, maps, inventory and committed snapshots. Review evidence must be Markdown under the setup-review directory. Each catalog row must declare a safe `selected_pdf` path covered by that same row's validated source hashes and included in the ZIP. A future change to the review schema or its fingerprint inputs requires an explicit tool update and tests; changing a version label alone does not.

Packaging preserves empty directories, including each catalog job's Products, Research and Short-term/Long-term seed folders, all selected files, and the **current generation's committed** map recovery snapshot. It excludes old map generations and preimages, repair history, assistant/MCP/download/rollover runtime state, generated directories, root folders beginning with `_`, caches, lock/temp files, database runtime files and macOS sidecars. Existing reviewed publications remain byte-identical. This is a bounded packaging filter, not a general personal-data or secret detector.

Symlinks anywhere in the source tree, including excluded folders, hard-linked files, special files, portable-name collisions and unsafe member paths are refused. Supplied source/output paths must not traverse symlink ancestors; on macOS use the resolved `/private/...` spelling for temporary directories rather than `/tmp` or `/var`. Output cannot be inside the source. All archive members are checked for exact unique membership and CRC before extraction.

ZIP metadata uses fixed timestamps, permissions, ordering and compression settings. The manifest contains every included file hash, included directories, a hash of the entire original source tree including exclusions, the archive hash, review/source counts and verification results. It deliberately omits output paths and timestamps, so two runs with identical source, root label and verification options produce matching ZIPs **and manifests** in the same Python/zlib environment. Cross-zlib compressed-byte reproducibility is not promised.

The source tree is compared before and after packaging. New output files are flushed and read back. The helper does not claim atomic two-file publication or concurrent-writer safety on ExFAT, and the selected source/output directory must remain quiescent during a run. A crash between output writes can leave an incomplete pair; inspect it and select a new output name rather than overwriting it. These report artifacts do not select or replace the current release.

## Tests

```bash
python3 -B -m unittest discover -s Brain/tools/tests -p test_mindmake_release.py -v
```

Tests build synthetic reviewed packages in temporary directories and cover reproducibility, untouched source, required folders/snapshots, stale reviews/catalog/evidence, configuration gating, unsafe paths/links, no overwrite, default no execution, relocated boot and detection of writes by extracted helpers.

## X1.5 dependency and privacy extension

The optional review-input contract also binds the X1.5 local resolver, compact review, correction/work/task/skill/release helpers, case corpora, procedures and skill registry when present. Any addition, removal or changed bytes invalidates prior reviews; this does not renew them. Work-records, corrections and reports directories are excluded in both authoring and Brain layouts so personal samples and receipts are not shipped. Required review evidence remains included.
