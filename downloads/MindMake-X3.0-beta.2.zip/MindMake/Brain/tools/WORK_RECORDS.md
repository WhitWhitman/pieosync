# Intent, outcomes and attention

Use `Brain/tools/mindmake_work.py` alongside the existing task report/JOB record for
substantial or recurring work. Tiny edits can keep these fields in the existing
report. This is a local evidence journal, not another task queue or agent runner.
It never sends messages, executes a repair, approves work, or closes assistant
commitments. Those operations keep their existing owner and authorization.

## Capture once from the existing request

Preserve the original request verbatim, then state scope, owner, constraints and
one or more acceptance criteria. Do not repeatedly interview the user for information
already present. Ask only when a missing fact would change the work. Link the
frozen intent record from the existing plan; avoid duplicated competing specs.

Create a small JSON definition:

```json
{
  "id": "phone-check-example",
  "request": "Confirm the reminder reaches my iPhone",
  "owner": "the user",
  "scope": "Existing enrolled reminder only",
  "constraints": ["Do not send SMS or create duplicate reminders"],
  "sources": ["Brain/Reports/my-task/INTENT.md"],
  "criteria": [
    {
      "id": "phone",
      "outcome": "the user sees the alert on the iPhone",
      "check": "Read an explicit observation from the user",
      "kind": "user_observation"
    }
  ]
}
```

`python3 Brain/tools/mindmake_work.py init --file definition.json`

The source must already exist inside the canonical workspace. Store precise
acceptance kinds: `check`, `artifact`, `deployment`, `user_observation`. Freeze
intent sources; put evolving progress in later events. If intent changes, create
a new revision ID and link it from the task report rather than overwriting the
old definition. Local `Brain/.mindmake/work-records/ID/` is personal runtime and must
not enter a customer ZIP. Use the task's existing report for discovery.

## Review each criterion against the requested result

A JSON observation has an event ID, criterion ID, matching kind, observer,
`state` (`observed`, `pending`, `failed`), note and evidence paths:

```json
{
  "id": "phone-still-pending",
  "criterion": "phone",
  "kind": "user_observation",
  "observer": "Current session agent",
  "state": "pending",
  "note": "Mac-side sync succeeded; no phone observation supplied",
  "evidence": ["Brain/Reports/my-task/sync-result.json"]
}
```

```sh
python3 Brain/tools/mindmake_work.py result phone-check-example --file observation.json
python3 Brain/tools/mindmake_work.py status phone-check-example
```

A missing criterion stays pending. A check cannot satisfy a criterion whose
kind is user observation. `OBSERVED` means every criterion has a matching,
attributed observation and current referenced file hashes. It does not mean
Python verified the note's truth. Review the evidence substance, author and scope;
never label a local test `user_observation` just to satisfy the kind check.
A changed definition source or current result evidence makes the result stale.
A later failed/pending observation can reopen a previously observed criterion.
Unknown/malformed entries fail visibly. Receipts remain historical evidence;
changing a superseded receipt's source does not erase a later valid observation.

## Failure to proposal

For a failed result include `cause` (use `UNKNOWN` until investigated) and
`suggestion`. The event automatically carries an unapproved `PROPOSED` repair,
the current owner/scope, the failure evidence and the criterion's regression
check. Repeating the same event ID and content does not create another proposal;
reusing it for different evidence is refused. There is no execute/approve command.
A later result resolves or replaces the criterion's current disposition; old
failure events remain in its history.

For an actual scoped review failure, preserve the observed error in the existing
run report. Use that work's definition, or initialize a narrowly scoped record
from the existing authorized task and failure evidence. Record the failed result
with an investigation/repair suggestion and exact next check. An unverified cause
stays UNKNOWN. A suspected fault or monitoring alert does not authorize unrelated
changes. If canonical authority/storage is unavailable, report the blocker;
do not create a substitute workspace just to save a proposal.

## Measure attention requested from the user

Use `attention WORK_ID --file sample.json` for a manually observed interval. The
sample requires a unique `id`, offset-aware `start`/`end`, `observer`, `evidence`
paths and all four explicit integer `counts`:

- `repeated_explanations`: the user had to repeat information already supplied for this work.
- `unnecessary_questions`: questions whose answers were already available or immaterial.
- `missed_followups`: an agreed check-back for this work was missed, with evidence.
- `reopened_mistakes`: a previously corrected mistake recurred in this work.

Count observable instances, not inferred frustration. Never infer a due date to
create a missed-follow-up count. Avoid sensitive personal identifiers in notes.
Windows must have elapsed, be nonempty and not overlap within the work record.
Exact duplicate IDs/content are idempotent. If any category is unknown, do not
submit an all-zero sample; leave the period unmeasured or narrow it to an observed
interval with sufficient evidence. `NOT_MEASURED` means no sample, not zero cost.

Status reports the observed duration and counts, or STALE when sample evidence
changed. Counts are attributed measurements, not automatic telemetry, population
rates, or proof of improvement. Keep separate work scopes separate; do not sum
overlapping work records as independent time. Compare similarly observed tasks
before claiming attention savings. No global inbox, message or account scan is
part of this measurement.

## Changes and handoff

Run [TASK_EVAL.md](TASK_EVAL.md) after relevant skill, helper, or model changes.
Keep fixture mechanics, recorded model decisions and live user acceptance
separate. A green unit suite does not establish that the selected model can do
the work. Preserve the original request and a per-criterion evidence/disposition
summary in the final handoff, plus unresolved user-visible acceptance.

This journal reuses the existing local append/create/readback helpers. It is not
an immutable storage system, permission sandbox, or concurrent-writer guarantee.
Use one writer per work record; source hashes detect byte drift, not semantic
truth. Interrupted writes remain visible errors for recovery.

## Scoped corrections

`Brain/tools/mindmake_corrections.py` captures an immutable revision of an issue,
cause, scoped fix, acceptance criterion, evidence hashes and an explicit argv
check. Use `--start` before the subcommand when running from outside the package.
`capture ID --scope ... --issue ... --cause ... --fix ... --criteria ...
--source relative/path --command-json '["python3", "check.py"]'` creates an
UNVERIFIED record. Run `verify ID` only when that exact check is authorized;
a saved record never grants permission to execute its command. `status --scope
SCOPE` reads matching correction evidence. State lives in
`Brain/.mindmake/corrections/` and must be excluded from distributable archives.

A successful exit plus unchanged inputs records CHECK_PASSED, not model learning,
user acceptance or phone delivery. Changed evidence is STALE, changed inputs during
execution are SOURCE_CHANGED, and failed/binary-output checks retain failure
status. Preserve an existing revision and capture a new ID after a changed fix.
Both tools resolve the local dot locator through `mindmake_local.resolve_root`;
neither follows authoring-machine authority or external workspace pins.
