#!/usr/bin/env python3
"""Make new, empty MindMake workspaces from a clean template.

X3.0. Commands, run from the workspace folder:

  python3 Brain/tools/mindmake_clone.py approve --confirm-fresh-kit
      Kit maker only, on a fresh, never-used copy: records every kit file and its
      hash in Brain/tools/clean-kit-manifest.json (the allowlist).

  python3 Brain/tools/mindmake_clone.py template
      Builds "_Clean Template/MindMake-clean.zip" only from files on that allowlist.
      Refuses, and says why, if anything else is present: seeds, tasks, profile
      answers, user projects, Wiki subjects, downloads, any file not on the
      allowlist, a changed kit file, or anything that looks like a credential
      (every text file is scanned, with or without an extension).
      An existing zip is kept as a dated backup, never overwritten.

  python3 Brain/tools/mindmake_clone.py clone --name "Business 1"
      Unzips the template next to this workspace as "<name of this folder> (Business 1)",
      for example "MindMake (Business 1)". Refuses if that folder exists.
      Then runs boot and check_map on the new copy and reports the result.

The template folder starts with "_", so the folder map, boot and housekeeping
never read it. Nothing here deletes anything or touches the source workspace
beyond writing the template zip.
"""
import argparse
import base64
import datetime as dt
import gzip
import fnmatch
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import zipfile

TEMPLATE_DIR = '_Clean Template'
TEMPLATE_ZIP = 'MindMake-clean.zip'
# Runtime state and history: never part of a clean copy.
SKIP_STATE = {'assistant-state', 'corrections', 'downloads-watch', 'folder-map.pending.json',
              'map-changes.json', 'map-history', 'personal-mcp-runtime', 'personal-mcp-state',
              'repair-history', 'seed-rollovers', 'work-records', 'workspace-state'}
SKIP_NAMES = {'.DS_Store', '__pycache__', '.pytest_cache'}
SEED_POOLS = ('Short-term', 'Long-term', 'Dreams', 'TaskCycle')
MANIFEST = 'Brain/tools/clean-kit-manifest.json'
# Files the map tools rewrite on every update (and TODO.md, rewritten by the task tool).
# The template never copies these from the workspace: it writes the pristine copies saved
# at approval, so anything a user added to them can never leak into a clone.
GENERATED = ('FOLDER_MAP.md', 'TODO.md', '*INDEX.md', 'Jobs/*/JOB.md', 'Jobs/FILES.md', 'Seeds/SEEDS_MAP.md',
             'Seeds/Index/*', 'Brain/.mindmake/folder-map.json', 'Brain/.mindmake/folder-inventory.json')


def files_in(folder):
    return [p for p in folder.rglob('*') if p.is_file() and p.name != '.DS_Store'] if folder.is_dir() else []


def dirty_reasons(root):
    """Why this workspace is not a clean kit. Empty list means clean."""
    reasons = []
    for pool in SEED_POOLS:
        if files_in(root/'Seeds'/pool):
            reasons.append('Seeds/' + pool + ' has seeds')
    for job in sorted((root/'Jobs').iterdir()) if (root/'Jobs').is_dir() else []:
        page = job/'JOB.md'
        if page.is_file() and 'Type: User Project' in page.read_text(errors='replace'):
            reasons.append(job.relative_to(root).as_posix() + ' is a user project')
        for pool in ('Short-term', 'Long-term'):
            if files_in(job/'Seeds'/pool):
                reasons.append(job.relative_to(root).as_posix() + '/Seeds/' + pool + ' has seeds')
    for area in ('Wiki', 'Downloads'):
        extra = [p for p in files_in(root/area) if p.relative_to(root/area).as_posix() != 'INDEX.md']
        if extra:
            reasons.append(area + ' has ' + str(len(extra)) + ' file(s)')
    try:
        if json.loads((root/'Brain/.mindmake/intake.json').read_text()).get('answers'):
            reasons.append('setup answers are recorded (intake.json)')
    except (OSError, ValueError):
        reasons.append('Brain/.mindmake/intake.json is missing or unreadable')
    if (root/'Brain/.mindmake/workspace-state').exists():
        reasons.append('task records exist (workspace-state)')
    # The assistant role ships confirmed; the user and companion profiles must still be pending.
    for name in ('user.md', 'companion.md'):
        page = root/'Brain/Profiles'/name
        if page.is_file() and 'status: pending' not in page.read_text(errors='replace').lower():
            reasons.append('Brain/Profiles/' + name + ' is filled in')
    for rel, p in kit_files(root):
        # The kit's own tests hold fake credentials on purpose; the allowlist hash check covers them.
        if rel.startswith('Brain/tools/tests/') or p.stat().st_size > 2_000_000:
            continue
        if generated(rel) and (root/MANIFEST).is_file():
            continue  # never packed from the workspace; the pristine copy is used instead
        try:
            text = p.read_bytes().decode('utf-8')
        except UnicodeDecodeError:
            continue  # binary (PDF, zip, image): not scanned as text
        # "hunter2" is the well-known fake password used in a shipped SkillMaster test case.
        if any('hunter2' not in m.group(0) for m in SECRET.finditer(text)):
            reasons.append(rel + ' looks like it holds a credential')
    return reasons


# A basic check for obvious credentials, not a full secret scanner.
SECRET = re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----|\bsk-[A-Za-z0-9_-]{20,}|\bAKIA[0-9A-Z]{16}\b'
                    r'|\bgh[pousr]_[A-Za-z0-9]{30,}|(?i:\b(?:password|passwd|api[_-]?key|secret[_-]?key|token)\b\s*[:=]\s*["\']?[^\s"\'<>()]{8,}(?![\w.(]))')


def keep(rel):
    parts = PurePosixPath(rel).parts
    if parts[0].startswith('_') or any(p in SKIP_NAMES for p in parts):
        return False
    if parts[:2] == ('Brain', '.mindmake') and len(parts) > 2 and parts[2] in SKIP_STATE:
        return False
    return not rel.endswith(('.pyc', '.tmp'))


def kit_files(root):
    for p in sorted(root.rglob('*')):
        rel = p.relative_to(root).as_posix()
        if p.is_file() and not p.is_symlink() and keep(rel):
            yield rel, p


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def generated(rel):
    return any(fnmatch.fnmatchcase(rel, pat) for pat in GENERATED)


def approve(root, confirmed):
    if not confirmed:
        return dict(status='REFUSED', reasons=['Only for a fresh, never-used kit: add --confirm-fresh-kit'])
    reasons = dirty_reasons(root)
    if reasons:
        return dict(status='REFUSED', reasons=reasons)
    files, pristine = {}, {}
    for rel, p in kit_files(root):
        if rel == MANIFEST:
            continue
        files[rel] = sha(p)
        if generated(rel):
            pristine[rel] = base64.b64encode(gzip.compress(p.read_bytes(), mtime=0)).decode()
    (root/MANIFEST).parent.mkdir(parents=True, exist_ok=True)
    (root/MANIFEST).write_text(json.dumps(dict(schema_version=2, files=files, pristine=pristine), indent=1, sort_keys=True))
    return dict(status='APPROVED', files=len(files), manifest=MANIFEST,
                next_action='Log the manifest with note_change, run update_map, then template')


def allowlist_reasons(root):
    try:
        manifest = json.loads((root/MANIFEST).read_text())
        allowed = manifest['files']
        if manifest.get('schema_version') != 2:
            raise ValueError
    except (OSError, ValueError, KeyError):
        return ['No clean-kit allowlist (' + MANIFEST + '); the kit maker runs approve on a fresh kit']
    reasons = []
    for rel, p in kit_files(root):
        if rel == MANIFEST:
            continue
        if rel not in allowed:
            reasons.append('not part of the clean kit: ' + rel)
        elif not generated(rel) and sha(p) != allowed[rel]:
            reasons.append('kit file changed since approval: ' + rel)
    return reasons


def make_template(root):
    reasons = dirty_reasons(root) + allowlist_reasons(root)
    if reasons:
        return dict(status='REFUSED', reasons=reasons,
                    next_action='Build the template from a fresh, unused MindMake copy')
    folder = root/TEMPLATE_DIR
    folder.mkdir(exist_ok=True)
    out = folder/TEMPLATE_ZIP
    backup = None
    if out.exists():
        backup = folder/('MindMake-clean.' + dt.datetime.now().strftime('%Y%m%d-%H%M%S') + '.zip')
        out.rename(backup)
    count = 0
    manifest = json.loads((root/MANIFEST).read_text())
    allowed, pristine = set(manifest['files']) | {MANIFEST}, manifest.get('pristine', {})
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob('*')):
            rel = p.relative_to(root).as_posix()
            if p.is_symlink() or not keep(rel):
                continue
            if p.is_dir():
                z.writestr(rel + '/', '')
            elif p.is_file() and rel in allowed and not generated(rel):
                z.write(p, rel)
                count += 1
        for rel, blob in sorted(pristine.items()):
            z.writestr(rel, gzip.decompress(base64.b64decode(blob)))
            count += 1
    (folder/'README.md').write_text(
        '# Clean MindMake template\n\nA clean, empty copy of MindMake, used only by '
        '`python3 Brain/tools/mindmake_clone.py clone --name "<name>"`.\n'
        'Nothing else reads this folder. Don\'t put your own files here.\n')
    return dict(status='CREATED', template=out.relative_to(root).as_posix(), files=count,
                backup=backup.relative_to(root).as_posix() if backup else None)


def run(dest, *args):
    r = subprocess.run([sys.executable, '-B', str(dest/'Brain/tools/mindmake.py'), *args, '--root', str(dest)],
                       capture_output=True, text=True)
    try:
        out = json.loads(r.stdout)
    except ValueError:
        out = dict(status='FAIL', errors=[(r.stderr or r.stdout).strip()[-500:]])
    return out


def clone(root, name, parent=None):
    name = name.strip()
    if not name or not re.fullmatch(r"[A-Za-z0-9 ._&'-]{1,60}", name) or name.startswith('.'):
        return dict(status='REFUSED', reasons=['Use a short plain name, like "Personal" or "Business 1"'])
    zpath = root/TEMPLATE_DIR/TEMPLATE_ZIP
    if not zpath.is_file():
        return dict(status='REFUSED', reasons=['No clean template yet'],
                    next_action='Run: python3 Brain/tools/mindmake_clone.py template')
    base = re.sub(r'\s*\([^()]*\)$', '', root.name)
    dest = (Path(parent) if parent else root.parent)/(base + ' (' + name + ')')
    if dest.exists():
        return dict(status='REFUSED', reasons=[dest.name + ' already exists; nothing was changed'])
    dest.mkdir(parents=True)
    with zipfile.ZipFile(zpath) as z:
        for member in z.namelist():
            pure = PurePosixPath(member)
            if pure.is_absolute() or '..' in pure.parts:
                return dict(status='FAIL', reasons=['Unsafe path in template: ' + member], folder=str(dest))
        z.extractall(dest)
    boot = run(dest, 'boot')
    if boot.get('status') == 'FAIL':
        run(dest, 'rebuild_map')
        boot = run(dest, 'boot')
    check = run(dest, 'check_map')
    ok = boot.get('status') != 'FAIL' and check.get('status') == 'PASS'
    return dict(status='CREATED' if ok else 'CREATED_WITH_PROBLEMS', folder=str(dest),
                boot=boot.get('status'), check_map=check.get('status'),
                errors=(boot.get('errors') or []) + (check.get('errors') or []),
                next_action='Open the new folder in a new chat and say "load up"' if ok
                else 'Tell the user what failed; the new folder is kept for inspection')


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('operation', choices=['approve', 'template', 'clone', 'check'])
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    p.add_argument('--name')
    p.add_argument('--confirm-fresh-kit', action='store_true')
    p.add_argument('--parent', help='folder to create the clone in (default: next to this workspace)')
    a = p.parse_args()
    root = a.root.resolve()
    if a.operation == 'approve':
        result = approve(root, a.confirm_fresh_kit)
    elif a.operation == 'template':
        result = make_template(root)
    elif a.operation == 'check':
        reasons = dirty_reasons(root) + allowlist_reasons(root)
        result = dict(status='CLEAN' if not reasons else 'NOT_CLEAN', reasons=reasons)
    else:
        if not a.name:
            p.error('clone needs --name')
        result = clone(root, a.name, a.parent)
    print(json.dumps(result, indent=2))
    return 0 if result['status'] in ('CREATED', 'CLEAN', 'NOT_CLEAN', 'APPROVED') else 1


if __name__ == '__main__':
    sys.exit(main())
