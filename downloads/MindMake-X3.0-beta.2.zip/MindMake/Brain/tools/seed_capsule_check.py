#!/usr/bin/env python3
"""Seed capsule check — Seed Protocol v3.1.

Enforces the three fields the November 2025 empirical result recommends and the
Seed Capsule spec names: assertion (A), proof (K), uncertainty (U). Deterministic
and checkable: presence, minimum substance, and a proof that carries a number, a
file path, or a hash. It judges form, never whether a claim is true.

Seeds dated before ENFORCED_FROM are grandfathered and always pass.
Between ENFORCED_FROM and HARD_FROM the verdict is WARN instead of FAIL, so a
running lane is not broken mid-task by a change it has not read yet.

Boot safety is checked first and has no grandfathering or warn window: a seed
whose metadata the boot loader refuses (for example `supersedes:` carrying a
folder path instead of a bare filename) stops orientation for every session,
so it FAILs whatever its date. The check runs the loader's own selector, so
the two cannot drift apart.
"""

import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse, datetime, json, pathlib, re, sys, tempfile

ENFORCED_FROM = datetime.date(2026, 9, 18)   # seeds dated before this are exempt
HARD_FROM = datetime.date(2026, 9, 25)       # warn-only window ends here
FIELDS = ("assertion", "proof", "uncertainty")
EMPTY = {"none", "n/a", "na", "unknown", "none known", "tbd", "-", "none.", "nothing"}
PROOF = re.compile(r"\d|[A-Za-z0-9_\-/]+\.(md|py|json|txt|pdf|docx|xlsx|jsonl|html)|\b[0-9a-f]{12,64}\b")
DATED = re.compile(r"^(\d{4}-\d{2}-\d{2})")
LANE_SLUG = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*\Z")


def optional_fields(text):
    """Inspect optional fields independently of legacy capsule prose.

    Full YAML parsing is needed only for links. Without PyYAML, report that
    validation is unavailable; never silently claim a list was validated.
    Lane scalars use a bounded portable subset and need no YAML dependency.
    Invalid lane metadata stays in Pete's lane with a visible warning.
    """
    lines = text.lstrip('\ufeff').splitlines()
    result = {'source_lgi': '', 'optional_warnings': []}
    if not lines or lines[0].strip() != '---':
        return result
    end = next((i for i, line in enumerate(lines[1:], 1) if line.strip() == '---'), None)
    fields, key = {}, None
    for line in lines[1:end]:
        match = re.match(r'^([A-Za-z_][\w-]*):\s*(.*)$', line)
        if match:
            key = match[1]
            if key in ('links', 'source_lgi'):
                fields.setdefault(key, []).append([line])
        elif key in fields:
            fields[key][-1].append(line)
    for key, entries in fields.items():
        if end is None or len(entries) != 1:
            result['optional_warnings'].append(f'{key}: duplicate field or unclosed frontmatter')
            continue
        block = '\n'.join(entries[0])
        if key == 'links':
            try:
                import yaml
                value = yaml.safe_load(block)
                if not isinstance(value, dict) or not isinstance(value.get('links'), list):
                    raise ValueError('expected a YAML list')
            except ImportError:
                result['optional_warnings'].append('links: YAML validation unavailable; install PyYAML to validate lists')
            except (ValueError, yaml.YAMLError, RecursionError):
                result['optional_warnings'].append('links: must be a valid YAML list')
        else:
            raw = entries[0][0].split(':', 1)[1].strip()
            # Comments after a quoted value do not become part of the slug.
            match = re.fullmatch(r'''(?:"([a-z0-9-]*)"|'([a-z0-9-]*)'|([a-z0-9-]*))(?:\s+\#.*)?''', raw)
            if raw.startswith('#'):
                raw = ''
                match = re.fullmatch(r'(.*)', raw)
            value = next((v for v in match.groups() if v is not None), '') if match else None
            extra = [line for line in entries[0][1:] if line.strip() and not line.lstrip().startswith('#')]
            reserved = re.split(r'\s+#', raw, maxsplit=1)[0] in ('null', 'true', 'false', 'yes', 'no', 'on', 'off')
            if value is None or extra or reserved or (value and not LANE_SLUG.fullmatch(value)):
                result['optional_warnings'].append('source_lgi: must be empty or a lowercase hyphen-separated slug')
            else:
                result['source_lgi'] = value
    return result


def validate_lane(lane):
    if not isinstance(lane, str) or (lane != '*' and not LANE_SLUG.fullmatch(lane)):
        raise ValueError('Lane must be pete, a lowercase LGI slug (e.g. dreamweaver), or * for all lanes')
    return lane


def in_lane(source_lgi, lane):
    return lane == '*' or (source_lgi or 'pete') == lane


def boot_blocker(text, name="seed"):
    """Return the boot loader's refusal for this seed's own metadata, or None.

    Runs mindmake_seeds.select_recent_seeds on a one-seed scratch pool, so
    this is the loader's verdict, not a copy of its rules. It covers per-seed
    refusals (frontmatter shape, status, unsafe or self supersedes references,
    filename date). Pool-level refusals such as a cycle across several seeds or
    a reference present in both pools need the real pool and are not covered.
    """
    here = str(pathlib.Path(__file__).resolve().parent)
    if here not in sys.path:
        sys.path.insert(0, here)
    try:
        import mindmake_seeds
    except ImportError as exc:
        return None, "boot safety: loader unavailable (%s); not checked" % exc
    base = pathlib.Path(name).name
    if not (DATED.match(base) and base.endswith(".md")):
        base = "2000-01-01_000000_boot-safety-check.md"
    with tempfile.TemporaryDirectory() as tmp:
        pool = pathlib.Path(tmp) / "Seeds" / "Short-term"
        pool.mkdir(parents=True)
        (pool / base).write_bytes(text.encode("utf-8", "replace"))
        try:
            mindmake_seeds.select_recent_seeds(pool, 1)
        except RuntimeError as exc:
            return str(exc).replace(str(pool) + "/", ""), None
    return None, None


def seed_date(path):
    m = DATED.match(pathlib.Path(path).name)
    if not m:
        return None
    try:
        return datetime.date.fromisoformat(m.group(1))
    except ValueError:
        return None


def frontmatter(text):
    if not text.startswith("---"):
        return {}
    lines = text.splitlines()
    end = next((i for i, l in enumerate(lines[1:], 1) if l.strip() == "---"), None)
    if end is None:
        return {}
    out, key = {}, None
    for line in lines[1:end]:
        m = re.match(r"^([A-Za-z_][\w-]*):\s*(.*)$", line)
        if m:
            key = m.group(1).lower()
            out[key] = m.group(2).strip()
        elif key and line.strip():
            out[key] = (out[key] + " " + line.strip()).strip()
    return out


def check_text(text, name="seed", today=None):
    today = today or datetime.date.today()
    optional_warnings = optional_fields(text)['optional_warnings']
    blocker, unavailable = boot_blocker(text, name)
    if unavailable:
        optional_warnings = optional_warnings + [unavailable]
    if blocker:
        return {"verdict": "FAIL", "grandfathered": False, "missing": [], "seed": name,
                "boot_blocking": blocker, "optional_warnings": optional_warnings,
                "reasons": ["boot loader refuses this seed: %s" % blocker,
                            "one refused seed stops orientation for every session; no grace period. "
                            "supersedes takes a bare filename (see Seeds/SEED_TEMPLATE.md)"]}
    dated = seed_date(name)
    if dated and dated < ENFORCED_FROM:
        return {"verdict": "PASS", "grandfathered": True, "missing": [], "reasons":
                ["seed dated %s predates capsule enforcement" % dated], "seed": name,
                "boot_blocking": None, "optional_warnings": optional_warnings}
    fm = frontmatter(text)
    missing, reasons = [], []
    for field in FIELDS:
        value = (fm.get(field) or "").strip()
        low = value.lower().rstrip(".")
        if not value or low in EMPTY:
            missing.append(field)
            reasons.append("%s: missing or empty" % field)
            continue
        if field == "assertion" and len(value.split()) < 5:
            missing.append(field)
            reasons.append("assertion: fewer than 5 words, not a claim")
        elif field == "proof" and not PROOF.search(value):
            missing.append(field)
            reasons.append("proof: no number, file path or hash — nothing checkable")
        elif field == "uncertainty" and len(value.split()) < 3:
            missing.append(field)
            reasons.append("uncertainty: fewer than 3 words")
    if not missing:
        return {"verdict": "PASS", "grandfathered": False, "missing": [],
                "reasons": ["assertion, proof and uncertainty present"], "seed": name,
                "boot_blocking": None, "optional_warnings": optional_warnings}
    verdict = "FAIL" if today >= HARD_FROM else "WARN"
    reasons.append("warn-only until %s; hard after" % HARD_FROM if verdict == "WARN"
                   else "capsule fields required by Seed Protocol v3.1")
    return {"verdict": verdict, "grandfathered": False, "missing": missing,
            "reasons": reasons, "seed": name, "boot_blocking": None,
            "optional_warnings": optional_warnings}


def check_path(path, today=None):
    p = pathlib.Path(path)
    try:
        text = p.read_text(errors="replace")
    except (OSError, UnicodeError) as exc:
        return {"verdict": "FAIL", "missing": list(FIELDS), "seed": str(p),
                "reasons": ["unreadable seed: %s" % exc], "optional_warnings": []}
    return check_text(text, p.name, today)


GOOD = """---
status: active
scope: general
created: 2026-09-18
assertion: Capsule fields are enforced at the save ledger rather than at write time
proof: tools/seed_capsule_check.py selftest, 9 cases
uncertainty: unknown whether lanes will bounce more than once each
---
# body
"""
CASES = [
    (GOOD, "2026-09-18_120000_x.md", "PASS"),
    (GOOD.replace("assertion: Capsule fields are enforced at the save ledger rather than at write time\n", ""), "2026-09-18_120000_x.md", "FAIL"),
    (GOOD.replace("proof: tools/seed_capsule_check.py selftest, 9 cases", "proof: it worked"), "2026-09-18_120000_x.md", "FAIL"),
    (GOOD.replace("uncertainty: unknown whether lanes will bounce more than once each", "uncertainty: none"), "2026-09-18_120000_x.md", "FAIL"),
    (GOOD.replace("assertion: Capsule fields are enforced at the save ledger rather than at write time", "assertion: fixed it"), "2026-09-18_120000_x.md", "FAIL"),
    (GOOD, "2026-05-01_120000_old.md", "PASS"),
    (GOOD.replace("proof: tools/seed_capsule_check.py selftest, 9 cases", "proof: x"), "2026-05-01_120000_old.md", "PASS"),
    ("no frontmatter at all\n", "2026-09-18_120000_x.md", "FAIL"),
    (GOOD.replace("proof: tools/seed_capsule_check.py selftest, 9 cases", "proof: sha 9e755f9446807a578f9c matches on reopen"), "2026-09-18_120000_x.md", "PASS"),
    # 2026-09-18/19 boot outage: a folder path in supersedes blocked every boot.
    (GOOD.replace("scope: general\n", "scope: general\nsupersedes: Seeds/Short-term/2026-09-17_120000_old.md\n"), "2026-09-18_120000_x.md", "FAIL"),
    (GOOD.replace("scope: general\n", "scope: general\nsupersedes: 2026-09-17_120000_old.md\n"), "2026-09-18_120000_x.md", "PASS"),
]


def selftest():
    hard = datetime.date(2026, 10, 1)   # past HARD_FROM, so failures are FAIL
    ok = True
    for text, name, expect in CASES:
        got = check_text(text, name, hard)["verdict"]
        if got != expect:
            ok = False
        print("%s %-28s expected %-4s got %s" % ("ok " if got == expect else "FAIL", name, expect, got))
    soft = check_text(CASES[1][0], "2026-09-18_120000_x.md", datetime.date(2026, 9, 19))["verdict"]
    if soft != "WARN":
        ok = False
    print("%s warn-window case              expected WARN got %s" % ("ok " if soft == "WARN" else "FAIL", soft))
    boot = check_text(CASES[-2][0], "2026-09-18_120000_x.md", datetime.date(2026, 9, 19))["verdict"]
    if boot != "FAIL":
        ok = False
    print("%s boot-blocker in warn window   expected FAIL got %s" % ("ok " if boot == "FAIL" else "FAIL", boot))
    print("selftest: %s (%d cases)" % ("PASS" if ok else "FAIL", len(CASES) + 2))
    return 0 if ok else 2


def main():
    ap = argparse.ArgumentParser(description="Seed capsule check (Seed Protocol v3.1)")
    ap.add_argument("command", choices=["check", "scan", "selftest"])
    ap.add_argument("paths", nargs="*")
    a = ap.parse_args()
    if a.command == "selftest":
        return selftest()
    targets = []
    for p in a.paths:
        path = pathlib.Path(p)
        targets.extend(sorted(x for x in path.glob("*.md") if not x.name.startswith("._"))
                       if path.is_dir() else [path])
    results = [check_path(t) for t in targets]
    if a.command == "scan":
        counts = {}
        for r in results:
            counts[r["verdict"]] = counts.get(r["verdict"], 0) + 1
        print(json.dumps({"scanned": len(results), "counts": counts,
                          "optional_warnings": [{"seed": r['seed'], "warnings": r['optional_warnings']}
                                                for r in results if r['optional_warnings']],
                          "not_passing": [{"seed": r["seed"], "missing": r["missing"]}
                                          for r in results if r["verdict"] != "PASS"][:25]}, indent=2))
        return 0
    for r in results:
        print(json.dumps(r, indent=2))
    return 0 if all(r["verdict"] != "FAIL" for r in results) else 2


if __name__ == "__main__":
    sys.exit(main())
