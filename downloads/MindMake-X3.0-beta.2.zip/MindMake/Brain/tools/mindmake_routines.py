#!/usr/bin/env python3
"""One shared "last run" log for MindMake's regular routines. X3.0.

Nothing runs between chats. Instead, boot reads this log once at the start of a
chat and says what is due:

  daily  (first chat of the day):  deepsleep_clean (boot runs it itself, read-only),
                                   overdue_check   (you: one line on what slipped)
  weekly (first chat of the week): weekly_recap    (you: the five-line recap),
                                   dreamweaver     (you: patterns across seeds, DreamWeaver helper)
  every chat:                      downloads intake, and the switch change check
                                   while a switch to MindMake is running

After you finish one of "your" routines, record it so later chats skip it:
  python3 Brain/tools/mindmake_routines.py mark --routine weekly_recap
See what's due without running anything:
  python3 Brain/tools/mindmake_routines.py status

Routines never interrupt the user's work. Do them after the user's task, and
mention them only when something needs attention. If a chat ends before a
routine is done, it is simply still due next time.
"""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse
import datetime as dt
import importlib.util
import json
from pathlib import Path
import sys

LOG = 'Brain/.mindmake/work-records/last-run.json'
DAILY = ('deepsleep_clean', 'overdue_check')
WEEKLY = ('weekly_recap', 'dreamweaver')
WHAT = dict(
    deepsleep_clean='Brain clean: boot ran it; mention issues in one line, sort them after the task',
    overdue_check='One line on overdue tasks and follow-ups (TODO.md, assistant.py status); skip if none',
    weekly_recap='Five-line weekly recap (AGENTS.md, Weekly recap)',
    dreamweaver='DreamWeaver pattern pass across recent seeds, if there are enough seeds; offer, never force')


def period(routine, today):
    if routine in DAILY:
        return today.isoformat()
    year, week, _ = today.isocalendar()
    return '%d-W%02d' % (year, week)


def read_log(root):
    try:
        data = json.loads((root/LOG).read_text())
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def mark(root, routine, today=None, note=None):
    if routine not in DAILY + WEEKLY:
        raise ValueError('Unknown routine: ' + routine)
    today = today or dt.date.today()
    log = read_log(root)
    log[routine] = dict(period=period(routine, today), at=dt.datetime.now().astimezone().isoformat(timespec='seconds'),
                        **({'note': note} if note else {}))
    path = root/LOG
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(log, indent=2, sort_keys=True))
    tmp.replace(path)
    return dict(status='RECORDED', routine=routine, period=log[routine]['period'])


def due(root, today=None):
    today = today or dt.date.today()
    log = read_log(root)
    return [r for r in DAILY + WEEKLY if (log.get(r) or {}).get('period') != period(r, today)]


def switch_running(root):
    try:
        spec = importlib.util.spec_from_file_location('workspace', root/'Brain/tools/workspace.py')
        sys.path.insert(0, str(root/'Brain/tools'))
        ws = importlib.util.module_from_spec(spec); spec.loader.exec_module(ws)
        return any((t.get('project') or '') == 'Jobs/Switch to MindMake' for t in ws.status(root)['open_tasks'])
    except Exception:
        return (root/'Jobs/Switch to MindMake/PLAN.md').is_file()


def startup(root, today=None, allow_write=True):
    """Called by boot. Fast; the only thing it runs itself is the read-only brain clean."""
    today = today or dt.date.today()
    pending = due(root, today)
    result = dict(due=[dict(routine=r, what=WHAT[r]) for r in pending if r != 'deepsleep_clean'],
                  every_chat=['downloads intake'] + (['switch change check (Brain/MIGRATION.md section 6)'] if switch_running(root) else []),
                  brain_clean=dict(status='SKIPPED', reason='already ran today'))
    if 'deepsleep_clean' in pending:
        if not allow_write:
            result['brain_clean'] = dict(status='NOT_RUN', reason='read-only boot')
        else:
            spec = importlib.util.spec_from_file_location('mindmake_clean', root/'Brain/tools/mindmake_clean.py')
            cleaner = importlib.util.module_from_spec(spec); spec.loader.exec_module(cleaner)
            found = cleaner.scan(root, 3)
            result['brain_clean'] = dict(status=found['status'], issues={k: v for k, v in found['counts'].items() if v},
                                         examples=found.get('findings', {}))
            mark(root, 'deepsleep_clean', today)
    try:  # GUARD section 10: show active overrides
        spec = importlib.util.spec_from_file_location('mindmake_overrides', root/'Brain/tools/mindmake_overrides.py')
        mo = importlib.util.module_from_spec(spec); spec.loader.exec_module(mo)
        result['overrides'] = mo.summary(root)
    except Exception:
        result['overrides'] = dict(active=[], review_due=[])
    result['rule'] = ('Startup adds at most one line for all of this, only if something needs attention. '
                      'Do due routines after the user\'s task, then mark them.')
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('operation', choices=['status', 'mark'])
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    p.add_argument('--routine', choices=DAILY + WEEKLY)
    p.add_argument('--note')
    a = p.parse_args()
    root = a.root.resolve()
    if a.operation == 'mark':
        if not a.routine:
            p.error('mark needs --routine')
        result = mark(root, a.routine, note=a.note)
    else:
        result = dict(status='OK', due=due(root), log=read_log(root))
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
