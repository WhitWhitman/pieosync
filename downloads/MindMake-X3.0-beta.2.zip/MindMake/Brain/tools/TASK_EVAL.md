# Task outcome regressions

This helper checks actual package-local helper workflows in disposable temporary fixtures,
and scores recorded model decisions against a separate fixed corpus. It does not
run a model, call an API, touch native Reminders, or modify the personal ledger.
Fixture success does not establish phone delivery, fresh-model recovery, producer
acceptance, or general reliability.

Use the canonical workspace. Supply the actual model identity, revision and host;
use the literal `unknown` for unavailable values. Provenance is operator reported,
not independently attested. No result establishes model equivalence. Do not claim
an unknown revision is the same as an earlier run.

```sh
python3 -B Brain/tools/mindmake_task_eval.py run --model gpt-6-astra --revision unknown --host Codex
python3 -B Brain/tools/mindmake_task_eval.py packet --model gpt-6-astra --revision unknown --host Codex > /tmp/task-packet.json
python3 -B Brain/tools/mindmake_task_eval.py score --model gpt-6-astra --revision unknown --host Codex --observations /tmp/task-observations.json
python3 -B -m unittest Brain.tools.tests.test_task_eval
```

Save packet/output in a new report path; shell redirection overwrites existing
files, so check the destination first. Give only the blind packet to a fresh model
context. Ask it to follow the packet's response schema and save its actual answer
without editing decisions. Do not give it the corpus, implementation or tests.
Those contain the answer key. No observation is generated from the key by the CLI.

The score contract requires exactly one known choice key for each case, a nonempty
rationale, exact model provenance, and the current fingerprint. Every case must
match its fixed expected decision; there is no partial pass. Missing, duplicate,
unknown, invalid, incorrect and stale observations fail with nonzero exit status.
Rationale presence is checked; its semantic quality is not scored. Tests use
synthetic observations only to validate the scorer and are not model outcomes.

The fingerprint freezes corpus, helper, tests, docs, package-local authority locator,
verified engine files, shared workspace skill, scoped procedures
and governance, including FOLLOW_THROUGH.md, WORKFLOW_IMPROVEMENT.md, Brain/governance/RUNTIME.md
and the active mindmake_review.py implementation, plus the supplied model identity/revision/host. Changes require a
new packet and new observations. Score also serves as current observation status:
old results are invalid after any frozen input changes. Preserve raw observations,
packet, score, fixture result and hashes together. Hashes detect drift, not malicious
modification; this is a trusted local evidence helper rather than an attestation
or security boundary. It covers only the listed skill/procedure files.

`run` checks capture then a separate CLI process restart retaining owner, project,
next step and open status; repeated capture; changed-source refusal; simulated
enrolled completion imported once; simultaneous reminder conflict; and paused
sync making zero adapter calls. The engine is read only from this extracted package's Brain/tools directory and
its current file hashes are bound into provenance. No authoring-machine pins or
external authority are used; engine files are never edited by evaluation. All generated ledger/config/source data lives
under a temporary directory and is removed on exit. The reminder transport is
explicitly simulated; there are no native calls. Tests and fixture commands use
`-B` to avoid writing bytecode beside the installed engine.

## Package skill-choice probes

The separate `mindmake_skill_routes.py` reads the actual `Brain/SKILLS.md`
registry, including product wrappers and shared host/job entries. `audit` checks
registered wrapper paths and reports literal trigger overlaps as review candidates.
`packet` emits blind prompts with the current catalog/corpus fingerprint. Record
actual model choices as `{"fingerprint":"...","observations":[{"id":"R01a",
"selected":["PPI Export"]}]}` and use `score --observations FILE` for complete
scoring. Supply all cases exactly once. Unknown, duplicate, malformed, missing,
incorrect or stale choices cannot pass. A negative case can correctly select a
different installed skill or an empty list.

```sh
python3 -B Brain/tools/mindmake_skill_routes.py audit
python3 -B Brain/tools/mindmake_skill_routes.py packet
python3 -B Brain/tools/mindmake_skill_routes.py score --observations /tmp/skill-observations.json
```

The packaged corpus has 24 cases: explicit requests, paraphrases and negative
controls for eight installed targets. The scorer verifies recorded choices; it
does not route live host calls or establish task completion. Unit-test answers
are synthetic scorer fixtures and must never be presented as model observations.
