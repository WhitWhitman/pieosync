#!/usr/bin/env python3
"""Evidence-bound Wiki intake bookkeeping. The assistant reads and writes the knowledge."""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys

SPEC=importlib.util.spec_from_file_location('mindmake',Path(__file__).with_name('mindmake.py'))
mm=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(mm)
LEDGER='Brain/.mindmake/knowledge.json'

def state(root):
    return json.loads((root/LEDGER).read_text())

def verified(root,item):
    return (item.get('status')=='verified' and
            mm.digest(mm.read(mm.within(root,item['source'])))==item['source_sha256'] and
            bool(item.get('outputs')) and
            all(mm.digest(mm.read(mm.within(root,p)))==h for p,h in item['outputs'].items()))

def status(root):
    entries=[]
    for key,item in state(root)['items'].items():
        current=verified(root,item)
        map_ok=mm.verify(root)['status']=='PASS' if current else False
        entries.append(dict(id=key,source=item['source'],status='verified' if current and map_ok else 'mapped_pending' if current else 'stale' if item['status']=='verified' else item['status']))
    return dict(items=entries,pending=[x for x in entries if x['status']!='verified'],errors=[])

def register(root,source,metadata):
    if not source.startswith('Wiki/') or '/Sources/' not in source:
        raise ValueError('Knowledge originals belong in Wiki/<subject>/Sources/')
    sourcepath=mm.within(root,source)
    data=sourcepath.read_bytes();sha=mm.digest(data)
    if not data:raise ValueError('Source is empty')
    for field in ['title','creator','source_url','captured_at','published_at','epistemic_status']:
        if field not in metadata:raise ValueError('Missing metadata field '+field+'; use null when unknown')
    if not metadata['title'] or not metadata['captured_at'] or not metadata['epistemic_status']:
        raise ValueError('Title, capture date and epistemic status must be explicit')
    with mm.acquire(root):
        ledger=state(root)
        if sha in ledger['items']:
            item=ledger['items'][sha]
            if mm.digest(mm.read(mm.within(root,item['source'])))!=sha:
                raise ValueError('Existing source record changed; reconcile it before registering a duplicate')
            return dict(status='EXISTS',id=sha,source=item['source'],errors=[])
        ledger['items'][sha]=dict(source=source,source_sha256=sha,metadata=metadata,status='new',outputs={},registered_at=mm.now())
        if sourcepath.read_bytes()!=data:raise ValueError('Source changed during registration')
        mm.atomic(root/LEDGER,mm.encoded(ledger))
    mm.rebuild(root,[LEDGER,source])
    return dict(status='NEW',id=sha,errors=[])

def begin(root,key,force=False):
    with mm.acquire(root):
        ledger=state(root);item=ledger['items'][key]
        if mm.digest(mm.read(mm.within(root,item['source'])))!=item['source_sha256']:
            raise ValueError('Source changed; preserve both revisions and reconcile provenance')
        if not force and verified(root,item) and mm.verify(root)['status']=='PASS':return dict(status='ALREADY_VERIFIED',id=key,errors=[])
        item['status']='processing';item['started_at']=mm.now()
        mm.atomic(root/LEDGER,mm.encoded(ledger))
    mm.rebuild(root,[LEDGER,'/'.join(Path(item['source']).parts[:2])])
    return dict(status='PROCESSING',id=key,source=item['source'],source_sha256=item['source_sha256'],metadata=item['metadata'],errors=[])

def commit(root,key,evidence):
    """Check concrete output files and a read-coverage attestation, then verify maps."""
    with mm.acquire(root):
        ledger=state(root);item=ledger['items'][key]
        if item['status']!='processing':raise ValueError('Begin source processing before commit')
        source=mm.within(root,item['source']);sha=mm.digest(source.read_bytes())
        if sha!=item['source_sha256']:raise ValueError('Source changed while processing')
        for field in ['read_coverage','retrieval_seed','wiki_pages','claim_evidence','conflicts','open_issues']:
            if field not in evidence:raise ValueError('Missing evidence field '+field)
        if not evidence['read_coverage'] or not evidence['wiki_pages'] or not evidence['claim_evidence']:
            raise ValueError('Read coverage, Wiki output and claim evidence are required')
        if evidence['open_issues']:raise ValueError('Unresolved processing issues remain pending')
        outputs={}
        paths=[evidence['retrieval_seed'],*evidence['wiki_pages']]
        if len(paths)!=len(set(paths)):raise ValueError('Seed and Wiki pages must be distinct')
        for rel in paths:
            if not rel.startswith('Wiki/') or not rel.endswith('.md') or rel==item['source']:
                raise ValueError('Derived outputs must be separate Markdown files in Wiki')
            p=mm.within(root,rel);data=p.read_bytes();text=data.decode()
            if not text.strip():raise ValueError('Derived output is empty')
            if mm.link_errors(root,rel,text):raise ValueError('Broken links in '+rel)
            targets=[]
            for m in re.finditer(r'\[[^\]\n]+\]\((?:<([^>]+)>|([^\s)]+))\)',text):
                from urllib.parse import unquote
                target=unquote((m.group(1) or m.group(2)).split('#')[0])
                if not re.match('[a-zA-Z]+:',target):targets.append((p.parent/target).resolve())
            if source.resolve() not in targets:raise ValueError('Output must link directly to its original source: '+rel)
            outputs[rel]=mm.digest(data)
        seed=(root/evidence['retrieval_seed']).read_text()
        if len([line for line in seed.splitlines() if line.strip()])>5:raise ValueError('Retrieval seed must contain at most five nonempty lines')
        if seed.count('Load when:')!=1:raise ValueError('Retrieval seed needs exactly one Load when clause')
        if mm.digest(source.read_bytes())!=sha:raise ValueError('Concurrent source change')
        item.update(status='mapped_pending',outputs=outputs,evidence=evidence,processed_at=mm.now())
        mm.atomic(root/LEDGER,mm.encoded(ledger))
    # Registry completion precedes the verified label; failures remain resumable.
    mm.rebuild(root,[LEDGER,*paths])
    with mm.acquire(root):
        ledger=state(root);item=ledger['items'][key]
        if mm.digest(mm.read(root/item['source']))!=sha or any(mm.digest(mm.read(root/p))!=h for p,h in outputs.items()):
            raise ValueError('Evidence changed before verified commit')
        item['status']='verified';item['verified_at']=mm.now()
        mm.atomic(root/LEDGER,mm.encoded(ledger))
    try:
        mm.rebuild(root,[LEDGER])
    except (OSError,ValueError):
        with mm.acquire(root):
            ledger=state(root);ledger['items'][key]['status']='mapped_pending'
            mm.atomic(root/LEDGER,mm.encoded(ledger))
        raise
    return dict(status='VERIFIED',id=key,errors=[],evidence_type='File integrity plus assistant read-coverage attestation, not proof of semantic correctness')

def _cited_claims(root, rel, source):
    """Lines in a derived page that link straight to the original, with their locator."""
    from urllib.parse import unquote
    page=mm.within(root,rel); claims=[]
    for n,line in enumerate(page.read_text().splitlines(),1):
        for m in re.finditer(r'\[([^\]\n]+)\]\((?:<([^>]+)>|([^\s)]+))\)',line):
            raw=m.group(2) or m.group(3); target,_,fragment=unquote(raw).partition('#')
            if not re.match('[a-zA-Z]+:',target) and (page.parent/target).resolve()==source.resolve():
                claims.append(dict(page=rel,line=n,claim=line.strip()[:400],locator=fragment or m.group(1)))
    return claims

def ingest(root,source,metadata,seed,pages,read_coverage):
    """X3.0 one-command intake: register, begin, build evidence from inline citations, commit.

    The assistant still reads the source and writes the seed and pages; this only removes the
    hand-built JSON. Lines starting 'Conflict:' or 'Open issue:' in the pages are carried into the
    evidence, and any open issue keeps the source pending, exactly as before."""
    if not read_coverage or not str(read_coverage).strip():
        raise ValueError('--read must say what was actually read (pages, sections or timestamps)')
    for rel in [seed,*pages]: mm.within(root,rel).read_text()  # outputs must exist before intake
    mm.rebuild(root,[source,seed,*pages])  # map the new files first, so intake never trips on them
    reg=register(root,source,metadata); key=reg['id']
    item=state(root)['items'][key]; recorded=item.get('evidence') or {}
    if verified(root,item) and mm.verify(root)['status']=='PASS' and seed==recorded.get('retrieval_seed') \
            and set(pages)<=set(recorded.get('wiki_pages',[])):
        return dict(status='ALREADY_VERIFIED',id=key,registered=reg['status'],errors=[])
    # X3.0: new or different pages for a known source are checked, never waved through,
    # and pages verified earlier stay in the record.
    pages=list(dict.fromkeys([*(p for p in recorded.get('wiki_pages',[]) if mm.within(root,p).is_file()),*pages]))
    started=begin(root,key,force=True)
    src=mm.within(root,mm.within(root,source).relative_to(root).as_posix())
    claims,conflicts,issues=[],[],[]
    for rel in pages:
        claims+=_cited_claims(root,rel,src)
        for line in mm.within(root,rel).read_text().splitlines():
            t=line.strip().lstrip('-* ').strip()
            if t.lower().startswith('conflict:'): conflicts.append(dict(page=rel,note=t[9:].strip()))
            if t.lower().startswith('open issue:'): issues.append(dict(page=rel,note=t[11:].strip()))
    if not claims: raise ValueError('No claims cite the original inline; link the source next to each claim')
    evidence=dict(read_coverage=[str(read_coverage).strip()],retrieval_seed=seed,wiki_pages=list(pages),
                  claim_evidence=claims,conflicts=conflicts,open_issues=issues,built_by='knowledge.py ingest')
    if issues:
        return dict(status='PROCESSING',id=key,open_issues=issues,errors=[],
                    next_action='Resolve the open issues in the pages, then run ingest again')
    result=commit(root,key,evidence)
    return dict(result,registered=reg['status'],claims_cited=len(claims),conflicts=len(conflicts))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=['status','register','begin','commit','ingest'])
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument('--source');parser.add_argument('--metadata',type=Path)
    parser.add_argument('--id');parser.add_argument('--evidence',type=Path)
    for f in ('title','creator','url','published','status-label','seed','read'):parser.add_argument('--'+f)
    parser.add_argument('--pages',nargs='+')
    a=parser.parse_args();root=a.root.resolve()
    try:
        if a.operation=='status':result=status(root)
        elif a.operation=='register':result=register(root,a.source,json.loads(a.metadata.read_text()))
        elif a.operation=='begin':result=begin(root,a.id)
        elif a.operation=='ingest':
            meta=json.loads(a.metadata.read_text()) if a.metadata else dict(title=a.title,creator=a.creator,source_url=a.url,
                 captured_at=mm.now(),published_at=a.published,epistemic_status=a.status_label)
            result=ingest(root,a.source,meta,a.seed,a.pages or [],a.read)
        else:result=commit(root,a.id,json.loads(a.evidence.read_text()))
    except (OSError,ValueError,KeyError,TypeError,AttributeError) as e:result={'status':'FAIL','errors':[str(e)]}
    print(json.dumps(result,indent=2));return bool(result.get('errors'))

if __name__=='__main__':sys.exit(main())
