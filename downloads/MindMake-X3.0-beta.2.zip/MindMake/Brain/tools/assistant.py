#!/usr/bin/env python3
"""Scoped next-action ledger and optional SMS outbox. No scheduler or AI reader."""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse
import base64
from contextlib import contextmanager
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sqlite3
import time
import uuid
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from zoneinfo import ZoneInfo
import mindmake as mm

CONFIG = 'Brain/.mindmake/assistant.json'
DB = 'Brain/.mindmake/assistant-state/state.sqlite3'
TERMINAL = {'delivered', 'failed', 'undelivered', 'canceled'}
PROVIDER_STATES = {'accepted', 'queued', 'sending', 'sent'} | TERMINAL

def configure_layout(root):
    """Select storage only after the caller has resolved workspace authority."""
    global CONFIG, DB
    prefix = '.mindmake' if (root / '.mindmake/authority.json').is_file() else 'Brain/.mindmake'
    CONFIG = prefix + '/assistant.json'
    DB = prefix + '/assistant-state/state.sqlite3'

def stamp(value):
    parsed = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('Use a timezone-aware date and time')
    return parsed.astimezone(dt.timezone.utc)

def utc():
    return dt.datetime.now(dt.timezone.utc)

def ident(value):
    if not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}', value):
        raise ValueError('Use an opaque stable ID of 1 to 80 letters, digits, _ or -')
    return value

def config(root):
    c = json.loads(mm.within(root, CONFIG).read_text())
    if c.get('schema_version') != 1 or type(c.get('enabled')) is not bool:
        raise ValueError('Invalid assistant configuration')
    ZoneInfo(c['timezone'])
    for key in ['start', 'end']:
        if not re.fullmatch(r'(?:[01][0-9]|2[0-3]):[0-5][0-9]', c['quiet_hours'][key]):
            raise ValueError('Quiet hours must use HH:MM')
    if type(c['max_sms_per_day']) is not int or not 1 <= c['max_sms_per_day'] <= 20:
        raise ValueError('Daily SMS limit must be 1 to 20')
    if type(c['sms']['consented']) is not bool:
        raise ValueError('SMS consent must be explicit true or false')
    age = c.get('scheduler', {}).get('max_age_hours', 24)
    if type(age) not in (int, float) or not math.isfinite(age) or age <= 0:
        raise ValueError('Scheduler max_age_hours must be a positive finite number')
    return c

def runtime_lock(root, relative, timeout=15):
    """Reuse the existing portable advisory lock, waiting briefly for a writer."""
    deadline = time.monotonic() + timeout
    while True:
        try:
            return mm.acquire(root, relative)
        except ValueError as exc:
            if str(exc) != 'Another map writer holds the lock' or time.monotonic() >= deadline:
                raise
            time.sleep(0.01)

@contextmanager
def database(root):
    path = mm.within(root, DB)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    lock = runtime_lock(root, DB + '.init.lock')
    db = None
    try:
        # ExFAT needs first-open/WAL initialization serialized before connect.
        db = sqlite3.connect(path, timeout=15)
        os.chmod(path, 0o600)
        db.row_factory = sqlite3.Row
        if db.execute('PRAGMA journal_mode=WAL').fetchone()[0].lower() != 'wal':
            raise ValueError('Runtime storage requires SQLite WAL journaling')
        db.execute('PRAGMA synchronous=FULL')
        # Serialize schema upgrades as well as first creation across processes.
        db.execute('BEGIN IMMEDIATE')
        db.execute('''CREATE TABLE IF NOT EXISTS actions (
          id TEXT PRIMARY KEY, step TEXT NOT NULL, source TEXT NOT NULL,
          due TEXT, review_after TEXT, status TEXT NOT NULL, snoozed_until TEXT,
          created_at TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS reminders (
          id TEXT PRIMARY KEY, action_id TEXT NOT NULL, body TEXT NOT NULL,
          due TEXT NOT NULL, state TEXT NOT NULL, attempted_at TEXT,
          provider_id TEXT, error TEXT)''')
        columns = {row[1] for row in db.execute('PRAGMA table_info(actions)')}
        for name, declaration in [('project', "TEXT NOT NULL DEFAULT ''"),
                                  ('owner', "TEXT NOT NULL DEFAULT ''"),
                                  ('source_hash', 'TEXT'), ('last_reviewed_at', 'TEXT'),
                                  ('blocker', 'TEXT')]:
            if name not in columns:
                db.execute('ALTER TABLE actions ADD COLUMN ' + name + ' ' + declaration)
        db.execute('''CREATE TABLE IF NOT EXISTS events (
          sequence INTEGER PRIMARY KEY AUTOINCREMENT, action_id TEXT NOT NULL,
          kind TEXT NOT NULL, occurred_at TEXT NOT NULL, payload TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS scheduler_runs (
          run_id TEXT PRIMARY KEY, trigger TEXT NOT NULL, outcome TEXT NOT NULL,
          note TEXT NOT NULL, source_refs TEXT NOT NULL, recorded_at TEXT NOT NULL)''')
        db.commit()
        lock.close()
        yield db
    finally:
        if db is not None:
            db.close()
        lock.close()

def snapshot(root, path=None):
    """Online SQLite backup: capture WAL state without copying live database files."""
    source = mm.within(root, DB)
    if not source.is_file():
        raise ValueError('No runtime database exists to snapshot')
    path = path or str(Path(DB).parent / 'backups' / ('state-' + uuid.uuid4().hex + '.sqlite3'))
    target = mm.within(root, path)
    if target.exists() or target.with_suffix(target.suffix + '.json').exists():
        raise ValueError('Snapshot destination already exists; use a unique path')
    target.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive create is a collision check; random default names avoid ExFAT races.
    with target.open('xb'):
        pass
    original = sqlite3.connect(source.as_uri() + '?mode=ro', uri=True, timeout=15)
    backup = sqlite3.connect(target, timeout=15)
    try:
        if backup.execute('PRAGMA journal_mode=WAL').fetchone()[0].lower() != 'wal':
            raise ValueError('Snapshot storage requires SQLite WAL journaling')
        backup.execute('PRAGMA synchronous=FULL')
        original.backup(backup)
        integrity = backup.execute('PRAGMA integrity_check').fetchone()[0]
        if integrity != 'ok':
            raise ValueError('Snapshot integrity check failed')
        if backup.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0] != 0:
            raise ValueError('Snapshot checkpoint failed; backup is not ready')
    finally:
        backup.close()
        original.close()
    receipt = {'status': 'SNAPSHOT', 'path': path, 'integrity_check': integrity,
               'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'created_at': utc().isoformat()}
    with target.with_suffix(target.suffix + '.json').open('x') as out:
        json.dump(receipt, out, indent=2)
        out.flush()
        os.fsync(out.fileno())
    return receipt

def source_snapshot(root, source):
    if not isinstance(source, str) or not source.strip() or '://' in source:
        raise ValueError('A workspace-relative local source is required')
    path = mm.within(root, source.split('#', 1)[0])
    if not path.is_file():
        raise ValueError('Source is missing or is not a regular file')
    return hashlib.sha256(path.read_bytes()).hexdigest()

def event(db, action_id, kind, payload):
    db.execute('INSERT INTO events(action_id,kind,occurred_at,payload) VALUES (?,?,?,?)',
               (action_id, kind, utc().isoformat(), json.dumps(payload, sort_keys=True)))

def capture(root, action_id, step, source, project='', owner='', due=None, review_after=None):
    snapshot = source_snapshot(root, source)
    return _add(root, action_id, step, source, due, review_after, project, owner, snapshot)

def add(root, action_id, step, source, due=None, review_after=None):
    """Compatibility entrypoint; new local commitments should use capture."""
    return _add(root, action_id, step, source, due, review_after)

def _add(root, action_id, step, source, due=None, review_after=None, project='', owner='', snapshot=None):
    ident(action_id)
    if not step.strip() or not source.strip():
        raise ValueError('A next action and source reference are required')
    due = stamp(due).isoformat() if due else None
    review_after = stamp(review_after).isoformat() if review_after else None
    with database(root) as db, db:
        db.execute('BEGIN IMMEDIATE')
        previous = db.execute('SELECT * FROM actions WHERE id=?', (action_id,)).fetchone()
        if previous:
            if tuple(previous[k] for k in ['step', 'source', 'due', 'project', 'owner']) != (step, source, due, project, owner):
                raise ValueError('Existing action ID has different content; preserve its history')
            # Reviews may advance review_after; recapture never overwrites state.
            return dict(status='UNCHANGED', id=action_id)
        db.execute('''INSERT INTO actions
                   (id,step,source,due,review_after,status,snoozed_until,created_at,project,owner,source_hash)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
                   (action_id, step, source, due, review_after, 'open', None, utc().isoformat(), project, owner, snapshot))
        event(db, action_id, 'captured', {'step': step, 'source': source, 'source_hash': snapshot,
                                        'project': project, 'owner': owner, 'due': due, 'review_after': review_after})
    return dict(status='RECORDED', id=action_id)

def change(root, action_id, action, until=None, note=None):
    ident(action_id)
    if action not in ('done', 'snooze', 'resume'):
        raise ValueError('Unsupported action change')
    until = stamp(until).isoformat() if action == 'snooze' and until else None
    if action == 'snooze' and not until:
        raise ValueError('Snooze needs an explicit date')
    with database(root) as db, db:
        db.execute('BEGIN IMMEDIATE')
        previous = db.execute('SELECT * FROM actions WHERE id=?', (action_id,)).fetchone()
        if not previous:
            raise ValueError('Unknown action')
        if action == 'snooze' and previous['status'] == 'done':
            raise ValueError('Explicitly resume a completed action before snoozing')
        new_status = 'done' if action == 'done' else ('open' if action == 'resume' else previous['status'])
        if previous['status'] == new_status and previous['snoozed_until'] == until:
            return dict(status=action.upper(), id=action_id)
        db.execute('UPDATE actions SET status=?, snoozed_until=? WHERE id=?',
                   (new_status, until, action_id))
        event(db, action_id, action, {'previous_status': previous['status'], 'status': new_status,
                                     'until': until, 'note': note or 'Explicit user action'})
        if action == 'done':
            db.execute("UPDATE reminders SET state='canceled' WHERE action_id=? AND state='prepared'", (action_id,))
    return dict(status=action.upper(), id=action_id)

def review(root, action_id, expected_source_sha256, outcome, note, next_review=None):
    ident(action_id)
    if outcome not in ('open', 'blocked', 'done') or not isinstance(note, str) or not note.strip():
        raise ValueError('Review requires an open, blocked or done outcome and substantive evidence note')
    next_review = stamp(next_review).isoformat() if next_review else None
    with database(root) as db, db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT * FROM actions WHERE id=?', (action_id,)).fetchone()
        if not row:
            raise ValueError('Unknown action')
        current = source_snapshot(root, row['source'])
        if current != expected_source_sha256:
            raise ValueError('Source changed; reread it before recording a review')
        if row['status'] == 'done' and outcome != 'done':
            raise ValueError('Explicitly resume a completed action before reopening review')
        reviewed_at = utc().isoformat()
        db.execute('''UPDATE actions SET source_hash=?,last_reviewed_at=?,review_after=?,
                      status=?,blocker=? WHERE id=?''',
                   (current, reviewed_at, next_review, outcome, note if outcome == 'blocked' else None, action_id))
        event(db, action_id, 'reviewed', {'source': row['source'], 'source_hash': current,
                                        'outcome': outcome, 'note': note, 'next_review': next_review})
        if outcome == 'done':
            db.execute("UPDATE reminders SET state='canceled' WHERE action_id=? AND state='prepared'", (action_id,))
    return dict(status='REVIEWED', id=action_id, outcome=outcome, reviewed_at=reviewed_at)

def actions(root):
    """Read persisted records without creating or migrating a database."""
    path = mm.within(root, DB)
    if not path.exists():
        return []
    db = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
    try:
        db.row_factory = sqlite3.Row
        return [dict(row) for row in db.execute('SELECT * FROM actions ORDER BY due IS NULL,due,created_at,id')]
    finally:
        db.close()

def record_run(root, run_id, trigger, outcome, note, source_refs):
    ident(run_id)
    if outcome not in ('success', 'failed', 'blocked', 'unchanged') or not trigger or not note.strip() or not source_refs:
        raise ValueError('A run needs trigger, outcome, evidence note and source references')
    refs = []
    for ref in source_refs:
        source = ref['source'] if isinstance(ref, dict) else ref
        sha = source_snapshot(root, source)
        if isinstance(ref, dict) and ref.get('sha256') != sha:
            raise ValueError('Run source changed; reread it before recording receipt')
        refs.append({'source': source, 'sha256': sha})
    refs = json.dumps(sorted(refs, key=lambda x: x['source']), sort_keys=True)
    content = (trigger, outcome, note, refs)
    with database(root) as db, db:
        db.execute('BEGIN IMMEDIATE')
        previous = db.execute('SELECT * FROM scheduler_runs WHERE run_id=?', (run_id,)).fetchone()
        if previous:
            if tuple(previous[k] for k in ('trigger', 'outcome', 'note', 'source_refs')) != content:
                raise ValueError('Existing run ID has a different receipt')
            return dict(status='UNCHANGED', id=run_id)
        db.execute('INSERT INTO scheduler_runs VALUES (?,?,?,?,?,?)', (run_id, *content, utc().isoformat()))
    return dict(status='RECORDED', id=run_id)

def source_health(root, row, at):
    row = dict(row)
    row.update(source_missing=False, source_stale=False, source_unverified=not bool(row.get('source_hash')), current_source_hash=None)
    if row.get('source_hash'):
        try:
            current = source_snapshot(root, row['source'])
            row['current_source_hash'] = current
            row['source_stale'] = current != row['source_hash']
        except (ValueError, OSError):
            row['source_missing'] = True
    row['review_freshness'] = ('UNVERIFIED_SOURCE' if row['source_unverified'] else
                               'MISSING_SOURCE' if row['source_missing'] else
                               'SOURCE_CHANGED' if row['source_stale'] else
                               'OVERDUE' if row.get('review_after') and stamp(row['review_after']) <= at else
                               'OVERDUE' if not row.get('review_after') and row.get('last_reviewed_at') and
                               at - stamp(row['last_reviewed_at']) >= dt.timedelta(hours=24) else
                               'UNREVIEWED' if not row.get('last_reviewed_at') else 'CURRENT')
    return row

def scheduler_health(c, runs, at):
    scheduler = c.get('scheduler', {})
    configured = bool(scheduler.get('id')) and scheduler.get('status') not in ('NOT_CONFIGURED', 'PAUSED')
    observed = [r for r in runs if r['trigger'] == scheduler.get('id')]
    latest = observed[-1] if observed else None
    health = 'NOT_CONFIGURED' if not configured else 'CONFIGURED_UNVERIFIED'
    if configured and latest:
        age_hours = (at - stamp(latest['recorded_at'])).total_seconds() / 3600
        health = ('FAILED' if latest['outcome'] in ('failed', 'blocked') else
                  'STALE' if age_hours > float(scheduler.get('max_age_hours', 24)) or age_hours < 0 else 'OBSERVED')
    return {'status': health, 'configured': configured, 'last_run': latest}

def status(root, at=None):
    at = at or utc(); c = config(root)
    result = dict(enabled=c['enabled'], scheduler=c['scheduler'], connections=c['connections'],
                  runtime='HELPER_ONLY; no scheduler or autonomous source review', next_action=None,
                  reviews_due=[], reminders=[], open_actions=[],
                  scheduler_health=scheduler_health(c, [], at))
    # A status read must not create a runtime database.
    path = mm.within(root, DB)
    if not path.exists():
        return result
    db = sqlite3.connect(path.as_uri()+'?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    try:
        records = [source_health(root, x, at) for x in db.execute("SELECT * FROM actions WHERE status IN ('open','blocked') ORDER BY due IS NULL, due, created_at")]
        result['open_actions'] = records
        visible = [a for a in records if a['status'] == 'open' and (not a['snoozed_until'] or stamp(a['snoozed_until']) <= at)]
        result['next_action'] = visible[0] if visible else None
        result['reviews_due'] = [a['id'] for a in records if a['review_freshness'] != 'CURRENT' and (not a['snoozed_until'] or stamp(a['snoozed_until']) <= at)]
        result['reminders'] = [dict(x) for x in db.execute('SELECT id, action_id, state, attempted_at, provider_id, error FROM reminders ORDER BY due')]
        if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='scheduler_runs'").fetchone():
            runs = [dict(x) for x in db.execute('SELECT * FROM scheduler_runs ORDER BY recorded_at,run_id')]
            result['scheduler_health'] = scheduler_health(c, runs, at)
    finally:
        db.close()
    return result

def queue(root, reminder_id, action_id, body, due):
    ident(reminder_id); ident(action_id); due = stamp(due).isoformat()
    if not body.strip() or len(body) > 320:
        raise ValueError('Use a short reminder of 1 to 320 characters')
    with database(root) as db, db:
        action = db.execute('SELECT status FROM actions WHERE id=?', (action_id,)).fetchone()
        if not action or action['status'] != 'open':
            raise ValueError('Reminder needs an open action')
        previous = db.execute('SELECT * FROM reminders WHERE id=?', (reminder_id,)).fetchone()
        if previous:
            if tuple(previous[k] for k in ['action_id', 'body', 'due']) != (action_id, body, due):
                raise ValueError('Existing reminder ID has different content')
            return dict(status=previous['state'], id=reminder_id)
        db.execute('INSERT INTO reminders VALUES (?,?,?,?,?,?,?,?)',
                   (reminder_id, action_id, body, due, 'prepared', None, None, None))
    return dict(status='prepared', id=reminder_id)

class Twilio:
    """Credentials stay in the host environment; never include HTTP errors in output."""
    def __init__(self, c):
        values = [os.environ.get(k, '') for k in ['TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN', 'TWILIO_FROM_NUMBER', 'MINDMAKE_SMS_TO']]
        self.account, self.token, self.sender, self.recipient = values
        if not re.fullmatch(r'AC[a-fA-F0-9]{32}', self.account) or not self.token:
            raise ValueError('SMS provider setup is incomplete')
        if not all(re.fullmatch(r'\+[1-9][0-9]{6,14}', x) for x in [self.sender, self.recipient]):
            raise ValueError('SMS phone setup is incomplete')
        if hashlib.sha256(self.recipient.encode()).hexdigest() != c['sms'].get('recipient_sha256'):
            raise ValueError('SMS destination needs verification and consent')
    def request(self, sid=None, body=None):
        if sid and not re.fullmatch(r'SM[a-fA-F0-9]{32}', sid):
            raise ValueError('Invalid provider message ID')
        url = 'https://api.twilio.com/2010-04-01/Accounts/'+self.account+'/Messages'+('/'+sid if sid else '')+'.json'
        headers = {'Authorization': 'Basic '+base64.b64encode((self.account+':'+self.token).encode()).decode()}
        data = urlencode({'To': self.recipient, 'From': self.sender, 'Body': body}).encode() if body is not None else None
        if data: headers['Content-Type'] = 'application/x-www-form-urlencoded'
        with urlopen(Request(url, data=data, headers=headers), timeout=20) as response:
            value = json.load(response)
        return {'sid': value.get('sid'), 'status': value.get('status')}
    def send(self, body): return self.request(body=body)
    def poll(self, sid): return self.request(sid=sid)

def quiet(c, at):
    time = at.astimezone(ZoneInfo(c['timezone'])).strftime('%H:%M')
    start, end = c['quiet_hours']['start'], c['quiet_hours']['end']
    if start == end: return False
    return start <= time < end if start < end else time >= start or time < end

def checked_response(value, expected=None):
    sid, state = value.get('sid'), value.get('status')
    if not isinstance(sid, str) or not re.fullmatch(r'SM[a-fA-F0-9]{32}', sid) or state not in PROVIDER_STATES or (expected and sid != expected):
        raise ValueError('Unrecognized provider response')
    return sid, state

def send(root, reminder_id, at=None, transport=None):
    ident(reminder_id); at = at or utc(); c = config(root)
    if not c['enabled'] or not c['sms']['consented']:
        return dict(status='PAUSED_OR_NOT_AUTHORIZED', id=reminder_id)
    if quiet(c, at): return dict(status='QUIET_HOURS', id=reminder_id)
    transport = transport or Twilio(c)
    with database(root) as db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT * FROM reminders WHERE id=?', (reminder_id,)).fetchone()
        if not row: raise ValueError('Unknown reminder')
        if row['state'] != 'prepared': return dict(status=row['state'], id=reminder_id)
        action = db.execute('SELECT * FROM actions WHERE id=?', (row['action_id'],)).fetchone()
        if not action or action['status'] != 'open': return dict(status='ACTION_CLOSED', id=reminder_id)
        health = source_health(root, action, at)
        if health['source_unverified'] or health['source_stale'] or health['source_missing']:
            return dict(status='SOURCE_REVIEW_REQUIRED', id=reminder_id)
        if stamp(row['due']) > at or (action['snoozed_until'] and stamp(action['snoozed_until']) > at):
            return dict(status='NOT_DUE', id=reminder_id)
        local_day = at.astimezone(ZoneInfo(c['timezone'])).date()
        count = sum(stamp(x[0]).astimezone(ZoneInfo(c['timezone'])).date() == local_day
                    for x in db.execute('SELECT attempted_at FROM reminders WHERE attempted_at IS NOT NULL'))
        if count >= c['max_sms_per_day']: return dict(status='DAILY_LIMIT', id=reminder_id)
        db.execute("UPDATE reminders SET state='attempting', attempted_at=? WHERE id=?", (at.isoformat(), reminder_id))
        db.commit()  # Durable before network; a crash must not cause an automatic repeat.
        try:
            sid, state = checked_response(transport.send(row['body']))
            error = None
        except Exception:
            sid, state, error = None, 'unknown', 'Uncertain submission; reconcile provider history before any new send'
        with db:
            db.execute('UPDATE reminders SET state=?, provider_id=?, error=? WHERE id=?', (state, sid, error, reminder_id))
    return dict(status=state, id=reminder_id)

def poll(root, reminder_id, transport=None):
    c = config(root)
    if not c['enabled'] or not c['sms']['consented']:
        return dict(status='PAUSED_OR_NOT_AUTHORIZED', id=reminder_id)
    with database(root) as db:
        row = db.execute('SELECT * FROM reminders WHERE id=?', (ident(reminder_id),)).fetchone()
        if not row or not row['provider_id']:
            raise ValueError('No known provider ID; reconcile provider history')
        if row['state'] in TERMINAL: return dict(status=row['state'], id=reminder_id)
        try:
            sid, state = checked_response((transport or Twilio(c)).poll(row['provider_id']), row['provider_id'])
        except Exception:
            return dict(status='CHECK_FAILED', last_known_status=row['state'], id=reminder_id)
        with db: db.execute('UPDATE reminders SET state=?, error=NULL WHERE id=?', (state, reminder_id))
    return dict(status=state, id=reminder_id)

def pause(root):
    if CONFIG.startswith('Brain/'):
        with mm.acquire(root):
            c = config(root); c['enabled'] = False
            mm.atomic(mm.within(root, CONFIG), mm.encoded(c))
        mapped = mm.rebuild(root)
        return dict(status='PAUSED', maps=mapped['status'], note='Stop the host review schedule separately; already submitted messages may still arrive')
    # Canonical Cartographer owns its own map system; never run the X1.3 mapper.
    with runtime_lock(root, '.mindmake/assistant-config.lock'):
        c = config(root)
        backup = mm.within(root, str(Path(DB).parent / 'backups' / ('config-' + uuid.uuid4().hex + '.json')))
        backup.parent.mkdir(parents=True, exist_ok=True)
        with backup.open('x') as out:
            out.write(mm.within(root, CONFIG).read_text())
            out.flush(); os.fsync(out.fileno())
        c['enabled'] = False
        mm.atomic(mm.within(root, CONFIG), mm.encoded(c))
    return dict(status='PAUSED', backup=str(backup.relative_to(root)), note='Stop the host review schedule separately; already submitted messages may still arrive')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    sub = p.add_subparsers(dest='command', required=True)
    sub.add_parser('status')
    sub.add_parser('actions', aliases=['list'])
    sub.add_parser('pause')
    q = sub.add_parser('snapshot');q.add_argument('--path')
    addp = sub.add_parser('add');addp.add_argument('id');addp.add_argument('--step', required=True);addp.add_argument('--source', required=True);addp.add_argument('--due');addp.add_argument('--review-after')
    q = sub.add_parser('capture');q.add_argument('id');q.add_argument('--step', required=True);q.add_argument('--source', required=True);q.add_argument('--project', default='');q.add_argument('--owner', default='');q.add_argument('--due');q.add_argument('--review-after')
    q = sub.add_parser('review');q.add_argument('id');q.add_argument('--expected-source-sha256', required=True);q.add_argument('--outcome', required=True, choices=['open','blocked','done']);q.add_argument('--note', required=True);q.add_argument('--next-review')
    q = sub.add_parser('record-run');q.add_argument('id');q.add_argument('--trigger', required=True);q.add_argument('--outcome', required=True, choices=['success','failed','blocked','unchanged']);q.add_argument('--note', required=True);q.add_argument('--source', required=True, action='append')
    for name in ['done', 'resume', 'snooze']:
        q = sub.add_parser(name);q.add_argument('id')
        if name == 'snooze':q.add_argument('--until', required=True)
    q = sub.add_parser('queue');q.add_argument('id');q.add_argument('--action', required=True);q.add_argument('--body', required=True);q.add_argument('--due', required=True)
    for name in ['send', 'poll']:
        q = sub.add_parser(name);q.add_argument('id')
    a = p.parse_args(); root = a.root.resolve()
    configure_layout(root)
    try:
        if a.command == 'pause':
            result = pause(root)
        elif a.command == 'snapshot':result = snapshot(root, a.path)
        elif a.command == 'status':result = status(root)
        elif a.command in ('actions', 'list'):result = actions(root)
        elif a.command == 'add':result = add(root, a.id, a.step, a.source, a.due, a.review_after)
        elif a.command == 'capture':result = capture(root, a.id, a.step, a.source, a.project, a.owner, a.due, a.review_after)
        elif a.command == 'review':result = review(root, a.id, a.expected_source_sha256, a.outcome, a.note, a.next_review)
        elif a.command == 'record-run':result = record_run(root, a.id, a.trigger, a.outcome, a.note, a.source)
        elif a.command in ('done', 'resume', 'snooze'):result = change(root, a.id, a.command, getattr(a, 'until', None))
        elif a.command == 'queue':result = queue(root, a.id, a.action, a.body, a.due)
        elif a.command == 'send':result = send(root, a.id)
        else:result = poll(root, a.id)
        print(json.dumps(result, indent=2))
    except (ValueError, OSError, KeyError, sqlite3.Error) as e:
        # External exceptions can contain identifiers; keep them out of console logs.
        print(json.dumps({'status':'FAIL', 'error':str(e) if isinstance(e, ValueError) else 'Local setup or storage error; inspect configuration'}))
        raise SystemExit(1)

if __name__ == '__main__':main()
