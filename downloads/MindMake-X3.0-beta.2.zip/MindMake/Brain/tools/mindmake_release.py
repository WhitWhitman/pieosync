#!/usr/bin/env python3
"""Deterministic packaging of an already reviewed MindMake deployment. No source writes."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tempfile
import unicodedata
import zipfile

META = 'Brain/.mindmake/'
BEGIN = '<!-- MINDMAKE FOLDER MAP BEGIN -->'
END = '<!-- MINDMAKE FOLDER MAP END -->'
REVIEW_INPUTS = '''AGENTS.md MINDMAKE.md INTAKE.md GUARD.md Brain/governance/WORKSPACE_POLICY.md Brain/tools/mindmake.py Brain/tools/downloads_watch.py Brain/DOWNLOADS_WATCHER.md Brain/FIRST_WIN.md Brain/governance/FIRST_RUN_ACCEPTANCE.md Brain/WIKI_WORKFLOW.md Brain/tools/knowledge.py Brain/PERSONAL_ASSISTANT.md Brain/CAPABILITIES.md Brain/tools/assistant.py Brain/PERSONAL_MCP.md Brain/tools/personal_mcp.py Brain/MCP/personal_mcp_server.py'''.split()
OPTIONAL_REVIEW_INPUTS = ['Brain/tools/apple_reminders.'+suffix for suffix in ('py','jxa','applescript')] + ['Brain/tools/mindmake_seed_memory.py', 'Brain/tools/mindmake_seeds.py', 'Brain/tools/SEED_MEMORY_PROTOCOL.md', 'Brain/tools/mindmake_local.py', 'Brain/tools/mindmake_review.py', 'Brain/tools/mindmake_corrections.py', 'Brain/tools/mindmake_work.py', 'Brain/tools/mindmake_task_eval.py', 'Brain/tools/mindmake_skill_routes.py', 'Brain/tools/mindmake_release.py', 'Brain/tools/task-eval-cases.json', 'Brain/tools/skill-routing-cases.json', 'Brain/tools/WORKFLOW_IMPROVEMENT.md', 'Brain/tools/WORK_RECORDS.md', 'Brain/tools/TASK_EVAL.md', 'Brain/tools/FOLLOW_THROUGH.md', 'Brain/tools/RELEASE_TOOL.md']
EXCLUDED_DIRS = {'seed-memory','work-records','corrections','reports','repair-history','__pycache__','downloads-watch','seed-rollovers','assistant-state','personal-mcp-state','personal-mcp-runtime','generated','.git','.pytest_cache','.mypy_cache'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def safe_relative(value):
    """Portable member names: no traversal, Windows aliases or ambiguous components."""
    if not isinstance(value,str) or not value or '\\' in value or ':' in value:
        raise ValueError('Unsafe relative path: '+str(value))
    p = PurePosixPath(value)
    if not p.parts or p.is_absolute() or p.as_posix() != value:
        raise ValueError('Noncanonical relative path: '+value)
    for part in p.parts:
        if part in ('.','..') or part[-1:] in (' ','.') or any(ord(c)<32 or c in '<>"|?*' for c in part):
            raise ValueError('Unsafe path component: '+value)
        if re.fullmatch(r'(?i)(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?',part):
            raise ValueError('Reserved path component: '+value)
    return p


def reject_symlink_chain(path):
    # Resolve only after checking the supplied spelling, including existing ancestors.
    path = Path(os.path.abspath(path))
    for p in (path,*path.parents):
        if p.is_symlink():
            raise ValueError('Symlink/alias path refused: '+str(p))
    return path


def snapshot(root):
    """Inventory every entry, including excluded state; refuse links and special files."""
    result = {}
    portable = set()
    for base, dirs, names in os.walk(root, followlinks=False):
        for name in sorted(dirs+names):
            p = Path(base)/name
            rel = p.relative_to(root).as_posix()
            safe_relative(rel)
            key = unicodedata.normalize('NFC',rel).casefold()
            if key in portable:
                raise ValueError('Case/Unicode path alias: '+rel)
            portable.add(key)
            st = p.lstat()
            if stat.S_ISLNK(st.st_mode):
                raise ValueError('Symlink refused: '+rel)
            if stat.S_ISDIR(st.st_mode):
                result[rel] = None
            elif stat.S_ISREG(st.st_mode):
                if st.st_nlink > 1:
                    raise ValueError('Hardlink alias refused: '+rel)
                result[rel] = sha(p.read_bytes())
            else:
                raise ValueError('Special file refused: '+rel)
    return result


def included(rel, generation):
    parts = PurePosixPath(rel).parts
    if parts[0].startswith('_') or any(x in EXCLUDED_DIRS or x.startswith('._') for x in parts):
        return False
    name = parts[-1]
    if name in ('.DS_Store','map.lock') or name.startswith(('.~lock.','.mindmake-write-')) or name.endswith(('.pyc','.tmp','.sqlite3','.sqlite3-wal','.sqlite3-shm','.db','.db-wal','.db-shm')):
        return False
    history = META+'map-history'
    if rel == history or rel.startswith(history+'/'):
        keep = history+'/'+generation+'/committed'
        return rel == keep or rel.startswith(keep+'/') or keep.startswith(rel+'/')
    return True


def document(root, rel):
    safe_relative(rel)
    return json.loads((root/rel).read_text())


SHARED_JOB = '_shared'


def review_scheme(root):
    try:
        return json.loads((root/'Brain/.mindmake/runtime.json').read_text()).get('review_scheme','combined')
    except (OSError, ValueError):
        return 'combined'


def fingerprint(root, item, dependencies=None):
    """The supported schema-1 review contract; generated JOB map blocks are omitted.

    Mirrors mindmake.review_fingerprint, including the X3.0 'per_helper' scheme."""
    scheme = review_scheme(root)
    shared = set(REVIEW_INPUTS) | {p for p in OPTIONAL_REVIEW_INPUTS if (root/p).is_file()}
    if scheme == 'per_helper':
        shared |= {p for p in ('Brain/MEMORY.md', 'Brain/tools/workspace.py') if (root/p).is_file()}
    if (root/'Brain/tools/mindmake_review.py').is_file():
        shared.update(['Brain/governance/RUNTIME.md', 'Brain/SKILLS.md', 'Brain/skills/mindmake-workspace/SKILL.md'])
    if item['job'] == SHARED_JOB:
        paths = shared
    else:
        paths = set(item['sha256']) | {item['job']+'/JOB.md',item['job']+'/LGI_ENGINE_CONTRACT.md'}
        paths.update(p.relative_to(root).as_posix() for p in (root/item['job']/'Skills').glob('*/SKILL.md'))
        if scheme != 'per_helper':
            paths |= shared
    if dependencies is not None:
        dependencies.update(paths)
    hashes = {}
    for rel in sorted(paths):
        safe_relative(rel)
        data = (root/rel).read_bytes()
        if rel.endswith('/JOB.md'):
            text = data.decode()
            if text.count(BEGIN) != text.count(END) or text.count(BEGIN)>1:
                raise ValueError('Malformed map markers: '+rel)
            if BEGIN in text:
                if text.index(BEGIN)>text.index(END):
                    raise ValueError('Reversed map markers: '+rel)
                text = text[:text.index(BEGIN)]+text[text.index(END)+len(END):]
            data = text.strip().encode()
        hashes[rel] = sha(data)
    return sha(encoded(hashes))


def validate(root, inventory, required_helpers):
    dependencies = set(REVIEW_INPUTS) | set(required_helpers) | {META+name for name in ('runtime.json','intake.json','assistant.json','folder-map.json','source-catalog.json','setup-review.json')}
    for rel in sorted(dependencies):
        if inventory.get(rel) is None:
            raise ValueError('Missing package file: '+rel)
    runtime = document(root,META+'runtime.json')
    if not isinstance(runtime.get('release'),str) or not runtime['release'].startswith('MINDMAKE '):
        raise ValueError('Not a supported MindMake distribution')
    for rel in required_helpers:
        safe_relative(rel)
        if not rel.startswith('Brain/tools/') or inventory.get(rel) is None:
            raise ValueError('Required helper missing or outside Brain/tools: '+rel)
    if document(root,META+'intake.json').get('answers') != {}:
        raise ValueError('Intake must be unanswered')
    assistant = document(root,META+'assistant.json')
    if assistant.get('enabled') is not False or assistant.get('connections') != {} or assistant.get('sms',{}).get('consented') is not False:
        raise ValueError('Personal services must be explicitly disabled and unconnected')
    if assistant.get('sms',{}).get('recipient_sha256') or any(assistant.get(k) for k in ('goals','approved_sources','routine_actions')):
        raise ValueError('Personal assistant configuration must be empty')
    sched = assistant.get('scheduler',{})
    if sched.get('status','NOT_CONFIGURED') != 'NOT_CONFIGURED' or any(sched.get(k) for k in ('id','last_success_at')):
        raise ValueError('Personal scheduler must be unconfigured')
    for name in ('personal-mcp.json',):
        if META+name in inventory:
            dependencies.add(META+name)
            config = document(root,META+name)
            if config.get('enabled') is not False or config.get('connections') or config.get('servers'):
                raise ValueError('Personal MCP must be disabled and unconnected')
    if META+'folder-map.pending.json' in inventory:
        raise ValueError('Pending map transaction must be resolved before packaging')
    maps = document(root,META+'folder-map.json')
    generation = maps['generation_id']
    safe_relative(generation)
    if '/' in generation:
        raise ValueError('Map generation must be a single component')
    inv = document(root,maps['inventory_path'])
    if inv.get('generation_id') != generation:
        raise ValueError('Map inventory generation mismatch')
    map_paths = [maps['root_map'],*maps['project_maps'].values(),*maps.get('specialist_maps',[])]
    for rel in map_paths:
        safe_relative(rel)
        text = (root/rel).read_text()
        if text.count(BEGIN)!=1 or text.count(END)!=1 or text.index(BEGIN)>text.index(END) or generation not in text.split(BEGIN)[1].split(END)[0]:
            raise ValueError('Map generation/marker mismatch: '+rel)
        if maps.get('map_hashes',{}).get(rel) != inventory.get(rel):
            raise ValueError('Map hash mismatch: '+rel)
    for rel in [*map_paths,META+'folder-map.json',maps['inventory_path']]:
        committed = META+'map-history/'+generation+'/committed/'+rel
        dependencies.update((rel,committed))
        if inventory.get(rel) is None or inventory.get(committed) != inventory[rel]:
            raise ValueError('Current committed map snapshot missing or stale: '+rel)
    catalog = document(root,META+'source-catalog.json')
    rows = catalog.get('sources')
    if not isinstance(rows,list) or not rows:
        raise ValueError('Source catalog must contain reviewed sources')
    ledger = document(root,META+'setup-review.json')
    if ledger.get('schema_version') != 1 or not isinstance(ledger.get('records'),dict):
        raise ValueError('Unsupported review ledger; requires schema 1')
    jobs = set()
    sources = {}
    for item in rows:
        job = item['job']; safe_relative(job)
        if not job.startswith('Jobs/') or job in jobs:
            raise ValueError('Invalid or duplicate catalog job: '+job)
        jobs.add(job)
        if not isinstance(item.get('sha256'),dict) or not item['sha256']:
            raise ValueError('Catalog source hashes missing: '+job)
        selected_pdf = item.get('selected_pdf','')
        safe_relative(selected_pdf)
        if selected_pdf not in item['sha256']:
            raise ValueError('Selected PDF must be covered by its catalog row hashes: '+job)
        dependencies.add(selected_pdf)
        for rel, digest in item['sha256'].items():
            safe_relative(rel)
            if not isinstance(digest,str) or not re.fullmatch('[0-9a-f]{64}',digest) or inventory.get(rel)!=digest:
                raise ValueError('Catalog source hash mismatch: '+rel)
            sources[rel] = digest
        for suffix in ('Products','Research','Seeds/Short-term','Seeds/Long-term'):
            if not (root/job/suffix).is_dir():
                raise ValueError('Missing job directory: '+job+'/'+suffix)
        record = ledger['records'].get(job,{})
        if not record.get('reviewed_at') or record.get('fingerprint')!=fingerprint(root,item,dependencies):
            raise ValueError('Source review missing or stale: '+job)
        evidence = record.get('evidence',''); safe_relative(evidence)
        dependencies.add(evidence)
        if not evidence.startswith('Brain/governance/setup-reviews/') or not evidence.endswith('.md') or inventory.get(evidence) is None or inventory[evidence]!=record.get('evidence_sha256'):
            raise ValueError('Review evidence missing or changed: '+job)
    if review_scheme(root) == 'per_helper':
        record = ledger['records'].get(SHARED_JOB,{})
        if not record.get('reviewed_at') or record.get('fingerprint')!=fingerprint(root,{'job':SHARED_JOB,'sha256':{}},dependencies):
            raise ValueError('Shared rules review missing or stale')
        evidence = record.get('evidence',''); safe_relative(evidence); dependencies.add(evidence)
        if inventory.get(evidence) is None or inventory[evidence]!=record.get('evidence_sha256'):
            raise ValueError('Review evidence missing or changed: '+SHARED_JOB)
    selected = {p:v for p,v in inventory.items() if included(p,generation)}
    for rel in sorted(dependencies | set(sources)):
        if rel not in selected:
            raise ValueError('Required content would be excluded: '+rel)
    return generation, selected, len(jobs), len(sources)


def verify_archive(archive, label, selected, run_code):
    with tempfile.TemporaryDirectory(prefix='mindmake-release-verify-') as tmp:
        tmp = Path(tmp)
        with zipfile.ZipFile(archive) as z:
            expected = {label+'/'} | {label+'/'+p+('/' if digest is None else '') for p,digest in selected.items()}
            names = z.namelist()
            if len(names)!=len(set(names)) or set(names)!=expected or z.testzip() is not None:
                raise ValueError('Archive member or CRC mismatch')
            for info in z.infolist():
                safe_relative(info.filename.rstrip('/'))
                if stat.S_ISLNK(info.external_attr>>16):
                    raise ValueError('Archive symlink refused')
            z.extractall(tmp/'extracted')
        moved = tmp/'Different parent'/'Customer renamed workspace'
        moved.parent.mkdir()
        (tmp/'extracted'/label).rename(moved)
        if snapshot(moved)!=selected:
            raise ValueError('Relocated archive bytes/directories do not match manifest')
        checks = []
        if run_code:
            for operation,status,extra in [('boot','READY_INTAKE_PENDING',['--no-maintenance']),('check_map','PASS',[])]:
                q = subprocess.run([sys.executable,'-B',str(moved/'Brain/tools/mindmake.py'),operation,'--root',str(moved),*extra],cwd=tmp,capture_output=True,text=True,timeout=120,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
                if q.returncode:
                    raise ValueError('Extracted helper failed: '+operation+' '+q.stderr[-2000:])
                result = json.loads(q.stdout)
                if result.get('status')!=status or result.get('errors'):
                    raise ValueError('Extracted helper rejected package: '+operation)
                if operation=='boot' and Path(result.get('root','')).resolve()!=moved.resolve():
                    raise ValueError('Boot did not resolve relocated root')
                checks.append({'operation':operation,'status':status})
                if snapshot(moved)!=selected:
                    raise ValueError('Read-only package verification changed extracted files')
        return checks


def package(source, output, root_label, *, verify_package_code=False, required_helpers=()):
    safe_relative(root_label)
    if '/' in root_label:
        raise ValueError('Archive root label must be one component')
    source = reject_symlink_chain(source)
    output = reject_symlink_chain(output)
    if not source.is_dir() or not output.parent.is_dir() or output.suffix.lower()!='.zip':
        raise ValueError('Source and output parent must exist; output must end in .zip')
    if output.is_relative_to(source):
        raise ValueError('Output must be outside source')
    manifest = output.with_suffix('.manifest.json')
    for path in (output,manifest):
        reject_symlink_chain(path)
        if path.exists():
            raise FileExistsError('Refusing existing output: '+str(path))
    before = snapshot(source)
    generation, selected, jobs, source_count = validate(source,before,required_helpers)
    # Build privately first. A failed validation never leaves a successful-looking ZIP.
    with tempfile.TemporaryDirectory(prefix='.mindmake-release-',dir=output.parent) as tmp:
        archive = Path(tmp)/'candidate.zip'
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for rel,digest in [('',None),*sorted(selected.items())]:
                name = root_label+('/'+rel if rel else '')+('/' if digest is None else '')
                info = zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0))
                info.create_system = 3
                info.external_attr = ((0o40755 if digest is None else 0o100644)<<16)|(0x10 if digest is None else 0)
                info.compress_type = zipfile.ZIP_DEFLATED
                data = b'' if digest is None else (source/rel).read_bytes()
                if digest is not None and sha(data)!=digest:
                    raise ValueError('Concurrent source change: '+rel)
                z.writestr(info,data,compresslevel=9)
        checks = verify_archive(archive,root_label,selected,verify_package_code)
        if snapshot(source)!=before:
            raise ValueError('Source changed during packaging')
        result = {'schema_version':1,'root_label':root_label,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'files':{p:v for p,v in sorted(selected.items()) if v is not None},'directories':sorted(p for p,v in selected.items() if v is None),'map_generation':generation,'reviewed_jobs':jobs,'catalog_sources':source_count,'required_helpers':sorted(set(required_helpers)),'verification':'RELOCATED_BOOT_AND_MAP_PASS' if verify_package_code else 'STATIC_ONLY','checks':checks,'source_unchanged':True,'source_tree_sha256':sha(encoded(dict(sorted(before.items())))),'relocated_byte_match':True}
        # No replacement/rename-overwrite. Read back both newly created artifacts.
        created = []
        try:
            for destination,data in [(output,archive.read_bytes()),(manifest,encoded(result))]:
                reject_symlink_chain(destination)
                with destination.open('xb') as f:
                    created.append(destination)
                    f.write(data); f.flush(); os.fsync(f.fileno())
                if destination.read_bytes()!=data:
                    raise ValueError('Output readback mismatch: '+str(destination))
        except Exception:
            for path in reversed(created):
                path.unlink()
            raise
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--root-label',required=True)
    parser.add_argument('--require-helper',action='append',default=[],help='Required package-relative Brain/tools path; repeatable')
    parser.add_argument('--verify-package-code',action='store_true',help='Explicitly execute trusted extracted helper boot/check_map; not a sandbox')
    args = parser.parse_args()
    try:
        result = package(args.source,args.output,args.root_label,verify_package_code=args.verify_package_code,required_helpers=args.require_helper)
    except (ValueError,OSError,KeyError,TypeError,subprocess.TimeoutExpired) as error:
        parser.exit(1,'Release refused: '+str(error)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('files','directories')},indent=2))


if __name__=='__main__':
    main()
