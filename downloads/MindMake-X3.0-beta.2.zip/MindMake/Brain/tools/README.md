# MindMake local helpers

Run from the extracted MindMake X3.0 folder with Python 3.9 or newer. The helper locates its own workspace, including when --root is used from another working directory. Map writes support cross-platform file locking (Unix `fcntl` with Windows `msvcrt` fallback); tested locally on macOS, with simulated Windows-branch tests; native Windows acceptance remains unverified.

```sh
python3 -B Brain/tools/mindmake.py boot
python3 Brain/tools/mindmake.py tutorial
python3 Brain/tools/mindmake.py check_map
python3 Brain/tools/mindmake.py new_job --name "Project Name" [--purpose "Description"]
python3 Brain/tools/mindmake.py check_downloads [--force]
python3 Brain/tools/mindmake.py file_download --file "name.pdf" --destination "Wiki/..."
python3 Brain/tools/mindmake.py rollover_seeds [--pool <pool>] [--target 350] [--force]
python3 Brain/tools/mindmake.py update_map --paths 'path/created' 'old/path' 'new/path'
python3 Brain/tools/mindmake.py rebuild_map
python3 Brain/tools/mindmake.py recover_map
```

`boot` reads startup files, sources and available shared seeds and reports structure/intake state. The assistant must first follow `session_loading.components` and each `read_order`, including the Cartographer product source, before intake or readiness. It then reads the named seeds and task context. `READ_REQUIRED` is a conversation action, not a persisted activation flag; `RECORDED` packaging reviews cannot satisfy it. This command does not activate a model.

`check_downloads` performs an on-demand scan of the `Downloads/` intake folder, filing rule-matched files automatically and reporting files needing review. `file_download` files a specific downloaded document directly to an agreed workspace location under `Brain/`, `Jobs/`, or `Wiki/`. Both commands use a durable filing record, exclusively create destinations and keep map completion separate from successful byte transfer. Unfinished transfers remain recoverable or explicitly blocked on conflicting bytes.

`new_job --name <Project Name>` scaffolds an isolated customer project workspace under `Jobs/<Project Name>/` with its own `JOB.md`, `Research/`, `Notes/`, and local `Seeds/Short-term/` and `Seeds/Long-term/` pools, and automatically registers the new project across all workspace maps.

`rollover_seeds` checks all short-term seed pools and automatically rolls over pools reaching the 500-seed cap down to 350 active records by archiving the oldest unpinned records, moving them into Long-term with a hash-bound plan written before movement in `Brain/.mindmake/seed-rollovers/` and a summary memory. Pending plans resume even below the threshold; completion follows map verification. Rollover runs during `boot` only after structural checks pass, or on demand. `boot --no-maintenance` checks without moving seeds.

`tutorial` reports file readiness through the [First Win walkthrough](<../FIRST_WIN.md>). Empty seeds do not pass. It leaves fresh-conversation acceptance pending and does not run automatic maintenance.

`check_map` verifies registered generations, map hashes and links. `update_map` records confirmed changed paths, including old and new for moves; unseen parts of the inventory retain their prior observation times. For a new job pass its whole folder after constructing the required package, and register its skill/source before completion. `rebuild_map` scans the active tree during explicit reconstruction. Both preserve authored map text and exclude archives, sidecars, temporary files and symlinks.

A transaction journals prior bytes, checks concurrent edits, saves backups and commits the registry last. Failures retain the old registration or a pending journal. `recover_map` restores the journaled generation only if each file still matches its old or candidate bytes; it refuses to overwrite later edits. A missing authored map is restored only from a real history backup whose hash matches the registry; otherwise the helper stops for restoration. Never substitute generated prose for lost authored work.

Map update/check operations do not move source files, run tasks, assign a persona or schedule activity. Separate filing and seed-rollover operations have their own explicitly documented effects. The separate Downloads watcher can move files under configured rules. Maps are checked at startup and updated after observed changes. Additions made outside a session are candidates for review at the next load.

X.1 adds `record_review --job <catalog job> --evidence <relative Markdown path> --fingerprint <boot fingerprint>`. See [INTAKE.md](<../../INTAKE.md>). Boot reports SETUP_REVIEW_PENDING when a review is missing or stale; current recorded reviews can instead lead to READY_INTAKE_PENDING. Successful filesystem checks do not manufacture completed reviews. After recording evidence update its map and the ledger map.

`record_intake --field preferred_name --answer "explicit user answer"` stores one confirmed response. Use `--skip` for an explicit skip. Read `intake.next_question` from boot or the recording result to resume; synchronize the Brain/Profiles record and update maps after saving.

Downloads can be processed on-demand in-session via `check_downloads` or `file_download`, or continuously via the optional [Downloads watcher](../DOWNLOADS_WATCHER.md).

## X.1 knowledge processing

Follow [Wiki intake and retrieval](<../WIKI_WORKFLOW.md>) for source registration, separate retrieval seeds and Wiki pages, evidence checks, retry, and optional Journal/Contacts jobs. A filed download is not a processed source. Use `python3 Brain/tools/knowledge.py status` from the workspace root to check the queue.

## X1.5 intake continuity

`intake_status` is a read-only checkpoint containing pending questions and ACTIVE/DEFERRED/COMPLETE interaction. `defer_intake --reason "user supplied request"` stores an explicit pause without answering questions; `resume_intake` restores the sequence. Record real answers with `record_intake`; it resumes intake. Update maps after these writes. An MCP yes returns INSPECT_EXISTING_MCP; follow the discovery/reuse procedure before building a new starter.

AppleDouble metadata is preserved as a separately journaled `<filename>.appledouble` artifact for download filing and seed rollover. Verify both content and metadata copies before removing originals; do not overwrite destination operating-system `._` files. These artifacts preserve raw bytes and do not automatically restore native metadata. Native macOS/ExFAT fixtures exercise copy, interruption and recovery paths. Native Windows and physical power-loss recovery remain unverified.

## X1.5 workflow helpers

`python3 -B Brain/tools/mindmake.py boot --mode review` performs compact read-only commitment orientation. Follow [the review procedure](FOLLOW_THROUGH.md); it never starts a scheduler or syncs reminders. [Workflow improvements](WORKFLOW_IMPROVEMENT.md), [work records](WORK_RECORDS.md), [task checks](TASK_EVAL.md) and [release packaging](RELEASE_TOOL.md) are on demand. Run skill-selection audit with `python3 -B Brain/tools/mindmake_skill_routes.py audit`; fresh observations are required for scoring. Personal records under Brain/.mindmake/work-records and corrections are excluded from navigation and release packages.

## Seed capsule check

`python3 Brain/tools/seed_capsule_check.py check <seed.md>` checks that a seed carries its assertion, proof and uncertainty fields and that boot can load it. `tools/seed_capsule_check.py` at the workspace root is a shortcut to the same script. `selftest` runs its own cases. A pass checks form, not truth.
