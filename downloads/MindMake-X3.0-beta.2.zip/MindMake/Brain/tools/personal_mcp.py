#!/usr/bin/env python3
"""Build the optional MCP launch bundle only after an explicit intake yes."""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse, importlib.util, json, shutil, subprocess, sys, venv
from pathlib import Path
import mindmake as mm
ROOT=Path(__file__).resolve().parents[2]

def decision(root):
    item=json.loads((root/mm.INTAKE).read_text())['answers'].get('personal_mcp',{})
    return item.get('answer') if item.get('status')=='confirmed' else 'pending'

CORE_PYTHON=(3,9)
MCP_PYTHON=(3,10)

def compatibility(version=None, platform=None):
    """Can this computer run the personal MCP? Check before offering to install it."""
    version=tuple((version or sys.version_info)[:2]);platform=platform or sys.platform
    reasons=[]
    if version<CORE_PYTHON:reasons.append('Python %d.%d is too old even for MindMake (needs 3.9 or newer)'%version)
    elif version<MCP_PYTHON:reasons.append('Python %d.%d runs MindMake, but the personal MCP needs 3.10 or newer'%version)
    if platform=='win32':reasons.append('Native Windows is not tested; the map helper needs macOS or Linux')
    return {'compatible':not reasons,'python':'%d.%d'%version,'core_ok':version>=CORE_PYTHON,'mcp_ok':version>=MCP_PYTHON,'reasons':reasons}

def build(root, install=False):
    if decision(root)!='yes':raise ValueError('Record the user\'s explicit personal_mcp=yes first. No build performed.')
    c=compatibility()
    if not c['compatible']:raise ValueError('Not compatible: '+'; '.join(c['reasons']))
    # The existing map helper uses fcntl. Do not claim Windows packaging acceptance.
    source=mm.within(root,'Brain/MCP/personal_mcp_server.py')
    spec=importlib.util.spec_from_file_location('personal_mcp_core',source);core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    core.workspace_status(core.check_root(root))
    runtime=mm.within(root,'Brain/.mindmake/personal-mcp-runtime')
    exe=runtime/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python')
    if install:
        if not exe.exists():venv.EnvBuilder(with_pip=True).create(runtime)
        subprocess.run([str(exe),'-m','pip','install','-r',str(root/'Brain/MCP/requirements.txt')],check=True)
    ready=False
    if exe.exists():
        ready=subprocess.run([str(exe),'-c','import importlib.metadata as m; assert m.version("mcp")=="1.29.1"'],capture_output=True).returncode==0
    folder=mm.within(root,'Brain/MCP/generated');folder.mkdir(exist_ok=True)
    connection={'mcpServers':{'mindmake-personal':{'command':str(exe),'args':[str(source),'--root',str(root)]}}}
    output=folder/'connection.json'
    if output.exists() and output.read_bytes()!=mm.encoded(connection):
        shutil.copy2(output,folder/('connection-'+mm.now().replace(':','-')+'.backup.json'))
    mm.atomic(output,mm.encoded(connection))
    state={'build':'BUILT','dependencies':'READY' if ready else 'PENDING','host_connection':'UNVERIFIED',
           'next_action':'Connect this command and argument array using the chosen host settings; verify live tools' if ready else 'Install the pinned dependency in the private runtime, then connect and verify the host',
           'server_sha256':mm.digest(source.read_bytes())}
    mm.atomic(folder/'setup.json',mm.encoded(state));mm.rebuild(root)
    result=mm.verify(root)
    if result['status']!='PASS':raise ValueError('Build remains incomplete: map verification failed')
    return state

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['status','check','build']);p.add_argument('--install-dependencies',action='store_true');a=p.parse_args()
    try:
        if a.action=='status':print(json.dumps({'choice':decision(ROOT),'launch_bundle_exists':(ROOT/'Brain/MCP/generated/connection.json').exists(),'live_connection':'Use the host MCP tool call; filesystem status cannot establish this'}))
        elif a.action=='check':print(json.dumps(compatibility(),indent=2))
        else:print(json.dumps(build(ROOT,a.install_dependencies),indent=2))
    except Exception as e:print(json.dumps({'status':'FAILED','error':str(e)}));sys.exit(1)
if __name__=='__main__':main()
