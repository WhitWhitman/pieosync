"""Bounded, read-only seed supersession and historical open-work routing.

This intentionally accepts a small YAML frontmatter subset, not executable or
general YAML. Supersedes references are exact basenames in this seed pool or
its sibling Long-term pool. Invalid metadata/graphs fail visibly; uncertain
chronology is quarantined. Missing history and incomplete question extraction
require explicit reconciliation.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
import re

DATE_PREFIX = re.compile(r'^\d{4}-\d{2}-\d{2}')
MAX_METADATA = 16_384
MAX_SEEDS = 2_000
MAX_REFERENCES = 32
MAX_HISTORY = 20
MAX_HISTORY_BYTES = 262_144
MAX_EXCERPT = 2_048
MAX_TOTAL_EXCERPT = 8_192
MAX_WARNINGS = 20
POLICY = ('Historical Open Questions are reconciliation evidence only, not active '
          'directives. Compare each with the replacement and current authority '
          'before deciding what remains open; never reinstate obsolete Next Steps. '
          'Open Questions extraction is partial coverage: Key Decisions and other '
          'sections can contain requirements and must also be reconciled using '
          'the historical source ranges before acting. '
          'Warnings or omitted history require targeted source review before acting.')


def _fail(message):
    raise RuntimeError('Seed supersession: ' + message)


def _scalar(raw):
    raw = raw.strip()
    if raw.startswith('"'):
        try:
            value, end = json.JSONDecoder().raw_decode(raw)
        except ValueError:
            _fail('invalid quoted metadata value')
        if not isinstance(value, str) or (raw[end:].strip() and not raw[end:].lstrip().startswith('#')):
            _fail('invalid quoted metadata value')
        return value
    if raw.startswith("'"):
        match = re.fullmatch(r"'((?:[^']|'')*)'\s*(?:#.*)?", raw)
        if not match:
            _fail('invalid quoted metadata value')
        return match.group(1).replace("''", "'")
    raw = re.split(r'\s+#', raw, maxsplit=1)[0].strip()
    if raw and (raw[0] in '{[!&*|>' or ': ' in raw):
        _fail('unsupported metadata structure')
    return raw


def _references(raw, continuation):
    if raw.strip().startswith('['):
        # Filenames cannot contain commas in this conservative subset. Quoted
        # or unquoted scalar elements are accepted; nesting is rejected.
        value = re.split(r'\s+#', raw, maxsplit=1)[0].strip()
        if not value.endswith(']') or continuation:
            _fail('invalid inline supersedes list')
        refs = [_scalar(x) for x in value[1:-1].split(',')] if value[1:-1].strip() else []
    elif raw.strip() and not raw.lstrip().startswith('#'):
        if continuation:
            _fail('supersedes scalar cannot also contain a list')
        value = _scalar(raw)
        refs = [] if value in ('null', '~') else [value]
    else:
        refs = []
        for line in continuation:
            match = re.fullmatch(r'\s*-\s+(.+)', line)
            if not match:
                _fail('unsupported supersedes block list')
            refs.append(_scalar(match.group(1)))
    if len(refs) > MAX_REFERENCES or len(set(refs)) != len(refs):
        _fail('too many or duplicate supersedes references')
    return refs


def _stamp(name):
    try:
        date = dt.date.fromisoformat(name[:10])
        timed = re.match(r'^\d{4}-\d{2}-\d{2}_(\d{6})(?:_|\.)', name)
        digits = timed.group(1) if timed else None
        time = dt.time(int(digits[:2]), int(digits[2:4]), int(digits[4:])) if digits else None
    except ValueError:
        _fail(f'invalid date or time in {name}')
    return date, time


def _metadata(path):
    if path.is_symlink():
        _fail(f'symlink seed is unsafe: {path}')
    try:
        with path.open('rb') as handle:
            head = handle.read(MAX_METADATA + 1)
        if head.startswith(b'\xef\xbb\xbf'):
            head = head[3:]
        # Decode only the metadata, so cutting a legacy body UTF-8 character
        # at the read bound cannot produce a false metadata failure.
        lines = head.splitlines()
        if lines and lines[0].strip().startswith(b'---') and lines[0].strip() != b'---':
            _fail(f'unsupported frontmatter delimiter: {path}')
        if not lines or lines[0].strip() != b'---':
            return {'path':path, 'status':'active', 'refs':[], 'stamp':_stamp(path.name)}
        end = next((i for i,line in enumerate(lines[1:],1) if line.strip() == b'---'), None)
        if end is None or sum(len(x)+1 for x in lines[:end+1]) > MAX_METADATA:
            _fail(f'unclosed or oversized frontmatter: {path}')
        text = b'\n'.join(lines[1:end]).decode('utf-8')
    except (OSError, UnicodeError) as exc:
        _fail(f'unreadable metadata {path}: {exc}')
    fields = {}
    key = None
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        if re.match(r'^\s+(?:status|supersedes)\s*:', line):
            _fail(f'indented or nested control metadata is unsupported: {path}')
        match = re.match(r'^([A-Za-z_][\w-]*):\s*(.*)$', line)
        if match:
            key, value = match.groups()
            if key in ('status', 'supersedes'):
                if key in fields:
                    _fail(f'duplicate {key} metadata: {path}')
                fields[key] = (value, [])
        elif key in ('status', 'supersedes'):
            fields[key][1].append(line)
        elif not line[:1].isspace() and not line.startswith('- '):
            _fail(f'unrecognized frontmatter line: {path}')
    status_raw, status_lines = fields.get('status', ('active', []))
    status = _scalar(status_raw)
    if status_lines or not status or len(status) > 100:
        _fail(f'unrecognized status metadata: {path}')
    stamp = _stamp(path.name)
    # Legacy created values mix dates, ISO timestamps and human timezones.
    # They are descriptive; ordering is proved only by filename date/time.
    return {'path':path, 'status':status, 'refs':_references(*fields.get('supersedes', ('', []))), 'stamp':stamp}


def _open_questions(source, replacement, budget, warn):
    item = {'source':str(source), 'replacement':str(replacement),
            'reconciliation_required':True, 'start_line':None, 'end_line':None, 'text':''}
    try:
        with source.open('rb') as handle:
            raw = handle.read(MAX_HISTORY_BYTES + 1)
        if len(raw) > MAX_HISTORY_BYTES:
            warn(f'Historical source exceeds read bound; inspect Open Questions manually: {source}')
            return {**item, 'status':'manual review required'}, budget
        lines = raw.decode('utf-8').splitlines()
        item['sha256'] = hashlib.sha256(raw).hexdigest()
    except (OSError, UnicodeError):
        warn(f'Historical source unreadable; reconcile manually: {source}')
        return {**item, 'status':'manual review required'}, budget
    # Ignore fenced code, where a heading may merely be a quoted example.
    headings = []
    fence = None
    for index,line in enumerate(lines):
        fm = re.match(r'^\s{0,3}(`{3,}|~{3,})', line)
        if fm:
            marker = fm.group(1)
            if fence is None: fence = marker
            elif marker[0] == fence[0] and len(marker) >= len(fence): fence = None
            continue
        if not fence:
            hm = re.match(r'^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$', line)
            if hm: headings.append((index, len(hm.group(1)), hm.group(2).strip()))
    matches = [(i,level) for i,level,title in headings if title.casefold() == 'open questions']
    sections = []
    for i,level,title in headings:
        if level != 2 or title.casefold() == 'open questions': continue
        section_end = next((n for n,l,_ in headings if n > i and l <= level),len(lines))
        sections.append({'title':title[:100], 'start_line':i+1, 'end_line':section_end})
    item['other_historical_sections_require_reconciliation'] = sections[:6]
    if len(sections) > 6:
        warn(f'Additional historical section ranges omitted; review remaining source sections: {source}')
    if len(matches) != 1:
        warn(f'Historical Open Questions missing or ambiguous; reconcile full source with replacement: {source}')
        return {**item, 'status':'manual review required; range covers full historical source',
                'start_line':1, 'end_line':len(lines)}, budget
    start,level = matches[0]
    end = next((i for i,l,_ in headings if i > start and l <= level), len(lines))
    body = '\n'.join(lines[start+1:end]).strip()
    item.update(start_line=start+1, end_line=end)
    if not body:
        warn(f'Historical Open Questions empty; unresolved work cannot be inferred absent: {source}')
        return {**item, 'status':'manual review required'}, budget
    cap = min(MAX_EXCERPT, budget)
    truncated = len(body) > cap
    item.update(text=body[:cap], status='partial; read source range' if truncated else 'historical; reconcile with replacement')
    if truncated:
        warn(f'Historical Open Questions excerpt bounded; read full source range {start+1}-{end}: {source}')
    return item, budget - min(len(body), cap)


def select_recent_seeds(directory: Path, limit: int, *, all_warnings: bool = False) -> dict:
    directory = Path(directory)
    if directory.is_symlink() or directory.parent.is_symlink():
        _fail(f'symlink seed pool is unsafe: {directory}')
    directory = directory.resolve()
    warnings = []
    warning_count = 0
    def warn(message):
        nonlocal warning_count
        warning_count += 1
        if all_warnings or len(warnings) < MAX_WARNINGS: warnings.append(message)
    report = {'policy':POLICY, 'provenance':[], 'historical_open_questions':[], 'partial_corrections':[],
              'warnings':warnings, 'reconciliation_required':False}
    result = {'recent_seeds':[], 'seed_supersession':report}
    if not directory.is_dir() or limit <= 0:
        return result
    candidates = []
    for path in directory.iterdir():
        if DATE_PREFIX.match(path.name) and (path.is_file() or path.is_symlink()):
            candidates.append(path)
            if len(candidates) > MAX_SEEDS: _fail('seed pool exceeds bounded metadata scan')
    candidates.sort(key=lambda p:p.name, reverse=True)
    records = {p.name:_metadata(p) for p in candidates}
    pending = list(records)
    edges = {}
    partial_edges = {}
    archive = directory.parent / 'Long-term' if directory.name == 'Short-term' else None
    while pending:
        name = pending.pop()
        record = records[name]
        edges[name] = []
        for raw_ref in record['refs']:
            if (not DATE_PREFIX.match(raw_ref) and len(raw_ref) <= 512
                    and len(raw_ref.split()) > 1
                    and not re.search(r'(^[./\\]|\.md\b|\.\./|[\x00-\x1f])', raw_ref)):
                # Legacy prose has no exact target. Never fuzzy-match it or
                # silently retire records based on a descriptive claim.
                warn(f'Descriptive supersedes in {name}: {raw_ref}; exact predecessor unresolved, no seed suppressed; reconcile with current source before related work.')
                continue
            ref, marker, fragment = raw_ref.partition('#')
            if marker and not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}', fragment):
                _fail(f'unsafe or unsupported partial supersedes scope in {name}: {raw_ref[:255]}')
            if (not DATE_PREFIX.match(ref) or not ref.endswith('.md') or
                    '/' in ref or '\\' in ref or any(ord(c)<32 for c in ref) or len(ref)>255):
                _fail(f'unsafe or unsupported supersedes reference in {name}: {ref[:255]}')
            if ref == name: _fail(f'self supersedes reference: {name}')
            _stamp(ref)
            target = directory / ref
            historical = archive / ref if archive else None
            if archive and archive.is_symlink() and (historical.exists() or historical.is_symlink()):
                _fail(f'symlink history pool is unsafe: {archive}')
            if target.exists() and historical and historical.exists():
                _fail(f'ambiguous reference exists in both seed pools: {ref}')
            if historical and (historical.exists() or historical.is_symlink()) and not target.exists():
                target = historical
            if marker:
                # A field correction does not retire the predecessor's other
                # requirements. Scope is routed for semantic review, not guessed.
                if target.is_symlink(): _fail(f'symlink seed is unsafe: {target}')
                partial_edges.setdefault(name, []).append(ref)
                if ref not in records and target.is_file():
                    if len(records) >= MAX_SEEDS: _fail('referenced history exceeds bounded metadata scan')
                    records[ref] = _metadata(target)
                    pending.append(ref)
                warn(f'Partial correction {name} -> {raw_ref}: reconcile only the named scope with both sources; whole predecessor remains eligible.')
                if not target.is_file(): warn(f'Missing partial-correction predecessor: {target}')
                if len(report['partial_corrections']) < MAX_HISTORY:
                    report['partial_corrections'].append({'replacement': str(record['path']),
                        'predecessor': str(target), 'scope': fragment, 'whole_seed_superseded': False})
                else:
                    warn('Additional partial-correction paths omitted; review source metadata before acting.')
                continue
            if ref not in records:
                if not target.exists():
                    warn(f'Missing superseded predecessor {ref} referenced by {name}; open work requires manual reconciliation.')
                    # Preserve the edge for ordering validation and provenance.
                    edges[name].append(ref)
                    continue
                if len(records) >= MAX_SEEDS: _fail('referenced history exceeds bounded metadata scan')
                records[ref] = _metadata(target)
                pending.append(ref)
            edges[name].append(ref)
    for record in records.values():
        if record['status'] not in ('active', 'superseded', 'archived'):
            warn(f'Unrecognized seed status {record["status"]}; source excluded from active directives, reconcile manually: {record["path"]}')
    # Iterative graph walk avoids recursion failure on long but valid histories.
    state = {}
    for name in records:
        stack = [(name, False)]
        while stack:
            node, exiting = stack.pop()
            if exiting:
                state[node] = 2
                continue
            if state.get(node) == 1: _fail(f'cycle in supersedes graph at {node}')
            if state.get(node) == 2: continue
            state[node] = 1
            stack.append((node, True))
            stack.extend((ref, False) for ref in edges.get(node, []) + partial_edges.get(node, []))
    parents = {}
    invalid_order = set()
    for name,refs in edges.items():
        newer = records[name]['stamp']
        for ref in refs:
            older = _stamp(ref)
            if not (newer[0] > older[0] or (newer[0] == older[0] and newer[1] and older[1] and newer[1] > older[1])):
                warn(f'Invalid or ambiguous supersedes date order: {name} -> {ref}; connected history is quarantined for manual reconciliation.')
                invalid_order.update((name,ref))
            parents.setdefault(ref, []).append(name)
    def ancestors(name):
        seen = set()
        queue = list(edges.get(name, []))
        while queue:
            node = queue.pop()
            if node in seen: continue
            seen.add(node)
            queue.extend(edges.get(node, []))
        return seen
    for ref,replacements in parents.items():
        if len(replacements) > 1:
            for i,left in enumerate(replacements):
                for right in replacements[i+1:]:
                    if left not in ancestors(right) and right not in ancestors(left):
                        warn(f'Ambiguous independent replacements for {ref}: {left}, {right}; connected history quarantined for manual reconciliation.')
                        invalid_order.update((ref, left, right))
    quarantine = set()
    queue = list(invalid_order)
    while queue:
        name = queue.pop()
        if name in quarantine: continue
        quarantine.add(name)
        queue.extend(edges.get(name, []))
        queue.extend(parents.get(name, []))
    report['quarantined_count'] = len(quarantine)
    report['quarantined_seeds'] = [str(records[n]['path']) if n in records else str(directory/n)
                                   for n in sorted(quarantine, reverse=True)[:MAX_HISTORY]]
    if len(quarantine) > MAX_HISTORY:
        warn(f'{len(quarantine)-MAX_HISTORY} additional quarantined source paths omitted; follow supersedes from listed sources.')
    selected = [p for p in candidates if records[p.name]['status'] == 'active' and p.name not in parents and p.name not in quarantine][:min(limit,10)]
    result['recent_seeds'] = [str(p) for p in selected]
    suppressed = [p for p in candidates if p.name in parents]
    report['suppressed_count'] = len(suppressed)
    report['metadata_files_scanned'] = len(records)
    for name,record in records.items():
        if edges.get(name) and name not in parents and record['status'] != 'active':
            warn(f'Latest replacement is {record["status"]}; predecessor directives remain suppressed. Reconcile retained history manually: {record["path"]}')
    history_count = 0
    budget = MAX_TOTAL_EXCERPT
    seen = set()
    review_groups = [(replacement, sorted(ancestors(replacement.name), reverse=True), False) for replacement in selected]
    # Quarantine is not deletion of context: expose bounded source ranges and
    # questions for affected current records as well as their predecessors.
    quarantine_roots = sorted((n for n in quarantine if not parents.get(n)),reverse=True)
    for name in quarantine_roots:
        replacement = records[name]['path']
        review_groups.append((replacement, [name, *sorted(ancestors(name),reverse=True)], True))
    for replacement,refs,is_quarantined in review_groups:
        for ref in refs:
            if ref in seen: continue
            seen.add(ref)
            history_count += 1
            if history_count > MAX_HISTORY: continue
            source = records[ref]['path'] if ref in records else directory / ref
            report['provenance'].append({'replacement':str(replacement), 'predecessor':str(source),
                                         'quarantined':is_quarantined,
                                         'superseded_by':[str(records[p]['path']) for p in parents.get(ref, [])][:MAX_REFERENCES]})
            item,budget = _open_questions(source, replacement, budget, warn)
            item['quarantined'] = is_quarantined
            report['historical_open_questions'].append(item)
    report['historical_count'] = history_count
    report['history_omitted_count'] = max(0,history_count - MAX_HISTORY)
    if history_count > MAX_HISTORY:
        warn(f'Historical chain has {history_count} predecessors; only {MAX_HISTORY} shown. Follow supersedes from selected replacements to reconcile omitted sources before acting.')
    report['warning_count'] = warning_count
    report['warnings_omitted_count'] = warning_count - len(warnings)
    report['reconciliation_required'] = bool(history_count or warning_count)
    return result
