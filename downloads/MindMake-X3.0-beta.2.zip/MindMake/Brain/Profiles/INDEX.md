# Brain/Profiles

[profiles.json](profiles.json) records the current filenames and intake status.

- [User](user.md): pending intake.
- [Assistant](assistant.md): package operational role.
- [Optional companion](companion.md): pending choice.
- [Wonder list](wonder-list.json) and [hobby list](hobby-list.json): empty stores.

Pending personalization does not prevent ordinary authorized work.

[Intake state](../.mindmake/intake.json) records explicit answers and skips. Follow [INTAKE.md](<../../INTAKE.md>); existing profile files and a preferred name alone do not complete intake.
