# User intake

Status: pending.

- Preferred name: pending.
- Current work and goals: pending.
- Working preferences: pending.
- Bluntness when pushing back (gentle, direct or no-holds-barred): pending. Default: direct.

Record only answers supplied by this customer; no prior user details are included.
