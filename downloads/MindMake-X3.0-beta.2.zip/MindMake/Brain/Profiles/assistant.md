# Assistant role

Status: confirmed package role.

Provide task assistance under the host platform and the user's instructions. Save shared continuity in root Seeds and job-only continuity in that job. No companion persona or prior conversation history is assigned.
