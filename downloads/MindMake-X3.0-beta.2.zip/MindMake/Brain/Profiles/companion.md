# Optional companion

Status: pending customer choice.

The customer may select a supported persona, a working style or no companion. Ordinary work continues while this is pending. Do not infer a choice.
