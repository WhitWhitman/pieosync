# MindMake Skills

## Active Skills

### MindMake DeepSleep

- Type: helper (PPI), version 0.1.3; loaded on demand in X3.0.
- Use for: Keeps an AI workspace tidy and findable at the start of a session.
- Triggers: `load mindmake deepsleep`; `mindmake deepsleep`; Keeps an AI workspace tidy and findable at the start of a session..
- Wrapper: [MindMake DeepSleep](<../Jobs/MindMake DeepSleep/Skills/mindmake-deepsleep/SKILL.md>).
- PPI source: [DEEPSLEEP_v0.1.3.md](<../Jobs/MindMake DeepSleep/Products/DEEPSLEEP_v0.1.3.md>).
- Read the source in the current conversation before precision work.

### MindMake Cartographer

- Type: helper (PPI), version 0.1.2; loaded on demand in X3.0.
- Use for: A reasoning lens that makes an AI assistant's answers tighter, grounded and honest.
- Triggers: `load mindmake cartographer`; `mindmake cartographer`; A reasoning lens that makes an AI assistant's answers tighter, grounded and honest..
- Wrapper: [MindMake Cartographer](<../Jobs/MindMake Cartographer/Skills/mindmake-cartographer/SKILL.md>).
- PPI source: [CARTOGRAPHER_v0.1.2.md](<../Jobs/MindMake Cartographer/Products/CARTOGRAPHER_v0.1.2.md>).
- Read the source in the current conversation before precision work.

### MindMake SignalGuard

- Type: helper (PPI), version 0.1.3; loaded on demand in X3.0.
- Use for: Keeps an AI assistant honest about how it knows what it says.
- Triggers: `load mindmake signalguard`; `mindmake signalguard`; Keeps an AI assistant honest about how it knows what it says..
- Wrapper: [MindMake SignalGuard](<../Jobs/MindMake SignalGuard/Skills/mindmake-signalguard/SKILL.md>).
- PPI source: [SIGNALGUARD_v0.1.3.md](<../Jobs/MindMake SignalGuard/Products/SIGNALGUARD_v0.1.3.md>).
- Read the source in the current conversation before precision work.

### MindMake ThoughtVault

- Type: helper (PPI), version 0.1.3; loaded on demand in X3.0.
- Use for: Gives an AI assistant a memory and a to-do list that last between conversations.
- Triggers: `load mindmake thoughtvault`; `mindmake thoughtvault`; Gives an AI assistant a memory and a to-do list that last between conversations..
- Wrapper: [MindMake ThoughtVault](<../Jobs/MindMake ThoughtVault/Skills/mindmake-thoughtvault/SKILL.md>).
- PPI source: [THOUGHTVAULT_v0.1.3.md](<../Jobs/MindMake ThoughtVault/Products/THOUGHTVAULT_v0.1.3.md>).
- Read the source in the current conversation before precision work.

### MindMake DreamWeaver

- Type: helper (PPI), version 0.1.1; loaded on demand in X3.0.
- Use for: Reads a handful of random memory seeds and "dreams" over them, finding patterns, contradictions and conspicuous gaps nobody asked about, then compresses the result into one short, clearly labeled dream seed.
- Triggers: `load mindmake dreamweaver`; `mindmake dreamweaver`; Reads a handful of random memory seeds and "dreams" over them, finding patterns, contradictions and conspicuous gaps nobody asked about, then compresses the result into one short, clearly labeled dream seed..
- Wrapper: [MindMake DreamWeaver](<../Jobs/MindMake DreamWeaver/Skills/mindmake-dreamweaver/SKILL.md>).
- PPI source: [DREAMWEAVER_v0.1.1.md](<../Jobs/MindMake DreamWeaver/Products/DREAMWEAVER_v0.1.1.md>).
- Read the source in the current conversation before precision work.

### MindMake Seed Protocol

- Type: helper (PPI), version 0.1.3; loaded on demand in X3.0.
- Use for: Keeps an AI assistant's long-term memory small, honest and findable.
- Triggers: `load mindmake seed protocol`; `mindmake seed protocol`; Keeps an AI assistant's long-term memory small, honest and findable..
- Wrapper: [MindMake Seed Protocol](<../Jobs/MindMake Seed Protocol/Skills/mindmake-seed-protocol/SKILL.md>).
- PPI source: [SEED_PROTOCOL_v0.1.3.md](<../Jobs/MindMake Seed Protocol/Products/SEED_PROTOCOL_v0.1.3.md>).
- Read the source in the current conversation before precision work.

### MindMake AI Turbo

- Type: helper (PPI), version 0.1.2; loaded on demand in X3.0.
- Use for: Keeps every answer as short and direct as the task allows, stated with exactly the confidence the evidence supports, and still aimed at the question the user actually asked.
- Triggers: `load mindmake ai turbo`; `mindmake ai turbo`; Keeps every answer as short and direct as the task allows, stated with exactly the confidence the evidence supports, and still aimed at the question the user actually asked..
- Wrapper: [MindMake AI Turbo](<../Jobs/MindMake AI Turbo/Skills/mindmake-ai-turbo/SKILL.md>).
- PPI source: [AI_TURBO_v0.1.2.md](<../Jobs/MindMake AI Turbo/Products/AI_TURBO_v0.1.2.md>).
- Read the source in the current conversation before precision work.

### MindMake Heartbeat

- Type: helper (PPI), version 0.1.1; loaded on demand in X3.0.
- Use for: Checks that an AI assistant's setup actually loaded (governing instructions, profiles, memory, task list, other helpers) and restores it after the conversation is compressed or reset.
- Triggers: `load mindmake heartbeat`; `mindmake heartbeat`; Checks that an AI assistant's setup actually loaded (governing instructions, profiles, memory, task list, other helpers) and restores it after the conversation is compressed or reset..
- Wrapper: [MindMake Heartbeat](<../Jobs/MindMake Heartbeat/Skills/mindmake-heartbeat/SKILL.md>).
- PPI source: [HEARTBEAT_v0.1.1.md](<../Jobs/MindMake Heartbeat/Products/HEARTBEAT_v0.1.1.md>).
- Read the source in the current conversation before precision work.

### MindMake SkillMaster

- Type: helper (PPI), version 0.1.1; loaded on demand in X3.0.
- Use for: Helps an AI assistant pick the right skill, tool or connection for the task, and be honest about what actually works.
- Triggers: `load mindmake skillmaster`; `mindmake skillmaster`; Helps an AI assistant pick the right skill, tool or connection for the task, and be honest about what actually works..
- Wrapper: [MindMake SkillMaster](<../Jobs/MindMake SkillMaster/Skills/mindmake-skillmaster/SKILL.md>).
- PPI source: [SKILLMASTER_v0.1.1.md](<../Jobs/MindMake SkillMaster/Products/SKILLMASTER_v0.1.1.md>).
- Read the source in the current conversation before precision work.

### MindMake TaskCycle

- Type: helper (PPI), version 0.1.3; loaded on demand in X3.0.
- Use for: Works through the user's to-do list on its own, within limits.
- Triggers: `load mindmake taskcycle`; `mindmake taskcycle`; Works through the user's to-do list on its own, within limits..
- Wrapper: [MindMake TaskCycle](<../Jobs/MindMake TaskCycle/Skills/mindmake-taskcycle/SKILL.md>).
- PPI source: [TASKCYCLE_v0.1.3.md](<../Jobs/MindMake TaskCycle/Products/TASKCYCLE_v0.1.3.md>).
- Read the source in the current conversation before precision work.

### MindMake Seed Capsule

- Type: helper (PPI), version 0.2.1.
- Use for: Adds a short capsule (assertion, proof, uncertainty, plus optional meaning and next move) to the top of important memory seeds, so a future assistant can orient fast and then check the real proof.
- Triggers: `load mindmake seed capsule`; `mindmake seed capsule`; Adds a short capsule (assertion, proof, uncertainty, plus optional meaning and next move) to the top of important memory seeds, so a future assistant can orient fast and then check the real proof..
- Wrapper: [MindMake Seed Capsule](<../Jobs/MindMake Seed Capsule/Skills/mindmake-seed-capsule/SKILL.md>).
- PPI source: [SEED_CAPSULE_v0.2.1.md](<../Jobs/MindMake Seed Capsule/Products/SEED_CAPSULE_v0.2.1.md>).
- Read the source in the current conversation before precision work.

### Personal Assistant

- Type: helper (PPI), version 0.1.1.
- Use for: A goal-focused personal assistant that keeps you moving on what matters: it remembers the current direction, turns unfinished work into one next action, follows up on commitments from sources you approve, and sets reminders you control, while being honest about what is actually connected, scheduled or sent.
- Triggers: `load personal assistant`; `personal assistant`; A goal-focused personal assistant that keeps you moving on what matters: it remembers the current direction, turns unfinished work into one next action, follows up on commitments from sources you approve, and sets reminders you control, while being honest about what is actually connected, scheduled or sent..
- Wrapper: [Personal Assistant](<../Jobs/Personal Assistant/Skills/personal-assistant/SKILL.md>).
- PPI source: [PERSONAL_ASSISTANT_v0.1.1.md](<../Jobs/Personal Assistant/Products/PERSONAL_ASSISTANT_v0.1.1.md>).
- Read the source in the current conversation before precision work.

### Personal MCP Builder

- Type: helper (PPI), version 0.1.1.
- Use for: Explains why an AI assistant sometimes needs a small local tool server (MCP), and helps a person design, build, connect and verify one safely, with the smallest possible set of tools.
- Triggers: `load personal mcp builder`; `personal mcp builder`; Explains why an AI assistant sometimes needs a small local tool server (MCP), and helps a person design, build, connect and verify one safely, with the smallest possible set of tools..
- Wrapper: [Personal MCP Builder](<../Jobs/Personal MCP Builder/Skills/personal-mcp-builder/SKILL.md>).
- PPI source: [PERSONAL_MCP_BUILDER_v0.1.1.md](<../Jobs/Personal MCP Builder/Products/PERSONAL_MCP_BUILDER_v0.1.1.md>).
- Read the source in the current conversation before precision work.

### Your AI Companion

- Type: helper (PPI), version 0.1.2.
- Use for: Gives an AI assistant a steady, honest working personality, Pete or Jess, the user's choice.
- Triggers: `load your ai companion`; `your ai companion`; Gives an AI assistant a steady, honest working personality, Pete or Jess, the user's choice..
- Wrapper: [Your AI Companion](<../Jobs/Your AI Companion/Skills/your-ai-companion/SKILL.md>).
- PPI source: [YOUR_AI_COMPANION_v0.1.2.md](<../Jobs/Your AI Companion/Products/YOUR_AI_COMPANION_v0.1.2.md>).
- Read the source in the current conversation before precision work.

### PPI Architect

- Type: tool (PPI Toolbox), version 0.2.3.
- Use for: Turns a person's own knowledge into a PPI (Portable Plug-in): a helper another AI can run without guessing.
- Triggers: `load ppi architect`; `ppi architect`; Turns a person's own knowledge into a PPI (Portable Plug-in): a helper another AI can run without guessing..
- Wrapper: [PPI Architect](<../Jobs/PPI Architect/Skills/ppi-architect/SKILL.md>).
- PPI source: [PPI_ARCHITECT_v0.2.3.md](<../Jobs/PPI Architect/Products/PPI_ARCHITECT_v0.2.3.md>).
- Read the source in the current conversation before precision work.

### PPI Export

- Type: tool (PPI Toolbox), version 0.2.2.
- Use for: Packages a tested PPI helper as a readable document and an optional Agent Plugins folder, checks the files are well formed, and states plainly where they will and won't work.
- Triggers: `load ppi export`; `ppi export`; Packages a tested PPI helper as a readable document and an optional Agent Plugins folder, checks the files are well formed, and states plainly where they will and won't work..
- Wrapper: [PPI Export](<../Jobs/PPI Export/Skills/ppi-export/SKILL.md>).
- PPI source: [PPI_EXPORT_v0.2.2.md](<../Jobs/PPI Export/Products/PPI_EXPORT_v0.2.2.md>).
- Read the source in the current conversation before precision work.

### PPI Revise

- Type: tool (PPI Toolbox), version 0.2.2.
- Use for: Applies only the changes a PPI owner approved, keeps everything else word for word, and records every change so versions can be trusted or rolled back.
- Triggers: `load ppi revise`; `ppi revise`; Applies only the changes a PPI owner approved, keeps everything else word for word, and records every change so versions can be trusted or rolled back..
- Wrapper: [PPI Revise](<../Jobs/PPI Revise/Skills/ppi-revise/SKILL.md>).
- PPI source: [PPI_REVISE_v0.2.2.md](<../Jobs/PPI Revise/Products/PPI_REVISE_v0.2.2.md>).
- Read the source in the current conversation before precision work.

### PPI Test

- Type: tool (PPI Toolbox), version 0.2.1.
- Use for: Checks whether a PPI helper is complete and behaves as its own tests say, before anyone relies on it.
- Triggers: `load ppi test`; `ppi test`; Checks whether a PPI helper is complete and behaves as its own tests say, before anyone relies on it..
- Wrapper: [PPI Test](<../Jobs/PPI Test/Skills/ppi-test/SKILL.md>).
- PPI source: [PPI_TEST_v0.2.1.md](<../Jobs/PPI Test/Products/PPI_TEST_v0.2.1.md>).
- Read the source in the current conversation before precision work.

### MindMake Guide

- Type: reference, version 0.4.
- Use for: The quick start and user manual in one: what MindMake is, the two ways to use it, the helpers, the folder, memory, safety and troubleshooting.
- Triggers: `load mindmake guide`; `mindmake guide`; The quick start and user manual in one: what MindMake is, the two ways to use it, the helpers, the folder, memory, safety and troubleshooting..
- Wrapper: [MindMake Guide](<../Jobs/MindMake Guide/Skills/mindmake-guide/SKILL.md>).
- PPI source: [MINDMAKE_X2_GUIDE_v0.4.md](<../Jobs/MindMake Guide/Products/MINDMAKE_X2_GUIDE_v0.4.md>).
- Read the source in the current conversation before precision work.

## Shared host workflow

- [mindmake-workspace](<skills/mindmake-workspace/SKILL.md>): load, recovery, shared seed routing and map maintenance for this local host. The product wrappers remain registered above.
- Apply [the local deployment policy](<governance/WORKSPACE_POLICY.md>) before product setup instructions. This is a workspace registry, not a claim of global Codex skill installation.


## Personal Assistant

- [personal-assistant](<../Jobs/Personal Assistant/Skills/personal-assistant/SKILL.md>): goals, relevant connections, routine reviews, next actions and reminders. Read the full source before precision work.
- [Capability guide](CAPABILITIES.md): what each helper does and which account checks are needed.
