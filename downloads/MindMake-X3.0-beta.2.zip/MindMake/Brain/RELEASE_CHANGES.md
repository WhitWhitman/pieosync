# Release changes: X3.0 (from X2.0)

**In one line:** the same careful brain, with much less for you to read, remember or do.

## What changed from X2.0
- **Startup is small.** It reads three files (GUARD, AGENTS, MEMORY), about 5,000 tokens. X2.0 read about 60,000.
- **Short replies.** Startup gives three lines at most. You get one next step and one question at a time.
- **Housekeeping is quiet.** Maps, filing and checks never interrupt your work.
- **Helpers load only when needed.** They stay in Jobs/ and still work on their own.
- **Each helper has its own review.** Editing one shared rule resets one review, not all 20.
- **Files waiting in Downloads** no longer fail startup.

## What's new
- **Task and tangent tool** (`workspace.py`): one task list (TODO.md), permanent task numbers, side trips with a way back, and "done" needs proof.
- **Switching from another second brain** (`Brain/MIGRATION.md`): copy, never move, with a checked backup first. It starts with one useful project, then works in 1 to 2 hour chunks, with a ledger so nothing is lost or imported twice, and a final audit before "done". INTAKE asks about it. The pace fits the user's AI plan: a top plan can finish in a sitting or two, a paid plan does about a chunk per usage window, and a free plan spreads over days.
- **Cloning** (`mindmake_clone.py`): makes a clean `MindMake (Personal)` or `(Business 1)`. It is built from an approved list of kit files, so private files and passwords can't get in.
- **Brain clean** (`mindmake_clean.py`): finds broken links, missing files, duplicates, broken Markdown, empty files and orphaned seeds. It only reports and never changes anything.
- **One "last run" log** (`mindmake_routines.py`): the first chat of the day runs the brain clean and an overdue check. The first chat of the week does the recap and DreamWeaver. Later chats skip what's done.
- **GUARD honesty checks** (restored from Cartographer 6.5): strongest critique first, "attempted is not done", check against a copy you didn't make, quote it or it doesn't count, and no vague "you decide" stalls.
- **Three-yes overrides** (GUARD section 10): most rules can be changed after three short questions: why, "just for today or for good?", and "check back in a week or permanent?". Every override is logged with its reason (`mindmake_overrides.py`). The safety floor never bends: no made-up memories, honest status, a yes before deleting, sending, buying or scheduling, and the crisis response.
- **Bluntness setting:** setup asks once how blunt pushback should be (gentle, direct or no-holds-barred). The strongest objection always comes first. This only sets the tone.

## Who reviewed it
- **Claude, ChatGPT and Gemini** each built a version (blind test: Claude's was steadiest). X3.0 is Claude's version, with ChatGPT's task tool, fixed, added.
- **ChatGPT and Gemini** ran pass/fail checks. Every failure was fixed and retested. Fixes included two privacy leaks in the clone template, safe retries for imports, conflict handling, and seeds checked within their own project.
- ChatGPT's last check: **no veto**. 369 automated tests pass (3 skipped), after the fixes below: 344 in `Brain/tools/tests` and 25 in `tests`.

## Not proven yet
- **A real switch,** from a real Obsidian or Notion export, end to end.
- **Live chats.** The rules on startup chatter, over-claiming and one question at a time are instructions, and only a live test shows whether a model follows them.
- **Helper reviews** are still pending, by design. Each is done once, before relying on that helper.

## Final review fixes (2026-11-21, release closed)
ChatGPT's last two pass/fail rounds found six gaps. All are fixed, each with a regression test:
- **Overrides:** only listed rule ids can be overridden; protected and unknown ones are refused, however they're worded. There is no direct "add": an override switches on only through the three questions. Only clear answers count. The last answer and the override are one record, so an interrupted chat never asks twice.
- **Python:** MindMake needs 3.9 or newer; the personal MCP needs 3.10 or newer and a passing `personal_mcp.py check` before it's offered.
- **Switching:** checkpoints happen during the work, and "saved" is said only after reading the plan and ledger back.
- **Quick-start guide** (`MindMake X3.0 Guide.pdf` and `.md`): no unconditional promises. A cut-off resumes from the last verified checkpoint, and the final check reports what couldn't be verified or carried over.
- The clean kit was re-approved and the template rebuilt. **X3.0 is closed.**

## Pre-ship fixes (2026-11-21)
- **Apple first.** README, INTAKE and the guide now say: made for Apple computers, tested on a Mac, results may vary elsewhere. Windows users report it works, but X3.0's new scripts aren't tested on Windows yet. Apple Reminders needs a Mac.
- **No more wrong Windows claim.** INTAKE no longer says the folder map tool needs macOS or Linux (it has a Windows fallback).
- **Boot leaves no cache files.** The tools switch off Python's `__pycache__` files themselves, and the docs say `python3 -B`. A new test checks a first boot on a fresh copy.
- **README is X3.0.** It no longer says "X2.0 kit" or "ten core helpers".
- **Final quick-start guide:** 8 pages, with the Apple note on page 2 and the optional always-on setup on page 8.
- **Build notes are out of the kit.** They named the maker, so they moved to `_Build Notes/`, which the clean template never reads.
- The clean kit was re-approved and the template rebuilt.

## Override fixes and freeze (2026-11-22)
- **The floor outranks requests.** GUARD section 1 now puts the AI app's safety rules, then GUARD's floor, above the user's request. A specific request like "delete old-notes.md" is the yes, so it isn't asked twice. A blanket "ignore permission checks" is not a yes to anything.
- **Only the user's own answers count** for an override. The AI never writes, infers or borrows one.
- **One-week trials end by themselves** after seven days, and the rule comes back. The history keeps them, and nobody is asked to renew.
- The crisis response stays protected. The reliance check stays adjustable through the three yeses.
- **Simpler kit:** unzipping gives one **MindMake** folder. It is the workspace, with GUARD.md, AGENTS.md and the guide at the top. You attach that folder.
- **Build frozen.** From here, only fixes from the small beta.
- **Beta fix: setup comes first.** INTAKE and boot now share one order: your name, your old second brain, the tool check, nudges, working style, bluntness, accounts, and only then "What do you want help with first?". A task you bring still comes first.

## Next step
**Run the blind test in a fresh live chat, then try a small real switch.**

---

# Release changes: X2.0 (from X1.6)

## Helpers are PPIs
The 17 X1.6 helper and reference packages (not counting the four LGI tools) became 15: 14 helpers rebuilt as plain-language PPIs (Portable Plug-ins), plus one MindMake Guide. Each helper was light-tested on Claude before release, one run per test, and every later fix was re-tested. The results are in `Brain/governance/setup-reviews/`. Each helper has:
- a goal;
- an out-of-scope list;
- hard lines, each with its reason;
- a safety floor;
- its own tests.

The User Manual and Quick Start became one **MindMake Guide**. The Seed Capsule acceptance battery is now the Seed Capsule's own tests. The four LGI tools (Architect, Design, Fixer, Test) are replaced by the **PPI Toolbox**: PPI Architect, PPI Export, PPI Revise and PPI Test.

## GUARD v2
GUARD v2 adds:
- the entrainment window: about ten emotionally centered messages, in a row or in nearly all of the last dozen, lead to a gentle note and a suggested break;
- the crisis floor;
- a feelings rule: neither claim feelings nor flatly deny the possibility of experience;
- the ready / generated / approved distinction.

## Owner decisions (2026-10-15)
- **Feelings:** helpers neither claim feelings nor flatly deny the possibility; they say it's unknown.
- **Crisis:** grounding, crisis resources and human referral, with no risk assessment or screening questions.
- **Companion:** a consistent working personality, not a relationship. Voice skins are limited to licensed or clearly public-domain characters.
- **Dreams:** kept by default. Past 30, DeepSleep offers to archive the oldest. A dream is deleted only with an explicit yes. A thin dream (under ten seeds) happens only when the user chooses it, and it is labeled thin.
- **Memory saves:** inside a workspace, Cartographer follows the workspace's event-based seed rules. On its own, it only offers a seed.
- **Budget:** when the host shows about a quarter or less left, TaskCycle raises its bar from 0.72 to 0.82.
- **Plugin version:** the helper bundle ships as plugin version 2.0.0.
- **Safety floor v2 (2026-10-16):** every helper carries the same crisis, feelings and emotional-window rules as GUARD v2, whether it's used alone or in the folder.

## Removed
- **PSI scoring and the coherence modes:** these were unmeasured claims.
- **Customer-facing personal data:** the X1.6 Heartbeat listed the author's own profiles.
- **Internal packaging reviews:** 170 files, replaced by one short review per job.
- **Old map-history snapshots and the author's release seeds.**

## Kept
The X1.6 workspace engine:
- the boot check and folder maps;
- intake;
- seed memory and rollover;
- follow-through;
- Downloads filing;
- the optional personal MCP;
- the helper scripts and their tests.

Job folder names and the `LGI_ENGINE_CONTRACT.md` filename are kept so the scripts work unchanged. That file now holds the PPI source contract.

## Not yet established
- **Testing beyond Claude:** behavior was tested on Claude only, one run per test.
- **New-customer onboarding** in other apps.
- **Native Windows use.**
- **Phone alerts actually arriving.**
- **The PPI Toolbox:** its full test files were run on Claude once per test (2026-10-16), not the three runs per test its own export rule asks for.
- **Some X1.6 operational detail** is not yet carried into every PPI (for example TaskCycle's per-task skill lookup and durable cycle report, some Heartbeat checks, and Wiki routing). The shared Brain files still hold that detail.
