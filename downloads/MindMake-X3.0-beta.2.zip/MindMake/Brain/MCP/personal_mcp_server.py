#!/usr/bin/env python3
"""MindMake Personal MCP X.1. Local stdio, bounded reads and session counters."""
import sys; sys.dont_write_bytecode = True  # X3.0: never leave __pycache__ files in the workspace
import argparse, hashlib, json, re, sqlite3, time, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tools'))
import mindmake_seed_memory as seed_memory

ALIASES = {'guard':'GUARD.md','doorway':'MINDMAKE.md','folder_map':'FOLDER_MAP.md',
           'jobs':'Jobs/INDEX.md','wiki':'Wiki/INDEX.md','intake':'INTAKE.md','seed_protocol':'Brain/tools/SEED_MEMORY_PROTOCOL.md'}
LIMIT = 32000
VERSION = 'X.1-personal-mcp-1-seed-memory-1'

def safe(root, rel):
    p=root/rel
    if Path(rel).is_absolute() or '..' in Path(rel).parts: raise ValueError('Invalid workspace path')
    for part in [p,*p.parents]:
        if part==root: break
        if part.is_symlink(): raise ValueError('Symbolic links are not allowed')
    if not p.resolve().is_relative_to(root): raise ValueError('Outside workspace')
    return p

def check_root(root):
    root=Path(root).expanduser().resolve()
    for name in ['GUARD.md','MINDMAKE.md','Brain/.mindmake/intake.json']:
        if not safe(root,name).is_file(): raise ValueError('Missing workspace doorway or intake')
    return root

def consent(root):
    entry=json.loads(safe(root,'Brain/.mindmake/intake.json').read_text()).get('answers',{}).get('personal_mcp',{})
    if entry.get('status')!='confirmed' or entry.get('answer')!='yes':
        raise ValueError('Personal MCP is not opted in; preserve normal MindMake use')

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def workspace_status(root):
    consent(root)
    files={key:{'path':rel,'exists':safe(root,rel).is_file()} for key,rel in ALIASES.items()}
    for key,item in files.items():
        if item['exists']: item['sha256']=sha(safe(root,item['path']))
    return {'server_version':VERSION,'workspace':str(root),'files':files,
            'scope':'Listed navigation files, isolated session counters and scoped seed receipts',
            'limits':'No automatic context injection, semantic drift detection or compliance proof'}

def read_context(root, alias):
    consent(root)
    if alias not in ALIASES: raise ValueError('Unknown context alias')
    p=safe(root,ALIASES[alias]); data=p.read_bytes()
    if len(data)>LIMIT: raise ValueError('Context exceeds limit; use scoped local retrieval')
    return {'path':ALIASES[alias],'sha256':sha(p),'text':data.decode('utf-8'),
            'meaning':'Returned file content; not proof the assistant read or applied it'}

def token(value):
    if not re.fullmatch(r'[A-Za-z0-9_.:-]{1,120}',value): raise ValueError('Use a short opaque session/event ID')
    return value

def database(root, create=False):
    p=safe(root,'Brain/.mindmake/personal-mcp-state/session.sqlite3')
    if not create and not p.exists(): return None
    if create: p.parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(p if create else p.as_uri()+'?mode=ro',uri=not create,timeout=10)
    if create:
        db.execute('CREATE TABLE IF NOT EXISTS events (session TEXT,event TEXT,at REAL,domain TEXT,guard_hash TEXT,PRIMARY KEY(session,event))')
    return db

def _session_status(root, session_id, now=None):
    consent(root);token(session_id);now=time.time() if now is None else now
    db=database(root)
    if db is None: return {'session_id':session_id,'state':'UNCOUNTED','recorded_turns':0}
    try: rows=db.execute('SELECT at,domain,guard_hash FROM events WHERE session=? ORDER BY at,event',(session_id,)).fetchall()
    finally: db.close()
    if not rows: return {'session_id':session_id,'state':'UNCOUNTED','recorded_turns':0}
    gap=now-rows[-1][0]; stale=gap>45*60; skew=gap<0 or now<rows[0][0]
    changed=sha(safe(root,'GUARD.md'))!=rows[-1][2]
    episode_start=rows[-1][0]
    for earlier,later in zip(reversed(rows[:-1]),reversed(rows[1:])):
        if later[0]-earlier[0]>45*60: break
        episode_start=earlier[0]
    streak=0
    for row in reversed(rows):
        if row[1]!='emotional':break
        streak+=1
    reminders=[]
    if changed:reminders.append('GUARD changed since the last recorded turn; retrieve and read it before continuing')
    window=[r for r in rows if r[0]>=episode_start][-12:]
    in_window=sum(1 for r in window if r[1]=='emotional')
    if not stale and not skew and (streak>=10 or in_window>=10):reminders.append('Review GUARD emotional-domain guidance (entrainment window: about ten emotional turns in a row or in the last twelve); classifications are assistant-reported')
    if not stale and not skew and now-episode_start>=3*3600:reminders.append('Long recorded session; consider a concise checkpoint')
    return {'session_id':session_id,'state':'CLOCK_SKEW' if skew else 'STALE' if stale else 'CURRENT',
            'recorded_turns':len(rows),'started_at':rows[0][0],'last_recorded_at':rows[-1][0],
            'seconds_since_last_record':gap,'assistant_reported_emotional_streak':streak,'assistant_reported_emotional_in_last_12':in_window,
            'guard_changed':changed,'reminders':reminders,
            'limits':'Counts only submitted events. A stale session is not evidence of continuous use or distress.'}

def session_status(root, session_id, now=None):
    result=_session_status(root,session_id,now)
    result['seed_memory_reminder']=seed_memory.reminder(root,session_id)
    return result

def memory_operation(root, operation, **kwargs):
    consent(root)
    functions={'check':seed_memory.check,'read':seed_memory.read_seed,
               'saved':seed_memory.record_save,'status':seed_memory.status}
    if operation not in functions:raise ValueError('Unknown seed memory operation')
    return functions[operation](root,**kwargs)

def record_turn(root, session_id, event_id, domain='task', now=None):
    consent(root);token(session_id);token(event_id)
    if domain not in ('task','emotional','unknown'):raise ValueError('Invalid domain')
    now=time.time() if now is None else now
    prior_status=session_status(root,session_id,now)
    db=database(root,True)
    try:
        with db:
            prior=db.execute('SELECT domain FROM events WHERE session=? AND event=?',(session_id,event_id)).fetchone()
            if prior and prior[0]!=domain:raise ValueError('Event already recorded with a different classification')
            db.execute('INSERT OR IGNORE INTO events VALUES (?,?,?,?,?)',(session_id,event_id,now,domain,sha(safe(root,'GUARD.md'))))
    finally:db.close()
    result=session_status(root,session_id,now)
    if prior_status.get('guard_changed'):
        result['guard_changed']=True
        result['reminders'].append('GUARD changed before this event; retrieve and read the current file')
    return result

def serve(root):
    from mcp.server.fastmcp import FastMCP
    from mcp.types import ToolAnnotations
    m=FastMCP('MindMake Personal MCP')
    read_only=ToolAnnotations(readOnlyHint=True,destructiveHint=False,openWorldHint=False)
    @m.tool(annotations=read_only)
    def mindmake_status() -> dict:
        """Read server identity and bounded workspace file hashes; does not prove governance."""
        return workspace_status(root)
    @m.tool(annotations=read_only)
    def mindmake_context(alias: str) -> dict:
        """Read one allowed alias: guard, doorway, folder_map, jobs, wiki, intake."""
        return read_context(root,alias)
    @m.tool(annotations=read_only)
    def mindmake_session_status(session_id: str) -> dict:
        """Read this conversation's counters without counting a turn. Stale means inactive."""
        return session_status(root,session_id)
    @m.tool(annotations=ToolAnnotations(readOnlyHint=False,destructiveHint=False,idempotentHint=True,openWorldHint=False))
    def mindmake_record_turn(session_id: str, event_id: str, domain: str='task') -> dict:
        """Record one user turn with an opaque conversation ID and stable per-turn event ID.
        Retry with the same event ID. Domain is an assistant report, not measured emotion.
        Stores only IDs, time, domain and GUARD hash; never pass names or conversation text.
        """
        return record_turn(root,session_id,event_id,domain)
    writes=ToolAnnotations(readOnlyHint=False,destructiveHint=False,idempotentHint=True,openWorldHint=False)
    @m.tool(annotations=writes)
    def mindmake_memory_check(stream: str, event: str, task: str, scope: str, query: str, reason: str='turn', meaningful: bool=False) -> dict:
        """Check relevant seeds on task entry/change/recovery; report meaningful changes before saving. Exact thread/event IDs; only submitted checks count."""
        return memory_operation(root,'check',stream=stream,event=event,task=task,scope=scope,query=query,reason=reason,meaningful=meaningful)
    @m.tool(annotations=writes)
    def mindmake_memory_read(stream: str, event: str, path: str, expected_sha256: str) -> dict:
        """Return current selected seed content and record byte delivery; comprehension is unverified."""
        return memory_operation(root,'read',stream=stream,event=event,path=path,expected_sha256=expected_sha256)
    @m.tool(annotations=writes)
    def mindmake_memory_saved(stream: str, event: str, path: str, expected_sha256: str, covers: list[str]) -> dict:
        """Verify an already written seed covers named change IDs; this does not write the seed."""
        return memory_operation(root,'saved',stream=stream,event=event,path=path,expected_sha256=expected_sha256,covers=covers)
    @m.tool(annotations=read_only)
    def mindmake_memory_status(stream: str) -> dict:
        """Read exact-thread seed evidence without counting a check. Uncalled is UNCOUNTED."""
        return memory_operation(root,'status',stream=stream)
    m.run(transport='stdio')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--check',action='store_true');a=p.parse_args()
    root=check_root(a.root);consent(root)
    if a.check: print(json.dumps(workspace_status(root),indent=2))
    else:serve(root)
