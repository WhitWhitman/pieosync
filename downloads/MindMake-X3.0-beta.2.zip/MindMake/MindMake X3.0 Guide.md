# MindMake X3.0: Quick Start

*Version 1.0, November 2026*

## MINDMAKE 3.0

**MindMake is a second brain your AI operates, with you in control.**

I have ADHD and dyslexia. I built MindMake so I could come back after a distraction without rebuilding the whole picture.

It keeps track of your projects, decisions and next steps in files you own. Many second brains still leave the organizing to you. MindMake handles the work most of us struggle to maintain.

It shows where every memory came from, and it requires evidence before it says work is done.

Your continuity belongs to you. It moves with you between AI services.

**MindMake meets the brain you actually have.**

---

<!-- page break (PDF) -->

## 1. Set it up (once)

1. **Unzip MindMake.** You get one **MindMake** folder, with this guide inside. Put it on your Desktop, or on a drive you always use. Keep the folder whole.
2. **Get an AI app that can work with folders.** It must open a folder on your computer and run small programs. A plain chat window won't work.
   - **Claude** (the desktop app's Cowork, or Claude Code): tested.
   - **OpenAI Codex**, **Google Gemini CLI** or **Microsoft Copilot Cowork**: should work. Not tested with MindMake yet.
3. **Attach the MindMake folder** in that app.
4. **Say "Load up."**

**Made for Apple computers.** Tested on a Mac; results may vary elsewhere. Windows users report it works, but X3.0's new scripts aren't tested on Windows yet. Apple Reminders needs a Mac.

> **Never forget:** attach the **MindMake** folder **every time** you start a new chat.

## 2. Every new chat

Attach the **MindMake** folder. Then say **"Load up."**

You'll get three short lines at most: anything broken, your next step, and anything urgent. Then it does what you ask.

| Say | What happens |
| --- | --- |
| "Load up." | Starts MindMake. |
| "Where were we?" | Your task and its next step. |
| "Back to it." | Ends a side trip. |
| "Work the list." | Works through your tasks on its own. |
| "Forget that." | Shows what it would remove, then removes it after your yes. |
| "Stop." | Stops the current work in this chat. |

---

<!-- page break (PDF) -->

## 3. The one-time setup

The first time, MindMake asks a few short questions. One at a time. Skip any of them. Setup never blocks your work: if you arrive with a task, the task comes first.

**About you.** Your name.

**Your old second brain.** If you already use one, it may offer to bring it in (page 7).

**A tool check.** It checks your computer for programs that help:
- **Python** (3.9 or newer). This runs MindMake's checks, filing, task list and cleaning. If it's missing, MindMake shows you how to install it, one step at a time. **Nothing is installed without your yes.** Some apps, like Claude's Cowork, already have it.
- **The personal MCP** (optional). A small helper that lets MindMake check itself: re-read its rules, keep count of each chat and spot changed files. It helps keep MindMake on track, but it doesn't guarantee it. It needs Python 3.10 or newer, and MindMake checks that before offering it.

**How you like to work.** How to nudge you, how much detail you want, how blunt to be, and which accounts would help.

**Then your first goal.** Once things are set up, it asks what you want help with first.

Without Python, MindMake still works, just more simply. It tells you once and never nags.

> **Do this:** answer what you want, skip what you don't. Say **"later"** anytime.

---

<!-- page break (PDF) -->

## 4. What it does for you

You don't have to ask for these.

- **One task list.** You see one next step, not a wall of tasks.
- **Side trips are fine.** Wander off topic. It parks your main task, then offers the way back: "Back to X? Next step was Y."
- **It remembers.** Decisions and promises are saved between chats, so you don't have to recap.
- **It files your downloads.** Drop files in the **Downloads** folder. If it can't tell where one goes, it leaves it there for you.
- **"Done" needs proof.** It shows you the result before it says done.

**The daily and weekly check** happens when you open a chat, after your task:
- **First chat of the day:** a brain clean (broken links, missing files, duplicates, empty files). It only reports. It changes nothing. Plus one line on anything overdue.
- **First chat of the week:** a five-line recap (saved, done, still open, waiting on others, next action) and a pass to spot patterns and gaps in your notes.

> **Do this:** drop new files in **Downloads.** The rest takes care of itself.

---

<!-- page break (PDF) -->

## 5. What it won't do behind your back

**Nothing runs between chats.** When the chat closes, MindMake stops. It won't remind you of anything unless Apple Reminders (Mac only) is set up and checked. It won't say "I'll remind you" without it.

**Honest status.** It keeps apart what it saw, what you told it, and what it guessed. Its rules forbid making up memories, sources or results. AI can still make mistakes, so it shows where a memory came from and the proof that work is done. If it can't confirm something worked, it says so.

**It asks first, and waits for a clear yes,** before it:
- deletes, or overwrites without a backup;
- sends, buys, installs or publishes anything;
- makes a schedule, or goes beyond what you asked.

**Your privacy.** It doesn't save passwords, account numbers or ID numbers. Say **"stop"** and it stops the current work. Say **"forget"** and it shows what it would remove from your MindMake files, then removes it once you say yes. It can't erase what your AI app or its company keeps. Their own settings control that.

**Pushback first.** Before agreeing with a big plan, it gives you the strongest objection. You choose how blunt.

## If something goes wrong

- **It doesn't load:** is the MindMake folder attached? Attach it and say "Load up" again.
- **It says it can't read GUARD:** the folder may be incomplete. Copy it again, whole.
- **Too wordy, or drifting:** say "shorter" or "you're drifting."

If this guide and the rule files (GUARD.md, AGENTS.md) ever disagree, the files win.

---

<!-- page break (PDF) -->

## 6. Changing a rule: three yeses

Some working-style rules can be changed, such as short replies, the pushback, or one question at a time. You don't need to know the rule's name. Just say what you want changed.

It asks three short questions, one at a time:
1. It tells you what the rule protects, and asks **why** you want to change it.
2. **"Just for today, or for good?"** Today ends at midnight.
3. If for good: **"Should I check back in a week, or make it permanent now?"** A one-week change ends by itself after seven days.

Only your own answers count. Every change is written down with your reason. If a chat ends halfway, it picks up at the next question. It never nags. If you stop answering, the rule stays as it was.

**The floor never bends.** No answer changes these:
- your AI app's own safety rules;
- no made-up memories or sources;
- honest status;
- a clear yes before deleting, sending, buying or scheduling (asking for something specific, like "delete this file", is that yes);
- the crisis response. If you might be in danger, the work stops and it points you to help. In the US, call or text **988**.

> **Do this:** say what rule you want changed. Answer the three questions.

---

<!-- page break (PDF) -->

## 7. Coming from another second brain

Obsidian, Notion, Logseq, Evernote, Apple Notes, Google Docs or Keep, or plain folders.

1. **Export a copy** and drop it in MindMake's **Downloads** folder. Not sure how? Say "I don't know where to start." It walks you through one step at a time.
2. **It backs up the copy first,** and checks the backup works.
3. **Your old system stays as it is.** MindMake copies. It won't move or delete anything without your yes.
4. **It brings in your most useful project first.**
5. **It paces itself to you.** It asks which AI plan you're on and how urgent this is. A top plan and "it's a priority" means bigger chunks. A free plan or "no rush" means small ones, spread over days. It saves checkpoints as it works. If your plan's limit cuts a chat off, it resumes from the last verified checkpoint.
6. **From then on, use only MindMake.** Slipped? Just tell it. No scolding. It can spot changes by itself only when it can read the old system directly (an Obsidian vault or a folder on this computer). For apps like Notion, it asks for one fresh export at the end.

Before it says "done", it runs a final check and tells you anything it couldn't verify or carry over.

> **Do this:** say **"I want to bring in my old notes."**

## 8. Personal and Business MindMakes

Want home and work kept apart? MindMake can make a clean, empty copy next to this one, such as **MindMake (Personal)** or **MindMake (Business 1)**. Each copy starts empty, so your notes and passwords can't leak in. Attach the one you want and say "Load up."

> **Do this:** say **"Make me a clean Business MindMake."**

---

<!-- page break (PDF) -->

## 9. Optional: the always-on setup

How Whit, who made MindMake, runs it. It's optional, not the default.

- **A computer that never sleeps.** If the computer holding MindMake stays on, awake and online, an AI app can reach it whenever you ask.
- **A voice or text assistant.** Whit uses OpenAI's "dot". It runs on its own cloud computer and keeps working while you're away. If you allow local access, it can reach your computer's files by chat, voice or text, so you can capture an idea or ask a question from anywhere. It needs ChatGPT Pro (about $100 a month when this was written), and texting is a limited US beta.
- **Google Drive for desktop.** Put the MindMake folder inside your Google Drive folder. It syncs the folder to your other computers, so any AI app that can work with folders can use it there. The Google Drive connections inside Claude and ChatGPT mostly only read files. Syncing is what actually lets them work in MindMake.

**The limits, plainly:**
- The computer has to stay on, awake and online. If it sleeps or loses its connection, nothing can reach MindMake.
- Nothing in the folder runs on its own. MindMake works only while an AI app, such as the dot, is working in it.
- **One AI writing at a time.** If two AIs change the same synced file at once, you can end up with conflicting or duplicate copies. MindMake's ledger and add-only memory notes limit the damage, but they don't prevent it.
- Files synced to Google Drive are also stored by Google. Think about that for private notes.

*Not yet tested by MindMake:* how these work together with your apps and settings.

> **Do this:** add one piece at a time, and tell MindMake what you set up so it can check it.
