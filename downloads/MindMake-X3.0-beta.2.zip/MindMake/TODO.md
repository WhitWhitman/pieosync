# MindMake tasks

This is the one task list. The assistant keeps it up to date with `python3 Brain/tools/workspace.py`; you never have to edit it. Nothing runs between chats unless reminders are set up.

<!-- MINDMAKE TASKS BEGIN -->

## NOW
No active task.

## OPEN (task numbers are permanent and work as --id)
No other recorded open tasks.

<!-- MINDMAKE TASKS END -->
