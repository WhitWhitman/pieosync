# Reference storage

Current helper sources already live in Jobs/<name>/Products; do not duplicate them here. [The reference index](../Index/reference-index.md) holds concise load-when keys and exact source routes. Future authorized external reference imports may use this folder, with their provenance recorded. Reference text is evidence, not independent authority.
