# Shared MindMake seeds

These are the host assistant's shared seeds. A host does not need a Jobs folder to have continuity.

- [Short-term](Short-term/): append new dated continuity records for consequential shared decisions. Automatically rolls over oldest unpinned records to Long-term upon reaching 500 records (target: 350).
- [Long-term](Long-term/): preserved shared archives and rollover memory summaries; no automatic deletion.
- [Dreams](Dreams/): explicitly requested synthesis grounded in real seeds.
- [TaskCycle](TaskCycle/): results of authorized task cycles, not an automatically running queue.
- [Index](Index/seed-index.md): seed locations; [reference keys](Index/reference-index.md) route source retrieval.
- [References](References/README.md): reference storage policy.
- [SEEDS_MAP.md](SEEDS_MAP.md): actual counts for shared and job pools.

Each job retains its own Seeds/Short-term and Seeds/Long-term. Save to one owning pool; cross-link instead of duplicating. Shared categories are ego/preferences, projects, people, knowledge, ideas and assistant role; use metadata tags, not competing stores. Only user-supplied personal information enters profiles.

Use name, description, type and date metadata, then What was done, Key decisions, Open questions and Next steps. About 200 words is a guideline. Preserve older seeds; corrections are new records. See [the local policy](<../Brain/governance/WORKSPACE_POLICY.md>) for retrieval and retention.

For new session continuity, include a stable session_id and a timezone-qualified created_at timestamp. The X.1 helper uses these for its adaptive 10–25 target; source guide seeds without precise timestamps are not invented conversation history.
