# Seed index

No seeds yet. New shared seeds go in [Short-term](../Short-term/). The folder map tools refresh this index.

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

<!-- MINDMAKE FOLDER MAP END -->
