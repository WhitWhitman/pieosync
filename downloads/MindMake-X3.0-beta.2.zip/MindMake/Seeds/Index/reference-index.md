# Reference keys (X2.0)

Read the load-when key first. PPI sources hold product instructions; they are not external verification. Apply [the local deployment policy](<../../Brain/governance/WORKSPACE_POLICY.md>) for setup. Open at most three relevant sources per ordinary task; an explicit full review can exceed that budget.

## MindMake DeepSleep

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [DEEPSLEEP_v0.1.3.md](<../../Jobs/MindMake DeepSleep/Products/DEEPSLEEP_v0.1.3.md>).
- Context: [job and seed routes](<../../Jobs/MindMake DeepSleep/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake Cartographer

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [CARTOGRAPHER_v0.1.2.md](<../../Jobs/MindMake Cartographer/Products/CARTOGRAPHER_v0.1.2.md>).
- Context: [job and seed routes](<../../Jobs/MindMake Cartographer/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake SignalGuard

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [SIGNALGUARD_v0.1.3.md](<../../Jobs/MindMake SignalGuard/Products/SIGNALGUARD_v0.1.3.md>).
- Context: [job and seed routes](<../../Jobs/MindMake SignalGuard/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake ThoughtVault

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [THOUGHTVAULT_v0.1.3.md](<../../Jobs/MindMake ThoughtVault/Products/THOUGHTVAULT_v0.1.3.md>).
- Context: [job and seed routes](<../../Jobs/MindMake ThoughtVault/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake DreamWeaver

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [DREAMWEAVER_v0.1.1.md](<../../Jobs/MindMake DreamWeaver/Products/DREAMWEAVER_v0.1.1.md>).
- Context: [job and seed routes](<../../Jobs/MindMake DreamWeaver/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake Seed Protocol

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [SEED_PROTOCOL_v0.1.3.md](<../../Jobs/MindMake Seed Protocol/Products/SEED_PROTOCOL_v0.1.3.md>).
- Context: [job and seed routes](<../../Jobs/MindMake Seed Protocol/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake AI Turbo

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [AI_TURBO_v0.1.2.md](<../../Jobs/MindMake AI Turbo/Products/AI_TURBO_v0.1.2.md>).
- Context: [job and seed routes](<../../Jobs/MindMake AI Turbo/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake Heartbeat

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [HEARTBEAT_v0.1.1.md](<../../Jobs/MindMake Heartbeat/Products/HEARTBEAT_v0.1.1.md>).
- Context: [job and seed routes](<../../Jobs/MindMake Heartbeat/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake SkillMaster

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [SKILLMASTER_v0.1.1.md](<../../Jobs/MindMake SkillMaster/Products/SKILLMASTER_v0.1.1.md>).
- Context: [job and seed routes](<../../Jobs/MindMake SkillMaster/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake TaskCycle

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow (or on "load up", as a core helper).
- Source: [TASKCYCLE_v0.1.3.md](<../../Jobs/MindMake TaskCycle/Products/TASKCYCLE_v0.1.3.md>).
- Context: [job and seed routes](<../../Jobs/MindMake TaskCycle/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake Seed Capsule

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow.
- Source: [SEED_CAPSULE_v0.2.1.md](<../../Jobs/MindMake Seed Capsule/Products/SEED_CAPSULE_v0.2.1.md>).
- Context: [job and seed routes](<../../Jobs/MindMake Seed Capsule/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## Personal Assistant

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow.
- Source: [PERSONAL_ASSISTANT_v0.1.1.md](<../../Jobs/Personal Assistant/Products/PERSONAL_ASSISTANT_v0.1.1.md>).
- Context: [job and seed routes](<../../Jobs/Personal Assistant/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## Personal MCP Builder

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow.
- Source: [PERSONAL_MCP_BUILDER_v0.1.1.md](<../../Jobs/Personal MCP Builder/Products/PERSONAL_MCP_BUILDER_v0.1.1.md>).
- Context: [job and seed routes](<../../Jobs/Personal MCP Builder/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## Your AI Companion

- Core: helper (PPI).
- Load when: the user requests this helper or its workflow.
- Source: [YOUR_AI_COMPANION_v0.1.2.md](<../../Jobs/Your AI Companion/Products/YOUR_AI_COMPANION_v0.1.2.md>).
- Context: [job and seed routes](<../../Jobs/Your AI Companion/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## PPI Architect

- Core: tool (PPI Toolbox).
- Load when: the user requests this tool or its workflow.
- Source: [PPI_ARCHITECT_v0.2.3.md](<../../Jobs/PPI Architect/Products/PPI_ARCHITECT_v0.2.3.md>).
- Context: [job and seed routes](<../../Jobs/PPI Architect/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## PPI Export

- Core: tool (PPI Toolbox).
- Load when: the user requests this tool or its workflow.
- Source: [PPI_EXPORT_v0.2.2.md](<../../Jobs/PPI Export/Products/PPI_EXPORT_v0.2.2.md>).
- Context: [job and seed routes](<../../Jobs/PPI Export/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## PPI Revise

- Core: tool (PPI Toolbox).
- Load when: the user requests this tool or its workflow.
- Source: [PPI_REVISE_v0.2.2.md](<../../Jobs/PPI Revise/Products/PPI_REVISE_v0.2.2.md>).
- Context: [job and seed routes](<../../Jobs/PPI Revise/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## PPI Test

- Core: tool (PPI Toolbox).
- Load when: the user requests this tool or its workflow.
- Source: [PPI_TEST_v0.2.1.md](<../../Jobs/PPI Test/Products/PPI_TEST_v0.2.1.md>).
- Context: [job and seed routes](<../../Jobs/PPI Test/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.

## MindMake Guide

- Core: reference.
- Load when: the user requests this reference or its workflow.
- Source: [MINDMAKE_X2_GUIDE_v0.4.md](<../../Jobs/MindMake Guide/Products/MINDMAKE_X2_GUIDE_v0.4.md>).
- Context: [job and seed routes](<../../Jobs/MindMake Guide/JOB.md>).
- Status: tested source; file checks are separate from behavior in a given conversation.
