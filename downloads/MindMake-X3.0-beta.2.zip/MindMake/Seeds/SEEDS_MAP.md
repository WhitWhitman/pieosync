# Shared and job seed map

Counts below are generated from the packaged pools. Short-term pools automatically roll over the oldest unpinned records to Long-term upon reaching 500 records (target: 350).

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

| Pool | Short-term | Long-term |
|---|---:|---:|
| [Seeds](<.>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake AI Turbo/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake Cartographer/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake DeepSleep/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake DreamWeaver/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake Guide/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake Heartbeat/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake Seed Capsule/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake Seed Protocol/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake SignalGuard/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake SkillMaster/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake TaskCycle/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/MindMake ThoughtVault/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/PPI Architect/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/PPI Export/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/PPI Revise/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/PPI Test/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/Personal Assistant/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/Personal MCP Builder/Seeds>) | 0 | 0 |
| [Seeds](<../Jobs/Your AI Companion/Seeds>) | 0 | 0 |

<!-- MINDMAKE FOLDER MAP END -->
