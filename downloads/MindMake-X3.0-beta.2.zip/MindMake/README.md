# MindMake X3.0 workspace

An AI-run second brain. The AI does the remembering, filing and follow-through; you check its work.

**Made for Apple computers.** Tested on a Mac; results may vary elsewhere. Windows users report it works, but X3.0's new scripts aren't tested on Windows yet. Apple Reminders needs a Mac.

Start with the quick-start guide: [MindMake X3.0 Guide.pdf](<MindMake X3.0 Guide.pdf>) (also as [Markdown](<MindMake X3.0 Guide.md>)).

To set up:
1. Extract the whole folder, including the hidden `Brain/.mindmake` directory.
2. Open or attach the folder in an AI app that can read local files and run Python 3.9 or newer.
3. Say **"Load up."** The assistant reads three short files ([GUARD.md](GUARD.md), [AGENTS.md](AGENTS.md), [Brain/MEMORY.md](Brain/MEMORY.md)), runs the folder check and replies in three lines at most.

Setup questions ([INTAKE.md](INTAKE.md)) come later, one at a time, at a natural pause. You can skip any of them.

## What's inside

- **[TODO.md](TODO.md):** the one task list. The assistant keeps it up to date.
- **[Jobs](Jobs/INDEX.md):** one folder for each helper, tool and reference (19 in all), plus any project folders you create. Helpers load only when a task needs them.
- **[Brain](Brain/INDEX.md):** governance, profiles (empty until you answer), the helper scripts and their tests, and the optional personal MCP server.
- **[Seeds](Seeds/README.md):** shared memory across sessions, empty at the start.
- **[Wiki](Wiki/INDEX.md):** references, read when needed.
- **[Downloads](Downloads/INDEX.md):** files waiting to be filed.

The [folder map](FOLDER_MAP.md) and [filing rules](Brain/FILING.md) keep everything findable.

New in X3.0: the task and tangent tool, switching from another second brain ([Brain/MIGRATION.md](Brain/MIGRATION.md)), clean Personal and Business copies, the daily brain clean, and three-yes rule overrides. See [release changes](Brain/RELEASE_CHANGES.md).

## Standalone PDFs and optional plugins

- [Helpers (PDF)](<Helpers (PDF)/>): standalone versions of the 14 helpers.
- [Plugin](<Plugin/>): optional Agent Plugin ZIPs. The helper bundle is still the X2.0 one (version 2.0.0); the helpers didn't change in X3.0.
- [Toolbox (PDF)](<Toolbox (PDF)/>): Architect, Export, Revise and Test.

These are for using a helper on its own. Inside this folder, the working sources load from `Jobs/` via [Brain/SKILLS.md](Brain/SKILLS.md).

## Honest limits

- Nothing runs between chats. The Downloads watcher, Apple Reminders and the personal MCP are optional and stay off until you set them up and they are verified.
- The folder check (`python3 -B Brain/tools/mindmake.py boot`) confirms files, not behavior. It leaves no cache files behind. A helper is in use only when the assistant has read it in the current conversation.
- Each helper's review is still pending, by design. It's done once, before you rely on that helper. Behavior was tested on Claude; other AI apps haven't been tested.
- The personal MCP needs Python 3.10 or newer and `mcp>=1.2,<2`.

See the [helper commands](Brain/tools/README.md).
