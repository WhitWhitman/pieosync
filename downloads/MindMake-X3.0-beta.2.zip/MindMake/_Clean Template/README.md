# Clean MindMake template

A clean, empty copy of MindMake, used only by `python3 Brain/tools/mindmake_clone.py clone --name "<name>"`.
Nothing else reads this folder. Don't put your own files here.
