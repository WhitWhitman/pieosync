# MindMake folder map

Start with [MINDMAKE.md](MINDMAKE.md). This folder, **MindMake Brain**, is the shared workspace for MindMake X2.0.

Every included helper, tool and reference has its own Jobs folder. Shared continuity is in [Seeds](Seeds/README.md); each job retains its own pools. [AGENTS.md](AGENTS.md) requires map updates and verification after authorized filesystem changes.

[Jobs index](Jobs/INDEX.md) · [Skills registry](Brain/SKILLS.md) · [Profiles](Brain/Profiles/INDEX.md)

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

## Shared workspace routes

- [AGENTS.md](<AGENTS.md>)
- [Brain](<Brain>)
- [Downloads](<Downloads>)
- [FOLDER_MAP.md](<FOLDER_MAP.md>)
- [GUARD.md](<GUARD.md>)
- [Helpers (PDF)](<Helpers (PDF)>)
- [INTAKE.md](<INTAKE.md>)
- [Jobs](<Jobs>)
- [MEMORY.md](<MEMORY.md>)
- [MINDMAKE.md](<MINDMAKE.md>)
- [MindMake X3.0 Guide.md](<MindMake X3.0 Guide.md>)
- [MindMake X3.0 Guide.pdf](<MindMake X3.0 Guide.pdf>)
- [Plugin](<Plugin>)
- [README.md](<README.md>)
- [Seeds](<Seeds>)
- [TODO.md](<TODO.md>)
- [Toolbox (PDF)](<Toolbox (PDF)>)
- [Wiki](<Wiki>)
- [tests](<tests>)
- [tools](<tools>)

## Jobs

- [MindMake AI Turbo](<Jobs/MindMake AI Turbo/JOB.md>)
- [MindMake Cartographer](<Jobs/MindMake Cartographer/JOB.md>)
- [MindMake DeepSleep](<Jobs/MindMake DeepSleep/JOB.md>)
- [MindMake DreamWeaver](<Jobs/MindMake DreamWeaver/JOB.md>)
- [MindMake Guide](<Jobs/MindMake Guide/JOB.md>)
- [MindMake Heartbeat](<Jobs/MindMake Heartbeat/JOB.md>)
- [MindMake Seed Capsule](<Jobs/MindMake Seed Capsule/JOB.md>)
- [MindMake Seed Protocol](<Jobs/MindMake Seed Protocol/JOB.md>)
- [MindMake SignalGuard](<Jobs/MindMake SignalGuard/JOB.md>)
- [MindMake SkillMaster](<Jobs/MindMake SkillMaster/JOB.md>)
- [MindMake TaskCycle](<Jobs/MindMake TaskCycle/JOB.md>)
- [MindMake ThoughtVault](<Jobs/MindMake ThoughtVault/JOB.md>)
- [PPI Architect](<Jobs/PPI Architect/JOB.md>)
- [PPI Export](<Jobs/PPI Export/JOB.md>)
- [PPI Revise](<Jobs/PPI Revise/JOB.md>)
- [PPI Test](<Jobs/PPI Test/JOB.md>)
- [Personal Assistant](<Jobs/Personal Assistant/JOB.md>)
- [Personal MCP Builder](<Jobs/Personal MCP Builder/JOB.md>)
- [Your AI Companion](<Jobs/Your AI Companion/JOB.md>)

Detailed file metadata: [folder-inventory.json](<Brain/.mindmake/folder-inventory.json>).

Exclusions: root archive/revision directories beginning with _; macOS sidecars, lock files, temporary files, Python caches; Brain/.mindmake/map-history and repair-history; generated inventory, transaction journal, updater lock; all symbolic links (reported separately); personal MCP runtime and session state (documented in Brain/PERSONAL_MCP.md); assistant runtime state (documented in Brain/PERSONAL_ASSISTANT.md); seed rollover manifests (Brain/.mindmake/seed-rollovers); private correction/work records (Brain/.mindmake/corrections and work-records).

<!-- MINDMAKE FOLDER MAP END -->
