#!/usr/bin/env python3
"""Shortcut for Brain/tools/seed_capsule_check.py, the path the Seed Capsule helper names."""
import pathlib, runpy, sys
target = pathlib.Path(__file__).resolve().parent.parent / "Brain" / "tools" / "seed_capsule_check.py"
sys.argv[0] = str(target)
runpy.run_path(str(target), run_name="__main__")
