# Wiki

Reference knowledge is read on demand. Use one subject folder containing SOURCE documents, a short reference seed and its own INDEX.md when adding a topic. Operational helper engines belong in Jobs. Do not manufacture empty topic folders. See [the filing rules](../Brain/FILING.md).

<!-- MINDMAKE FOLDER MAP BEGIN -->

Generation: `folder-map-20261122T004637-01e11709`. Checked: 2026-11-22T00:46:37+00:00. Coverage: scoped.

<!-- MINDMAKE FOLDER MAP END -->
