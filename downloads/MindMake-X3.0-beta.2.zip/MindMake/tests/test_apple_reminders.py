"""Native interaction contract tests; never contacts Apple Reminders."""
import copy
import importlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'Brain/tools'))
import assistant as a
try:
    import apple_reminders as ar
except ImportError:
    ar = None

WHEN = '2030-01-01T12:00:00+00:00'
LATER = '2030-01-02T12:00:00+00:00'
OTHER = '2030-01-03T12:00:00+00:00'
class Fake:
    def __init__(self): self.rows=[]; self.creates=0; self.updates=[]; self.uncertain=None
    def inspect(self, list_name): return {'status':'READY', 'list_name':list_name}
    def ensure_list(self, list_name): return self.inspect(list_name)
    def list_owned(self, list_name, prefix): return copy.deepcopy([r for r in self.rows if r['marker'].startswith(prefix)])
    def create(self, list_name, marker, when, title='MindMake: your next step'):
        self.creates+=1
        r=dict(id='native-'+str(self.creates), marker=marker, completed=False, when=when,title=title)
        if self.uncertain != 'before': self.rows.append(r)
        if self.uncertain: raise TimeoutError('private provider error')
        return copy.deepcopy(r)
    def update(self, list_name, native_id, marker, completed, when, expected_remote):
        self.updates.append(native_id)
        r=next(r for r in self.rows if r['id']==native_id and r['marker']==marker)
        if dict(completed=r['completed'],when=r['when']) != expected_remote: raise ar.NativeConflict()
        if r['completed'] and not completed: raise ar.NativeConflict()
        r.update(completed=completed, when=when)
        return copy.deepcopy(r)

class AppleTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(ar, 'Apple reminder adapter must exist')
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name); (self.root/'Brain/.mindmake').mkdir(parents=True)
        self.cfg=dict(schema_version=1,enabled=True,timezone='UTC',quiet_hours=dict(start='00:00',end='00:00'),max_sms_per_day=2,sms=dict(consented=False),apple_reminders=dict(enabled=True,list_name='MindMake',workspace_id='11111111-1111-4111-8111-111111111111'))
        self.save(); self.native=Fake()
        (self.root/'source.md').write_text('private source')
        a.capture(self.root,'step1','private action text','source.md',due=WHEN)
    def save(self): (self.root/a.CONFIG).write_text(json.dumps(self.cfg))
    def enroll(self): ar.enroll(self.root,'step1',WHEN)
    def sync(self): return ar.sync(self.root,self.native)
    def action(self):
        with a.database(self.root) as db: return dict(db.execute('SELECT * FROM actions WHERE id=?',('step1',)).fetchone())
    def test_requires_explicit_enrollment(self):
        self.sync(); self.assertEqual(self.native.creates,0)
        self.enroll(); self.sync(); self.sync(); self.assertEqual(self.native.creates,1)
    def test_uncertain_create_reconciles_marker(self):
        self.enroll(); self.native.uncertain='after'; self.sync(); self.sync()
        self.assertEqual(self.native.creates,1)
        self.assertEqual(ar.status(self.root)['links'][0]['state'],'linked')
    def test_uncertain_missing_never_retries_even_reenrolled(self):
        self.enroll(); self.native.uncertain='before'; self.sync(); self.enroll(); self.sync()
        self.assertEqual(self.native.creates,1)
        self.assertEqual(ar.status(self.root)['links'][0]['state'],'unknown')
    def test_duplicate_marker_conflicts(self):
        self.enroll(); self.sync(); self.native.rows.append(dict(self.native.rows[0],id='duplicate'))
        self.sync(); self.assertEqual(ar.status(self.root)['links'][0]['state'],'conflict')
        self.assertEqual(self.native.updates,[])
    def test_unrelated_items_never_changed(self):
        self.native.rows.append(dict(id='personal',marker='unrelated',completed=False,when=WHEN))
        self.enroll(); self.sync(); a.change(self.root,'step1','done'); self.sync()
        self.assertEqual(self.native.updates,['native-1']); self.assertFalse(self.native.rows[0]['completed'])
    def test_remote_completion_import(self):
        self.enroll(); self.sync(); self.native.rows[0]['completed']=True; self.sync()
        self.assertEqual(self.action()['status'],'done')
    def test_snooze_both_directions(self):
        self.enroll(); self.sync(); self.native.rows[0]['when']=LATER; self.sync()
        self.assertEqual(self.action()['snoozed_until'],LATER)
        a.change(self.root,'step1','snooze',OTHER); self.sync()
        self.assertEqual(self.native.rows[0]['when'],OTHER)
    def test_pause_prevents_import_and_write(self):
        self.enroll(); self.sync(); self.cfg['enabled']=False; self.save()
        self.native.rows[0]['completed']=True; self.sync(); self.assertEqual(self.action()['status'],'open')
        self.assertEqual(self.native.updates,[])
    def test_divergence_conflicts(self):
        self.enroll(); self.sync(); a.change(self.root,'step1','snooze',LATER)
        self.native.rows[0]['when']=OTHER; self.sync()
        self.assertEqual(ar.status(self.root)['links'][0]['state'],'conflict')
        self.assertEqual(self.action()['snoozed_until'],LATER); self.assertEqual(self.native.updates,[])
    def test_reminder_dates_use_native_whole_second_precision(self):
        enrolled=ar.enroll(self.root,'step1','2030-01-01T12:00:00.123456+00:00')
        self.assertEqual(enrolled['when'],WHEN)
        self.sync(); a.change(self.root,'step1','snooze','2030-01-02T12:00:00.654321+00:00')
        self.sync(); self.assertEqual(self.native.rows[0]['when'],LATER)
    def test_missing_list_setup_is_read_only(self):
        native=ar.NativeReminders()
        with patch.object(native,'_call',return_value={'status':'LIST_MISSING'}) as call:
            self.assertEqual(native.ensure_list()['status'],'LIST_MISSING')
            self.assertEqual(call.call_args.args,('inspect','MindMake'))
    def test_native_creation_passes_arguments_to_single_make_script(self):
        native=ar.NativeReminders(); marker='mindmake:11111111-1111-4111-8111-111111111111:'+('a'*64)
        result=subprocess.CompletedProcess([],0,stdout='native-id\n',stderr='')
        with patch.object(ar.sys,'platform','darwin'), patch.object(ar.subprocess,'run',return_value=result) as run, patch.object(native,'_call',return_value={'id':'native-id'}) as read:
            native.create('MindMake',marker,WHEN,'MindMake: check the proof')
            command=run.call_args.args[0]
            self.assertTrue(command[3].endswith('apple_reminders.applescript'))
            self.assertEqual(command[4:7],['MindMake',marker,'MindMake: check the proof'])
            self.assertEqual(read.call_args.args,('read_one','MindMake'))
            self.assertLessEqual(run.call_args.kwargs['timeout'],25)
    def test_concurrent_local_snooze_is_not_lost_to_phone_done(self):
        self.enroll(); self.sync(); self.native.rows[0]['completed']=True
        original=ar._import_remote
        def import_remote(*args):
            a.change(self.root,'step1','snooze',LATER)
            return original(*args)
        with patch.object(ar,'_import_remote',side_effect=import_remote): self.sync()
        self.assertEqual(self.action()['status'],'open')
        self.assertEqual(self.action()['snoozed_until'],LATER)
        self.assertEqual(ar.status(self.root)['links'][0]['state'],'conflict')
    def test_explicit_title_is_persisted_and_exported(self):
        ar.enroll(self.root,'step1',WHEN,title='MindMake: check the proof')
        self.sync(); self.assertEqual(self.native.rows[0]['title'],'MindMake: check the proof')
        result=subprocess.run([sys.executable,str(Path(ar.__file__)),'--root',str(self.root),'status'],capture_output=True,text=True)
        self.assertEqual(json.loads(result.stdout)['links'][0]['title'],'MindMake: check the proof')
        with self.assertRaises(ValueError): ar.enroll(self.root,'step1',WHEN,title='Different summary')
    def test_title_validation(self):
        for title in ['', 'x'*121, 'line\nnew', 'tab\tnew']:
            with self.assertRaises(ValueError): ar.enroll(self.root,'step1',WHEN,title=title)
    def test_legacy_unverified_source_never_creates(self):
        a.add(self.root,'legacy','old private step','unknown source')
        ar.enroll(self.root,'legacy',WHEN); self.sync()
        self.assertEqual(self.native.creates,0)
        self.assertEqual(ar.status(self.root)['links'][0]['state'],'source_review_required')
    def test_phone_completion_during_native_write_is_not_undone(self):
        self.enroll(); self.sync(); a.change(self.root,'step1','snooze',LATER)
        original=self.native.update
        def update(*args):
            self.native.rows[0]['completed']=True
            return original(*args)
        self.native.update=update; self.sync()
        self.assertTrue(self.native.rows[0]['completed'])
        self.assertEqual(ar.status(self.root)['links'][0]['state'],'conflict')
    def test_quiet_hours_reject_enrollment(self):
        self.cfg['quiet_hours']={'start':'21:00','end':'09:00'}; self.save()
        with self.assertRaisesRegex(ValueError,'quiet hours'):
            ar.enroll(self.root,'step1','2030-01-01T22:00:00+00:00')
    def test_blocked_action_does_not_create_alert(self):
        self.enroll()
        with a.database(self.root) as db,db:
            db.execute("UPDATE actions SET status='blocked' WHERE id='step1'")
        self.sync(); self.assertEqual(self.native.creates,0)
        self.assertEqual(ar.status(self.root)['links'][0]['state'],'blocked')
    def test_overdue_create_waits_out_quiet_hours(self):
        self.enroll(); self.cfg['quiet_hours']={'start':'21:00','end':'09:00'}; self.save()
        with patch.object(a,'utc',return_value=a.stamp('2030-01-01T22:00:00+00:00')):
            self.sync()
        self.assertEqual(self.native.creates,0)
        with patch.object(a,'utc',return_value=a.stamp('2030-01-02T12:00:00+00:00')):
            self.sync()
        self.assertEqual(self.native.creates,1)
    def test_concurrent_sync_does_not_duplicate_create(self):
        self.enroll(); original=self.native.create; nested=[]
        def create(*args):
            nested.append(self.sync()); return original(*args)
        self.native.create=create
        self.sync(); self.assertEqual(nested[0]['status'],'BUSY')
        self.assertEqual(self.native.creates,1)
    def test_source_drift_blocks_creation(self):
        source=self.root/'source.md'; source.write_text('reviewed source')
        a.capture(self.root,'tracked','private task','source.md')
        ar.enroll(self.root,'tracked',WHEN); source.write_text('changed source')
        self.sync(); self.assertEqual(self.native.creates,0)
        self.assertEqual(ar.status(self.root)['links'][0]['state'],'source_review_required')
    def test_native_timeout_and_error_are_bounded_and_sanitized(self):
        with patch.object(ar.sys,'platform','darwin'), patch.object(ar.subprocess,'run',side_effect=TimeoutError('SECRET')) as run:
            with self.assertRaisesRegex(RuntimeError,'Apple Reminders unavailable') as caught:
                ar.NativeReminders().inspect()
            self.assertNotIn('SECRET',str(caught.exception))
            self.assertEqual(run.call_args.kwargs['timeout'],25)
    def test_private_action_content_is_not_sent(self):
        self.enroll(); self.sync()
        payload=json.dumps(self.native.rows)
        self.assertNotIn('private action',payload); self.assertNotIn('private source',payload)
    def test_restart_preserves_enrollment(self):
        self.enroll(); self.sync()
        result=subprocess.run([sys.executable,str(Path(ar.__file__)),'--root',str(self.root),'status'],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(json.loads(result.stdout)['links'][0]['native_id'],'native-1')

if __name__=='__main__': unittest.main()
